export * from "./brandImageList.data";
