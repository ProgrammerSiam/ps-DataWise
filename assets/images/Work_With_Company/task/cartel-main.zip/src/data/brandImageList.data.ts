export const imgList = [
  {
    src: "/assets/img/brand/br1.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br2.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br3.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br4.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br5.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br6.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br7.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br8.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br9.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br10.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br11.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br12.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br13.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br14.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br15.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br16.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br17.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br18.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br19.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br20.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br21.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br22.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br23.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br24.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br25.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br26.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br27.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br28.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br29.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br30.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br31.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br32.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br33.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br34.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br35.png",
    alt: "",
    link: "#",
  },
  {
    src: "/assets/img/brand/br36.png",
    alt: "",
    link: "#",
  },
];
