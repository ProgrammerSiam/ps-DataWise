<?php
namespace ABlocks\Blocks\Icon;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ABlocks\Classes\BlockBaseAbstract;
use ABlocks\Classes\CssGenerator;
use ABlocks\Controls\Dimensions;

class Block extends BlockBaseAbstract {
	protected $block_name = 'icon';

	public function build_css( $attributes ) {
		$css_generator = new CssGenerator( $attributes, $this->block_name );

		// Generate wrapper CSS start
		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-block-container',
			$this->get_wrapper_css( $attributes ),
			$this->get_wrapper_css( $attributes, 'Tablet' ),
			$this->get_wrapper_css( $attributes, 'Mobile' )
		);
		// Generate wrapper CSS end

		$icon_desktop_css = [];
		if ( isset( $attributes['iconSize'] ) ) {
			$icon_desktop_css['font-size'] = $attributes['iconSize'] . 'px';
		}

		$icon_desktop_css = array_merge(
			$icon_desktop_css,
			$this->get_icon_wrapper_css( $attributes )
		);

		$icon_tablet_css = array_merge(
			$this->get_icon_wrapper_css( $attributes, 'Tablet' )
		);

		$icon_mobile_css = array_merge(
			$this->get_icon_wrapper_css( $attributes, 'Mobile' )
		);

		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-block-container .ablocks-icon-wrap',
			$icon_desktop_css,
			$icon_tablet_css,
			$icon_mobile_css
		);

		$icon_svg_desktop_css = array_merge(
			$this->get_icon_css( $attributes )
		);

		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-block-container .ablocks-icon-wrap svg.ablocks-svg-icon',
			$icon_svg_desktop_css,
		);

		return $css_generator->generate_css();
	}

	public function get_wrapper_css( $attributes = [], $device = '' ) {
		$css = [];
		if ( ! empty( $attributes['alignment'][ 'value' . $device ] ) ) {
			$css['justify-content'] = $attributes['alignment'][ 'value' . $device ];
		}
		return $css;
	}

	public function get_icon_wrapper_css( $attributes, $device = '' ) {
		$icon_type = isset( $attributes['iconType'] ) ? $attributes['iconType'] : 'default';
		$icon_shape = isset( $attributes['iconShape'] ) ? $attributes['iconShape'] : '';
		$background_color = isset( $attributes['backgroundColor'] ) ? $attributes['backgroundColor'] : '';
		$primary_color = isset( $attributes['primaryColor'] ) ? $attributes['primaryColor'] : '#69727d';

		$icon_view_css = [];

		if ( 'default' !== $icon_type
			&& ( 'stacked' === $icon_type || 'framed' === $icon_type )
			&& ( 'circle' === $icon_shape || 'square' === $icon_shape )
		) {
			$icon_view_css = [
				'background' => '' !== $background_color ? $background_color : ( 'stacked' === $icon_type ? '#ddd' : 'transparent' ),
				'padding' => '.5em',
			];
			if ( 'framed' === $icon_type ) {
				$icon_view_css['border'] = '2px solid ' . ( '' !== $primary_color ? $primary_color : '#69727d' );
			}
			if ( 'circle' === $icon_shape ) {
				$icon_view_css['border-radius'] = '50px';
			}
		}

		return array_merge(
			[
				'background' => $background_color,
			],
			$icon_view_css,
			Dimensions::get_css( isset( $attributes['padding'] ) ? $attributes['padding'] : '', 'padding', $device ),
			Dimensions::get_css( isset( $attributes['borderRadius'] ) ? $attributes['borderRadius'] : '', 'border-radius', $device ),
			Dimensions::get_css( isset( $attributes['borderWidth'] ) ? $attributes['borderWidth'] : '', 'border-width', $device )
		);
	}

	public function get_icon_css( $attributes ) {
		$icon_type = isset( $attributes['iconType'] ) ? $attributes['iconType'] : 'default';
		$icon_shape = isset( $attributes['iconShape'] ) ? $attributes['iconShape'] : '';
		$primary_color = isset( $attributes['primaryColor'] ) ? $attributes['primaryColor'] : '#69727d';

		$icon_view_css = [];

		if ( 'default' !== $icon_type
			&& ( 'stacked' === $icon_type || 'framed' === $icon_type )
			&& ( 'circle' === $icon_shape || 'square' === $icon_shape )
		) {
			$icon_view_css = [
				'fill' => '' !== $primary_color ? $primary_color : ( 'stacked' === $icon_type ? '#000000' : '#69727d' ),
			];
		}

		if ( isset( $attributes['rotate'] ) ) {
			$icon_view_css['transform'] = 'rotate(' . $attributes['rotate'] . 'deg)';
		}

		return array_merge(
			[
				'fill' => '' !== $primary_color ? $primary_color : '#69727d',
			],
			$icon_view_css,
		);
	}



}
