<?php

namespace ABlocks\Blocks\Divider;

use ABlocks\Classes\BlockBaseAbstract;
use ABlocks\Classes\CssGenerator;
use ABlocks\Controls\Alignment;
use ABlocks\Controls\TextStroke;
use ABlocks\Controls\Typography;

class Block extends BlockBaseAbstract {

	protected $block_name = 'divider';

	public function build_css( $attributes ) {
		$css_generator = new CssGenerator( $attributes, $this->block_name );
		$css_generator->add_class_styles(
			'{{WRAPPER}}',
			$this->get_wrapper_css( $attributes ),
			$this->get_wrapper_css( $attributes, 'Tablet' ),
			$this->get_wrapper_css( $attributes, 'Mobile' ),
		);

		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-block-container',
			$this->get_divider_container_css( $attributes ),
			$this->get_divider_container_css( $attributes, 'Tablet' ),
			$this->get_divider_container_css( $attributes, 'Mobile' ),
		);

		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-divider',
			$this->get_divider_css( $attributes ),
			$this->get_divider_css( $attributes, 'Tablet' ),
			$this->get_divider_css( $attributes, 'Mobile' ),
		);
		// element text
		
		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-divider__element-text',
			$this->get_divider_element_text_css($attributes),
			$this->get_divider_element_text_css( $attributes, 'Tablet' ),
			$this->get_divider_element_text_css( $attributes, 'Mobile' ),
		);
		// element icon wrapper
		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-divider__element-icon',
			$this->get_divider_element_icon_wrapper_css( $attributes ),
			$this->get_divider_element_icon_wrapper_css( $attributes, 'Tablet' ),
			$this->get_divider_element_icon_wrapper_css( $attributes, 'Mobile' ),
		);
		// element icon
	
		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-divider__element-icon svg.ablocks-svg-icon',
			$this->get_divider_element_icon_css($attributes),
			$this->get_divider_element_icon_css( $attributes, 'Tablet' ),
			$this->get_divider_element_icon_css( $attributes, 'Mobile' ),
		);

		return $css_generator->generate_css();
	}

	public function get_wrapper_css( $attributes, $device = '' ) {
		if ( isset( $attributes['alignment'] ) ) {
			return Alignment::get_css( $attributes['alignment'], 'text-align', $device );
		}
		return [];
	}

	public function get_divider_element_text_css( $attributes, $device = '' ) {
		$divider_text_styles=[];
		if ( ! empty( $attributes['elementTextColor'] ) ) {
			$divider_text_styles['color'] = $attributes['elementTextColor'];
		}
	    $spacing_value = isset($attributes['elementTextSpacing']['value' . $device]) ? $attributes['elementTextSpacing']['value' . $device] : '';
		$spacing_unit = ! empty( $attributes['elementTextSpacing']['valueUnit'] ) ? $attributes['elementTextSpacing']['valueUnit'] : 'px';
		$divider_text_styles['padding-left'] = $spacing_value . $spacing_unit;
		$divider_text_styles['padding-right'] = $spacing_value . $spacing_unit;
		return array_merge(
			$divider_text_styles,
			isset( $attributes['elementTextTypography'] ) ? Typography::get_css( $attributes['elementTextTypography'], $device ) : [],
			isset( $attributes['elementTextStroke'] ) ? TextStroke::get_css( $attributes['elementTextStroke'], $device ) : [],
		);
	}

	public function get_divider_element_icon_wrapper_css( $attributes, $device = '' ) {
		$iconType = isset( $attributes['elementIconType'] ) ? $attributes['elementIconType'] : '';
		$primaryColor = isset( $attributes['elementIconPrimaryColor'] ) ? $attributes['elementIconPrimaryColor'] : '';
		$backgroundColor = isset( $attributes['elementIconBackgroundColor'] ) ? $attributes['elementIconBackgroundColor'] : '';
	
		$icon_view_css = [];
		if ( 'default' !== $iconType ) {
			if ( 'stacked' === $iconType ) {
				$icon_view_css = [
					'background' => $backgroundColor ?? '#ddd',
					'padding' => '.5em',
				];
			} elseif ( 'framed' === $iconType ) {
				$icon_view_css = [
					'background' => $backgroundColor ?? 'transparent',
					'padding' => '.5em',
					'border' => '2px solid ' . ( $primaryColor ?? '#69727d' ),
				];
			}
		}
	
		$spacing_value = isset($attributes['elementIconSpacing']['value' . $device]) ? $attributes['elementIconSpacing']['value' . $device] : '';
		$spacing_unit = ! empty( $attributes['elementIconSpacing']['valueUnit'] ) ? $attributes['elementIconSpacing']['valueUnit'] : 'px';
		$icon_view_css['margin-left'] = $spacing_value . $spacing_unit;
		$icon_view_css['margin-right'] = $spacing_value . $spacing_unit;
	
		$css = array_merge(
			[
				'background' => $backgroundColor,
			],
			$icon_view_css
		);
		return $css;
	}
	

	public function get_divider_element_icon_css( $attributes, $device = '' ) {
		$primaryColor = isset( $attributes['elementIconPrimaryColor'] ) ? $attributes['elementIconPrimaryColor'] : '';
		$icon_view_css = [];
		$icon_size=isset($attributes['elementIconSize']['value' . $device]) ? $attributes['elementIconSize']['value' . $device] : '';
		$icon_rotate=isset($attributes['elementIconRotate']['value' . $device]) ? $attributes['elementIconRotate']['value' . $device] : '';
        if($icon_size){
			$icon_view_css['font-size']=$icon_size . 'px' . '!important';
		}
        if($icon_rotate){
			$icon_view_css['rotate']=$icon_rotate . 'deg';
		}
		if ( isset( $attributes['elementIconType'] ) ) {
			$iconType = $attributes['elementIconType'];
			if ( 'default' !== $iconType ) {
				if ( 'stacked' === $iconType ) {
					$icon_view_css = [
						'fill' => $primaryColor ?? '#000000',
						'font-size'=>$icon_size . 'px' . '!important',
						'rotate'=>$icon_rotate . 'deg',
					];
				} elseif ( 'framed' === $iconType ) {
					$icon_view_css = [
						'fill' => $primaryColor ?? '#69727d',
						'font-size'=>$icon_size . 'px' . '!important',
						'rotate'=>$icon_rotate . 'deg',
					];
				}
			}
		}

		$css = array_merge(
			[
				'fill' => $primaryColor ?? '#69727d',
			],
			$icon_view_css
		);
		return $css;
	}

	public function get_divider_container_css( $attributes, $device = '' ) {
		$divider_container_css = [];
		if ( ! empty( $attributes['gap'][ 'value' . $device ] ) ) {
			$divider_container_css['padding-block-start'] = $attributes['gap'][ 'value' . $device ] . 'px';
			$divider_container_css['padding-block-end'] = $attributes['gap'][ 'value' . $device ] . 'px';
		}
		if ( ! empty( $attributes['alignment'][ 'value' . $device ] ) ) {
			$divider_container_css['justify-content'] = $attributes['alignment'][ 'value' . $device ];
		}
		return $divider_container_css;
	}

	public function get_divider_css( $attributes, $device = '' ) {
		$divider_css = [];
		$width = isset( $attributes['width'] ) ? $attributes['width'] : array();
		$key = 'value' . $device;
		if ( ! empty( $width[ $key ] ) ) {
			$value_unit = isset( $width['valueUnit'] ) ? $width['valueUnit'] : 'px';
			$divider_css['width'] = $width[ $key ] . $value_unit;
		}
		return $divider_css;
	}
}
