<?php
namespace ABlocks\Blocks\lists;

use ABlocks\Classes\BlockBaseAbstract;
use ABlocks\Classes\CssGenerator;
use ABlocks\Controls\Alignment;
use ABlocks\Controls\Dimensions;
use ABlocks\Controls\Typography;
use ABlocks\Controls\Width;
use ABlocks\Controls\Border;

class Block extends BlockBaseAbstract {
	protected $block_name = 'lists';

	public function build_css( $attributes ) {
		// Generate CSS
		$css_generator = new CssGenerator( $attributes );
		// Wrapper CSS
		$css_generator->add_class_styles(
			'{{WRAPPER}}',
			$this->get_wrapper_css( $attributes, '' ),
			$this->get_wrapper_css( $attributes, 'Tablet' ),
			$this->get_wrapper_css( $attributes, 'Mobile' ),
		);
		// List CSS
		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-list',
			$this->get_list_css( $attributes, '' ),
			$this->get_list_css( $attributes, 'Tablet' ),
			$this->get_list_css( $attributes, 'Mobile' ),
		);
		// List Wrapper CSS
		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-list__item-content',
			$this->get_list_wrapper_css( $attributes, '' ),
			$this->get_list_wrapper_css( $attributes, 'Tablet' ),
			$this->get_list_wrapper_css( $attributes, 'Mobile' ),
		);
		// Marker CSS
		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-list__item-content .ablocks-list__item-marker',
			$this->get_marker_css( $attributes, '' ),
			$this->get_marker_css( $attributes, 'Tablet' ),
			$this->get_marker_css( $attributes, 'Mobile' ),
		);
		// Icon CSS
		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-list__item-content .ablocks-svg-icon',
			$this->get_icon_css( $attributes, '' ),
			$this->get_icon_css( $attributes, 'Tablet' ),
			$this->get_icon_css( $attributes, 'Mobile' ),
		);
		// Icon hover css
		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-list__item-content .ablocks-svg-icon:hover',
			$this->get_icon_hover_css( $attributes, '' ),
			$this->get_icon_hover_css( $attributes, 'Tablet' ),
			$this->get_icon_hover_css( $attributes, 'Mobile' ),
		);

		// List text CSS
		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-list__item-content .ablocks-list__item-text',
			$this->get_list_text_css( $attributes ),
			$this->get_list_text_css( $attributes, 'Tablet' ),
			$this->get_list_text_css( $attributes, 'Mobile' ),
		);

		return $css_generator->generate_css();
	}

	public function get_wrapper_css( $attributes, $device = '' ) {
		return array_merge(
			isset( $attributes['alignment'] ) ? Alignment::get_css( $attributes['alignment'], 'text-align', $device ) : [],
			isset( $attributes['typography'] ) ? Typography::get_css( $attributes['typography'], $device ) : [],
		);
	}

	public function get_list_css( $attributes, $device = '' ) {
		$css = [];
		$stack = isset( $attributes['stack'] ) ? $attributes['stack'] : '';

		if ( isset( $attributes['spaceBetween'][ 'value' . $device ] ) && ! empty( $attributes['spaceBetween'][ 'value' . $device ] ) ) {
			$css['gap'] = $attributes['spaceBetween'][ 'value' . $device ] . 'px';
		}

		if ( $stack === 'vertical' ) {
			if ( ! empty( $attributes['verticalAlignment'] ) ) {
					$css['align-items'] = $attributes['verticalAlignment'];
			}
		}

		if ( $stack === 'horizontal' ) {
			$css['flex-direction'] = 'row';
			if ( ! empty( $attributes['horizontalAlignment'] ) ) {
				$css['justify-content'] = $attributes['horizontalAlignment'];
			}
		}

		return array_merge(
			$css,
			isset( $attributes['width'] ) ? Width::get_css( $attributes['width'], 'width', $device ) : [],
		);
	}

	public function get_list_wrapper_css( $attributes, $device = '' ) {
		$css = [];
		if ( isset( $attributes['markerType'] ) && $attributes['markerType'] === 'icon' ) {
			if ( ! empty( $attributes['position'][ 'value' . $device ] ) ) {
				$css['align-items'] = $attributes['position'][ 'value' . $device ];
			}
		}
		if ( isset( $attributes['textIndent'][ 'value' . $device ] ) && ! empty( $attributes['textIndent'][ 'value' . $device ] ) ) {
			$css['gap'] = $attributes['textIndent'][ 'value' . $device ] . 'px';
		}
		return $css;
	}

	public function get_marker_css( $attributes, $device = '' ) {
		$css = [];

		if ( isset( $attributes['markerColor'] ) && ! empty( $attributes['markerColor'] ) ) {
			$css['background'] = $attributes['markerColor'];
		}

		if ( isset( $attributes['markerSize'][ 'value' . $device ] ) && ! empty( $attributes['markerSize'][ 'value' . $device ] ) ) {
			$size = $attributes['markerSize'][ 'value' . $device ] . 'px';
			$css['max-width'] = $size;
			$css['max-height'] = $size;
			$css['min-width'] = $size;
			$css['min-height'] = $size;
		}

		return $css;
	}

	public function get_icon_css( $attributes, $device = '' ) {
		$css = [];

		if ( isset( $attributes['markerType'] ) && $attributes['markerType'] === 'icon' ) {
			if ( $attributes['iconType'] === 'stacked' ) {
				$css['background'] = $attributes['iconBackgroundColor'] ?: '#ddd';
				$css['padding'] = '.2em';
				$css['color'] = $attributes['iconColor'] ?: '#000000';

				if ( $attributes['iconShape'] === 'circle' ) {
					$css['border-radius'] = '50px';
				}
			} elseif ( $attributes['iconType'] === 'framed' ) {
				$css['background'] = $attributes['iconBackgroundColor'] ?: 'transparent';
				$css['padding'] = '.2em';
				$css['color'] = $attributes['iconColor'] ?: '#69727d';
				$css['border'] = '2px solid' . $attributes['iconColor'] ?: '#69727d';

				if ( $attributes['iconShape'] === 'circle' ) {
					$css['border-radius'] = '50px';
				}
			}

			if ( ! empty( $attributes['iconSize'][ 'value' . $device ] ) && isset( $attributes['iconSize'][ 'value' . $device ] ) ) {
				$css['width'] = $attributes['iconSize'][ 'value' . $device ] . $attributes['iconSize'][ 'valueUnit' . $device ];
			}
			if ( ! empty( $attributes[ 'iconColor' . $device ] ) && isset( $attributes[ 'iconColor' . $device ] ) ) {
				$css['color'] = $attributes['iconColor'];
				$css['fill'] = $attributes['iconColor'];
			}
			if ( $attributes['iconBackground'] ) {
				if ( ! empty( $attributes['iconBackgroundColor'] ) ) {
					$css['background'] = $attributes['iconBackgroundColor'];
				}
			}
		}//end if

		return array_merge(
			$css,
			isset( $attributes['border'] ) ? Border::get_css( $attributes['border'], $device ) : [],
			isset( $attributes['padding'] ) ? Dimensions::get_css( $attributes['padding'], 'padding', $device ) : [],
		);
	}

	public function get_icon_hover_css( $attributes, $device = '' ) {
		return array_merge(
			isset( $attributes['border'] ) ? Border::get_hover_css( $attributes['border'], $device ) : [],
		);
	}

	public function get_list_text_css( $attributes, $device = '' ) {
		$css = [];
		if ( isset( $attributes['textColor'] ) ) {
				$css['color'] = $attributes['textColor'];
		}

		return array_merge(
			$css,
		);
	}
}
