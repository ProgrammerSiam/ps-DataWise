<?php
namespace ABlocks\Blocks\Counter;

use ABlocks\Classes\BlockBaseAbstract;
use ABlocks\Classes\CssGenerator;
use ABlocks\Controls\Alignment;
use ABlocks\Controls\Typography;

class Block extends BlockBaseAbstract {
	protected $block_name = 'counter';

	public function build_css( $attributes ) {
		$css_generator = new CssGenerator( $attributes, $this->block_name );
		// wrapper css
		$css_generator->add_class_styles(
			'{{WRAPPER}}',
			$this->get_wrapper_css( $attributes ),
			$this->get_wrapper_css( $attributes, 'Tablet' ),
			$this->get_wrapper_css( $attributes, 'Mobile' ),
		);
		// number text css
		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-counter__content',
			$this->get_number_text_css( $attributes ),
			$this->get_number_text_css( $attributes, 'Tablet' ),
			$this->get_number_text_css( $attributes, 'Mobile' ),
		);
		// heading text css
		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-counter__text',
			$this->get_heading_text_css( $attributes ),
			$this->get_heading_text_css( $attributes, 'Tablet' ),
			$this->get_heading_text_css( $attributes, 'Mobile' ),
		);
		// counter bar css
		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-counter--bar .ablocks-counter__content',
			$this->get_counter_bar_css( $attributes ),
		);
		// counter circle css
		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-counter--bar .ablocks-bar-counter__background',
			$this->get_counter_bar_bg_css( $attributes )
		);

		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-counter--bar .ablocks-bar-counter__progress',
			$this->get_counter_bar_progress_css( $attributes )
		);

		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-counter--circle .ablocks-circle-counter__background',
			$this->get_counter_circle_bg_css( $attributes )
		);

		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-counter--circle .ablocks-circle-counter__progress',
			$this->get_counter_circle_progress_css( $attributes )
		);

		$icon_wrapper_desktop_css = $this->get_icon_wrapper_css( $attributes ) ?? '';
		if ( isset( $attributes['iconSize'] ) ) {
			$icon_wrapper_desktop_css['font-size'] = $attributes['iconSize'] . 'px';
		}
		// icon wrapper css
		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-counter__icon',
			$icon_wrapper_desktop_css,
			$this->get_icon_wrapper_css( $attributes, 'Tablet' ),
			$this->get_icon_wrapper_css( $attributes, 'Mobile' ),
		);
		// icon css
		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-counter__icon svg.ablocks-svg-icon',
			$this->get_icon_css( $attributes ),
		);

		return $css_generator->generate_css();
	}

	public function get_wrapper_css( $attributes, $device = '' ) {
		$alignment = ! empty( $attributes['alignment'] ) ? $attributes['alignment'] : '';
		return Alignment::get_css( $alignment, 'text-align', $device );
	}

	public function get_number_text_css( $attributes, $device = '' ) {
		$css = [];
		$number_color = ! empty( $attributes['numberColor'] ) ? $attributes['numberColor'] : '';
		if ( $number_color ) {
			$css['color'] = $attributes['numberColor'];
		}
		if ( isset( $attributes['mediaPosition'] ) && $attributes['mediaPosition'] === 'leftOfNumber' || isset( $attributes['mediaPosition'] ) && $attributes['mediaPosition'] === 'rightOfNumber' || isset( $attributes['layout'] ) && $attributes['layout'] === 'bar' ) {
			$css['display'] = 'inline-flex';
			$css['align-items'] = 'center';
			$css['justify-content'] = 'center';
		} else {
			$css['display'] = 'initial';
		}
		return array_merge(
			isset( $attributes['numberTypography'] ) ? Typography::get_css( $attributes['numberTypography'], $device ) : [],
			$css
		);
	}

	public function get_heading_text_css( $attributes, $device = '' ) {
		$css = [];
		$heading_color = ! empty( $attributes['headingColor'] ) ? $attributes['headingColor'] : '';
		if ( $heading_color ) {
			$css['color'] = $attributes['headingColor'];
		}
		return array_merge(
			Typography::get_css( ! empty( $attributes['headingTypography'] ) ? $attributes['headingTypography'] : '', $device ),
			$css
		);
	}

	public function get_counter_bar_css( $attributes, $device = '' ) {
		$css = [];
		$bar_size = ! empty( $attributes['barSize'] ) ? $attributes['barSize'] : '';
		if ( $bar_size ) {
			$css['height'] = $attributes['barSize'] . 'px';
		}
		return $css;
	}

	public function get_counter_bar_bg_css( $attributes ) {
		$counter_bar_bg_css = [];

		if ( ! empty( $attributes['barBackgroundColor'] ) ) {
			$counter_bar_bg_css['background'] = $attributes['barBackgroundColor'];
		}

		return $counter_bar_bg_css;
	}

	public function get_counter_bar_progress_css( $attributes ) {
		$counter_bar_progress_css = [];

		if ( ! empty( $attributes['barProgressColor'] ) ) {
			$counter_bar_progress_css['background'] = $attributes['barProgressColor'];
		}

		return $counter_bar_progress_css;
	}

	public function get_counter_circle_bg_css( $attributes ) {
		$counter_circle_bg_css = [];

		if ( ! empty( $attributes['circleBackgroundColor'] ) ) {
			$counter_circle_bg_css['stroke'] = $attributes['circleBackgroundColor'];
		}

		if ( ! empty( $attributes['circleStrokeSize'] ) ) {
			$counter_circle_bg_css['stroke-width'] = $attributes['circleStrokeSize'];
		}

		return $counter_circle_bg_css;
	}

	public function get_counter_circle_progress_css( $attributes ) {
		$counter_circle_progress_css = [];

		if ( ! empty( $attributes['circleProgressColor'] ) ) {
			$counter_circle_progress_css['stroke'] = $attributes['circleProgressColor'];
		}

		if ( ! empty( $attributes['circleStrokeSize'] ) ) {
			$counter_circle_progress_css['stroke-width'] = $attributes['circleStrokeSize'];
		}

		return $counter_circle_progress_css;
	}


	public function get_icon_wrapper_css( $attributes, $device = '' ) {
		$icon_background_color = $attributes['iconBackgroundColor'] ?? '';
		$icon_primary_color = $attributes['iconPrimaryColor'] ?? '#69727d';
		$icon_type = $attributes['iconType'] ?? 'default';
		$icon_shape = $attributes['iconShape'] ?? '';
		$icon_view_css = [];
		if ( $icon_type !== 'default' ) {
			if ( $icon_type === 'stacked' ) {
				if ( $icon_shape === 'circle' ) {
					$icon_view_css = [
						'background' => $icon_background_color ?? '#ddd',
						'border-radius' => '50px',
						'padding' => '.5em',
					];
				} elseif ( $icon_shape === 'square' ) {
					$icon_view_css = [
						'background' => $icon_background_color ?? '#ddd',
						'padding' => '.5em',
					];
				}
			} elseif ( $icon_type === 'framed' ) {
				if ( $icon_shape === 'circle' ) {
					$icon_view_css = [
						'background' => $icon_background_color ?? 'transparent',
						'padding' => '.5em',
						'border-radius' => '50px',
						'border' => '2px solid ' . $icon_primary_color,
					];
				} elseif ( $icon_shape === 'square' ) {
					$icon_view_css = [
						'background' => $icon_background_color ?? 'transparent',
						'padding' => '.5em',
						'border' => '2px solid ' . $icon_primary_color
					];
				}
			}//end if
		}//end if
		return array_merge(
			[
				'display' => 'flex'
			],
			$icon_view_css
		);
	}

	public function get_icon_css( $attributes ) {
		$icon_type = $attributes['iconType'] ?? 'default';
		$icon_shape = $attributes['iconShape'] ?? '';
		$icon_primary_color = $attributes['iconPrimaryColor'] ?? '';
		$icon_rotate = $attributes['iconRotate'] ?? '';
		$icon_view_css = [];

		if ( $icon_type !== 'default' ) {
			if ( $icon_type === 'stacked' ) {
				if ( $icon_shape === 'circle' || $icon_shape === 'square' ) {
					$icon_view_css = [
						'fill' => $icon_primary_color ?? '#000000'
					];
				}
			} elseif ( $icon_shape === 'framed' ) {
				if ( $icon_shape === 'circle' || $icon_shape === 'square' ) {
					$icon_view_css  = [
						'fill' => $icon_primary_color ?? '#69727d',
					];
				}
			}
		}
		if ( $icon_rotate ) {
			$icon_view_css['transform'] = 'rotate(' . $attributes['iconRotate'] . 'deg)';
		}

		return array_merge(
			[
				'fill' => $icon_primary_color ?? '#69727d'
			],
			$icon_view_css
		);
	}


}
