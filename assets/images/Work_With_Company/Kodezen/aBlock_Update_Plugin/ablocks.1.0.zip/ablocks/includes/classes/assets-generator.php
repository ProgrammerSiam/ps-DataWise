<?php
namespace ABlocks\Classes;

use ABlocks\Classes\FileUpload;
use ABlocks\Classes\RegisterScripts;

class AssetsGenerator {
    public static function write_frontend_css_in_uploads_folder( $post_id ) {
		global $post;
		$post_type = get_post_type( $post_id );
		$parse_blocks_content = '';
		if ( empty( $post->post_content ) || $post_type === 'wp_template_part' || $post_type === 'wp_template' ) {
			$post           = get_post( $post_id );
			$parse_blocks_content = parse_blocks( $post->post_content );
		} else {
			$parse_blocks_content = parse_blocks( $post->post_content );
		}

		$aBlocks = [];
		self::recursive_block_parser( $parse_blocks_content, $aBlocks );
		$register_styles = RegisterScripts::get_register_styles();
		$register_scripts = RegisterScripts::get_register_scripts();
		$library_css = '';
		$static_css = '';
		$dynamic_css = '';
		$scripts = '';
		foreach ( $aBlocks as $aBlock ) {
			if ( isset( $aBlock['static_style'] ) ) {
				// css
				$style_depends = $aBlock['style_depends'];
				foreach($style_depends as $style_depend){
					$library_css .= file_get_contents($register_styles[$style_depend]['path']) . ' ';
				}
				// js
				$script_depends = $aBlock['script_depends'];
				foreach($script_depends as $script_depend){
					$scripts .= file_get_contents($register_scripts[$script_depend]['path']) . ' ';
				}
				$static_css .= self::minify_css( $aBlock['static_style'] ) . ' ';
			} elseif ( isset( $aBlock['dynamic_style'] ) ) {
				$dynamic_css .= $aBlock['dynamic_style'] . ' ';
			}
		}
		$FileUpload = new FileUpload();
		$FileUpload->create_file( $post_id . '.min.css', $library_css . $static_css . $dynamic_css );
		$FileUpload->create_file( $post_id . '.min.js', $scripts );
		return $aBlocks;
	}

	public static function recursive_block_parser( $parse_content, &$aBlocks ) {
		if ( count( $parse_content ) > 0 ) {
			foreach ( $parse_content as $item ) {
				if ( ! empty( $item['blockName'] ) ) {
					if ( strpos( $item['blockName'], 'ablocks' ) !== false ) {

						$block_name_class = str_replace(' ', '', ucwords(str_replace('-', ' ', explode('/', $item['blockName'])[1])));
						$dynamic_class = '\\ABlocks\\Blocks\\' . $block_name_class . '\\Block';
						if ( class_exists( $dynamic_class ) ) {
							$instance = new $dynamic_class( true );
							$attributes = wp_parse_args($item['attrs'], array_map(function( $item ) {
								if(!isset($item['default'])){
									return '';
								}
								return $item['default'];
							}, $instance->get_attributes()));
							// keep static css
							if ( ! isset( $aBlocks[ $item['blockName'] ] ) ) {
								$aBlocks[ $item['blockName'] ] = [
									'static_style' => $instance->get_static_css(),
									'style_depends' => $instance->get_style_depends(),
									'script_depends' => $instance->get_script_depends(),
								];
							}
							// keep dynamic css
							$aBlocks[ $item['attrs']['block_id'] ] = [
								'block_name' => $item['blockName'],
								'dynamic_style' => $instance->build_css( $attributes )
							];
						}
					}//end if
					if ( is_array( $item['innerBlocks'] ) && count( $item['innerBlocks'] ) ) {
						self::recursive_block_parser( $item['innerBlocks'], $aBlocks );
					}
				}//end if
			}//end foreach
		}//end if
		return $aBlocks;
	}

    public static function minify_css( $css_string ) {
		// Remove comments (/* ... */) using regex
		$css_string = preg_replace( '/\/\*[\s\S]*?\*\//', '', $css_string );

		// Remove double spaces, tabs, and newlines
		$css_string = preg_replace( '/\s+/', ' ', $css_string );

		// Remove spaces around colons, semicolons, curly braces, and commas
		$css_string = preg_replace( '/\s?([:,;{}])\s?/', '$1', $css_string );

		return $css_string;
	}


}