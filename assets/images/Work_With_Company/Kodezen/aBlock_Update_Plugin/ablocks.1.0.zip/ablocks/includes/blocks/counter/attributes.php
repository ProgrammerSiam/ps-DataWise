<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ABlocks\Controls\Alignment;
use ABlocks\Controls\TextShadow;
use ABlocks\Controls\Typography;
use ABlocks\Controls\Range;

$attributes = [
	'block_id' => [
		'type' => 'string',
		'default' => '',
	],
	'isShowIcon' => [
		'type' => 'bool',
		'default' => true,
	],
	'layout' => [
		'type' => 'string',
		'default' => 'number',
	],
	'mediaPosition' => [
		'type' => 'string',
		'default' => 'top',
	],
	'startNumber' => [
		'type' => 'number',
		'default' => 0,
	],
	'endNumber' => [
		'type' => 'number',
		'default' => 80,
	],
	'totalNumber' => [
		'type' => 'number',
		'default' => 100,
	],
	'decimalPlaces' => [
		'type' => 'number',
		'default' => 0,
	],
	'duration' => [
		'type' => 'number',
		'default' => 1000,
	],
	'animationRepeat' => [
		'type' => 'bool',
		'default' => false,
	],
	'counterPrefix' => [
		'type' => 'string',
		'default' => '',
	],
	'counterSuffix' => [
		'type' => 'string',
		'default' => '%',
	],
	'separator' => [
		'type' => 'string',
		'default' => ',',
	],
	'counterTitle' => [
		'type' => 'string',
		'default' => 'Enter your title',
	],
	'numberColor' => [
		'type' => 'string',
		'default' => '',
	],
	'headlineColor' => [
		'type' => 'string',
		'default' => '#4B4F58',
	],
	'circleProgressColor' => [
		'type' => 'string',
		'default' => 'black',
	],
	'circleBackgroundColor' => [
		'type' => 'string',
		'default' => '#dadada',
	],
	'circleSize' => [
		'type' => 'number',
		'default' => 220,
	],
	'circleStrokeSize' => [
		'type' => 'number',
		'default' => 20,
	],
	'barProgressColor' => [
		'type' => 'string',
		'default' => 'black',
	],
	'barBackgroundColor' => [
		'type' => 'string',
		'default' => '#dadada',
	],
	'barSize' => [
		'type' => 'number',
		'default' => 30,
	],
	'iconType' => [
		'type' => 'string',
		'default' => 'default',
	],
	'iconShape' => [
		'type' => 'string',
		'default' => 'circle',
	],
	'iconSize' => [
		'type' => 'number',
		'default' => 30,
	],
	'iconRotate' => [
		'type' => 'number',
		'default' => 0,
	],
	'iconPrimaryColor' => [
		'type' => 'string',
		'default' => 'black',
	],
	'iconBackgroundColor' => [
		'type' => 'string',
		'default' => '',
	],
];
$attributes = array_merge(
	Alignment::get_attribute( 'alignment', true, [ 'value' => 'center' ] ),
	Typography::get_attribute( 'numberTypography', true ),
	Typography::get_attribute( 'headlineTypography', true ),
	Range::get_attribute( [
		'attributeName' => 'duration',
		'isResponsive' => false,
		'defaultValue' => 1000,
	] ),
	Range::get_attribute( [
		'attributeName' => 'decimalPlaces',
		'isResponsive' => false,
		'defaultValue' => 0,
	] ),
	Range::get_attribute( [
		'attributeName' => 'circleSize',
		'isResponsive' => false,
		'defaultValue' => 220,
	] ),
	Range::get_attribute( [
		'attributeName' => 'circleStrokeSize',
		'isResponsive' => false,
		'defaultValue' => 20,
	]),
	Range::get_attribute( [
		'attributeName' => 'barSize',
		'isResponsive' => false,
		'defaultValue' => 30,
	]),
	Range::get_attribute( [
		'attributeName' => 'iconSize',
		'isResponsive' => false,
		'defaultValue' => 30,
	]),
	Range::get_attribute( [
		'attributeName' => 'iconRotate',
		'isResponsive' => false,
		'defaultValue' => 0,
	]),
	$attributes
);
return $attributes;
