<?php
namespace ABlocks\Classes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class RegisterScripts { 
    public static function get_register_styles(){
        return [
            'ablocks-animate-style' => [
                'path'  => ABLOCKS_ASSETS_PATH . 'library/animate/animate.min.css',
                'url'   => ABLOCKS_ASSETS_URL . 'library/animate/animate.min.css',
                'deps'  => array(),
                'ver'   => false,
                'media' => 'all'
            ],
            'ablocks-common-style' => [
                'path'  => ABLOCKS_ASSETS_PATH . 'build/blocks-common.css',
                'url'   => ABLOCKS_ASSETS_URL . 'build/blocks-common.css',
                'deps'  => array(),
                'ver'   => false,
                'media' => 'all'
            ],
        ];
    }
    public static function get_register_scripts(){
        return [
            'ablocks-common-script' => [
                'path'          => ABLOCKS_ASSETS_PATH . 'build/blocks-common.js',
                'url'           => ABLOCKS_ASSETS_URL . 'build/blocks-common.js',
                'deps'          => array(),
                'ver'           => false,
                'args'          => true,
                'dependencies'  => ABLOCKS_ASSETS_PATH . 'build/blocks-common.asset.php'
            ],
        ];
    }
}