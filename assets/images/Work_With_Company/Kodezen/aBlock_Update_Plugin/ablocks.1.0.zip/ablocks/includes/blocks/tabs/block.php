<?php

namespace ABlocks\Blocks\Tabs;

use ABlocks\Classes\BlockBaseAbstract;
use ABlocks\Classes\CssGenerator;
use ABlocks\Controls\Typography;
use ABlocks\Controls\Dimensions;
use ABlocks\Controls\Border;

class Block extends BlockBaseAbstract {

    protected $block_name = 'tabs';

    public function build_css($attributes) {
        $css_generator = new CssGenerator($attributes, $this->block_name);

        $css_generator->add_class_styles(
            '{{WRAPPER}} .ablocks-block-tabs',
            $this->get_tabs_css($attributes),
            $this->get_tabs_css($attributes, 'Tablet'),
            $this->get_tabs_css($attributes, 'Mobile')
        );

        $css_generator->add_class_styles(
            '{{WRAPPER}} .ablocks-block-tabs .ablocks-block-tabs__tab-panel',
            $this->get_tabs_panel_css($attributes),
            $this->get_tabs_panel_css($attributes, 'Tablet'),
            $this->get_tabs_panel_css($attributes, 'Mobile')
        );

        $css_generator->add_class_styles(
            '{{WRAPPER}} .ablocks-block-tabs .ablocks-block-tabs__tab-panel .ablocks-block-tabs__tab',
            $this->get_tabs_menu_content_css($attributes),
            $this->get_tabs_menu_content_css($attributes, 'Tablet'),
            $this->get_tabs_menu_content_css($attributes, 'Mobile')
        );

        $css_generator->add_class_styles(
            '{{WRAPPER}} .ablocks-block-tabs .ablocks-block-tabs__tab-panel .ablocks-block-tabs__tab--active',
            $this->get_tabs_menu_content_active_css($attributes),
            $this->get_tabs_menu_content_active_css($attributes, 'Tablet'),
            $this->get_tabs_menu_content_active_css($attributes, 'Mobile')
        );

        $css_generator->add_class_styles(
            '{{WRAPPER}} .ablocks-block-tabs .ablocks-block-tabs__tab-panel .ablocks-block-tabs__tab:hover',
            $this->get_tabs_menu_content_hover_css($attributes),
            $this->get_tabs_menu_content_hover_css($attributes, 'Tablet'),
            $this->get_tabs_menu_content_hover_css($attributes, 'Mobile')
        );
        $css_generator->add_class_styles(
            '{{WRAPPER}} .ablocks-block-tabs .ablocks-block-tabs__tab-panel .ablocks-block-tabs__tab-list .ablocks-block-tabs__tab-list-title',
            $this->get_tabs_title_css($attributes),
            $this->get_tabs_title_css($attributes, 'Tablet'),
            $this->get_tabs_title_css($attributes, 'Mobile')
        );

        $css_generator->add_class_styles(
            '{{WRAPPER}} .ablocks-block-tabs .ablocks-block-tabs__tab-panel .ablocks-block-tabs__tab--active .ablocks-block-tabs__tab-list .ablocks-block-tabs__tab-list-title',
            $this->get_tabs_active_title_css($attributes),
            $this->get_tabs_active_title_css($attributes, 'Tablet'),
            $this->get_tabs_active_title_css($attributes, 'Mobile')
        );

        $css_generator->add_class_styles(
            '{{WRAPPER}} .ablocks-block-tabs .ablocks-block-tabs__tab-list-content .ablocks-block-tabs__tab-list-subtitle',
            $this->get_tabs_subtitle_css($attributes),
            $this->get_tabs_subtitle_css($attributes, 'Tablet'),
            $this->get_tabs_subtitle_css($attributes, 'Mobile')
        );

        $css_generator->add_class_styles(
            '{{WRAPPER}} .ablocks-block-tabs .ablocks-block-tabs__tab-panel .ablocks-block-tabs__tab-list .ablocks-block-tabs__tab-list-subtitle',
            $this->get_tabs_subtitle_text_css($attributes),
            $this->get_tabs_subtitle_text_css($attributes, 'Tablet'),
            $this->get_tabs_subtitle_text_css($attributes, 'Mobile')
        );

        $css_generator->add_class_styles(
            '{{WRAPPER}} .ablocks-block-tabs .ablocks-block-tabs__tab-panel .ablocks-block-tabs__tab--active .ablocks-block-tabs__tab-list .ablocks-block-tabs__tab-list-subtitle',
            $this->get_tabs_active_subtitle_text_css($attributes),
            $this->get_tabs_active_subtitle_text_css($attributes, 'Tablet'),
            $this->get_tabs_active_subtitle_text_css($attributes, 'Mobile')
        );

        $css_generator->add_class_styles(
            '{{WRAPPER}} .ablocks-block-tabs .ablocks-block-tabs__tab-panel .ablocks-block-tabs__tab svg',
            $this->get_tabs_icon_css($attributes),
            $this->get_tabs_icon_css($attributes, 'Tablet'),
            $this->get_tabs_icon_css($attributes, 'Mobile')
        );

        $css_generator->add_class_styles(
            '{{WRAPPER}} .ablocks-block-tabs .ablocks-block-tabs__tab-panel .ablocks-block-tabs__tab--active svg',
            $this->get_tabs_active_icon_css($attributes),
            $this->get_tabs_active_icon_css($attributes, 'Tablet'),
            $this->get_tabs_active_icon_css($attributes, 'Mobile')
        );

        $css_generator->add_class_styles(
            '{{WRAPPER}} .ablocks-block-tabs .ablocks-block-tabs__body',
            $this->get_tabs_content_css($attributes),
            $this->get_tabs_content_css($attributes, 'Tablet'),
            $this->get_tabs_content_css($attributes, 'Mobile')
        );

        $css_generator->add_class_styles(
            '{{WRAPPER}} .ablocks-block-tabs .ablocks-block-tabs__body:hover',
            $this->get_tabs_content_hover_css($attributes),
            $this->get_tabs_content_hover_css($attributes, 'Tablet'),
            $this->get_tabs_content_hover_css($attributes, 'Mobile')
        );

        return $css_generator->generate_css();
    }

    // Methods to handle the generation of CSS for different parts
    public function get_tabs_css($attributes, $device = '') {
        $tabs_css = [];

        if (isset($attributes['tabsMenuPosition' . $device])) {
            $tabs_css['flex-direction'] = $attributes['tabsMenuPosition' . $device];
        }
        return $tabs_css;
    }

    public function get_tabs_panel_css($attributes, $device = '') {
        $tabs_panel_css = [];
        if (isset($attributes['tabMenuAlign' . $device])) {
            $tabs_panel_css['justify-content'] = $attributes['tabMenuAlign' . $device];
        }
        if (
            isset($attributes['tabsMenuPosition' . $device]) &&
            ($attributes['tabsMenuPosition' . $device] === 'column' || $attributes['tabsMenuPosition' . $device] === 'column-reverse')
        ) {
            $tabs_panel_css['align-items'] = 'center';
            $tabs_panel_css['flex-direction'] = 'row';
            $tabs_panel_css['max-width'] = '100%';
        }
        if (
            isset($attributes['tabsMenuPosition' . $device]) &&
            ($attributes['tabsMenuPosition' . $device] === 'row' || $attributes['tabsMenuPosition' . $device] === 'row-reverse')
        ) {
            $tabs_panel_css['max-width'] = '30%'; // Removed duplicate line
            $tabs_panel_css['flex-direction'] = 'column';
            $tabs_panel_css['flex-grow'] = 1;
        }
        return $tabs_panel_css;
    }

    public function get_tabs_menu_content_css($attributes, $device = '') {
        $css = [];
        if (isset($attributes['menuContentAlign' . $device])) {
            $css['text-align'] = $attributes['menuContentAlign' . $device];
        }
        if (isset($attributes['tabBackgroundColor'])) {
            $css['background-color'] = $attributes['tabBackgroundColor'];
        }

        return array_merge(
            $css,
            Dimensions::get_css($attributes['menuContentMargin'] ?? [], 'margin', $device),
            Dimensions::get_css($attributes['menuContentPadding'] ?? [], 'padding', $device),
            Border::get_css($attributes['menuContentBorder'] ?? [],"", $device)
        );
    }

    public function get_tabs_menu_content_active_css($attributes, $device = '') {
        $tabs_menu_content_active_css = [];
        if (isset($attributes['tabsMenuPosition' . $device])) {
            switch ($attributes['tabsMenuPosition' . $device]) {
                case 'column':
                    $tabs_menu_content_active_css['border-bottom-color'] = 'transparent';
                    break;
                case 'column-reverse':
                    $tabs_menu_content_active_css['border-top-color'] = 'transparent';
                    break;
                case 'row':
                    $tabs_menu_content_active_css['border-right-color'] = 'transparent';
                    break;
                case 'row-reverse':
                    $tabs_menu_content_active_css['border-left-color'] = 'transparent';
                    break;
            }
        }
        if (isset($attributes['tabActiveBackgroundColor'])) {
            $tabs_menu_content_active_css['background-color'] = $attributes['tabActiveBackgroundColor'];
        }
		if (isset($attributes['activeBorderColor'])) {
            $tabs_menu_content_active_css['border-color'] = $attributes['activeBorderColor'] . '!important';
        }
        return $tabs_menu_content_active_css;
    }

    public function get_tabs_menu_content_hover_css($attributes, $device = '') {
      
        return array_merge(
            Border::get_hover_css($attributes['menuContentBorder'] ?? [], '', $device),
		);
    }
    public function get_tabs_title_css($attributes, $device = '') {
		$css=[];
		if (isset($attributes['titleTextColor'])) {
            $css['color'] = $attributes['titleTextColor'];
        }
        return array_merge(
		    $css,
			Typography::get_css($attributes['titleTypography' . $device] ?? [], $device));
    }

    public function get_tabs_active_title_css($attributes, $device = '') {
		$css=[];
		if (isset($attributes['titleTextActiveColor'])) {
            $css['color'] = $attributes['titleTextActiveColor'];
        }
        return $css;
    }

    public function get_tabs_subtitle_text_css($attributes, $device = '') {
		$css=[];
		if (isset($attributes['subTitleTextColor'])) {
            $css['color'] = $attributes['subTitleTextColor'];
        }
        return array_merge(
			$css,
			Typography::get_css($attributes['subTitleTypography' . $device] ?? [], $device)
		);
    }

    public function get_tabs_subtitle_css($attributes, $device = '') {
        $tabsSubtitleCSS = [];
        $position = $attributes['tabsMenuPosition' . $device] ?? '';

        if ($position === 'column' || $position === 'column-reverse') {
            $tabsSubtitleCSS['width'] = '160px';
        } else {
            $tabsSubtitleCSS['width'] = '100%';
        }

        return $tabsSubtitleCSS;
    }

    public function get_tabs_active_subtitle_text_css($attributes, $device = '') {
		$css=[];
		if (isset($attributes['subTitleTextActiveColor'])) {
            $css['color'] = $attributes['subTitleTextActiveColor'] . '!important';
        }
        return $css;
    }

	public function get_tabs_icon_css($attributes, $device = '') {
        $css = [];
        $iconType = $attributes['iconType'] ?? 'default';
        $iconShape = $attributes['iconShape'] ?? 'square';
        $iconColor = $attributes['iconColor'] ?? '#69727d';
        $iconBackground = $attributes['iconBackground'] ?? 'transparent';
        $size = $attributes['size']['value' . $device] ?? null;
        $spacing = $attributes['spacing']['value' . $device] ?? null;
        $iconPosition = $attributes['iconPosition'] ?? '';

        // Determine icon view CSS based on type and shape
        $iconViewCSS = [];

        if ($iconType !== 'default') {
            if ($iconType === 'stacked') {
                $iconViewCSS['background'] = $iconBackground;
                $iconViewCSS['padding'] = '.5em';

                if ($iconShape === 'circle') {
                    $iconViewCSS['border-radius'] = '50px';
                }
            } elseif ($iconType === 'framed') {
                $iconViewCSS['background'] = 'transparent';
                $iconViewCSS['padding'] = '.5em';
                $iconViewCSS['border'] = '2px solid ' . ($iconColor ?: '#69727d');

                if ($iconShape === 'circle') {
                    $iconViewCSS['border-radius'] = '50px';
                }
            }
        }

        // Apply size CSS if available
        if ($size) {
            $css['width'] = $size . 'px' . ' !important';
            $css['height'] = $size . 'px' . ' !important';
        }

        // Apply icon color if available
        if (isset($attributes['iconColor'])) {
            $css['fill'] = $attributes['iconColor'];
        }

        // Apply spacing based on position
        if ($spacing) {
            switch ($iconPosition) {
                case 'left':
                    $css['margin-right'] = $spacing . 'px';
                    break;
                case 'right':
                    $css['margin-left'] = $spacing . 'px';
                    break;
                case 'bottom':
                    $css['margin-top'] = $spacing . 'px';
                    break;
                case 'top':
                    $css['margin-bottom'] = $spacing . 'px';
                    break;
            }
        }

        // Merge the icon view CSS with the main CSS
        return array_merge($css, $iconViewCSS);
    }

	public function get_tabs_active_icon_css($attributes) {
        $css = [];

        // Check for active icon color
        if (isset($attributes['iconActiveColor'])) {
            $css['fill'] = $attributes['iconActiveColor'];
        }

        // Check for icon type and active background color
        if (isset($attributes['iconType']) && $attributes['iconType'] !== 'default' && $attributes['iconType'] !== 'framed') {
            if (isset($attributes['iconActiveBackground'])) {
                $css['background-color'] = $attributes['iconActiveBackground'];
            }
        }

        return $css;
    }

    public function get_tabs_content_css($attributes, $device = '') {
		$tabs_content_css = [];
	
		// Merge margin, padding, and border CSS
		$tabs_content_css = array_merge(
			$tabs_content_css,
			Dimensions::get_css($attributes['contentMargin'] ?? [], 'margin', $device),
			Dimensions::get_css($attributes['contentPadding'] ?? [], 'padding', $device),
			Border::get_css($attributes['contentBorder'] ?? [],"", $device)
		);
	
		// Apply background color if set
		if (isset($attributes['contentBackgroundColor'])) {
			$tabs_content_css['background-color'] = $attributes['contentBackgroundColor'];
		}
	
		// Apply additional styles based on the menu position
		$menuPosition = $attributes['tabsMenuPosition' . $device] ?? '';
		if ($menuPosition === 'row' || $menuPosition === 'row-reverse') {
			$tabs_content_css['max-width'] = '70%';
			$tabs_content_css['flex-grow'] = 3;
		}
	
		return $tabs_content_css;
	}
	

    public function get_tabs_content_hover_css($attributes, $device = '') {
        return array_merge(
			Border::get_hover_css($attributes['contentBorder'] ?? [], '', $device),
		);
    }
}
