<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ABlocks\Controls\Dimensions;
use ABlocks\Controls\Alignment;
use ABlocks\Helper;
use ABlocks\Controls\Range;

$attributes = [
	'block_id' => [
		'type' => 'string',
		'default' => '',
	],
	'primaryColor' => [
		'type' => 'string',
		'default' => '#69727d',
	],
	'backgroundColor' => [
		'type' => 'string',
		'default' => '',
	],
	'iconType' => [
		'type' => 'string',
		'default' => 'default',
	],
	'iconShape' => [
		'type' => 'string',
		'default' => 'circle',
	],
];


$attributes = array_merge(
	$attributes,
	Dimensions::get_attribute( 'padding', false ),
	Dimensions::get_attribute( 'borderRadius', false ),
	Dimensions::get_attribute( 'borderWidth', false ),
	Alignment::get_attribute( 'alignment', true, [ 'value' => 'flex-start' ] ),
	Helper::get_icon_picker_attribute(),
	Range::get_attribute([
		'attributeName' => 'iconSize',
		'isResponsive' => false,
		'defaultValue' => 55,
	] ),
	Range::get_attribute([
		'attributeName' => 'rotate',
		'isResponsive' => false,
		'defaultValue' => 0,
	] ),
);

return $attributes;
