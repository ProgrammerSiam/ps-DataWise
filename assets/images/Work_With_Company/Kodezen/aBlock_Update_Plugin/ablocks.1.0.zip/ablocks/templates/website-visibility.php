<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1.0" charset="<?php bloginfo( 'charset' ); ?>">
<?php if ( ! current_theme_supports( 'title-tag' ) ) : ?>
<title><?php echo wp_get_document_title(); ?></title>
<?php endif; ?>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
	<?php
		$post = get_post( ABlocks\Helper::get_settings( 'coming_soon_page' ) ?? ABlocks\Helper::get_settings( 'maintenance_page' ) );
		echo apply_filters( 'the_content', $post->post_content );
		wp_footer();
	?>
</body>
</html>
