<?php
namespace SpectraPro\BlocksConfig\Login;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Class Login.
 */
class Base {
	// extended by 'block.php'.
}
