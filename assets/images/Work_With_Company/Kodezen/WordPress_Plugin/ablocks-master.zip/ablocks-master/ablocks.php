<?php
/**
 * Plugin Name:       aBlocks
 * Description:       The WordPress plugin for creating beautiful and functional websites using the Gutenberg editor, with a variety of customizable blocks to design website pages.
 * Requires at least: 6.3
 * Requires PHP:      7.4
 * Version:           1.0-beta2
 * Author:            Academy LMS
 * Author URI:        https://ablocks.pro/
 * License:           GPL-3.0+
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       ablocks
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ABlocks {
	public function __construct() {
		// define constants
		$this->academy_blocks_define_constants();
		$this->load_dependency();
		$this->set_global_settings();
		add_action( 'plugins_loaded', [ $this, 'init_plugin' ] );
	}

	public static function init() {
		static $instance = false;
		if ( ! $instance ) {
			$instance = new self();
		}
		return $instance;
	}

	/**
	 * Define the plugin constants
	 */
	private function academy_blocks_define_constants() {
		define( 'ABLOCKS_VERSION', '1.0-beta2' );
		define( 'ABLOCKS_PLUGIN_SLUG', 'ablocks' );
		define( 'ABLOCKS_ROOT_URL', plugin_dir_url( __FILE__ ) );
		define( 'ABLOCKS_ASSETS_URL', ABLOCKS_ROOT_URL . 'assets/' );
		define( 'ABLOCKS_ROOT_DIR_PATH', plugin_dir_path( __FILE__ ) );
		define( 'ABLOCKS_ASSETS_PATH', ABLOCKS_ROOT_DIR_PATH . 'assets/' );
		define( 'ABLOCKS_INCLUDES_DIR_PATH', ABLOCKS_ROOT_DIR_PATH . 'includes/' );
		define( 'ABLOCKS_BLOCKS_DIR_PATH', ABLOCKS_ROOT_DIR_PATH . 'includes/blocks/' );
	}

	public function load_dependency() {
		require_once ABLOCKS_INCLUDES_DIR_PATH . 'autoload.php';
	}

	public function set_global_settings() {
		$GLOBALS['ablocks_google_fonts'] = [];
	}

	public function init_plugin() {
		ABlocks\Ajax::init();
		ABlocks\Assets::init();
		ABlocks\Blocks::init();
	}
}

/**
 * Kickoff
*/

ABlocks::init();
