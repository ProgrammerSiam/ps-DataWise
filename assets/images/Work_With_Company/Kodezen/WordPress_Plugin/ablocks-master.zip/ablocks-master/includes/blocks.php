<?php
namespace ABlocks;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Blocks {
	private $has_academy_lms = false;
	public static function init() {
		$self = new self();
		$self->set_dependency_status();
		// block initialization
		add_action( 'init', [ $self, 'blocks_init' ] );
		add_action( 'enqueue_block_assets', [ $self, 'load_academy_core_scripts' ] );
		add_filter( 'block_categories_all', [ $self, 'register_block_category' ], 10, 2 );
	}

	public function set_dependency_status() {
		if ( Helper::is_plugin_active( 'academy/academy.php' ) ) {
			$this->has_academy_lms = true;
		}
	}

	public function blocks_init() {
		if ( $this->has_academy_lms ) {
			add_filter( 'academy/is_load_common_scripts', '__return_true' );
			new \ABlocks\Blocks\AcademyCourses\Block();
		}
		new \ABlocks\Blocks\Container\Block();
		new \ABlocks\Blocks\Heading\Block();
		new \ABlocks\Blocks\Paragraph\Block();
		new \ABlocks\Blocks\Image\Block();
		new \ABlocks\Blocks\Button\Block();
		new \ABlocks\Blocks\Icon\Block();
		new \ABlocks\Blocks\StarRatings\Block();
		new \ABlocks\Blocks\Divider\Block();
		new \ABlocks\Blocks\Spacer\Block();
		new \ABlocks\Blocks\Video\Block();
	}

	public function register_block_category( $categories, $post ) {
		return array_merge(
			array(
				array(
					'slug'  => 'ablocks',
					'title' => __( 'ABlocks', 'ablocks' ),
				),
				array(
					'slug'  => 'academy',
					'title' => __( 'Academy LMS', 'ablocks' ),
				),
			),
			$categories,
		);
	}

	public function load_academy_core_scripts() {
		if ( ! $this->has_academy_lms || ! is_admin() ) {
			return;
		}
		$ScriptsBase = new \Academy\Assets();
		$ScriptsBase->frontend_common_assets();
	}
}
