<?php
namespace ABlocks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Assets {

	public static function init() {
		$self = new self();
		add_action( 'enqueue_block_assets', [ $self, 'block_editor_assets' ] );
		add_action( 'wp_enqueue_scripts', [ $self, 'front_end_google_fonts' ] );
	}

	public function web_fonts_url( $font ) {
		$font_url = '';
		if ( 'off' !== _x( 'on', 'Google font: on or off', 'ablocks' ) ) {
			$font_url = add_query_arg( 'family', rawurlencode( $font ), '//fonts.googleapis.com/css' );
		}
		return $font_url;
	}

	public function front_end_google_fonts() {
		global $ablocks_google_fonts;
		if ( empty( $ablocks_google_fonts ) || ! is_array( $ablocks_google_fonts ) ) {
			return false;
		}
		$google_fonts_url = 'https://fonts.googleapis.com/css2?';
		foreach ( $ablocks_google_fonts as $family => $weights ) {
			$google_fonts_url .= 'family=' . preg_replace( '/\s+/', '+', $family );
			$total_weights = count( $weights );
			if ( $total_weights > 0 ) {
				$google_fonts_url .= ':wght@';
				sort( $weights );
				foreach ( $weights as $index => $weight ) {
					$google_fonts_url .= $weight . ';';
					if ( $index === $total_weights - 1 ) {
						$google_fonts_url = preg_replace( '/;$/', '', $google_fonts_url );
					}
				}
			}
			$google_fonts_url .= '&';
		}
		$google_fonts_url .= 'display=swap';

		wp_enqueue_style( 'ablocks-frontend-google-fonts', esc_url( $google_fonts_url ), array(), ABLOCKS_VERSION );
	}

	public function block_editor_assets() {
		if ( is_admin() ) {
			wp_enqueue_style( 'ablocks-editor-font-awesome', ABLOCKS_ASSETS_URL . 'library/font-awesome/css/all.min.css', array(), ABLOCKS_VERSION, 'all' );
			wp_enqueue_style( 'ablocks-editor-fonts', $this->web_fonts_url( 'Roboto:ital,wght@0,300;0,400;0,500;0,700;1,300&display=swap' ), array(), ABLOCKS_VERSION );
			wp_enqueue_style( 'ablocks-editor-icon', ABLOCKS_ASSETS_URL . 'library/css/ablocks-icon/style.css', array( 'wp-components' ), filemtime( ABLOCKS_ASSETS_PATH . 'library/css/ablocks-icon/style.css' ), 'all' );
			wp_enqueue_style( 'ablocks-editor-style', ABLOCKS_ASSETS_URL . 'build/blocks.css', array( 'wp-components' ), filemtime( ABLOCKS_ASSETS_PATH . 'build/blocks.css' ), 'all' );

			// js
			$dependencies = include ABLOCKS_ASSETS_PATH . 'build/blocks.asset.php';
			wp_enqueue_script(
				'ablocks-editor-scripts',
				ABLOCKS_ASSETS_URL . 'build/blocks.js',
				$dependencies['dependencies'],
				$dependencies['version'],
				true
			);
			wp_localize_script( 'ablocks-editor-scripts', 'ABlocksGlobal', [
				'rest_url'              => esc_url_raw( rest_url() ),
				'namespace'             => ABLOCKS_PLUGIN_SLUG . '/v1/',
				'plugin_root_url'       => ABLOCKS_ROOT_URL,
				'plugin_root_path'      => ABLOCKS_ROOT_DIR_PATH,
				'ajax_url'               => esc_url( admin_url( 'admin-ajax.php' ) ),
				'nonce'                 => wp_create_nonce( 'ablocks-editor-nonce' ),
			] );
			wp_set_script_translations( 'ablocks-editor-scripts', 'ablocks', ABLOCKS_ROOT_DIR_PATH . 'languages' );
		}//end if
	}

}
