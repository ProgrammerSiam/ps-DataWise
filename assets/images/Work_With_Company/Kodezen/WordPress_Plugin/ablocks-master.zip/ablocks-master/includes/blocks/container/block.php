<?php
namespace ABlocks\Blocks\Container;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ABlocks\Classes\BlockBaseAbstract;
use ABlocks\Classes\CssGenerator;

class Block extends BlockBaseAbstract {
	protected $block_name = 'container';

	public function build_css( $attributes ) {
		$css_generator = new CssGenerator( $attributes );

		$css_generator->add_class_styles(
			'{{WRAPPER}}.ablocks-block--container-block.ablocks-block--container-block.ablocks-block--container-block',
			$this->get_main_wrapper_css( $attributes ),
			$this->get_main_wrapper_css( $attributes, 'Tablet' ),
			$this->get_main_wrapper_css( $attributes, 'Mobile' )
		);

		$css_generator->add_class_styles(
			'{{WRAPPER}} > .ablocks-block-container',
			$this->get_block_container_css( $attributes ),
			$this->get_block_container_css( $attributes, 'Tablet' ),
			$this->get_block_container_css( $attributes, 'Mobile' )
		);

		$css_generator->add_class_styles(
			'{{WRAPPER}} > .ablocks-block-container > .ablocks-container-block-wrapper',
			$this->get_inner_blocks_closest_parent_css( $attributes ),
			$this->get_inner_blocks_closest_parent_css( $attributes, 'Tablet' ),
			$this->get_inner_blocks_closest_parent_css( $attributes, 'Mobile' )
		);

		return $css_generator->generate_css();
	}

	public function get_inner_blocks_closest_parent_css( $attributes, $device = '' ) {
		$css = [];

		$minimum_height = isset( $attributes['minimumHeight'] ) ? $attributes['minimumHeight'] : [];
		if ( ! empty( $minimum_height[ 'value' . $device ] ) ) {
			$css['min-height'] = $minimum_height[ 'value' . $device ]
				. ( ! empty( $minimum_height[ 'valueUnit' . $device ] ) ? $minimum_height[ 'valueUnit' . $device ] : 'px' );
		}

		if ( ! empty( $attributes[ 'direction' . $device ] ) ) {
			$css['flex-direction'] = $attributes[ 'direction' . $device ];
		}
		if ( ! empty( $attributes[ 'justify' . $device ] ) ) {
			$css['justify-content'] = $attributes[ 'justify' . $device ];
		}
		if ( ! empty( $attributes[ 'align' . $device ] ) ) {
			$css['align-items'] = $attributes[ 'align' . $device ];
		}
		if ( ! empty( $attributes[ 'wrap' . $device ] ) ) {
			$css['flex-wrap'] = $attributes[ 'wrap' . $device ];
		}

		$gap = isset( $attributes['gap'] ) ? $attributes['gap'] : [];
		if ( ! empty( $gap[ 'columnGap' . $device ] ) ) {
			$css['column-gap'] = $gap[ 'columnGap' . $device ]
			. ( ! empty( $gap[ 'columnGapUnit' . $device ] ) ? $gap[ 'columnGapUnit' . $device ] : 'px' );
		}

		if ( ! empty( $gap[ 'rowGap' . $device ] ) ) {
			$css['row-gap'] = $gap[ 'rowGap' . $device ]
				. ( ! empty( $gap[ 'rowGapUnit' . $device ] ) ? $gap[ 'rowGapUnit' . $device ] : 'px' );
		}

		return $css;
	}

	public function get_block_container_css( $attributes, $device = '' ) {
		$css = [];

		$container_width_type = isset( $attributes['containerWidthType'] ) ? $attributes['containerWidthType'] : '';
		$inner_width_type = isset( $attributes['innerWidthType'] ) ? $attributes['innerWidthType'] : '';

		if (
			'alignfull' === $container_width_type &&
			'alignwide' === $inner_width_type &&
			! empty( $attributes['contentBoxWidth'][ 'value' . $device ] )
		) {
			$css['max-width'] = 'min(100vw, '
				. $attributes['contentBoxWidth'][ 'value' . $device ]
				. (
					! empty( $attributes['contentBoxWidth'][ 'valueUnit' . $device ] )
						? $attributes['contentBoxWidth'][ 'valueUnit' . $device ]
						: 'px'
				)
				. ');';
			if ( ! $device ) {
				$css['margin-right'] = 'auto';
				$css['margin-left'] = 'auto';
			}
		}

		return $css;
	}

	public function get_main_wrapper_css( $attributes, $device = '' ) {
		$css = [];
		$custom_width = ! empty( $attributes['containerCustomWidth'][ 'value' . $device ] ) ? $attributes['containerCustomWidth'][ 'value' . $device ] : false;
		$custom_width_unit = ! empty( $attributes['containerCustomWidth'][ 'valueUnit' . $device ] ) ? $attributes['containerCustomWidth'][ 'valueUnit' . $device ] : 'px';
		$is_root_container = isset( $attributes['isRootContainer'] ) ? isset( $attributes['isRootContainer'] ) : false;
		$container_width_type = isset( $attributes['containerWidthType'] ) ? isset( $attributes['containerWidthType'] ) : 'default';
		if ( $custom_width && ( ! $is_root_container || 'default' === $container_width_type ) ) {
			$css['max-width'] = $custom_width . $custom_width_unit;
		}
		if ( ! empty( $attributes['overflow'] ) ) {
			$css['overflow'] = $attributes['overflow'];
		}

		return $css;
	}
}
