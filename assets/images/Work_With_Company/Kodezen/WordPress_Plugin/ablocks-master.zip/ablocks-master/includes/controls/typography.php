<?php
namespace ABlocks\Controls;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ABlocks\Classes\ControlBaseAbstract;

class Typography extends ControlBaseAbstract {
	public static function get_attribute_default_value( $is_responsive = false ) {
		if ( $is_responsive ) {
			return array(
				'fontFamily' => '',
				'weight' => '400',
				'transform' => '',
				'style' => '',
				'decoration' => '',
				'fontSize' => '',
				'fontSizeTablet' => '',
				'fontSizeMobile' => '',
				'fontSizeUnit' => 'px',
				'fontSizeUnitTablet' => 'px',
				'fontSizeUnitMobile' => 'px',
				'lineHeight' => '',
				'lineHeightTablet' => '',
				'lineHeightMobile' => '',
				'lineHeightUnit' => 'px',
				'lineHeightUnitTablet' => 'px',
				'lineHeightUnitMobile' => 'px',
				'letterSpacing' => '',
				'letterSpacingTablet' => '',
				'letterSpacingMobile' => '',
				'letterSpacingUnit' => 'px',
				'letterSpacingUnitTablet' => 'px',
				'letterSpacingUnitMobile' => 'px',
				'wordSpacing' => '',
				'wordSpacingTablet' => '',
				'wordSpacingMobile' => '',
				'wordSpacingUnit' => 'px',
				'wordSpacingUnitTablet' => 'px',
				'wordSpacingUnitMobile' => 'px',
			);
		}//end if
		return array(
			'fontFamily' => '',
			'weight' => '400',
			'transform' => '',
			'style' => '',
			'decoration' => '',
			'fontSize' => '',
			'fontSizeUnit' => 'px',
			'lineHeight' => '',
			'lineHeightUnit' => 'px',
			'letterSpacing' => '',
			'letterSpacingUnit' => 'px',
			'wordSpacing' => '',
			'wordSpacingUnit' => 'px',
		);
	}

	public static function get_attribute( $attributeName, $isResponsive = false ) {
		return [
			$attributeName => [
				'type' => 'object',
				'default' => self::get_attribute_default_value( $isResponsive ),
			]
		];
	}

	public static function get_css( $attribute_value, $property = '', $device = '' ) {
		global $ablocks_google_fonts;
		$default_attar_value = self::get_attribute_default_value( (bool) $device );
		$value = wp_parse_args( $attribute_value, $default_attar_value );
		$css = [];

		if ( '' === $device ) {
			if ( '' !== $value['fontFamily'] ) {
				$font_family = $value['fontFamily'];
				$css['font-family'] = $font_family;
				$font_weight = ! empty( $value['weight'] ) ? $value['weight'] : '400';
				if ( isset( $ablocks_google_fonts[ $font_family ] ) ) {
					if ( ! in_array( $font_weight, $ablocks_google_fonts[ $font_family ], true ) ) {
						$ablocks_google_fonts[ $font_family ][] = $font_weight;
					}
				} else {
					$ablocks_google_fonts[ $font_family ] = [ $font_weight ];
				}
			}
			if ( '400' !== $value['weight'] && '' !== $value['weight'] ) {
				$css['font-weight'] = $value['weight'];
			}
			if ( '' !== $value['transform'] ) {
				$css['text-transform'] = $value['transform'];
			}
			if ( '' !== $value['weight'] ) {
				$css['font-weight'] = $value['weight'];
			}
			if ( '' !== $value['style'] ) {
				$css['font-style'] = $value['style'];
			}
			if ( '' !== $value['decoration'] ) {
				$css['text-decoration'] = $value['decoration'];
			}
		}//end if

		if ( '' !== $value[ 'fontSize' . $device ] ) {
			$css['font-size'] = $value[ 'fontSize' . $device ] . $value[ 'fontSizeUnit' . $device ];
		}
		if (
			'' !== $value[ 'lineHeight' . $device ] &&
			'' !== $value[ 'lineHeightUnit' . $device ]
		) {
			$css['line-height'] = $value[ 'lineHeight' . $device ] . $value[ 'lineHeightUnit' . $device ];
		}
		if (
			'' !== $value[ 'letterSpacing' . $device ] &&
			'' !== $value[ 'letterSpacingUnit' . $device ]
		) {
			$css['letter-spacing'] = $value[ 'letterSpacing' . $device ] . $value[ 'letterSpacingUnit' . $device ];
		}
		if (
			'' !== $value[ 'wordSpacing' . $device ] &&
			'' !== $value[ 'wordSpacingUnit' . $device ]
		) {
			$css['word-spacing'] = $value[ 'wordSpacing' . $device ] . $value[ 'wordSpacingUnit' . $device ];
		}

		return $css;
	}


}
