<?php

use ABlocks\Controls\Typography;
use ABlocks\Controls\Background;
use ABlocks\Controls\Border;
use ABlocks\Controls\Dimensions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$attributes = [
	'block_id' => array(
		'type' => 'string',
	),
	'course_count' => array(
		'type' => 'number',
		'default' => 3,
	),
	'course_columns' => array(
		'type' => 'number',
		'default' => 3,
	),
	'show_pagination' => array(
		'type' => 'boolean',
	),
	'difficulty_levels' => array(
		'type' => 'array',
	),
	'price_types' => array(
		'type' => 'array',
	),
	'order_by' => array(
		'type' => 'string',
	),
	'course_order' => array(
		'type' => 'string',
	),
	'course_ids' => array(
		'type' => 'array',
	),
	'course_categories' => array(
		'type' => 'array',
	),
	'course_tags' => array(
		'type' => 'array',
	),
	'course_exclude_ids' => array(
		'type' => 'array',
	),
	'course_exclude_categories' => array(
		'type' => 'array',
	),
	'course_exclude_tags' => array(
		'type' => 'array',
	),
	'category_color' => array(
		'type' => 'string',
	),
	'category_hover_color' => array(
		'type' => 'string',
	),
	'title_color' => array(
		'type' => 'string',
	),
	'title_hover_color' => array(
		'type' => 'string',
	),
	'author_color' => array(
		'type' => 'string',
	),
	'author_hover_color' => array(
		'type' => 'string',
	),
	'rating_color' => array(
		'type' => 'string',
	),
	'rating_hover_color' => array(
		'type' => 'string',
	),
	'price_color' => array(
		'type' => 'string',
	),
	'price_hover_color' => array(
		'type' => 'string',
	),
	'wish_icon_color' => array(
		'type' => 'string',
	),
	'wish_icon_hover_color' => array(
		'type' => 'string',
	),
];

$attributes = array_merge(
	$attributes,
	Typography::get_attribute( 'cat_typography', true ),
	Typography::get_attribute( 'title_typography', true ),
	Typography::get_attribute( 'author_typography', true ),
	Typography::get_attribute( 'rating_typography', true ),
	Typography::get_attribute( 'price_typography', true ),
	Background::get_attribute( 'card_background', true ),
	Border::get_attribute( 'card_border', true ),
	Dimensions::get_attribute( 'card_margin', true ),
	Dimensions::get_attribute( 'card_hover_margin', true ),
	Dimensions::get_attribute( 'card_padding', true ),
	Dimensions::get_attribute( 'card_hover_padding', true ),
	Background::get_attribute( 'wish_icon_background', true )
);

return $attributes;
