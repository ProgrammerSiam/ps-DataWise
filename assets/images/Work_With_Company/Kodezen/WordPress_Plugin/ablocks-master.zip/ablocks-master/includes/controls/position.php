<?php
namespace ABlocks\Controls;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ABlocks\Classes\ControlBaseAbstract;

class Position extends ControlBaseAbstract {
	public static function get_attribute_default_value( $is_responsive = false ) {
		if ( $is_responsive ) {
			return [
				'positionType' => 'relative',
				'positionTypeTablet' => '',
				'positionTypeMobile' => '',
				'hOrientation' => '',
				'hOffset' => '',
				'hOffsetTablet' => '',
				'hOffsetMobile' => '',
				'hOffsetUnit' => 'px',
				'hOffsetUnitTablet' => 'px',
				'hOffsetUnitMobile' => 'px',
				'vOrientation' => '',
				'vOffset' => '',
				'vOffsetTablet' => '',
				'vOffsetMobile' => '',
				'vOffsetUnit' => 'px',
				'vOffsetUnitTablet' => 'px',
				'vOffsetUnitMobile' => 'px',
			];
		}//end if
		return [
			'positionType' => 'relative',
			'hOrientation' => '',
			'hOffset' => '0',
			'hOffsetUnit' => 'px',
			'vOrientation' => '',
			'vOffset' => '0',
			'vOffsetUnit' => 'px',
		];
	}

	public static function get_attribute( $attributeName, $isResponsive = false ) {
		return [
			$attributeName => [
				'type' => 'object',
				'default' => self::get_attribute_default_value( $isResponsive ),
			]
		];
	}

	public static function get_css( $attribute_value, $property = '', $device = '' ) {
		$default_attar_value = self::get_attribute_default_value( (bool) $device );
		$value = wp_parse_args( $attribute_value, $default_attar_value );
		$css = [];

		if ( $device ) {
			$hOffsetUnit = self::get_unit(
				[
					'unit' => $value['hOffsetUnit'],
					'unitTablet' => $value['hOffsetUnitTablet'],
					'unitMobile' => $value['hOffsetUnitMobile'],
				],
				$device
			);
			$vOffsetUnit = self::get_unit(
				[
					'unit' => $value['vOffsetUnit'],
					'unitTablet' => $value['vOffsetUnitTablet'],
					'unitMobile' => $value['vOffsetUnitMobile'],
				],
				$device
			);
		} else {
			$hOffsetUnit = $value['hOffsetUnit'];
			$vOffsetUnit = $value['vOffsetUnit'];
		}//end if

		if ( $value[ 'positionType' . $device ] ) {
			$css[ $property ] = $value[ 'positionType' . $device ];
		}

		$hOffsetValue = $value[ 'hOffset' . $device ];
		if ( '' !== $hOffsetValue ) {
			if ( 'right' === $value[ 'hOrientation' . $device ] ) {
				$css['right'] = $hOffsetValue . $hOffsetUnit;
				unset( $css['left'] );
			} else {
				$css['left'] = $hOffsetValue . $hOffsetUnit;
				unset( $css['right'] );
			}
		}

		$vOffsetValue = $value[ 'vOffset' . $device ];
		if ( '' !== $vOffsetValue ) {
			if ( 'bottom' === $value[ 'vOrientation' . $device ] ) {
				$css['bottom'] = $vOffsetValue . $vOffsetUnit;
				unset( $css['top'] );
			} else {
				$css['top'] = $vOffsetValue . $vOffsetUnit;
				unset( $css['bottom'] );
			}
		}

		return $css;
	}


}
