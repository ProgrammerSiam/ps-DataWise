<?php
namespace ABlocks\Classes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ABlocks\Controls\Dimensions;
use ABlocks\Controls\Width;
use ABlocks\Controls\Border;
use ABlocks\Controls\Position;
use ABlocks\Controls\Background;
use ABlocks\Controls\Zindex;
use ABlocks\Controls\Transform;
use ABlocks\Controls\Mask;
use ABlocks\Controls\Animation;

class BlockGlobal {
	public static function get_attributes() {
		$attributes = [
			'_hide_on_desktop' => [
				'type' => 'boolean',
				'default' => false,
			],
			'_hide_on_tablet' => [
				'type' => 'boolean',
				'default' => false,
			],
			'_hide_on_mobile' => [
				'type' => 'boolean',
				'default' => false,
			]
		];
		$attributes = array_merge(
			Dimensions::get_attribute( '_margin', true ),
			Dimensions::get_attribute( '_padding', true ),
			Width::get_attribute( '_width', true ),
			Border::get_attribute( '_border', true ),
			Position::get_attribute( '_position', true ),
			Background::get_attribute( '_background', true ),
			Zindex::get_attribute( '_zIndex', true ),
			Transform::get_attribute( '_transform', true ),
			Mask::get_attribute( '_mask', true ),
			Animation::get_attribute( '_animation', true ),
			$attributes,
		);
		return apply_filters( 'ablocks/get_block_common_attributes', $attributes );
	}
	public static function get_wrapper_css( $attribute, $device = '' ) {
		$css = array_merge(
			Position::get_css( $attribute['_position'], 'position', $device ),
			Zindex::get_css( $attribute['_zIndex'], 'z-index', $device ),
		);
		return apply_filters( 'ablocks/get_block_common_wrapper_css', $css );
	}
	public static function get_wrapper_hover_css( $attribute, $device = '' ) {
		$css = [];
		return apply_filters( 'ablocks/get_block_common_wrapper_hover_css', $css );
	}
	public static function get_container_css( $attribute, $device = '' ) {
		$css = array_merge(
			Dimensions::get_css( $attribute['_margin'], 'margin', $device ),
			Dimensions::get_css( $attribute['_padding'], 'padding', $device ),
			Mask::get_css( $attribute['_mask'], $device ),
			Transform::get_css( $attribute['_transform'], 'transform', $device ),
			Background::get_css( $attribute['_background'], 'background', $device ),
			Border::get_css( $attribute['_border'], '', $device ),
			Width::get_css( $attribute['_width'], 'width', $device ),
		);
		return apply_filters( 'ablocks/get_block_common_container_css', $css );
	}
	public static function get_container_hover_css( $attribute, $device = '' ) {
		$css = array_merge(
			Background::get_hover_css( $attribute['_background'], 'background', $device ),
			Transform::get_hover_css( $attribute['_transform'], 'transform', $device ),
			Border::get_hover_css( $attribute['_border'], '', $device )
		);
		return apply_filters( 'ablocks/get_block_common_container_hover_css', $css );
	}
	public static function get_wrapper_device_responsive_css( $attribute, $device = '' ) {
		if ( ! $device && $attribute['_hide_on_desktop'] ) {
			return [
				'display' => 'none'
			];
		}

		if ( 'Tablet' === $device && $attribute['_hide_on_tablet'] ) {
			return [
				'display' => 'none'
			];
		}
		if ( 'Mobile' === $device && $attribute['_hide_on_mobile'] ) {
			return [
				'display' => 'none'
			];
		}

		return [
			'display' => 'inherit'
		];
	}
}
