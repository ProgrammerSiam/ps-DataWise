<?php
namespace ABlocks\Blocks\Spacer;

use ABlocks\Classes\BlockBaseAbstract;
use ABlocks\Classes\CssGenerator;

class Block extends BlockBaseAbstract {
	protected $block_name = 'spacer';

	public function build_css( $attributes ) {
		$css_generator = new CssGenerator( $attributes );
		$desktop_height = ! empty( $attributes['spacerHeight']['value'] ) ? $attributes['spacerHeight']['value'] : '';
		$tablet_height = ! empty( $attributes['spacerHeight']['valueTablet'] ) ? $attributes['spacerHeight']['valueTablet'] : '';
		$mobile_height = ! empty( $attributes['spacerHeight']['valueMobile'] ) ? $attributes['spacerHeight']['valueMobile'] : '';

		$spacer_height_desktop_css = $desktop_height ? [ 'height' => $desktop_height . 'px' ] : array();
		$spacer_height_tablet_css = $tablet_height ? [ 'height' => $tablet_height . 'px' ] : array();
		$spacer_height_mobile_css = $mobile_height ? [ 'height' => $mobile_height . 'px' ] : array();

		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-spacer__box',
			$spacer_height_desktop_css,
			$spacer_height_tablet_css,
			$spacer_height_mobile_css
		);
		return $css_generator->generate_css();
	}

}
