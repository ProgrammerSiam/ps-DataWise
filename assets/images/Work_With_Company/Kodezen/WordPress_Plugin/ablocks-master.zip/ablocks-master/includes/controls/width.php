<?php
namespace ABlocks\Controls;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ABlocks\Classes\ControlBaseAbstract;

class Width extends ControlBaseAbstract {
	public static function get_attribute_default_value( $is_responsive = false ) {
		if ( $is_responsive ) {
			return [
				'widthType' => 'default',
				'widthTypeTablet' => '',
				'widthTypeMobile' => '',
				'vAlign' => '',
				'vAlignTablet' => '',
				'vAlignMobile' => '',
				'customWidth' => '',
				'customWidthTablet' => '',
				'customWidthMobile' => '',
				'unit' => '%',
				'unitTablet' => '',
				'unitMobile' => '',
			];
		}
		return [
			'widthType' => 'default',
			'vAlign' => '',
			'customWidth' => '',
			'unit' => '%'
		];
	}

	public static function get_attribute( $attributeName, $isResponsive = false ) {
		if ( $isResponsive ) {
			return [
				$attributeName => [
					'type' => 'object',
					'default' => self::get_attribute_default_value( $isResponsive )
				]
			];
		}
		return [
			$attributeName => [
				'type' => 'object',
				'default' => self::get_attribute_default_value( $isResponsive )
			]
		];
	}
	public static function get_css( $attribute_value, $property = '', $device = '' ) {
		$attribute_value = wp_parse_args( $attribute_value, self::get_attribute_default_value( (bool) $device ) );
		$css = [];
		if ( ! empty( $attribute_value[ 'widthType' . $device ] ) ) {
			$css[ $property ] = $attribute_value[ 'widthType' . $device ];
		}
		if ( ! empty( $attribute_value[ 'vAlign' . $device ] ) ) {
			$css['align-self'] = $attribute_value[ 'vAlign' . $device ];
		}
		if ( ! empty( $attribute_value[ 'customWidth' . $device ] ) ) {
			$css[ $property ] = $attribute_value[ 'customWidth' . $device ] . self::get_unit( $attribute_value, $device );
		}
		return $css;
	}
}
