<?php
namespace ABlocks;

use \ABlocks\Classes\Helper;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Ajax {
	public static function init() {
		$self = new self();
		add_action( 'wp_ajax_get_academy_terms', [ $self, 'get_academy_terms' ] );
	}
	public function get_academy_terms() {
		check_ajax_referer( 'ablocks-editor-nonce', 'security' );

		if ( ! current_user_can( 'edit_posts' ) ) {
			die();
		}

		$cats = Helper::get_terms_list( 'academy_courses_category' );
		$tags = Helper::get_terms_list( 'academy_courses_tag' );

		wp_send_json_success( array(
			'categories' => $cats,
			'tags'       => $tags,
		), 200 );
	}
}
