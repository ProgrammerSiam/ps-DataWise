<?php
namespace ABlocks\Controls;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ABlocks\Classes\ControlBaseAbstract;

class CssFilter extends ControlBaseAbstract {

	public static function get_attribute_default_value( $is_responsive = false ) {
		return [
			'blur' => '',
			'brightness' => '',
			'contrast' => '',
			'saturate' => '',
			'hue' => '',
		];
	}

	public static function get_attribute( $attributeName, $isResponsive = false ) {
		return [
			$attributeName => [
				'type' => 'object',
				'default' => self::get_attribute_default_value(),
			],
		];
	}

	public static function get_css( $attribute_value, $property = '', $device = '' ) {
		$value = wp_parse_args( $attribute_value,
		self::get_attribute_default_value( (bool) $device ) );

		$css = [];

		if ( '' !== $value['blur'] ||
			'' !== $value['brightness'] ||
			'' !== $value['contrast'] ||
			'' !== $value['saturate'] ||
			'' !== $value['hue'] ) {
			$filterValues = [
				'brightness' => 'brightness(' . ( $value['brightness'] ? $value['brightness'] : 100 ) . '%)',
				'contrast' => 'contrast(' . ( $value['contrast'] ? $value['contrast'] : 100 ) . '%)',
				'saturate' => 'saturate(' . ( $value['saturate'] ? $value['saturate'] : 100 ) . '%)',
				'blur' => 'blur(' . ( $value['blur'] ? $value['blur'] : 0 ) . 'px)',
				'hue' => 'hue-rotate(' . ( $value['hue'] ? $value['hue'] : 0 ) . 'deg)',
			];

			// Filter css
			$css['filter'] = implode( ' ', $filterValues );
		}

		return $css;
	}

}
