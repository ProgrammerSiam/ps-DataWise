<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ABlocks\Controls\Border;
use ABlocks\Controls\Dimensions;
use ABlocks\Controls\Typography;
use ABlocks\Controls\TextShadow;
use ABlocks\Controls\Alignment;
use ABlocks\Controls\Link;
use ABlocks\Classes\Helper;

$attributes = [
	'block_id' => [
		'type' => 'string',
	],
	'text' => [
		'type' => 'string',
		'default' => 'Click here',
	],
	'buttonType' => [
		'type' => 'string',
		'default' => '#ddd',
	],
	'buttonSize' => [
		'type' => 'string',
		'default' => 'small',
	],
	'textColor' => [
		'type' => 'string',
		'default' => '#000000',
	],
	'textColorH' => [
		'type' => 'string',
	],
	'background' => [
		'type' => 'string',
	],
	'backgroundH' => [
		'type' => 'string',
	],
	'iconPosition' => [
		'type' => 'string',
		'default' => 'left',
	],
	'iconSpace' => [
		'type' => 'number',
	],
	'rotation' => [
		'type' => 'number',
	],
];


$attributes = array_merge(
	$attributes,
	Link::get_attribute( 'link' ),
	Border::get_attribute( 'border', true ),
	Dimensions::get_attribute( 'padding', true ),
	Typography::get_attribute( 'typography', true ),
	TextShadow::get_attribute( 'textShadow' ),
	Alignment::get_attribute( 'alignment', true, [ 'value' => 'left' ] ),
	Helper::get_icon_picker_attribute( 'icon', [ 'className' => '' ] )
);

return $attributes;
