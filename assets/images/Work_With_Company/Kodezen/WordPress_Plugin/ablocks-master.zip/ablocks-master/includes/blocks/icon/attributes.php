<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ABlocks\Controls\Dimensions;
use ABlocks\Controls\Alignment;
use ABlocks\Classes\Helper;

$attributes = [
	'block_id' => [
		'type' => 'string',
	],
	'primaryColor' => [
		'type' => 'string',
		'default' => '#69727d',
	],
	'backgroundColor' => [
		'type' => 'string',
	],
	'iconType' => [
		'type' => 'string',
		'default' => 'default',
	],
	'iconShape' => [
		'type' => 'string',
		'default' => 'circle',
	],
	'iconSize' => [
		'type' => 'number',
	],
	'rotate' => [
		'type' => 'number',
	],
];


$attributes = array_merge(
	$attributes,
	Dimensions::get_attribute( 'padding', false ),
	Dimensions::get_attribute( 'borderRadius', false ),
	Dimensions::get_attribute( 'borderWidth', false ),
	Alignment::get_attribute( 'alignment', true, [ 'value' => 'left' ] ),
	Helper::get_icon_picker_attribute()
);

return $attributes;
