<?php

use ABlocks\Controls\Range;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$attributes = [
	'block_id' => [
		'type' => 'string',
	]
];
$attributes = array_merge(
	$attributes,
	Range::get_attribute( 'spacerHeight', true, [
		'value' => 50,
		'valueUnit' => 'px'
	] ),
);
return $attributes;
