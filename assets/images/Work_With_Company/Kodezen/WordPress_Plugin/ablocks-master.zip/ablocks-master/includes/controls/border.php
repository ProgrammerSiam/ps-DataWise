<?php
namespace ABlocks\Controls;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use ABlocks\Classes\ControlBaseAbstract;

class Border extends ControlBaseAbstract {
	public static function get_attribute_default_value( $is_responsive = false ) {

		if ( $is_responsive ) {
			return array(
				'borderStyle' => 'default',
				'borderStyleH' => 'default',
				// border color
				'borderColor' => '',
				// border color - Hover
				'borderColorH' => '',
				// width
				'isLinkedWidth' => true,
				'isLinkedWidthTablet' => true,
				'isLinkedWidthMobile' => true,
				'commonWidth' => '',
				'commonWidthTablet' => '',
				'commonWidthMobile' => '',
				'topWidth' => '',
				'rightWidth' => '',
				'bottomWidth' => '',
				'leftWidth' => '',
				'topWidthTablet' => '',
				'rightWidthTablet' => '',
				'bottomWidthTablet' => '',
				'leftWidthTablet' => '',
				'topWidthMobile' => '',
				'rightWidthMobile' => '',
				'bottomWidthMobile' => '',
				'leftWidthMobile' => '',
				'unitWidth' => 'px',
				'unitWidthTablet' => '',
				'unitWidthMobile' => '',
				'isLinkedWidthH' => true,
				'isLinkedWidthHTablet' => true,
				'isLinkedWidthHMobile' => true,
				// Width Hover
				'commonWidthH' => '',
				'commonWidthHTablet' => '',
				'commonWidthHMobile' => '',
				'topWidthH' => '',
				'rightWidthH' => '',
				'bottomWidthH' => '',
				'leftWidthH' => '',
				'topWidthHTablet' => '',
				'rightWidthHTablet' => '',
				'bottomWidthHTablet' => '',
				'leftWidthHTablet' => '',
				'topWidthHMobile' => '',
				'rightWidthHMobile' => '',
				'bottomWidthHMobile' => '',
				'leftWidthHMobile' => '',
				'unitWidthH' => 'px',
				'unitWidthHTablet' => '',
				'unitWidthHMobile' => '',
				// Radius
				'isLinkedRadius' => true,
				'isLinkedRadiusTablet' => true,
				'isLinkedRadiusMobile' => true,
				'commonRadius' => '',
				'commonRadiusTablet' => '',
				'commonRadiusMobile' => '',
				'topRadius' => '',
				'rightRadius' => '',
				'bottomRadius' => '',
				'leftRadius' => '',
				'topRadiusTablet' => '',
				'rightRadiusTablet' => '',
				'bottomRadiusTablet' => '',
				'leftRadiusTablet' => '',
				'topRadiusMobile' => '',
				'rightRadiusMobile' => '',
				'bottomRadiusMobile' => '',
				'leftRadiusMobile' => '',
				'unitRadius' => 'px',
				'unitRadiusTablet' => '',
				'unitRadiusMobile' => '',
				// Radius Hover
				'isLinkedRadiusH' => true,
				'isLinkedRadiusHTablet' => true,
				'isLinkedRadiusHMobile' => true,
				'commonRadiusH' => '',
				'commonRadiusHTablet' => '',
				'commonRadiusHMobile' => '',
				'topRadiusH' => '',
				'rightRadiusH' => '',
				'bottomRadiusH' => '',
				'leftRadiusH' => '',
				'topRadiusHTablet' => '',
				'rightRadiusHTablet' => '',
				'bottomRadiusHTablet' => '',
				'leftRadiusHTablet' => '',
				'topRadiusHMobile' => '',
				'rightRadiusHMobile' => '',
				'bottomRadiusHMobile' => '',
				'leftRadiusHMobile' => '',
				'unitRadiusH' => 'px',
				'unitRadiusHTablet' => '',
				'unitRadiusHMobile' => ''
			);
		}//end if
		return [
			'borderStyle' => 'default',
			'borderStyleH' => 'default',
			// border color
			'borderColor' => '',
			// border color - Hover
			'borderColorH' => '',
			// border width - Normal
			'isLinkedWidth' => true,
			'isLinkedWidthTablet' => true,
			'isLinkedWidthMobile' => true,
			'commonWidth' => '',
			'topWidth' => '',
			'rightWidth' => '',
			'bottomWidth' => '',
			'leftWidth' => '',
			'unitWidth' => 'px',

			// border width - Hover
			'isLinkedWidthH' => true,
			'isLinkedWidthHTablet' => true,
			'isLinkedWidthHMobile' => true,
			'commonWidthH' => '',
			'topWidthH' => '',
			'rightWidthH' => '',
			'bottomWidthH' => '',
			'leftWidthH' => '',
			'unitWidthH' => 'px',

			// border Radius
			'isLinkedRadius' => true,
			'commonRadius' => '',
			'topRadius' => '',
			'rightRadius' => '',
			'bottomRadius' => '',
			'leftRadius' => '',
			'unitRadius' => 'px',

			// border RadiusH - Hover
			'isLinkedRadiusH' => true,
			'isLinkedRadiusHTablet' => true,
			'isLinkedRadiusHMobile' => true,
			'commonRadiusH' => '',
			'topRadiusH' => '',
			'leftRadiusH' => '',
			'unitRadiusH' => 'px',
		];
	}

	public static function get_attribute( $attributeName, $isResponsive = false ) {
		$attribute_value = self::get_attribute_default_value( $isResponsive );
		if ( $isResponsive ) {
			return [
				$attributeName => [
					'type' => 'object',
					'default' => $attribute_value
				]
			];
		}
		return [
			$attributeName => [
				'type' => 'object',
				'default' => $attribute_value
			]
		];
	}
	public static function get_css( $attribute_value, $property = '', $device = '' ) {
		$value = wp_parse_args( $attribute_value, self::get_attribute_default_value( (bool) $device ) );
		$css = [];

		if ( $device ) {
			$widthUnit = self::get_unit([
				'unit' => $value['unitRadius'],
				'unitTablet' => $value['unitRadiusTablet'],
				'unitMobile' => $value['unitRadiusMobile'],
			], $device);
		} else {
			$widthUnit = $value['unitRadius'];
		}

		if ( $value[ 'isLinkedWidth' . $device ] ) {
			if ( '' !== $value[ 'commonWidth' . $device ] ) {
				$css['border-width'] = $value[ 'commonWidth' . $device ] . $widthUnit;
			}
		} else {
			if ( '' !== $value[ 'topWidth' . $device ] ) {
				$css['border-top-width'] = $value[ 'topWidth' . $device ] . $widthUnit;
			}
			if ( '' !== $value[ 'rightWidth' . $device ] ) {
				$css['border-right-width'] = $value[ 'rightWidth' . $device ] . $widthUnit;
			}
			if ( '' !== $value[ 'bottomWidth' . $device ] ) {
				$css['border-bottom-width'] = $value[ 'bottomWidth' . $device ] . $widthUnit;
			}
			if ( '' !== $value[ 'leftWidth' . $device ] ) {
				$css['border-left-radius'] = $value[ 'leftWidth' . $device ] . $widthUnit;
			}
		}
		if ( '' !== $value['borderStyle'] && 'default' !== $value['borderStyle'] ) {
			$css['border-style'] = $value['borderStyle'];
		}
		if ( '' !== $value['borderColor'] ) {
			$css['border-color'] = $value['borderColor'];
		}

		// Radius CSS
		if ( $device ) {
			$radiusUnit = self::get_unit([
				'unit' => $value['unitRadius'],
				'unitTablet' => $value['unitRadiusTablet'],
				'unitMobile' => $value['unitRadiusMobile'],
			], $device);
		} else {
			$radiusUnit = $value['unitRadius'];
		}

		if ( $value[ 'isLinkedRadius' . $device ] ) {
			if ( '' !== $value[ 'commonRadius' . $device ] ) {
				$css['border-radius'] = $value[ 'commonRadius' . $device ] . $radiusUnit;
			}
		} else {
			if ( '' !== $value[ 'topRadius' . $device ] ) {
				$css['border-top-left-radius'] = $value[ 'topRadius' . $device ] . $radiusUnit;
			}
			if ( '' !== $value[ 'rightRadius' . $device ] ) {
				$css['border-top-right-radius'] = $value[ 'rightRadius' . $device ] . $radiusUnit;
			}
			if ( '' !== $value[ 'bottomRadius' . $device ] ) {
				$css['border-bottom-right-radius'] = $value[ 'bottomRadius' . $device ] . $radiusUnit;
			}
			if ( '' !== $value[ 'leftRadius' . $device ] ) {
				$css['border-bottom-left-radius'] = $value[ 'leftRadius' . $device ] . $radiusUnit;
			}
		}

		return $css;
	}
	public static function get_hover_css( $attribute_value, $property = '', $device = '' ) {
		$value = wp_parse_args( $attribute_value, self::get_attribute_default_value( (bool) $device ) );
		$css = [];

		if ( $device ) {
			$widthUnit = self::get_unit([
				'unit' => $value['unitRadiusH'],
				'unitTablet' => $value['unitRadiusHTablet'],
				'unitMobile' => $value['unitRadiusHMobile'],
			], $device);
		} else {
			$widthUnit = $value['unitRadiusH'];
		}

		if ( $value[ 'isLinkedWidthH' . $device ] ) {
			if ( '' !== $value[ 'commonWidthH' . $device ] ) {
				$css['border-width'] = $value[ 'commonWidthH' . $device ] . $widthUnit;
			}
		} else {
			if ( '' !== $value[ 'topWidthH' . $device ] ) {
				$css['border-top-width'] = $value[ 'topWidthH' . $device ] . $widthUnit;
			}
			if ( '' !== $value[ 'rightWidthH' . $device ] ) {
				$css['border-right-width'] = $value[ 'rightWidthH' . $device ] . $widthUnit;
			}
			if ( '' !== $value[ 'bottomWidthH' . $device ] ) {
				$css['border-bottom-width'] = $value[ 'bottomWidthH' . $device ] . $widthUnit;
			}
			if ( '' !== $value[ 'leftWidthH' . $device ] ) {
				$css['border-left-radius'] = $value[ 'leftWidthH' . $device ] . $widthUnit;
			}
		}
		if ( '' !== $value['borderStyleH'] && 'default' !== $value['borderStyleH'] ) {
			$css['border-style'] = $value['borderStyleH'];
		}
		if ( '' !== $value['borderColorH'] ) {
			$css['border-color'] = $value['borderColorH'];
		}

		// Radius CSS
		if ( $device ) {
			$radiusUnit = self::get_unit([
				'unit' => $value['unitRadiusH'],
				'unitTablet' => $value['unitRadiusHTablet'],
				'unitMobile' => $value['unitRadiusHMobile'],
			], $device);
		} else {
			$radiusUnit = $value['unitRadiusH'];
		}

		if ( $value[ 'isLinkedRadiusH' . $device ] ) {
			if ( '' !== $value[ 'commonRadiusH' . $device ] ) {
				$css['border-radius'] = $value[ 'commonRadiusH' . $device ] . $radiusUnit;
			}
		} else {
			if ( '' !== $value[ 'topRadiusH' . $device ] ) {
				$css['border-top-left-radius'] = $value[ 'topRadiusH' . $device ] . $radiusUnit;
			}
			if ( '' !== $value[ 'rightRadiusH' . $device ] ) {
				$css['border-top-right-radius'] = $value[ 'rightRadiusH' . $device ] . $radiusUnit;
			}
			if ( '' !== $value[ 'bottomRadiusH' . $device ] ) {
				$css['border-bottom-right-radius'] = $value[ 'bottomRadiusH' . $device ] . $radiusUnit;
			}
			if ( '' !== $value[ 'leftRadiusH' . $device ] ) {
				$css['border-bottom-left-radius'] = $value[ 'leftRadiusH' . $device ] . $radiusUnit;
			}
		}

		return $css;
	}

}
