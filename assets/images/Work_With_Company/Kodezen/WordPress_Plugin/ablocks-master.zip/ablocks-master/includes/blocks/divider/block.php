<?php

namespace ABlocks\Blocks\Divider;

use ABlocks\Classes\BlockBaseAbstract;
use ABlocks\Classes\CssGenerator;
use ABlocks\Controls\Alignment;
use ABlocks\Controls\TextStroke;
use ABlocks\Controls\Typography;

class Block extends BlockBaseAbstract {

	protected $block_name = 'divider';

	public function build_css( $attributes ) {
		$css_generator = new CssGenerator( $attributes );
		$css_generator->add_class_styles(
			'{{WRAPPER}}',
			$this->get_wrapper_css( $attributes ),
			$this->get_wrapper_css( $attributes, 'Tablet' ),
			$this->get_wrapper_css( $attributes, 'Mobile' ),
		);

		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-block-container',
			$this->get_divider_container_css( $attributes ),
			$this->get_divider_container_css( $attributes, 'Tablet' ),
			$this->get_divider_container_css( $attributes, 'Mobile' ),
		);

		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-divider',
			$this->get_divider_css( $attributes ),
			$this->get_divider_css( $attributes, 'Tablet' ),
			$this->get_divider_css( $attributes, 'Mobile' ),
		);

		$divider_element_text_styles_css = $this->get_divider_element_text_css( $attributes );
		if ( ! empty( $attributes['elementTextColor'] ) ) {
			$divider_element_text_styles_css['color'] = $attributes['elementTextColor'];
		}
		if ( ! empty( $attributes['elementTextSpacing']['value'] ) ) {
			$divider_element_text_styles_css['padding'] = '0 ' . $attributes['elementTextSpacing']['value'] . 'px';
		}
		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-divider__element-text',
			$divider_element_text_styles_css,
			$this->get_divider_element_text_css( $attributes, 'Tablet' ),
			$this->get_divider_element_text_css( $attributes, 'Mobile' ),
		);

		$divider_element_icon_wrapper_styles = $this->get_divider_element_icon_wrapper_css( $attributes );
		if ( ! empty( $attributes['elementIconSpacing']['value'] ) ) {
			$divider_element_icon_wrapper_styles['margin'] = '0 ' . $attributes['elementIconSpacing']['value'] . 'px';
		}
		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-divider__element-icon',
			$divider_element_icon_wrapper_styles,
			$this->get_divider_element_icon_css( $attributes, 'Tablet' ),
			$this->get_divider_element_icon_css( $attributes, 'Mobile' ),
		);

		$divider_element_icon_styles = $this->get_divider_element_icon_css( $attributes );
		if ( ! empty( $attributes['elementIconSize']['value'] ) ) {
			$divider_element_icon_styles['font-size'] = $attributes['elementIconSize']['value'] . 'px';
		}
		if ( ! empty( $attributes['elementIconRotate']['value'] ) ) {
			$divider_element_icon_styles['rotate'] = $attributes['elementIconRotate']['value'] . 'deg';
		}
		$css_generator->add_class_styles(
			'{{WRAPPER}} .ablocks-divider__element-icon svg.ablocks-svg-icon',
			$divider_element_icon_styles,
			$this->get_divider_element_icon_css( $attributes, 'Tablet' ),
			$this->get_divider_element_icon_css( $attributes, 'Mobile' ),
		);

		return $css_generator->generate_css();
	}

	public function get_wrapper_css( $attributes, $device = '' ) {
		return Alignment::get_css( $attributes['alignment'], 'text-align', $device );
	}

	public function get_divider_element_text_css( $attributes, $device = '' ) {
		return array_merge(
			Typography::get_css( $attributes['elementTextTypography'], $device ),
			TextStroke::get_css( $attributes['elementTextStroke'], $device ),
		);
	}

	public function get_divider_element_icon_wrapper_css( $attributes, $device = '' ) {
		$iconType = $attributes['elementIconType'];
		$primaryColor = $attributes['elementIconPrimaryColor'];
		$backgroundColor = ! empty( $attributes['elementIconBackgroundColor'] ) ? $attributes['elementIconBackgroundColor'] : '';

		$icon_view_css = [];
		if ( 'default' !== $iconType ) {
			if ( 'stacked' === $iconType ) {
				$icon_view_css = [
					'background' => $backgroundColor ?? '#ddd',
					'padding' => '.5em',
				];
			} elseif ( 'framed' === $iconType ) {
				$icon_view_css = [
					'background' => $backgroundColor ?? 'transparent',
					'padding' => '.5em',
					'border' => '2px solid ' . ( $primaryColor ?? '#69727d' ),
				];
			}
		}

		$css = array_merge(
			[
				'background' => $backgroundColor,
			],
			$icon_view_css
		);
		return $css;
	}

	public function get_divider_element_icon_css( $attributes, $device = '' ) {
		$iconType = $attributes['elementIconType'];
		$primaryColor = $attributes['elementIconPrimaryColor'];

		$icon_view_css = [];
		if ( 'default' !== $iconType ) {
			if ( 'stacked' === $iconType ) {
				$icon_view_css = [
					'fill' => $primaryColor ?? '#0000000',
				];
			} elseif ( 'framed' === $iconType ) {
				$icon_view_css = [
					'fill' => $primaryColor ?? '#69727d',
				];
			}
		}

		$css = array_merge(
			[
				'fill' => $primaryColor ?? '#69727d',
			],
			$icon_view_css
		);
		return $css;
	}

	public function get_divider_container_css( $attributes, $device = '' ) {
		$divider_container_css = [];
		if ( ! empty( $attributes['gap'][ 'value' . $device ] ) ) {
			$divider_container_css['padding-block-start'] = $attributes['gap'][ 'value' . $device ] . 'px';
			$divider_container_css['padding-block-end'] = $attributes['gap'][ 'value' . $device ] . 'px';
		}
		if ( ! empty( $attributes['alignment'][ 'value' . $device ] ) ) {
			$divider_container_css['justify-content'] = $attributes['alignment'][ 'value' . $device ];
		}
		return $divider_container_css;
	}

	public function get_divider_css( $attributes, $device = '' ) {
		$divider_css = [];
		$alignment = $attributes['alignment'][ 'value' . $device ] ?? null;
		if ( ! empty( $attributes['width'][ 'value' . $device ] ) ) {
			$divider_css['width'] = $attributes['width'][ 'value' . $device ] . '%';
		}

		return $divider_css;
	}
}
