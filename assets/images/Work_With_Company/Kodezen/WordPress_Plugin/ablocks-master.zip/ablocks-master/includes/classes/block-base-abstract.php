<?php
namespace ABlocks\Classes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

abstract class BlockBaseAbstract {

	protected $namespace = 'ablocks';

	protected $block_name = '';

	protected $has_style = true;

	protected $has_script = false;


	public function __construct() {
		add_action( 'init', array( $this, 'register_block' ), 20 );
		add_filter( 'block_type_metadata', array( $this, 'register_block_attributes' ) );
	}

	public function register_block() {
		register_block_type( ABLOCKS_ASSETS_PATH . 'build/blocks/' . $this->block_name . '/block.json', array(
			'render_callback' => array( $this, 'render_callback' ),
		) );
	}



	public function register_block_attributes( $metadata ) {
		if ( $this->namespace . '/' . $this->block_name === $metadata['name'] ) {
			$attributes = include ABLOCKS_BLOCKS_DIR_PATH . $this->block_name . '/attributes.php';
			$attributes = array_merge( $attributes, BlockGlobal::get_attributes() );
			$metadata['attributes'] = apply_filters( 'ablocks/' . $this->block_name . '/get_attributes', $attributes );
		}
		return $metadata;
	}
	private function get_block_class( $css_class ) {
		$classes = array();
		if ( $css_class ) {
			if ( ! is_array( $css_class ) ) {
				$css_class = preg_split( '#\s+#', $css_class );
			}
			$classes = array_map( 'esc_attr', $css_class );
		} else {
			// Ensure that we always coerce class to being an array.
			$css_class = array();
		}

		echo 'class="' . esc_attr( implode( ' ', $classes ) ) . '"';
	}
	private function get_dynamic_block_wrap( $attributes, $content, $block_instance ) {
		$block_id = ( isset( $attributes['block_id'] ) ? $attributes['block_id'] : '' );
		ob_start();
		?>
		<div <?php $this->get_block_class( array( 'ablocks-block', 'ablocks-block-' . $block_id, 'ablocks-block--' . $this->block_name ) ); ?>>
			<div class="ablocks-block-container">
				<?php
					// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo $this->render_block_content( $attributes, $content, $block_instance );
				?>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	public function render_block_content( $attributes, $content, $block_instance ) {
		return $content;
	}

	public function render_callback( $attributes, $content, $block_instance ) {
		$block_name = $block_instance->name;

		// Dynamic block
		if ( ! $content ) {
			$content = $this->get_dynamic_block_wrap( $attributes, $content, $block_instance );
		}

		if ( ! is_admin() ) {
			$build_css = '<style>' . $this->build_css( $attributes ) . '</style>';

			return $build_css . $content;
		}
		return $content;
	}

	abstract public function build_css( $attributes);
}
