<?php
namespace ABlocks\Blocks\Divider;

use ABlocks\Controls\Alignment;
use ABlocks\Controls\TextStroke;
use ABlocks\Controls\Typography;
use ABlocks\Classes\Helper;

$attributes                = [
	'block_id'             => [
		'type'             => 'string',
	],
	'dividerPatternUrl'    => [
		'type'             => 'string',
		'default'          => 'solid',
	],
	'dividerType'          => [
		'type'             => 'string',
		'default'          => 'css-style',
	],
	'color'                => [
		'type'             => 'string',
		'default'          => '#000000',
	],
	'width'                => [
		'type'             => 'object',
		'default'          => [
			'value'        => 100,
			'valueMobile'  => 100,
			'valueTablet'  => 100,
		],
	],
	'weight'               => [
		'type'             => 'number',
		'default'          => 4,
	],
	'size'                 => [
		'type'             => 'number',
		'default'          => 20,
	],
	'gap'                  => [
		'type'             => 'object',
		'default'          => [
			'value'        => 10,
			'valueMobile'  => 10,
			'valueTablet'  => 10,
		],
	],
	'element'              => [
		'type'             => 'string',
		'default'          => 'none',
	],
	'elementText'          => [
		'type'             => 'string',
		'default'          => 'Divider',
	],
	'elementTextColor'     => [
		'type'             => 'string',
		'default'          => '#000000',
	],
	'elementTextPosition'  => [
		'type'             => 'string',
		'default'          => 'center',
	],
	'elementTextSpacing'   => [
		'type'             => 'object',
		'default'          => [
			'value'        => 0,
			'valueMobile'  => 0,
			'valueTablet'  => 0,
		],
	],
	'elementIconType'      => [
		'type'             => 'string',
		'default'          => 'default',
	],
	'elementIconSize'      => [
		'type'             => 'object',
		'default'          => [],
	],
	'elementIconPosition'  => [
		'type'             => 'string',
		'default'          => 'center',
	],
	'elementIconSpacing'   => [
		'type'             => 'object',
		'default'          => [
			'value'        => 0,
			'valueMobile'  => 0,
			'valueTablet'  => 0,
		],
	],
	'elementIconRotate'    => [
		'type'             => 'object',
		'default'          => [],
	],
	'elementIconPrimaryColor' => [
		'type'             => 'string',
		'default'          => '#69727d',
	],
	'elementIconBackgroundColor' => [
		'type'             => 'string',
	]
];

$attributes = array_merge(
	Typography::get_attribute( 'elementTextTypography', true ),
	TextStroke::get_attribute( 'elementTextStroke', true ),
	Alignment::get_attribute( 'alignment', true, [ 'value' => 'flex-start' ] ),
	Helper::get_icon_picker_attribute(
		'elementIcon', [
			'path' => 'M528.1 171.5L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6zM388.6 312.3l23.7 138.4L288 385.4l-124.3 65.3 23.7-138.4-100.6-98 139-20.2 62.2-126 62.2 126 139 20.2-100.6 98z',
			'viewBox' => '0 0 576 512',
			'className' => 'far fa-star',
		]
	),
	$attributes
);

return $attributes;
