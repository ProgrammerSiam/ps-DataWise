import React, { useEffect } from 'react';
import Settings from './settings';
import Render from './render';
import CSSGenerator from '@Utils/css-generator';
import {
	getButtonCSS,
	getButtonHoverCSS,
	getButtonTextCSS,
	getWrapperCSS,
	getIconCSS,
} from './styling';

export default function Edit(props) {
	const { isSelected, attributes, setAttributes, clientId } = props;

	useEffect(() => {
		setAttributes({ block_id: clientId });
	}, [clientId, setAttributes]);

	// Generate CSS
	const cssGenerator = new CSSGenerator(attributes);
	// Generate wrapper CSS
	cssGenerator.addClassStyles(
		'{{WRAPPER}}',
		getWrapperCSS(attributes),
		getWrapperCSS(attributes, 'Tablet'),
		getWrapperCSS(attributes, 'Mobile')
	);
	// Generate button CSS
	cssGenerator.addClassStyles(
		'{{WRAPPER}} .ablocks-block-container .ablocks-button',
		{
			'text-decoration': 'none',
			'column-gap': `${attributes?.iconSpace || 2}px`,
			color: attributes?.textColor,
			background:
				attributes?.background || attributes?.buttonType || '#ddd',
			...getButtonCSS(attributes),
		},
		getButtonCSS(attributes, 'Tablet'),
		getButtonCSS(attributes, 'Mobile')
	);

	// Generate button hover CSS
	cssGenerator.addClassStyles(
		'{{WRAPPER}} .ablocks-block-container .ablocks-button:hover',
		getButtonHoverCSS(attributes),
		getButtonHoverCSS(attributes, 'Tablet'),
		getButtonHoverCSS(attributes, 'Mobile')
	);
	cssGenerator.addClassStyles(
		'{{WRAPPER}} .ablocks-block-container .ablocks-button:hover svg.ablocks-svg-icon',
		{
			fill: attributes?.textColorH,
		}
	);

	// Generate button text CSS
	cssGenerator.addClassStyles(
		'{{WRAPPER}} .ablocks-block-container .ablocks-button .ablocks-button__text',
		getButtonTextCSS(attributes),
		getButtonTextCSS(attributes, 'Tablet'),
		getButtonTextCSS(attributes, 'Mobile')
	);
	// Generate button icon CSS
	cssGenerator.addClassStyles(
		'{{WRAPPER}} .ablocks-block-container .ablocks-button svg.ablocks-svg-icon',
		{
			fill: attributes?.textColor,
			...getIconCSS(attributes),
		},
		getIconCSS(attributes, 'Tablet'),
		getIconCSS(attributes, 'Mobile')
	);

	const generatedCSS = cssGenerator.generateCSS();

	return (
		<>
			<style>{generatedCSS}</style>
			{isSelected && <Settings {...props} />}
			<Render {...props} />
		</>
	);
}
