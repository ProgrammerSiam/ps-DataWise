import React, { useState } from 'react';
import { Popover, Button } from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import PropTypes from 'prop-types';

const propTypes = {
	attributeName: PropTypes.string,
	attributeValue: PropTypes.any,
	changeHandler: PropTypes.func,
	setAttributes: PropTypes.func,
};

const defaultProps = {
	attributeName: '',
};
const defaultColors = {
	primary: '#000000',
	secondary: '#ffffff',
	text: '#dh55555',
	accent: '#3fffff',
};

const ABlocsGlobalTextColor = ({ changeHandler, setType, className }) => {
	const [selectedOption, setSelectedOption] = useState('primary');

	const handleOptionChange = (option) => {
		setSelectedOption(option);
		changeHandler(defaultColors[option]);
	};

	return (
		<div>
			<Popover className={className}>
				<div className="ablocks-popover-header">
					<h4 className="ablocks-popover-header__title">
						{__('Global Colors', 'ablocks')}
					</h4>
					<Button
						icon={
							<span className="dashicons dashicons-no-alt"></span>
						}
						onClick={() => setType('')}
					/>
				</div>
				<div className="ablocks-popover-content">
					<div className="color-options">
						{Object.keys(defaultColors).map((option) => (
							<div key={option} className="color-option">
								<span>
									<input
										type="radio"
										name="text-color-option"
										value={option}
										checked={selectedOption === option}
										onChange={() =>
											handleOptionChange(option)
										}
									/>
									{`${option
										.charAt(0)
										.toUpperCase()}${option.slice(1)}`}
								</span>
								<span>
									{`#${defaultColors[option].substr(1)}`}
								</span>
							</div>
						))}
					</div>
				</div>
			</Popover>
		</div>
	);
};

export default ABlocsGlobalTextColor;
ABlocsGlobalTextColor.propTypes = propTypes;
ABlocsGlobalTextColor.defaultProps = defaultProps;
