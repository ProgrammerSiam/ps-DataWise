export const getAnchorClientRect = ({ elementRef, height, width }) => {
	if (!elementRef) {
		return false;
	}
	const { innerHeight } = window;
	const rect = elementRef.getBoundingClientRect();
	const topSpace = rect?.top;
	const leftSpace = rect?.left;
	const bottomSpace = innerHeight - rect?.bottom;

	const isTopHasMoreSpace = topSpace > bottomSpace;

	let fromTop = 0;
	if (isTopHasMoreSpace) {
		fromTop = topSpace > height ? topSpace - height : 20;
	} else {
		fromTop = bottomSpace > height ? topSpace : innerHeight - (height + 20);
	}
	const fromLeft = leftSpace - (width + 10);

	return {
		left: fromLeft,
		x: fromLeft,
		top: fromTop,
		y: fromTop,
		width: 0,
		height: 0,
		right: fromLeft,
		bottom: fromTop,
	};
};
