import React from 'react';
import PropTypes from 'prop-types';
import './editor.scss';

const propTypes = {
	margin: PropTypes.string,
	topMargin: PropTypes.string,
	bottomMargin: PropTypes.string,
};

const defaultProps = {
	margin: '',
	topMargin: '',
	bottomMargin: '',
};

export default function Separator({ margin, topMargin, bottomMargin }) {
	return (
		<React.Fragment>
			<div
				className="ablocks-component-separator"
				style={{
					marginTop: `${margin || topMargin}px`,
					marginBottom: `${margin || bottomMargin}px`,
				}}
			></div>
		</React.Fragment>
	);
}

Separator.propTypes = propTypes;
Separator.defaultProps = defaultProps;
