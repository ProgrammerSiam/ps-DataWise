import { getUnit } from '@Utils/helper';

export const borderStyleOpions = [
	{ value: 'default', label: 'Default' },
	{ value: 'none', label: 'None' },
	{ value: 'solid', label: 'Solid' },
	{ value: 'double', label: 'Double' },
	{ value: 'dotted', label: 'Dotted' },
	{ value: 'dashed', label: 'Dashed' },
	{ value: 'groove', label: 'Groove' },
];

export const getAttributeDefaultValue = (isResponsive = false) => {
	if (isResponsive) {
		return {
			borderStyle: 'default',
			borderStyleH: 'default',
			// border width - Normal
			isLinkedWidth: true,
			isLinkedWidthTablet: true,
			isLinkedWidthMobile: true,
			commonWidth: '',
			commonWidthTablet: '',
			commonWidthMobile: '',
			topWidth: '',
			rightWidth: '',
			bottomWidth: '',
			leftWidth: '',
			topWidthTablet: '',
			rightWidthTablet: '',
			bottomWidthTablet: '',
			leftWidthTablet: '',
			topWidthMobile: '',
			rightWidthMobile: '',
			bottomWidthMobile: '',
			leftWidthMobile: '',
			unitWidth: 'px',
			unitWidthTablet: '',
			unitWidthMobile: '',
			// border color
			borderColor: '',

			// border color - Hover
			borderColorH: '',

			// border width - Hover
			isLinkedWidthH: true,
			isLinkedWidthHTablet: true,
			isLinkedWidthHMobile: true,
			commonWidthH: '',
			commonWidthHTablet: '',
			commonWidthHMobile: '',
			topWidthH: '',
			rightWidthH: '',
			bottomWidthH: '',
			leftWidthH: '',
			topWidthHTablet: '',
			rightWidthHTablet: '',
			bottomWidthHTablet: '',
			leftWidthHTablet: '',
			topWidthHMobile: '',
			rightWidthHMobile: '',
			bottomWidthHMobile: '',
			leftWidthHMobile: '',
			unitWidthH: 'px',
			unitWidthHTablet: '',
			unitWidthHMobile: '',

			// border Radius
			isLinkedRadius: true,
			isLinkedRadiusTablet: true,
			isLinkedRadiusMobile: true,
			commonRadius: '',
			commonRadiusTablet: '',
			commonRadiusMobile: '',
			topRadius: '',
			rightRadius: '',
			bottomRadius: '',
			leftRadius: '',
			topRadiusTablet: '',
			rightRadiusTablet: '',
			bottomRadiusTablet: '',
			leftRadiusTablet: '',
			topRadiusMobile: '',
			rightRadiusMobile: '',
			bottomRadiusMobile: '',
			leftRadiusMobile: '',
			unitRadius: 'px',
			unitRadiusTablet: '',
			unitRadiusMobile: '',

			// border RadiusH - Hover
			isLinkedRadiusH: true,
			isLinkedRadiusHTablet: true,
			isLinkedRadiusHMobile: true,
			commonRadiusH: '',
			commonRadiusHTablet: '',
			commonRadiusHMobile: '',
			topRadiusH: '',
			rightRadiusH: '',
			bottomRadiusH: '',
			leftRadiusH: '',
			topRadiusHTablet: '',
			rightRadiusHTablet: '',
			bottomRadiusHTablet: '',
			leftRadiusHTablet: '',
			topRadiusHMobile: '',
			rightRadiusHMobile: '',
			bottomRadiusHMobile: '',
			leftRadiusHMobile: '',
			unitRadiusH: 'px',
			unitRadiusHTablet: '',
			unitRadiusHMobile: '',
		};
	}
	return {
		borderStyle: 'default',
		borderStyleH: 'default',
		// border width - Normal
		isLinkedWidth: true,
		commonWidth: '',
		topWidth: '',
		rightWidth: '',
		bottomWidth: '',
		leftWidth: '',
		unitWidth: 'px',

		// border width - Hover
		isLinkedWidthH: true,
		commonWidthH: '',
		topWidthH: '',
		rightWidthH: '',
		bottomWidthH: '',
		leftWidthH: '',
		unitWidthH: 'px',

		// border color
		borderColor: '',
		// border color - Hover
		borderColorH: '',

		// border Radius
		isLinkedRadius: true,
		commonRadius: '',
		topRadius: '',
		rightRadius: '',
		bottomRadius: '',
		leftRadius: '',
		unitRadius: 'px',

		// border RadiusH - Hover
		isLinkedRadiusH: true,
		commonRadiusH: '',
		topRadiusH: '',
		leftRadiusH: '',
		unitRadiusH: 'px',
	};
};

export const getAttribute = (attributeName, isResponsive = false) => {
	if (isResponsive) {
		return {
			[attributeName]: {
				type: 'object',
				default: getAttributeDefaultValue(isResponsive),
			},
		};
	}

	return {
		[attributeName]: {
			type: 'object',
			default: getAttributeDefaultValue(isResponsive),
		},
	};
};

export const getCSS = (attributeValue, device = '') => {
	const value = {
		...getAttributeDefaultValue(device ? true : false),
		...attributeValue,
	};

	const css = {};

	// Width CSS
	const widthUnit = getUnit(
		{
			unit: value.unitWidth,
			unitTablet: value.unitWidthTablet,
			unitMobile: value.unitWidthMobile,
		},
		device
	);

	// Border css
	const commonWidth = (value['commonWidth' + device] || 0) + widthUnit;
	if (value['isLinkedWidth' + device]) {
		if (value['commonWidth' + device] !== '') {
			css[`border-width`] = commonWidth;
		}
	} else {
		if (value['topWidth' + device] !== '') {
			css['border-top-width'] = value['topWidth' + device].widthUnit;
		}
		if (value['rightWidth' + device] !== '') {
			css['border-right-width'] = value['rightWidth' + device].widthUnit;
		}
		if (value['bottomWidth' + device] !== '') {
			css['border-bottom-width'] =
				value['bottomWidth' + device].widthUnit;
		}
		if (value['leftWidth' + device] !== '') {
			css['border-left-width'] = value['leftWidth' + device].widthUnit;
		}
	}
	if (value.borderStyle && value.borderStyle !== 'default') {
		css[`border-style`] = value.borderStyle;
	}
	if (value.borderColor) {
		css[`border-color`] = value.borderColor;
	}

	// Radius CSS
	const radiusUnit = getUnit(
		{
			unit: value.unitRadius,
			unitTablet: value.unitRadiusTablet,
			unitMobile: value.unitRadiusMobile,
		},
		device
	);

	const topRadius = value['topRadius' + device] || 0;
	const rightRadius = value['rightRadius' + device] || 0;
	const bottomRadius = value['bottomRadius' + device] || 0;
	const leftRadius = value['leftRadius' + device] || 0;

	if (
		value['commonRadius' + device] !== '' ||
		topRadius ||
		rightRadius ||
		bottomRadius ||
		leftRadius
	) {
		if (value['isLinkedRadius' + device]) {
			const commonRadius =
				(value['commonRadius' + device] || 0) + radiusUnit;
			if (value['commonRadius' + device] !== '') {
				css['border-radius'] = commonRadius;
			}
		} else {
			css['border-radius'] = `${topRadius + radiusUnit} ${
				rightRadius + radiusUnit
			} ${bottomRadius + radiusUnit} ${leftRadius + radiusUnit}`;
		}
	}

	return css;
};

export const getHoverCSS = (attributeValue, device = '') => {
	const value = {
		...getAttributeDefaultValue(device ? true : false),
		...attributeValue,
	};

	const css = {};

	// Width CSS
	const widthUnit = getUnit(
		{
			unit: value.unitWidthH,
			unitTablet: value.unitWidthHTablet,
			unitMobile: value.unitWidthHMobile,
		},
		device
	);

	// Border hover css
	const commonWidth = (value['commonWidthH' + device] || 0) + widthUnit;
	if (value['isLinkedWidthH' + device]) {
		if (value['commonWidthH' + device] !== '') {
			css[`border-width`] = commonWidth;
		}
	} else {
		if (value['topWidthH' + device] !== '') {
			css['border-top-width'] = value['topWidthH' + device].widthUnit;
		}
		if (value['rightWidthH' + device] !== '') {
			css['border-right-width'] = value['rightWidthH' + device].widthUnit;
		}
		if (value['bottomWidthH' + device] !== '') {
			css['border-bottom-width'] =
				value['bottomWidthH' + device].widthUnit;
		}
		if (value['leftWidthH' + device] !== '') {
			css['border-left-width'] = value['leftWidthH' + device].widthUnit;
		}
	}
	if (value.borderStyleH && value.borderStyleH !== 'default') {
		css[`border-style`] = value.borderStyleH;
	}
	if (value.borderColorH) {
		css[`border-color`] = value.borderColorH;
	}

	// Radius CSS
	const radiusUnit = getUnit(
		{
			unit: value.unitRadiusH,
			unitTablet: value.unitRadiusHTablet,
			unitMobile: value.unitRadiusHMobile,
		},
		device
	);

	const topRadiusH = value['topRadiusH' + device] || 0;
	const rightRadiusH = value['rightRadiusH' + device] || 0;
	const bottomRadiusH = value['bottomRadiusH' + device] || 0;
	const leftRadiusH = value['leftRadiusH' + device] || 0;

	if (
		value['commonRadiusH' + device] !== '' ||
		topRadiusH ||
		rightRadiusH ||
		bottomRadiusH ||
		leftRadiusH
	) {
		if (value['isLinkedRadiusH' + device]) {
			const commonRadiusH =
				(value['commonRadiusH' + device] || 0) + radiusUnit;
			if (value['commonRadiusH' + device] !== '') {
				css['border-radius'] = commonRadiusH;
			}
		} else {
			css['border-radius'] = `${topRadiusH + radiusUnit} ${
				rightRadiusH + radiusUnit
			} ${bottomRadiusH + radiusUnit} ${leftRadiusH + radiusUnit}`;
		}
	}

	return css;
};
