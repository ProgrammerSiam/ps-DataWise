import React, { useState } from 'react';
import ABlocksTextControl from '@Controls/text';
import { getAttributeDefaultValue } from './helper';
import { objectUniqueCheck } from '@Utils/helper';
import ABlocksToggleControl from '@Controls/toggleButton';
import { __ } from '@wordpress/i18n';
import './styles.scss';

export default function ABlockLinkControl(props) {
	const { attributeValue, setAttributes, attributeName, label } = props;
	const { href, noFollow, linkTarget, keyValue } = attributeValue;

	const [isOpenOptions, setIsOpenOptions] = useState(false);

	const onChangeHandler = (paramAttributeObjectKey, paramControlValue) => {
		const newAttributes = objectUniqueCheck(getAttributeDefaultValue(), {
			...attributeValue,
			[paramAttributeObjectKey]: paramControlValue,
		});
		setAttributes({
			[attributeName]: newAttributes,
		});
	};

	const toggleOptions = () => {
		setIsOpenOptions(!isOpenOptions);
	};

	return (
		<div className="ablocks-link-controls">
			<ABlocksTextControl
				label={label}
				attributeValue={href}
				placeholder="Paste URL or type"
				onChangeHandler={(controlValue) =>
					onChangeHandler('href', controlValue)
				}
			/>
			<button
				className="ablocks-link-options-button"
				onClick={toggleOptions}
			>
				{__('Link Options', 'ablocks')}
			</button>

			{isOpenOptions && (
				<div className="ablocks-link-options">
					<ABlocksToggleControl
						label={__('Open in new window', 'ablocks')}
						isResponsive={false}
						attributeValue={linkTarget}
						setAttributes={setAttributes}
						attributeName={attributeName}
						onChangeHandler={(controlValue) =>
							onChangeHandler('linkTarget', controlValue)
						}
					/>

					<ABlocksToggleControl
						label={__('Add nofollow', 'ablocks')}
						isResponsive={false}
						attributeValue={noFollow}
						setAttributes={setAttributes}
						attributeName={attributeName}
						onChangeHandler={(controlValue) =>
							onChangeHandler('noFollow', controlValue)
						}
					/>

					<ABlocksTextControl
						label={__('Custom Attributes', 'ablocks')}
						attributeValue={keyValue}
						placeholder="key|value"
						isInline={false}
						onChangeHandler={(controlValue) =>
							onChangeHandler('keyValue', controlValue)
						}
					/>

					<span className="ablocks-filed-description">
						Set custom attributes for the link element. Separate
						attribute keys from values using the | (pipe) character.
						Separate key-value pairs with a comma.
					</span>
				</div>
			)}
		</div>
	);
}
