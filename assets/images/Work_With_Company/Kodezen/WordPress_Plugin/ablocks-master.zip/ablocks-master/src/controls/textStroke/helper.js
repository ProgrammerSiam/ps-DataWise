export const getAttributeDefaultValue = (isResponsive = false) => {
	if (isResponsive) {
		return {
			strokeWidth: '',
			strokeWidthTablet: '',
			strokeWidthMobile: '',
			strokeWidthUnit: 'px',
			strokeWidthUnitTablet: 'px',
			strokeWidthUnitMobile: 'px',
			stroke: '',
		};
	}

	return {
		strokeWidth: '',
		strokeWidthUnit: 'px',
		stroke: '',
	};
};

export const getAttribute = (attributeName, isResponsive) => {
	if (isResponsive) {
		return {
			[attributeName]: {
				type: 'object',
				default: getAttributeDefaultValue(isResponsive),
			},
		};
	}
	return {
		[attributeName]: {
			type: 'object',
			default: getAttributeDefaultValue(isResponsive),
		},
	};
};

export const getCSS = (attributeValue, device = '') => {
	const value = {
		...getAttributeDefaultValue(device ? true : false),
		...attributeValue,
	};

	if (value['strokeWidth' + device] !== '') {
		const css = {};
		css['-webkit-text-stroke-width'] = `${value['strokeWidth' + device]}${
			value['strokeWidthUnit' + device]
		}`;
		css['stroke-width'] = `${value['strokeWidth' + device]}${
			value['strokeWidthUnit' + device]
		}`;
		css['-webkit-text-stroke-color'] = `${value.stroke || '#000'}`;
		css.stroke = `${value.stroke || '#000'}`;

		return css;
	}
};
