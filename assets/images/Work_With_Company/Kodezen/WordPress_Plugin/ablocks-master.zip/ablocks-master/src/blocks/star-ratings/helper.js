export const ratingScaleOptions = [
	{ label: '0 to 5', value: 5 },
	{ label: '0 to 10', value: 10 },
];
