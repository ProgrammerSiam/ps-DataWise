import React from 'react';
import PropTypes from 'prop-types';
import ABlocksRangeControl from '@Controls/range';
import { objectUniqueCheck } from '@Utils/helper';
import GetDeviceType from '@Utils/get-device-type';
import { getAttributeDefaultValue, widthTypeOptions } from './helper';
import ABlocksSelectControl from '@Controls/select';
import { __ } from '@wordpress/i18n';
import './styles.scss';

const propTypes = {
	isResponsive: PropTypes.bool,
	label: PropTypes.string,
	attributeName: PropTypes.string,
	attributeValue: PropTypes.any,
	onChangeHandler: PropTypes.func,
};

const defaultProps = {
	label: '',
	isResponsive: true,
};

const ABlocksWidthControl = (props) => {
	const {
		isResponsive,
		attributeName,
		attributeValue,
		setAttributes,
		label,
	} = props;
	const deviceType = GetDeviceType();

	const changeHandler = (controlValue, attributeObjectKey = '') => {
		return setAttributes({
			[attributeName]: objectUniqueCheck(
				getAttributeDefaultValue(isResponsive),
				{
					...attributeValue,
					[attributeObjectKey]: controlValue,
				}
			),
		});
	};

	const showCustomControl =
		attributeValue['widthType' + deviceType] === 'custom';

	const min = 0;
	let max = 100;

	const unit = attributeValue['customWidthUnit' + deviceType] || 'px';

	if (unit === 'px') {
		max = 1000;
	} else if (unit === '%') {
		max = 100;
	} else if (unit === 'rem' || unit === 'em') {
		max = 10;
	}

	return (
		<React.Fragment>
			<div className="ablocks-width-control">
				<ABlocksSelectControl
					label={label}
					isResponsive={isResponsive}
					options={widthTypeOptions}
					attributeValue={attributeValue}
					attributeObjectKey="widthType"
					attributeName={attributeName}
					setAttributes={setAttributes}
				/>
				{showCustomControl && (
					<div className="ablocks-width-control--range-control">
						<ABlocksRangeControl
							{...props}
							min={min}
							max={max}
							label={__('Custom Width', 'ablocks')}
							hasUnit={true}
							isInline={false}
							onChangeHandler={changeHandler}
							attributeObjectKey="customWidth"
						/>
					</div>
				)}
			</div>
		</React.Fragment>
	);
};
ABlocksWidthControl.propTypes = propTypes;
ABlocksWidthControl.defaultProps = defaultProps;
export default ABlocksWidthControl;
