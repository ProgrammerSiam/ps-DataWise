import { getUnit } from '@Utils/helper';
export const attributesDefault = {
	default: '',
	full: '',
	inline: '',
	custom: '',
};
export const getAttributeDefaultValue = (
	isResponsive = false,
	attributeObjectKey = 'value',
	defaultValue = {}
) => {
	if (isResponsive) {
		return {
			[attributeObjectKey]: '',
			[attributeObjectKey + 'Tablet']: '',
			[attributeObjectKey + 'Mobile']: '',
			...defaultValue,
		};
	}
	return {
		[attributeObjectKey]: '',
		...defaultValue,
	};
};

export const attributesResponsiveDefault = {
	default: '',
	full: '',
	inline: '',
	custom: '',
	defaultTablet: '',
	fullTablet: '',
	inlineTablet: '',
	customTablet: '',
	defaultMobile: '',
	fullMobile: '',
	inlineMobile: '',
	customMobile: '',
};

export const getAttributes = (attributeName, isResponsive = false) => {
	if (isResponsive) {
		return {
			[attributeName]: {
				type: 'object',
				default: attributesResponsiveDefault,
			},
		};
	}
	return {
		[attributeName]: {
			type: 'object',
			default: attributesDefault,
		},
	};
};

export const getCSS = (attributeValue, property = '', device = '') => {
	const css = {};
	const unitValue = getUnit(
		{
			unit: attributeValue.unit,
			unitTablet: attributeValue.unitTablet,
			unitMobile: attributeValue.unitMobile,
		},
		device
	);
	if (attributeValue['default' + device] !== '') {
		css[`${property}-default`] =
			attributeValue['default' + device] + unitValue;
	}
	if (attributeValue['full' + device] !== '') {
		css[`${property}-full`] = attributeValue['full' + device] + unitValue;
	}
	if (attributeValue['inline' + device] !== '') {
		css[`${property}-inline`] =
			attributeValue['inline' + device] + unitValue;
	}
	if (attributeValue['custom' + device] !== '') {
		css[`${property}-custom`] =
			attributeValue['custom' + device] + unitValue;
	}
	return css;
};

export const HTMLTagLists = [
	{
		label: 'H1',
		value: 'h1',
	},
	{
		label: 'H2',
		value: 'h2',
	},
	{
		label: 'H3',
		value: 'h3',
	},
	{
		label: 'H4',
		value: 'h4',
	},
	{
		label: 'H5',
		value: 'h5',
	},
	{
		label: 'H6',
		value: 'h6',
	},
	{
		label: 'DIV',
		value: 'div',
	},
	{
		label: 'SPAN',
		value: 'span',
	},
	{
		label: 'P',
		value: 'p',
	},
];
