export const getMainWrapperCss = (attributes, device = '') => {
	const {
		isRootContainer,
		containerWidthType,
		containerCustomWidth,
		overflow,
	} = attributes;
	const css = {};
	const customWidth = containerCustomWidth['value' + device];

	if (customWidth && (!isRootContainer || 'default' === containerWidthType)) {
		css['max-width'] = `${customWidth}${
			containerCustomWidth['valueUnit' + device] || 'px'
		}`;
	}

	if (overflow) {
		css.overflow = overflow;
	}

	return css;
};

export const getBlockContainerCSS = (attributes, device = '') => {
	const {
		containerWidthType,
		innerWidthType,
		contentBoxWidth = {},
	} = attributes;
	const css = {};
	if (
		'alignfull' === containerWidthType &&
		'alignwide' === innerWidthType &&
		contentBoxWidth['value' + device]
	) {
		css['max-width'] = `min(100vw, ${contentBoxWidth['value' + device]}${
			contentBoxWidth['valueUnit' + device] || 'px'
		})`;
		if (!device) {
			css['margin-left'] = 'auto';
			css['margin-right'] = 'auto';
		}
	}

	return css;
};

export const getMinHeightCss = (attributes, device = '') => {
	const { minimumHeight = {} } = attributes;
	const css = {};
	if (minimumHeight['value' + device]) {
		css['min-height'] = `${minimumHeight['value' + device]}${
			minimumHeight['valueUnit' + device] || 'px'
		}`;
	}

	return css;
};

export const getInnerBlocksClosestParentCss = (attributes, device = '') => {
	const css = getMinHeightCss(attributes, device);
	const { gap = {} } = attributes;

	if (attributes['direction' + device]) {
		css['flex-direction'] = attributes['direction' + device];
	}
	if (attributes['justify' + device]) {
		css['justify-content'] = attributes['justify' + device];
	}
	if (attributes['align' + device]) {
		css['align-items'] = attributes['align' + device];
	}
	if (attributes['wrap' + device]) {
		css['flex-wrap'] = attributes['wrap' + device];
	}

	if (gap['columnGap' + device]) {
		css['column-gap'] = `${gap['columnGap' + device]}${
			gap['columnGapUnit' + device] || 'px'
		}`;
	}

	if (gap['rowGap' + device]) {
		css['row-gap'] = `${gap['rowGap' + device]}${
			gap['rowGapUnit' + device] || 'px'
		}`;
	}

	return css;
};
