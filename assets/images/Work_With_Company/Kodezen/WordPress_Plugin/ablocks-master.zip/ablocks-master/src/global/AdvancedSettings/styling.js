import { getCSS as getDimensionCSS } from '@Controls/dimensions/helper';
import {
	getCSS as getBackgroundCSS,
	getHoverCSS as getBackgroundHoverCSS,
} from '@Controls/background/helper';
import {
	getBeforeCSS as getBackgroundOverlayBeforeCSS,
	getBeforeHoverCSS as getBackgroundOverlayBeforeHoverCSS,
} from '@Controls/background/overlay/helper';
import { getCSS as getWidthCSS } from '@Global/width/helper';
import { getCSS as getPositionCSS } from '@Global/positions/helper';
import { getCSS as getZIndexCSS } from '@Global/z-index/helper';
import {
	getCSS as getTransformCSS,
	getHoverCSS as getTransformHoverCSS,
} from '@Global/transform/helper';
import {
	getCSS as getDeviceResponsiveCSS,
	getInnerElementCSS as getDeviceResponsiveInnerCSS,
} from '@Global/DeviceResponsive/helper';
import {
	getCSS as getBorderCSS,
	getHoverCSS as getBorderHoverCSS,
} from '@Controls/border/helper';
import { getCSS as getMaskCSS } from '@Global/mask/helper';

export const getWrapperCSS = (attributes, device = '') => {
	return {
		...getPositionCSS(attributes?._position, 'position', device),

		...getZIndexCSS(attributes?._zIndex, 'z-index', device),
	};
};

export const getWrapperHoverCSS = (attributes, device = '') => {
	return {
		...getBackgroundHoverCSS(attributes?._background, 'background', device),
		...getBorderHoverCSS(attributes?._border, device),
	};
};

export const getWrapperDeviceResponsiveCSS = (attributes, device = '') => {
	return {
		...getDeviceResponsiveCSS(
			{
				_hide_on_desktop: attributes?._hide_on_desktop,
				_hide_on_tablet: attributes?._hide_on_tablet,
				_hide_on_mobile: attributes?._hide_on_mobile,
			},
			device
		),
	};
};

export const getContainerCSS = (attributes, device = '') => {
	return {
		...getDimensionCSS(attributes?._margin, 'margin', device),
		...getDimensionCSS(attributes?._padding, 'padding', device),
		...getMaskCSS(attributes?._mask, device),
		...getTransformCSS(attributes?._transform, 'transform', device),
		...getBackgroundCSS(attributes?._background, 'background', device),
		...getBorderCSS(attributes?._border, device),
		...getWidthCSS(attributes?._width, 'width', device),
	};
};
export const getContainerHoverCSS = (attributes, device = '') => {
	return {
		...getTransformHoverCSS(attributes?._transform, 'transform', device),
	};
};

export const getContainerBeforeCSS = (attributes, device = '') => {
	return {
		...getBackgroundOverlayBeforeCSS(
			attributes?._backgroundOverlay,
			'background',
			device
		),
	};
};

export const getContainerBeforeHoverCSS = (attributes, device = '') => {
	return {
		...getBackgroundOverlayBeforeHoverCSS(
			attributes?._backgroundOverlay,
			'background',
			device
		),
	};
};

export const getWrapperDeviceResponsiveInnerCSS = (attributes, device = '') => {
	return {
		...getDeviceResponsiveInnerCSS(
			{
				_hide_on_desktop: attributes?._hide_on_desktop,
				_hide_on_tablet: attributes?._hide_on_tablet,
				_hide_on_mobile: attributes?._hide_on_mobile,
			},
			device
		),
	};
};
