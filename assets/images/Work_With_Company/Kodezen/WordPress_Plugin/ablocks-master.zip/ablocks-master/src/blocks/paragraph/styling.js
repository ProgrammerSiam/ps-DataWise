import { getCSS as getAlignmentCSS } from '@Controls/alignment/helper';
import { getCSS as getTypographyCSS } from '@Controls/typography/helper';
import { getCSS as getTextShadowCSS } from '@Controls/textShadow/helper';
import { getCSS as getTextStrokeCSS } from '@Controls/textStroke/helper';

export const getWrapperCSS = (attributes, device = '') => {
	return {
		...getAlignmentCSS(attributes?.alignment, 'text-align', device),
	};
};
export const getParagraphTextCSS = (attributes, device = '') => {
	return {
		...getTypographyCSS(attributes?.typography, device),
		...getTextStrokeCSS(attributes?.textStroke, device),
		...getTextShadowCSS(attributes?.textShadow),
	};
};

export const getParagraphDropTextCSS = (attributes) => {
	const css = {};
	if (attributes.dropCapsTextColor) {
		css.color = attributes.dropCapsTextColor;
	}

	return css;
};
