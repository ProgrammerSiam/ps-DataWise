import React from 'react';
import ABlocksMaskSize from './size';
import ABlocksMaskShape from './shape';
import ABlocksMaskPosition from './position';
import { __ } from '@wordpress/i18n';
import ABlocksSelectControl from '@Controls/select';

const Repeats = [
	{ value: 'repeat-x', label: 'Repeat-x' },
	{ value: 'repeat-y', label: 'Repeat-y' },
	{ value: 'repeat', label: 'Repeat' },
	{ value: 'space', label: 'Space' },
	{ value: 'round', label: 'Round' },
	{ value: 'no-repeat', label: 'No-repeat' },
];

function ABlocksMaskOptions(props) {
	const { deviceType, attributeValue, setAttributes, attributeName } = props;

	return (
		<>
			<ABlocksMaskShape {...props} />

			<ABlocksMaskSize {...props} />

			<ABlocksMaskPosition {...props} />

			{attributeValue['maskSize' + deviceType] !== 'cover' && (
				<ABlocksSelectControl
					label={__('Repeat', 'ablocks')}
					options={Repeats}
					isResponsive={true}
					attributeValue={attributeValue}
					attributeObjectKey="maskRepeat"
					attributeName={attributeName}
					setAttributes={setAttributes}
				/>
			)}
		</>
	);
}

export default ABlocksMaskOptions;
