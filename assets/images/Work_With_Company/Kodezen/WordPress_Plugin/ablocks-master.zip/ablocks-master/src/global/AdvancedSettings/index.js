import React from 'react';
import { __ } from '@wordpress/i18n';
import { PanelBody } from '@wordpress/components';
import ABlocksDimensions from '@Controls/dimensions';
import ABlocksWidthControl from '@Global/width';
import ABlocksTransformControl from '@Global/transform';
import ABlocksTextControl from '@Controls/text';
import ABlocksBorderControl from '@Controls/border';
import ABlocksPositionControl from '../positions';
import ABlocksZIndexControl from '@Global/z-index';
import ABlocksBackgroundControl from '@Controls/background';
import ABlocksMasks from '@Global/mask';
import DeviceResponsive from '@Global/DeviceResponsive';

const propTypes = {};

const defaultProps = {};

export default function AdvancedSettings({ attributes, setAttributes }) {
	return (
		<React.Fragment>
			<PanelBody title={__('Layout', 'ablocks')} initialOpen={true}>
				<ABlocksDimensions
					label={__('Margin', 'ablocks')}
					attributeName="_margin"
					attributeValue={attributes?._margin}
					setAttributes={setAttributes}
				/>
				<ABlocksDimensions
					label={__('Padding', 'ablocks')}
					attributeName="_padding"
					attributeValue={attributes?._padding}
					setAttributes={setAttributes}
				/>
				<ABlocksWidthControl
					label={__('Width', 'ablocks')}
					isResponsive={true}
					attributeName="_width"
					attributeValue={attributes?._width}
					setAttributes={setAttributes}
				/>
				<ABlocksPositionControl
					label={__('Position', 'ablocks')}
					isResponsive={true}
					attributeName="_position"
					attributeValue={attributes?._position}
					setAttributes={setAttributes}
				/>
				<ABlocksZIndexControl
					label={__('Z-Index', 'ablocks')}
					isResponsive={true}
					attributeName="_zIndex"
					attributeValue={attributes?._zIndex}
					setAttributes={setAttributes}
				/>
				<ABlocksTextControl
					label={__('CSS ID', 'ablocks')}
					attributeValue={attributes?.anchor}
					onChangeHandler={(nextValue) => {
						setAttributes({
							anchor: nextValue.replace(/[\s#]/g, '-'),
						});
					}}
					isInline={false}
				/>
				<ABlocksTextControl
					label={__('CSS Classes', 'ablocks')}
					attributeName="className"
					attributeValue={attributes?.className}
					setAttributes={setAttributes}
					isInline={false}
				/>
			</PanelBody>
			{/* <PanelBody
				title={__('Motion Effects', 'ablocks')}
				initialOpen={false}
			>
				<ABlocksAnimationControl
					label={__('Entrance Animation', 'ablocks')}
					isResponsive={true}
					attributeName="_animation"
					attributeValue={attributes?._animation}
					setAttributes={setAttributes}
				/>
			</PanelBody> */}
			<PanelBody title={__('Transform', 'ablocks')} initialOpen={false}>
				<ABlocksTransformControl
					attributeName="_transform"
					attributeValue={attributes?._transform}
					setAttributes={setAttributes}
				/>
			</PanelBody>
			<PanelBody title={__('Background', 'ablocks')} initialOpen={false}>
				<ABlocksBackgroundControl
					isResponsive={true}
					attributeName="_background"
					attributeValue={attributes?._background}
					setAttributes={setAttributes}
				/>
			</PanelBody>
			{/* <PanelBody
				title={__('Background Overlay', 'ablocks')}
				initialOpen={false}
			>
				<ABlocksBackgroundOverlayControl
					isResponsive={true}
					attributeName="_backgroundOverlay"
					attributeValue={attributes?._backgroundOverlay}
					setAttributes={setAttributes}
				/>
			</PanelBody> */}
			<PanelBody title={__('Border', 'ablocks')} initialOpen={false}>
				<ABlocksBorderControl
					attributeName="_border"
					attributeValue={attributes?._border}
					setAttributes={setAttributes}
				/>
			</PanelBody>
			<PanelBody title={__('Mask', 'ablocks')} initialOpen={false}>
				<ABlocksMasks
					label={__('Mask', 'ablocks')}
					isResponsive={true}
					attributeName="_mask"
					attributeValue={attributes?._mask}
					setAttributes={setAttributes}
				/>
			</PanelBody>
			<PanelBody title={__('Responsive', 'ablocks')} initialOpen={false}>
				<DeviceResponsive
					attributes={attributes}
					setAttributes={setAttributes}
				/>
			</PanelBody>
		</React.Fragment>
	);
}

AdvancedSettings.propTypes = propTypes;
AdvancedSettings.defaultProps = defaultProps;
