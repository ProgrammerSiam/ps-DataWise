import { __ } from '@wordpress/i18n';
import ABlocksToggleControl from '@Controls/toggleButton';
import AblocksPopover from '@Components/popover';
import ABlocksRangeControl from '@Controls/range';
import ControlLabel from '@Components/control-label';
import Button from '@Components/Button';
import { useRef, useState } from 'react';

const ABlocksRotate = (props) => {
	const [isVisible, setIsVisible] = useState(false);
	const anchorRef = useRef(null);
	const { hover, resetHandler, attributeValue, label } = props;
	let attributeObjectKeyForRotate = 'rotate';
	let attributeObjectKeyFor3DRotate = 'rotate3D';
	let attributeObjectKeyForRotateX = 'rotateX';
	let attributeObjectKeyForRotateY = 'rotateY';
	let attributeObjectKeyForPerspective = 'rotateP';

	if (hover) {
		attributeObjectKeyForRotate = 'rotateH';
		attributeObjectKeyFor3DRotate = 'rotate3DH';
		attributeObjectKeyForRotateX = 'rotateXH';
		attributeObjectKeyForRotateY = 'rotateYH';
		attributeObjectKeyForPerspective = 'rotatePH';
	}

	const handleReset = () =>
		resetHandler({
			[attributeObjectKeyForRotate]: '',
			[attributeObjectKeyFor3DRotate]: false,
			[attributeObjectKeyForRotateX]: '',
			[attributeObjectKeyForRotateY]: '',
			[attributeObjectKeyForPerspective]: '',
		});

	const commonProps = {
		...props,
		min: -360,
		max: 360,
	};

	const togglePopoverVisibility = () => {
		setIsVisible(!isVisible);
	};

	return (
		<div className="ablocks-control ablocks-control-color-gradient-root-wrapper">
			{label && (
				<div className="ablocks-control-label">
					<ControlLabel label={label} isResponsive={false} />
				</div>
			)}
			<div className="ablocks-control-color-gradient">
				<div className="ablocks-component-popover">
					<div className="ablocks-component-popover__field">
						<div
							className="ablocks-component-popover-toggler-wrapper"
							ref={anchorRef}
						>
							<Button
								ref={anchorRef}
								onClick={togglePopoverVisibility}
								icon={
									<span className="ablocks-icon ablocks-icon--edit"></span>
								}
								preset="transparent"
								className={
									isVisible
										? 'ablocks-component-popover__field--active'
										: ''
								}
							/>
						</div>
					</div>
					{isVisible && (
						<AblocksPopover
							label={__('Rotate', 'ablocks')}
							isShowPrimaryLabel={false}
							isReset={true}
							handleReset={handleReset}
							isVisible={isVisible}
							toggleVisible={setIsVisible}
							anchorRef={anchorRef}
						>
							<ABlocksRangeControl
								{...commonProps}
								label={__('Rotate', 'ablocks')}
								isResponsive={true}
								isInline={false}
								attributeObjectKey={attributeObjectKeyForRotate}
							/>
							<ABlocksToggleControl
								{...commonProps}
								isResponsive={false}
								label={__('3D Rotate', 'ablocks')}
								attributeObjectKey={
									attributeObjectKeyFor3DRotate
								}
							/>

							{attributeValue[attributeObjectKeyFor3DRotate] && (
								<>
									<ABlocksRangeControl
										{...commonProps}
										label={__('Rotate X', 'ablocks')}
										isResponsive={true}
										attributeObjectKey={
											attributeObjectKeyForRotateX
										}
										isInline={false}
									/>
									<ABlocksRangeControl
										{...commonProps}
										label={__('Rotate Y', 'ablocks')}
										isResponsive={true}
										attributeObjectKey={
											attributeObjectKeyForRotateY
										}
										isInline={false}
									/>
									<ABlocksRangeControl
										{...commonProps}
										label={__('Perspective', 'ablocks')}
										isResponsive={true}
										attributeObjectKey={
											attributeObjectKeyForPerspective
										}
										isInline={false}
									/>
								</>
							)}
						</AblocksPopover>
					)}
				</div>
			</div>
		</div>
	);
};

export default ABlocksRotate;
