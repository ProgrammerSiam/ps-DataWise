import { registerBlockType } from '@wordpress/blocks';
import attributes from './attributes';
import Edit from './edit';
import Save from './save';
import metadata from './block.json';
import { variations } from './variations';
registerBlockType(metadata.name, {
	attributes,
	icon: (
		<svg
			width="24"
			height="25"
			viewBox="0 0 24 25"
			fill="none"
			xmlns="http://www.w3.org/2000/svg"
		>
			<path
				d="M19 6.56091H6C4.9 6.56091 4 7.46091 4 8.56091V17.5609C4 18.6609 4.9 19.5609 6 19.5609H19C20.1 19.5609 21 18.6609 21 17.5609V8.56091C21 7.46091 20.1 6.56091 19 6.56091ZM14.9 8.06091V18.0609H10V8.06091H14.9ZM5.5 17.5609V8.56091C5.5 8.26091 5.7 8.06091 6 8.06091H8.5V18.0609H6C5.7 18.0609 5.5 17.8609 5.5 17.5609ZM19.5 17.5609C19.5 17.8609 19.3 18.0609 19 18.0609H16.4V8.06091H19C19.3 8.06091 19.5 8.26091 19.5 8.56091V17.5609Z"
				fill="#E930F0"
			/>
		</svg>
	),
	edit: Edit,
	save: Save,
	variations,
});
