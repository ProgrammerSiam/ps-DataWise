import React, { useState, useEffect } from 'react';
import Settings from './settings';
import Render from './render';
import CSSGenerator from '@Utils/css-generator';

import {
	getCourseCardCategoryCss,
	getCourseCardTitleCss,
	getCourseCardAuthorCss,
	getCourseCardRatingCss,
	getCourseCardPriceCss,
	getCourseCardCss,
	getCourseCardHoverCss,
	getWishListIconCss,
	getWishListIconHoverCss,
} from './styling';

import './editor.scss';

export default function Edit(props) {
	const { isSelected, attributes, setAttributes, clientId } = props;
	const {
		category_color,
		category_hover_color,
		title_color,
		title_hover_color,
		author_color,
		author_hover_color,
		rating_color,
		rating_hover_color,
		price_color,
		price_hover_color,
	} = attributes;

	const [academyTerms, setAcademyTerms] = useState({});

	// Store the blockId in the attributes
	useEffect(() => {
		setAttributes({ block_id: clientId });
	}, [clientId, setAttributes]);

	useEffect(() => {
		if (academyTerms?.categories && academyTerms?.tags) {
			return false;
		}
		jQuery.post(
			window.ajaxurl,
			{
				action: 'get_academy_terms',
				security: window.ABlocksGlobal.nonce,
			},
			(data, status) => {
				if ('success' === status) {
					const { categories = [], tags = [] } = data?.data || {};
					const terms = {
						categories,
						tags,
					};
					setAcademyTerms(terms);
				}
			}
		);
	}, []); // eslint-disable-line react-hooks/exhaustive-deps

	// Generate CSS
	const cssGenerator = new CSSGenerator(attributes);

	const courseCardCategoryDesktopCss = getCourseCardCategoryCss(attributes);
	if (category_color) {
		courseCardCategoryDesktopCss.color = category_color;
	}
	cssGenerator.addClassStyles(
		'{{WRAPPER}} .academy-courses--grid .academy-course .academy-course__meta--categroy a',
		courseCardCategoryDesktopCss,
		getCourseCardCategoryCss(attributes, 'Tablet'),
		getCourseCardCategoryCss(attributes, 'Mobile')
	);

	const courseCardCategoryDesktopHoverCss = {};
	if (category_hover_color) {
		courseCardCategoryDesktopHoverCss.color = category_hover_color;
	}
	cssGenerator.addClassStyles(
		'{{WRAPPER}} .academy-courses--grid .academy-course .academy-course__meta--categroy:hover a',
		courseCardCategoryDesktopHoverCss,
		{},
		{}
	);

	const courseCardTitleDesktopCss = getCourseCardTitleCss(attributes);
	if (title_color) {
		courseCardTitleDesktopCss.color = title_color;
	}
	cssGenerator.addClassStyles(
		`{{WRAPPER}} .academy-courses--grid .academy-course .academy-course__title, 
        {{WRAPPER}} .academy-courses--grid .academy-course .academy-course__title a`,
		courseCardTitleDesktopCss,
		getCourseCardTitleCss(attributes, 'Tablet'),
		getCourseCardTitleCss(attributes, 'Mobile')
	);

	const courseCardTitleDesktopHoverCss = {};
	if (title_hover_color) {
		courseCardTitleDesktopHoverCss.color = attributes.title_hover_color;
	}
	cssGenerator.addClassStyles(
		`{{WRAPPER}} .academy-courses--grid .academy-course .academy-course__title:hover, 
        {{WRAPPER}} .academy-courses--grid .academy-course .academy-course__title:hover a`,
		courseCardTitleDesktopHoverCss,
		{},
		{}
	);

	const courseCardAuthorDesktopCss = getCourseCardAuthorCss(attributes);
	if (author_color) {
		courseCardAuthorDesktopCss.color = author_color;
	}
	cssGenerator.addClassStyles(
		`{{WRAPPER}} .academy-courses--grid .academy-course .academy-course__author, 
        {{WRAPPER}} .academy-courses--grid .academy-course .academy-course__author .author, 
        {{WRAPPER}} .academy-courses--grid .academy-course .academy-course__author .author a`,
		courseCardAuthorDesktopCss,
		getCourseCardAuthorCss(attributes, 'Tablet'),
		getCourseCardAuthorCss(attributes, 'Mobile')
	);

	const courseCardAuthorDesktopHoverCss = {};
	if (author_hover_color) {
		courseCardAuthorDesktopHoverCss.color = author_hover_color;
	}
	cssGenerator.addClassStyles(
		`{{WRAPPER}} .academy-courses--grid .academy-course .academy-course__author:hover, 
        {{WRAPPER}} .academy-courses--grid .academy-course .academy-course__author:hover .author, 
        {{WRAPPER}} .academy-courses--grid .academy-course .academy-course__author:hover .author a`,
		courseCardAuthorDesktopHoverCss,
		{},
		{}
	);

	const courseCardRatingDesktopCss = getCourseCardRatingCss(attributes);
	if (rating_color) {
		courseCardRatingDesktopCss.color = rating_color;
	}
	cssGenerator.addClassStyles(
		`{{WRAPPER}} .academy-courses--grid .academy-course .academy-course__rating,
        {{WRAPPER}} .academy-courses--grid .academy-course .academy-course__rating .academy-group-star, 
        {{WRAPPER}} .academy-courses--grid .academy-course .academy-course__rating .academy-group-star .academy-icon::before, 
        {{WRAPPER}} .academy-courses--grid .academy-course .academy-course__rating .academy-course__rating-count`,
		courseCardRatingDesktopCss,
		getCourseCardRatingCss(attributes, 'Tablet'),
		getCourseCardRatingCss(attributes, 'Mobile')
	);

	const courseCardRatingDesktopHoverCss = {};
	if (rating_hover_color) {
		courseCardRatingDesktopHoverCss.color = rating_hover_color;
	}
	cssGenerator.addClassStyles(
		`{{WRAPPER}} .academy-courses--grid .academy-course .academy-course__rating:hover,
        {{WRAPPER}} .academy-courses--grid .academy-course .academy-course__rating:hover .academy-group-star, 
        {{WRAPPER}} .academy-courses--grid .academy-course .academy-course__rating:hover .academy-group-star .academy-icon::before, 
        {{WRAPPER}} .academy-courses--grid .academy-course .academy-course__rating:hover .academy-course__rating-count`,
		courseCardTitleDesktopHoverCss,
		{},
		{}
	);

	cssGenerator.addClassStyles(
		`{{WRAPPER}} .academy-courses--grid .academy-row .academy-course,
        {{WRAPPER}} .academy-courses--grid .academy-row .academy-course, 
        {{WRAPPER}} .academy-courses--grid .academy-row .academy-course, 
        {{WRAPPER}} .academy-courses--grid .academy-row .academy-course`,
		getCourseCardCss(attributes),
		getCourseCardCss(attributes, 'Tablet'),
		getCourseCardCss(attributes, 'Tablet')
	);

	cssGenerator.addClassStyles(
		`{{WRAPPER}} .academy-courses--grid .academy-row .academy-course:hover,
        {{WRAPPER}} .academy-courses--grid .academy-row .academy-course:hover,
        {{WRAPPER}} .academy-courses--grid .academy-row .academy-course:hover,
        {{WRAPPER}} .academy-courses--grid .academy-row .academy-course:hover`,
		getCourseCardHoverCss(attributes),
		getCourseCardHoverCss(attributes, 'Tablet'),
		getCourseCardHoverCss(attributes, 'Tablet')
	);

	const courseCardPriceDesktopCss = getCourseCardPriceCss(attributes);
	if (price_color) {
		courseCardPriceDesktopCss.color = price_color;
	}
	cssGenerator.addClassStyles(
		'{{WRAPPER}} .academy-courses--grid .academy-course .academy-course__price',
		courseCardPriceDesktopCss,
		getCourseCardPriceCss(attributes, 'Tablet'),
		getCourseCardPriceCss(attributes, 'Mobile')
	);

	const courseCardPriceDesktopHoverCss = {};
	if (price_hover_color) {
		courseCardPriceDesktopHoverCss.color = price_hover_color;
	}
	cssGenerator.addClassStyles(
		'{{WRAPPER}} .academy-courses--grid .academy-course .academy-course__price:hover',
		courseCardPriceDesktopHoverCss,
		{},
		{}
	);

	cssGenerator.addClassStyles(
		'{{WRAPPER}} .academy-courses--grid .academy-row .academy-course .academy-add-to-wishlist-btn',
		getWishListIconCss(attributes),
		getWishListIconCss(attributes, 'Tablet'),
		getWishListIconCss(attributes, 'Mobile')
	);

	cssGenerator.addClassStyles(
		'{{WRAPPER}} .academy-courses--grid .academy-row .academy-course .academy-add-to-wishlist-btn:hover',
		getWishListIconHoverCss(attributes),
		getWishListIconHoverCss(attributes, 'Tablet'),
		getWishListIconHoverCss(attributes, 'Mobile')
	);

	const generatedCSS = cssGenerator.generateCSS();
	return (
		<>
			<style>{generatedCSS}</style>
			{isSelected && <Settings academyTerms={academyTerms} {...props} />}
			<Render {...props} />
		</>
	);
}
