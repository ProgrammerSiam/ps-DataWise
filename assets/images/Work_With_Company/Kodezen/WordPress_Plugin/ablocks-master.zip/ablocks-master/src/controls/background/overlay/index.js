import PropTypes from 'prop-types';
import GetDeviceType from '@Utils/get-device-type';
import { objectUniqueCheck } from '@Utils/helper';
import { getAttributeDefaultValue } from './helper';
import NormalHoverTabs from '@Components/normal-hover-tabs';
import BackgroundOverlayAllOptions from './options';

const propTypes = {
	isResponsive: PropTypes.bool,
	label: PropTypes.string,
	attributeName: PropTypes.string,
	attributeValue: PropTypes.any,
	onChangeHandler: PropTypes.func,
};

const defaultProps = {
	label: '',
	isResponsive: true,
};
export default function ABlocksBackgroundOverlayControl(props) {
	const { attributeName, attributeValue, setAttributes, isResponsive } =
		props;
	const deviceType = GetDeviceType();

	const changeHandler = (controlValue, name, deviceMode = '') => {
		if (isResponsive) {
			return setAttributes({
				[attributeName]: objectUniqueCheck(
					getAttributeDefaultValue(isResponsive),
					{
						...attributeValue,
						[name + deviceMode]: controlValue,
					}
				),
			});
		}
		return setAttributes({
			[attributeName]: {
				[name]: controlValue,
			},
		});
	};

	const onChangeHandler = (paramAttributeObjectKey, paramControlValue) => {
		return setAttributes({
			[attributeName]: objectUniqueCheck(getAttributeDefaultValue(), {
				...attributeValue,
				[paramAttributeObjectKey]: paramControlValue,
			}),
		});
	};

	return (
		<div className="ablocks-control ablocks-control--backgroundOverlay">
			<NormalHoverTabs
				normal={
					<BackgroundOverlayAllOptions
						{...props}
						deviceType={deviceType}
						changeHandler={changeHandler}
						onChangeHandler={onChangeHandler}
					/>
				}
				hover={
					<BackgroundOverlayAllOptions
						{...props}
						hover
						deviceType={deviceType}
						changeHandler={changeHandler}
						onChangeHandler={onChangeHandler}
					/>
				}
			/>
		</div>
	);
}
ABlocksBackgroundOverlayControl.propTypes = propTypes;
ABlocksBackgroundOverlayControl.defaultProps = defaultProps;
