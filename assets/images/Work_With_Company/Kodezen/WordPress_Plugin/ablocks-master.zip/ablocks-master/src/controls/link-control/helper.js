export const getAttributeDefaultValue = () => {
	return {
		linkDestination: '',
		href: '',
		lightbox: '',
		linkTarget: '',
		rel: '',
		noFollow: '',
		keyValue: '',
		linkClass: '',
	};
};

export const getAttribute = (attributeName) => {
	return {
		[attributeName]: {
			type: 'object',
			default: getAttributeDefaultValue(),
		},
	};
};

export const DynamicTag = ({ condition, tagMapping, children }) => {
	const { tag: Tag, attributes } = tagMapping[condition] || {
		tag: 'div',
		attributes: { className: 'default-class', id: 'default-id' },
	};

	return <Tag {...attributes}>{children}</Tag>;
};

export const getAnchorKeyValueAttributes = (keyValuePairs) => {
	const anchorKeyValueAttributes = {};
	if (keyValuePairs) {
		keyValuePairs.split(',').forEach((pair) => {
			const [key, value] = pair.split('|');
			anchorKeyValueAttributes[key] = value || '';
		});
	}
	return anchorKeyValueAttributes;
};
