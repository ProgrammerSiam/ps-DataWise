import { __ } from '@wordpress/i18n';
import ABlocksRangeControl from '@Controls/range';
import AblocksPopover from '@Components/popover';
import ControlLabel from '@Components/control-label';
import Button from '@Components/Button';
import { useRef, useState } from 'react';

const ABlocksSkew = ({ label, hover, resetHandler, ...props }) => {
	const [isVisible, setIsVisible] = useState(false);
	const anchorRef = useRef(null);
	let attributeObjectKeyForSkewX = 'skewX';
	let attributeObjectKeyForSkewY = 'skewY';

	if (hover) {
		attributeObjectKeyForSkewX = 'skewXH';
		attributeObjectKeyForSkewY = 'skewYH';
	}

	const handleReset = () =>
		resetHandler({
			[attributeObjectKeyForSkewX]: '',
			[attributeObjectKeyForSkewY]: '',
		});

	const commonProps = {
		...props,
		min: -360,
		max: 360,
	};

	const togglePopoverVisibility = () => {
		setIsVisible(!isVisible);
	};

	return (
		<div className="ablocks-control ablocks-control-color-gradient-root-wrapper">
			{label && (
				<div className="ablocks-control-label">
					<ControlLabel label={label} isResponsive={false} />
				</div>
			)}
			<div className="ablocks-control-color-gradient">
				<div className="ablocks-component-popover">
					<div className="ablocks-component-popover__field">
						<div
							className="ablocks-component-popover-toggler-wrapper"
							ref={anchorRef}
						>
							<Button
								ref={anchorRef}
								onClick={togglePopoverVisibility}
								icon={
									<span className="ablocks-icon ablocks-icon--edit"></span>
								}
								preset="transparent"
								className={
									isVisible
										? 'ablocks-component-popover__field--active'
										: ''
								}
							/>
						</div>
					</div>
					{isVisible && (
						<AblocksPopover
							label={__('Skew', 'ablocks')}
							isShowPrimaryLabel={false}
							isReset={true}
							handleReset={handleReset}
							isVisible={isVisible}
							toggleVisible={setIsVisible}
							anchorRef={anchorRef}
						>
							<ABlocksRangeControl
								{...commonProps}
								label={__('Skew X', 'ablocks')}
								isInline={false}
								attributeObjectKey={attributeObjectKeyForSkewX}
							/>
							<ABlocksRangeControl
								{...commonProps}
								label={__('Skew Y', 'ablocks')}
								isInline={false}
								attributeObjectKey={attributeObjectKeyForSkewY}
							/>
						</AblocksPopover>
					)}
				</div>
			</div>
		</div>
	);
};

export default ABlocksSkew;
