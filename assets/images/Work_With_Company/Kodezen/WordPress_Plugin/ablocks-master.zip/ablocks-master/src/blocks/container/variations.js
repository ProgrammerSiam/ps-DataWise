import { plugin_root_url as PluginURL } from '@Utils/helper';
export const variations = [
	{
		name: 'one-column',
		icon: (
			<img
				alt="one-column"
				className="ablocks-container-variation-image"
				src={PluginURL + '/assets/images/container-variations/1.svg'}
			/>
		),
		attributes: {
			variationSelected: true,
		},
		scope: ['block'],
	},
	{
		name: 'two-columns-split',
		icon: (
			<img
				alt="two-columns-split"
				className="ablocks-container-variation-image"
				src={PluginURL + '/assets/images/container-variations/2.svg'}
			/>
		),
		attributes: {
			variationSelected: true,
			wrapTablet: 'wrap',
		},
		isDefault: true,
		innerBlocks: [
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 50,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 50,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
		],
		scope: ['block'],
	},
	{
		name: 'three-columns-equal',
		icon: (
			<img
				alt="three-columns-equal"
				className="ablocks-container-variation-image"
				src={PluginURL + '/assets/images/container-variations/3.svg'}
			/>
		),
		attributes: {
			variationSelected: true,
			wrapTablet: 'wrap',
		},
		innerBlocks: [
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 33.33,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 33.33,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 33.33,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
		],
		scope: ['block'],
	},
	{
		name: 'four-columns-equal',
		icon: (
			<img
				alt="four-columns-equal"
				className="ablocks-container-variation-image"
				src={PluginURL + '/assets/images/container-variations/4.svg'}
			/>
		),
		attributes: {
			variationSelected: true,
			wrapTablet: 'wrap',
		},
		innerBlocks: [
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 25,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 25,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 25,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 25,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
		],
		scope: ['block'],
	},
	{
		name: '75-25',
		icon: (
			<img
				alt="75-25"
				className="ablocks-container-variation-image"
				src={PluginURL + '/assets/images/container-variations/5.svg'}
			/>
		),
		attributes: {
			variationSelected: true,
			wrapTablet: 'wrap',
		},
		innerBlocks: [
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 75,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 25,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
		],
		scope: ['block'],
	},
	{
		name: '25-75',
		icon: (
			<img
				alt="25-75"
				className="ablocks-container-variation-image"
				src={PluginURL + '/assets/images/container-variations/6.svg'}
			/>
		),
		attributes: {
			variationSelected: true,
			wrap: 'wrap',
		},
		innerBlocks: [
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 25,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 75,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
		],
		scope: ['block'],
	},
	{
		name: '50-50_50-50',
		icon: (
			<img
				alt="50-50_50-50"
				className="ablocks-container-variation-image"
				src={PluginURL + '/assets/images/container-variations/7.svg'}
			/>
		),
		attributes: {
			variationSelected: true,
			wrap: 'wrap',
		},
		innerBlocks: [
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 50,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 50,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 50,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 50,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
		],
		scope: ['block'],
	},
	{
		name: '33-33-33_33-33-33',
		icon: (
			<img
				alt="33-33-33_33-33-33"
				className="ablocks-container-variation-image"
				src={PluginURL + '/assets/images/container-variations/8.svg'}
			/>
		),
		attributes: {
			variationSelected: true,
			wrap: 'wrap',
		},
		innerBlocks: [
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 33,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 33,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 33,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 33,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 33,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 33,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
		],
		scope: ['block'],
	},
	{
		name: '25-50-25',
		icon: (
			<img
				alt="25-50-25"
				className="ablocks-container-variation-image"
				src={PluginURL + '/assets/images/container-variations/9.svg'}
			/>
		),
		attributes: {
			variationSelected: true,
			wrapTablet: 'wrap',
		},
		innerBlocks: [
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 25,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 50,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 25,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
		],
		scope: ['block'],
	},
	{
		name: '75-25_25-75',
		icon: (
			<img
				alt="75-25_25-75"
				className="ablocks-container-variation-image"
				src={PluginURL + '/assets/images/container-variations/10.svg'}
			/>
		),
		attributes: {
			variationSelected: true,
			wrap: 'wrap',
		},
		innerBlocks: [
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 75,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 25,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 25,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 75,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
		],
		scope: ['block'],
	},
	{
		name: '25-75_75-25',
		icon: (
			<img
				alt="25-75_75-25"
				className="ablocks-container-variation-image"
				src={PluginURL + '/assets/images/container-variations/11.svg'}
			/>
		),
		attributes: {
			variationSelected: true,
			wrap: 'wrap',
		},
		innerBlocks: [
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 25,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 75,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 75,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 25,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
		],
		scope: ['block'],
	},
	{
		name: '50-50_100',
		icon: (
			<img
				alt="50-50_100"
				className="ablocks-container-variation-image"
				src={PluginURL + '/assets/images/container-variations/12.svg'}
			/>
		),
		attributes: {
			variationSelected: true,
			wrap: 'wrap',
		},
		innerBlocks: [
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 50,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 50,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
			[
				'ablocks/container',
				{
					containerCustomWidth: {
						value: 100,
						valueUnit: '%',
						valueUnitTablet: '%',
						valueTablet: 100,
					},
				},
			],
		],
		scope: ['block'],
	},
];
