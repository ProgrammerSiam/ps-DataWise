import React from 'react';
import { __ } from '@wordpress/i18n';
import { InspectorControls } from '@wordpress/block-editor';
import ABlocksPanelBody from '@Components/panel-body';
import InspectorTabs from '@Components/inspector-tabs';
import ABlocksButtonGroupControl from '@Components/button-group';
import ABlocksRangeControl from '@Controls/range';
import GetDeviceType from '@Utils/get-device-type';
const propTypes = {};
const defaultProps = {};

export default function Settings(props) {
	const { attributes, setAttributes } = props;
	const {
		isRootContainer,
		contentBoxWidth,
		containerCustomWidth,
		containerWidthType,
		innerWidthType,
		minimumHeight = {},
		gap = {},
		overflow,
	} = attributes;

	const deviceType = GetDeviceType();

	return (
		<React.Fragment>
			<InspectorControls>
				<div className="ablocks-block-container-settings-wrapper">
					<InspectorTabs
						attributes={attributes}
						setAttributes={setAttributes}
					>
						<ABlocksPanelBody
							title={__('Container', 'ablocks')}
							initialOpen={true}
						>
							{isRootContainer && (
								<>
									<ABlocksButtonGroupControl
										isResponsive={false}
										allowDeselect={false}
										label={__('Container Width', 'ablocks')}
										options={[
											{
												value: 'alignfull',
												label: __(
													'Full Width',
													'ablocks'
												),
											},
											{
												value: 'alignwide',
												label: __('Boxed', 'ablocks'),
											},
											{
												value: 'default',
												label: __('Custom', 'ablocks'),
											},
										]}
										attributeName="containerWidthType"
										attributeValue={containerWidthType}
										setAttributes={setAttributes}
									/>
									{'alignfull' === containerWidthType && (
										<>
											<ABlocksButtonGroupControl
												isResponsive={false}
												allowDeselect={false}
												label={__(
													'Content Width',
													'ablocks'
												)}
												options={[
													{
														value: 'alignwide',
														label: __(
															'Boxed',
															'ablocks'
														),
													},
													{
														value: 'alignfull',
														label: __(
															'Full Width',
															'ablocks'
														),
													},
												]}
												attributeName="innerWidthType"
												attributeValue={innerWidthType}
												setAttributes={setAttributes}
											/>

											{'alignwide' === innerWidthType && (
												<ABlocksRangeControl
													label={__(
														'Content Box Width',
														'ablocks'
													)}
													attributeName="contentBoxWidth"
													attributeObjectKey="value"
													attributeValue={
														contentBoxWidth
													}
													setAttributes={
														setAttributes
													}
													isInline={false}
													hasUnit={true}
													unitOptions={[
														{
															value: 'px',
															label: 'px',
														},
														{
															value: '%',
															label: '%',
														},
														{
															value: 'em',
															label: 'em',
														},
														{
															value: 'rem',
															label: 'rem',
														},
														{
															value: 'vw',
															label: 'vw',
														},
													]}
													min={0}
													max={
														['vw', '%'].includes(
															contentBoxWidth[
																'valueUnit' +
																	deviceType
															]
														)
															? 100
															: 1600
													}
												/>
											)}
										</>
									)}
								</>
							)}
							{(!isRootContainer ||
								'default' === containerWidthType) && (
								<ABlocksRangeControl
									label={__('Custom Width', 'ablocks')}
									attributeName="containerCustomWidth"
									attributeObjectKey="value"
									attributeValue={containerCustomWidth}
									setAttributes={setAttributes}
									isInline={false}
									hasUnit={true}
									unitOptions={[
										{
											value: 'px',
											label: 'px',
										},
										{
											value: '%',
											label: '%',
										},
										{
											value: 'em',
											label: 'em',
										},
										{
											value: 'rem',
											label: 'rem',
										},
										{
											value: 'vw',
											label: 'vw',
										},
									]}
									min={0}
									max={
										['vw', '%'].includes(
											containerCustomWidth[
												'valueUnit' + deviceType
											]
										)
											? 100
											: 1600
									}
								/>
							)}

							<ABlocksRangeControl
								label={__('Minimum Height')}
								attributeName="minimumHeight"
								attributeObjectKey="value"
								attributeValue={minimumHeight}
								setAttributes={setAttributes}
								isInline={false}
								hasUnit={true}
								unitOptions={[
									{
										value: 'px',
										label: 'px',
									},
									{
										value: 'em',
										label: 'em',
									},
									{
										value: 'rem',
										label: 'rem',
									},
									{
										value: 'vh',
										label: 'vh',
									},
								]}
								min={0}
								max={
									'vh' ===
									minimumHeight['valueUnit' + deviceType]
										? 100
										: 1600
								}
							/>

							<ABlocksButtonGroupControl
								isResponsive={false}
								label={__('Overflow', 'ablocks')}
								options={[
									{
										label: 'Visible',
										value: 'visible',
									},
									{
										label: 'Hidden',
										value: 'hidden',
									},
									{
										label: 'Auto',
										value: 'auto',
									},
								]}
								attributeName="overflow"
								attributeValue={overflow}
								setAttributes={setAttributes}
							/>

							<hr />
							<h3>Items</h3>
							<ABlocksButtonGroupControl
								isInline
								label={__('Direction', 'ablocks')}
								options={[
									{
										label: __('Row', 'ablocks'),
										value: 'row',
										icon: (
											<span className="ablocks-icon ablocks-icon--arrow-right" />
										),
									},
									{
										label: __('Column', 'ablocks'),
										value: 'column',
										icon: (
											<span className="ablocks-icon ablocks-icon--arrow-down" />
										),
									},
									{
										label: __('Row Reverse', 'ablocks'),
										value: 'row-reverse',
										icon: (
											<span className="ablocks-icon ablocks-icon--arrow-left" />
										),
									},
									{
										label: __('Column Reverse', 'ablocks'),
										value: 'column-reverse',
										icon: (
											<span className="ablocks-icon ablocks-icon--arrow-up" />
										),
										tooltipPosition: 'top-left',
									},
								]}
								attributeName="direction"
								attributeValue={
									attributes['direction' + deviceType]
								}
								setAttributes={setAttributes}
							/>

							<div
								className={`ablocks-buttongroup-flex-justify-content ablocks-rotate-children-icons-for-${
									attributes['direction' + deviceType] ||
									'row'
								}`}
							>
								<ABlocksButtonGroupControl
									isInline
									label={__('Justify', 'ablocks')}
									options={[
										{
											label: __('Flex Start', 'ablocks'),
											value: 'flex-start',
											icon: (
												<span className="ablocks-icon ablocks-icon--justify-start" />
											),
										},
										{
											label: __('Center', 'ablocks'),
											value: 'center',
											icon: (
												<span className="ablocks-icon ablocks-icon--justify-Center" />
											),
										},
										{
											label: __('Flex End', 'ablocks'),
											value: 'flex-end',
											icon: (
												<span className="ablocks-icon ablocks-icon--justify-end" />
											),
										},
										{
											label: __(
												'Space Between',
												'ablocks'
											),
											value: 'space-between',
											icon: (
												<span className="ablocks-icon ablocks-icon--justify-spacebetween" />
											),
										},
										{
											label: __(
												'Space Around',
												'ablocks'
											),
											value: 'space-around',
											icon: (
												<span className="ablocks-icon ablocks-icon--justify-spacearound" />
											),
										},
										{
											label: __(
												'Space Evenly',
												'ablocks'
											),
											value: 'space-evenly',
											icon: (
												<span className="ablocks-icon ablocks-icon--justify-spaceevenly" />
											),
											tooltipPosition: 'top-left',
										},
									]}
									attributeName="justify"
									attributeValue={
										attributes['justify' + deviceType]
									}
									setAttributes={setAttributes}
								/>
							</div>

							<div
								className={`ablocks-buttongroup-flex-align-items ablocks-rotate-children-icons-for-${
									attributes['direction' + deviceType] ||
									'row'
								}`}
							>
								<ABlocksButtonGroupControl
									isInline
									label={__('Align Items', 'ablocks')}
									options={[
										{
											label: __('Start', 'ablocks'),
											value: 'flex-start',
											icon: (
												<span className="ablocks-icon ablocks-icon--align-start" />
											),
										},
										{
											label: __('Center', 'ablocks'),
											value: 'center',
											icon: (
												<span className="ablocks-icon ablocks-icon--align-center-two" />
											),
										},
										{
											label: __('End', 'ablocks'),
											value: 'flex-end',
											icon: (
												<span className="ablocks-icon ablocks-icon--align-end" />
											),
										},
										{
											label: __('Stretch', 'ablocks'),
											value: 'stretch',
											icon: (
												<span className="ablocks-icon ablocks-icon--align-stretch" />
											),
											tooltipPosition: 'top-left',
										},
									]}
									attributeName="align"
									attributeValue={
										attributes['align' + deviceType]
									}
									setAttributes={setAttributes}
								/>
							</div>

							<hr />

							<ABlocksRangeControl
								label={__('Columns Gap', 'ablocks')}
								attributeName="gap"
								attributeObjectKey="columnGap"
								attributeValue={gap}
								setAttributes={setAttributes}
								isInline={false}
								hasUnit={true}
								unitOptions={[
									{
										value: 'px',
										label: 'px',
									},
									{
										value: '%',
										label: '%',
									},
									{
										value: 'em',
										label: 'em',
									},
									{
										value: 'rem',
										label: 'rem',
									},
									{
										value: 'vw',
										label: 'vw',
									},
								]}
								min={0}
								max={
									['vw', '%'].includes(
										gap['columnGapUnit' + deviceType]
									)
										? 100
										: 1000
								}
							/>

							<ABlocksRangeControl
								label={__('Rows Gap', 'ablocks')}
								attributeName="gap"
								attributeObjectKey="rowGap"
								attributeValue={gap}
								setAttributes={setAttributes}
								isInline={false}
								hasUnit={true}
								unitOptions={[
									{
										value: 'px',
										label: 'px',
									},
									{
										value: '%',
										label: '%',
									},
									{
										value: 'em',
										label: 'em',
									},
									{
										value: 'rem',
										label: 'rem',
									},
									{
										value: 'vw',
										label: 'vw',
									},
								]}
								min={0}
								max={
									['vw', '%'].includes(
										gap['rowGapUnit' + deviceType]
									)
										? 100
										: 1000
								}
							/>

							<ABlocksButtonGroupControl
								isInline
								label={__('Wrap', 'ablocks')}
								options={[
									{
										label: __('Wrap', 'ablocks'),
										value: 'wrap',
										icon: (
											<span className="ablocks-icon ablocks-icon--wrap" />
										),
									},
									{
										label: __('No Wrap', 'ablocks'),
										value: 'nowrap',
										icon: (
											<span className="ablocks-icon ablocks-icon--no-wrap" />
										),
									},
									{
										label: __('Wrap Reverse', 'ablocks'),
										value: 'wrap-reverse',
										icon: (
											<span className="ablocks-icon ablocks-icon--wrap ablocks-icon-rotate-180-deg" />
										),
										tooltipPosition: 'top-left',
									},
								]}
								attributeName="wrap"
								attributeValue={attributes['wrap' + deviceType]}
								setAttributes={setAttributes}
							/>

							{/*  */}
						</ABlocksPanelBody>
					</InspectorTabs>
				</div>
			</InspectorControls>
		</React.Fragment>
	);
}

Settings.propTypes = propTypes;
Settings.defaultProps = defaultProps;
