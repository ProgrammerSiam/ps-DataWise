export const formatClassName = (names) => names.filter(Boolean).join(' ');
