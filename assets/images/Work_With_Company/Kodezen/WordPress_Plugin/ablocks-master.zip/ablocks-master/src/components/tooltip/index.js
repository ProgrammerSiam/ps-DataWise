import React, { useState } from 'react';
import './editor.scss';
import PropTypes from 'prop-types';
const defaultProps = {
	tooltipText: '',
	children: '',
	position: 'top',
};
const propsTypes = {
	tooltipText: PropTypes.string,
	children: PropTypes.node,
};
const Tooltip = (props) => {
	const { tooltipText, children, position } = props;
	const [showTooltip, setShowTooltip] = useState(false);
	const handleMouseEnter = () => {
		setShowTooltip(true);
	};

	const handleMouseLeave = () => {
		setShowTooltip(false);
	};
	return (
		<div
			className={`ablocks-tooltip tooltip--${position}`}
			onMouseEnter={handleMouseEnter}
			onMouseLeave={handleMouseLeave}
		>
			{showTooltip && (
				<div className="ablocks-tooltip__text  ">{tooltipText}</div>
			)}
			{children}
		</div>
	);
};

Tooltip.defaultProps = defaultProps;
Tooltip.propsTypes = propsTypes;
export default Tooltip;
