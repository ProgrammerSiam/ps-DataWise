import {
	getWrapperCSS,
	getContainerCSS,
	getContainerBeforeCSS,
	getContainerBeforeHoverCSS,
	getWrapperHoverCSS,
	getContainerHoverCSS,
	getWrapperDeviceResponsiveCSS,
	getWrapperDeviceResponsiveInnerCSS,
} from '@Global/AdvancedSettings/styling';

class CSSGenerator {
	constructor(attributes = {}) {
		this.parentClass = `.editor-styles-wrapper .ablocks-block-${attributes.block_id}`;
		this.classStyles = [];
		// Alert - don't touch here
		this.addClassStyles(
			'{{WRAPPER}}',
			getWrapperCSS(attributes),
			getWrapperCSS(attributes, 'Tablet'),
			getWrapperCSS(attributes, 'Mobile')
		);
		this.addClassStyles(
			'{{WRAPPER}}:hover',
			getWrapperHoverCSS(attributes),
			getWrapperHoverCSS(attributes, 'Tablet'),
			getWrapperHoverCSS(attributes, 'Mobile')
		);
		this.addClassStyles(
			'{{WRAPPER}}.ablocks-hide-on-desktop,{{WRAPPER}}.ablocks-hide-on-tablet,{{WRAPPER}}.ablocks-hide-on-mobile',
			getWrapperDeviceResponsiveCSS(attributes),
			getWrapperDeviceResponsiveCSS(attributes, 'Tablet'),
			getWrapperDeviceResponsiveCSS(attributes, 'Mobile')
		);

		this.addClassStyles(
			'{{WRAPPER}}::before',
			getContainerBeforeCSS(attributes),
			getContainerBeforeCSS(attributes, 'Tablet'),
			getContainerBeforeCSS(attributes, 'Mobile')
		);

		this.addClassStyles(
			'{{WRAPPER}}:hover::before',
			getContainerBeforeHoverCSS(attributes),
			getContainerBeforeHoverCSS(attributes, 'Tablet'),
			getContainerBeforeHoverCSS(attributes, 'Mobile')
		);

		this.addClassStyles(
			'{{WRAPPER}}:hover > .ablocks-block-container',
			getContainerHoverCSS(attributes),
			getContainerHoverCSS(attributes, 'Tablet'),
			getContainerHoverCSS(attributes, 'Mobile')
		);
		this.addClassStyles(
			'{{WRAPPER}} > .ablocks-block-container',
			getContainerCSS(attributes),
			getContainerCSS(attributes, 'Tablet'),
			getContainerCSS(attributes, 'Mobile')
		);
		this.addClassStyles(
			'{{WRAPPER}}.ablocks-hide-on-desktop .ablocks-block-container,{{WRAPPER}}.ablocks-hide-on-tablet .ablocks-block-container,{{WRAPPER}}.ablocks-hide-on-mobile .ablocks-block-container',
			getWrapperDeviceResponsiveInnerCSS(attributes),
			getWrapperDeviceResponsiveInnerCSS(attributes, 'Tablet'),
			getWrapperDeviceResponsiveInnerCSS(attributes, 'Mobile')
		);
	}

	addClassStyles(
		className,
		desktopStyles,
		tabletStyles = {},
		mobileStyles = {}
	) {
		this.classStyles.push({
			className,
			desktopStyles,
			tabletStyles,
			mobileStyles,
		});
	}

	generateCSS() {
		const cssString = this.classStyles
			.map(({ className, desktopStyles, tabletStyles, mobileStyles }) => {
				const desktopCSS = this.minifyCSS(
					this.generateCSSForMediaQuery('desktop', desktopStyles)
				);
				const tabletCSS = this.minifyCSS(
					this.generateCSSForMediaQuery('tablet', tabletStyles)
				);
				const mobileCSS = this.minifyCSS(
					this.generateCSSForMediaQuery('mobile', mobileStyles)
				);

				const selectorWithParent = this.getParentSelector(className);

				const cssBlocks = [];

				if (desktopCSS) {
					cssBlocks.push(`${selectorWithParent} { ${desktopCSS} }`);
				}

				if (tabletCSS) {
					cssBlocks.push(
						`@media screen and (max-width: ${this.getBreakpoint(
							'tablet'
						)}) { ${selectorWithParent} { ${tabletCSS} } }`
					);
				}

				if (mobileCSS) {
					cssBlocks.push(
						`@media screen and (max-width: ${this.getBreakpoint(
							'mobile'
						)}) { ${selectorWithParent} { ${mobileCSS} } }`
					);
				}

				return cssBlocks.join('\n\n');
			})
			.join('\n\n');
		return cssString.replace(/\s+/g, ' ');
	}

	generateCSSForMediaQuery(mediaQuery, styles) {
		if (Object.keys(styles).length === 0) {
			return '';
		}

		const cssString = Object.keys(styles)
			.map((property) => `${property}: ${styles[property]};`)
			.join('\n');

		return cssString;
	}

	getBreakpoint(mediaQuery) {
		switch (mediaQuery) {
			case 'tablet':
				return '800px';
			case 'mobile':
				return '480px';
			default:
				return '1200px';
		}
	}

	minifyCSS(cssString) {
		// Remove comments (/* ... */)
		cssString = cssString.replace(/\/\*[\s\S]*?\*\//g, '');
		// Remove newlines and multiple spaces
		cssString = cssString.replace(/\s+/g, ' ');
		// Remove spaces around colons, semicolons, curly braces, and commas
		cssString = cssString.replace(/\s?([:,;{}])\s?/g, '$1');
		return cssString;
	}

	getParentSelector(className) {
		return this.parentClass
			? className.replaceAll('{{WRAPPER}}', this.parentClass)
			: className;
	}
}

export default CSSGenerator;
