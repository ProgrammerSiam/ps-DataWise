import PropTypes from 'prop-types';
import NormalHoverTabs from '@Components/normal-hover-tabs';
import TransformAllOptions from './options';
import { objectUniqueCheck } from '@Utils/helper';
import { getAttributeDefaultValue } from './helper';
import './editor.scss';

const propTypes = {
	attributeName: PropTypes.string,
	attributeValue: PropTypes.any,
	setAttributes: PropTypes.func,
};

const ABlocksTransformControl = (props) => {
	const { attributeName, setAttributes, attributeValue } = props;

	const onChangeHandler = (controlValue, attributeObjectKey) => {
		return setAttributes({
			[attributeName]: objectUniqueCheck(getAttributeDefaultValue(), {
				...attributeValue,
				[attributeObjectKey]: controlValue,
			}),
		});
	};

	return (
		<div className="ablocks-control ablocks-control--transform">
			<NormalHoverTabs
				normal={
					<TransformAllOptions
						{...props}
						onChangeHandler={onChangeHandler}
					/>
				}
				hover={
					<TransformAllOptions
						hover
						{...props}
						onChangeHandler={onChangeHandler}
					/>
				}
			/>
		</div>
	);
};

ABlocksTransformControl.propTypes = propTypes;
export default ABlocksTransformControl;
