export const { ajax_url, namespace, plugin_root_path, plugin_root_url } =
	window.ABlocksGlobal ?? {};

export const objectUniqueCheck = (defaultObject, savedObject) => {
	const changes = {};
	for (const key in savedObject) {
		const defaultValue = defaultObject[key];
		const changeValue = savedObject[key];
		if (
			changeValue !== null &&
			JSON.stringify(defaultValue) !== JSON.stringify(changeValue)
		) {
			changes[key] = changeValue;
		}
	}
	return changes;
};

export const getUnit = (attributeValue, device = '') => {
	const unit = attributeValue.unit;

	if (!device) {
		return unit;
	}

	const unitTablet = attributeValue.unitTablet;
	const unitMobile = attributeValue.unitMobile;

	if (device === 'Tablet') {
		return unitTablet || unit;
	} else if (device === 'Mobile') {
		return unitMobile || unitTablet || unit;
	}

	return unit;
};

export const noop = () => {};
