export const getAttributeDefaultValue = () => {
	return {
		color: '#fffff',
		customColor: '',
		defaultColor: '',
	};
};

export const getAttribute = (attributeName, isResponsive = false) => {
	return {
		[attributeName]: {
			type: 'object',
			default: getAttributeDefaultValue(isResponsive),
		},
	};
};
