import { useState, useEffect } from 'react';

import { hsvaSame } from './utils/convert';
import { equalColorObjects } from './utils/compare';
import { Hue } from './components/Hue';
import { Saturation } from './components/Saturation';
import { Alpha } from './components/Alpha';
import { useColorManipulation } from './hooks/useColorManipulation';
import { InputColor } from './components/InputColor';

import {
	colorStringGetTypeAndHsvaObject,
	onUpdateColorString,
} from './utils/helperFunctions';

import './editor.scss';

const colorModel = {
	defaultColor: { h: 285, s: 100, v: 80, a: 1 },
	toHsva: hsvaSame,
	fromHsva: hsvaSame,
	equal: equalColorObjects,
};

const initialTypeAndHsvaObject = {
	type: 'hex',
	hsva: { h: 285, s: 100, v: 80, a: 1 },
};

let ablocksHelperOnChangeTimeoutId;

export const ColorPicker = ({ value, onChange }) => {
	const { type, hsva: hsvaObject } =
		colorStringGetTypeAndHsvaObject(value) || initialTypeAndHsvaObject;

	const [colorType, setColorType] = useState(type);
	const [color, setColor] = useState(
		hsvaObject || initialTypeAndHsvaObject.hsva
	);
	const [alpha, setAlpha] = useState(hsvaObject?.a * 100);

	const onColorChange = (changeColor) => {
		onUpdateColorString({ hsva: changeColor, colorType, onChange });
		setColor(changeColor);
	};
	const [hsva, updateHsva] = useColorManipulation(
		colorModel,
		color,
		onColorChange
	);

	const onInputColorChange = (changeHsvaObject, changeType) => {
		if (changeHsvaObject.a === 1 && hsva.a) {
			changeHsvaObject.a = hsva.a;
		}
		setColor(changeHsvaObject);
		onUpdateColorString({
			hsva: changeHsvaObject,
			colorType: changeType,
			onChange,
		});
	};

	useEffect(() => {
		clearTimeout(ablocksHelperOnChangeTimeoutId);
		ablocksHelperOnChangeTimeoutId = setTimeout(() => {
			setAlpha(Math.round(hsva.a * 100));
		}, 300);
		return () => {
			clearTimeout(ablocksHelperOnChangeTimeoutId);
		};
	}, [hsva.a]);

	const handleAphaChange = (val) => {
		const alphaValue = parseInt(val);
		if (alphaValue > 100 || alphaValue < 0) {
			return false;
		}
		setAlpha(alphaValue);
		clearTimeout(ablocksHelperOnChangeTimeoutId);
		ablocksHelperOnChangeTimeoutId = setTimeout(() => {
			const newColor = {
				...color,
				a: alphaValue / 100,
			};
			setColor(newColor);
			onUpdateColorString({ hsva: newColor, colorType, onChange });
		}, 300);
	};

	return (
		<div className="ablocks-control ablocks-control--customizable-color-picker">
			<Saturation hsva={hsva} onChange={updateHsva} />
			<Hue hue={hsva.h} onChange={updateHsva} />
			<Alpha hsva={hsva} onChange={updateHsva} />
			<InputColor
				setColorType={setColorType}
				colorType={colorType}
				hsva={hsva}
				onChange={onInputColorChange}
				alpha={alpha}
				handleAphaChange={handleAphaChange}
			/>
		</div>
	);
};
