import { getUnit } from '@Utils/helper';

export const typeOptions = [
	{ label: 'None', value: 'none' },
	{ label: 'Color', value: 'color' },
	{ label: 'Image', value: 'image' },
];

export const blendModeOptions = [
	{ label: 'Normal', value: 'normal' },
	{ label: 'Multiply', value: 'multiply' },
	{ label: 'Screen', value: 'screen' },
	{ label: 'Overlay', value: 'overlay' },
	{ label: 'Darken', value: 'darken' },
	{ label: 'Lighten', value: 'lighten' },
	{ label: 'Color Dodge', value: 'color-dodge' },
	{ label: 'Saturation', value: 'saturation' },
	{ label: 'Color', value: 'color' },
	{ label: 'Luminosity', value: 'luminosity' },
];

export const getAttributeDefaultValue = (isResponsive = false) => {
	if (isResponsive) {
		return {
			backgroundOverlayType: 'none',
			backgroundOverlayTypeH: 'none',
			// Normal background image attritbute
			imgId: '',
			imgIdTablet: '',
			imgIdMobile: '',
			imgUrl: '',
			imgUrlTablet: '',
			imgUrlMobile: '',
			imgSize: '',
			imgSizeTablet: '',
			imgSizeMobile: '',
			imgPosition: '',
			imgPositionTablet: '',
			imgPositionMobile: '',
			imgXPositionUnit: 'px',
			imgXPositionTabletUnit: '',
			imgXPositionMobileUnit: '',
			imgXPosition: '',
			imgXPositionTablet: '',
			imgXPositionMobile: '',
			imgYPositionUnit: 'px',
			imgYPositionUnitTablet: '',
			imgYPositionUnitMobile: '',
			imgYPosition: '',
			imgYPositionTablet: '',
			imgYPositionMobile: '',
			imgAttachment: '',
			imgRepeat: '',
			imgRepeatTablet: '',
			imgRepeatMobile: '',
			imgDisplaySize: '',
			imgDisplaySizeTablet: '',
			imgDisplaySizeMobile: '',
			imgDisplaySizeWidth: '',
			imgDisplaySizeWidthTablet: '',
			imgDisplaySizeWidthMobile: '',
			imgDisplaySizeWidthUnit: 'px',
			imgDisplaySizeWidthUnitTablet: '',
			imgDisplaySizeWidthUnitMobile: '',
			// Hover background image attritbute
			imgIdH: '',
			imgIdTabletH: '',
			imgIdMobileH: '',
			imgUrlH: '',
			imgUrlHTablet: '',
			imgUrlHMobile: '',
			imgSizeH: '',
			imgSizeHTablet: '',
			imgSizeHMobile: '',
			imgPositionH: '',
			imgPositionHTablet: '',
			imgPositionHMobile: '',
			imgXPositionUnitH: 'px',
			imgXPositionUnitHTablet: '',
			imgXPositionUnitHMobile: '',
			imgXPositionH: '',
			imgXPositionHTablet: '',
			imgXPositionHMobile: '',
			imgYPositionUnitH: 'px',
			imgYPositionUnitHTablet: '',
			imgYPositionUnitHMobile: '',
			imgYPositionH: '',
			imgYPositionHTablet: '',
			imgYPositionHMobile: '',
			imgAttachmentH: '',
			imgRepeatH: '',
			imgRepeatHTablet: '',
			imgRepeatHMobile: '',
			imgDisplaySizeH: '',
			imgDisplaySizeHTablet: '',
			imgDisplaySizeHMobile: '',
			imgDisplaySizeWidthH: '',
			imgDisplaySizeWidthHTablet: '',
			imgDisplaySizeWidthHMobile: '',
			imgDisplaySizeWidthHUnit: 'px',
			imgDisplaySizeWidthHUnitTablet: '',
			imgDisplaySizeWidthHUnitMobile: '',

			blendMode: '',
			blur: '',
			brightness: '',
			contrast: '',
			saturate: '',
			hue: '',
			blendModeH: '',

			transitionDuration: '',
		};
	}
	return {
		backgroundOverlayType: 'none',
		backgroundOverlayTypeH: 'none',
		// Normal background image attritbute
		imgId: '',
		imgUrl: '',
		imgSize: '',
		imgPosition: '',
		imgAttachment: '',
		imgRepeat: '',
		imgDisplaySize: '',
		imgdisplaySizeWidth: '',
		imgDisplaySizeWidthUnit: 'px',
		imgXPositionUnit: 'px',
		imgXPosition: '',
		imgYPositionUnit: 'px',
		imgYPosition: '',
		// Hover background image attritbute
		imgIdH: '',
		imgUrlH: '',
		imgSizeH: '',
		imgPositionH: '',
		imgXPositionUnitH: 'px',
		imgXPositionH: '',
		imgYPositionUnitH: 'px',
		imgYPositionH: '',
		imgAttachmentH: '',
		imgRepeatH: '',
		imgDisplaySizeH: '',
		imgDisplaySizeWidthH: '',
		imgDisplaySizeWidthHUnit: 'px',

		blendMode: '',
		blurH: '',
		brightnessH: '',
		contrastH: '',
		saturateH: '',
		hueH: '',
		blendModeH: '',

		transitionDuration: '',
	};
};

export const getAttribute = (attributeName, isResponsive = false) => {
	if (isResponsive) {
		return {
			[attributeName]: {
				type: 'object',
				default: getAttributeDefaultValue(isResponsive),
			},
		};
	}
	return {
		[attributeName]: {
			type: 'object',
			default: getAttributeDefaultValue(isResponsive),
		},
	};
};

export const getBeforeCSS = (attributeValue, property = '', device = '') => {
	const value = {
		...getAttributeDefaultValue(device ? true : false),
		...attributeValue,
	};

	const unitXPositionUnit = getUnit(
		{
			unit: value.imgXPositionUnit,
			unitTablet: value.imgXPositionUnitTablet,
			unitMobile: value.imgXPositionUnitMobile,
		},
		device
	);
	const unitYPositionUnit = getUnit(
		{
			unit: value.imgYPositionUnit,
			unitTablet: value.imgYPositionUnitTablet,
			unitMobile: value.imgYPositionUnitMobile,
		},
		device
	);
	const displaySizeWidthUnit = getUnit(
		{
			unit: value.displaySizeWidthUnit,
			unitTablet: value.displaySizeWidthUnitTablet,
			unitMobile: value.displaySizeWidthUnitMobile,
		},
		device
	);

	const css = {};

	if (value.backgroundOverlayType === 'image') {
		if (
			value['imgUrl' + device] !== '' &&
			value['imgUrl' + device] !== undefined
		) {
			const filterValues = {
				brightness: `brightness(${value?.brightness ?? 100}%)`,
				contrast: `contrast(${value?.contrast ?? 100}%)`,
				saturate: `saturate(${value?.saturate ?? 100}%)`,
				blur: `blur(${value?.blur ?? 0}px)`,
				hue: `hue-rotate(${value?.hue ?? 0}deg)`,
			};
			// background image and ::before psoudo element
			css[`${property}-image`] = `url("${value['imgUrl' + device]}")`;
			css.position = 'absolute';
			css.content = `''`;
			css.top = '0';
			css.left = '0';
			css.width = '100%';
			css.height = '100%';
			css.opacity = '0.5';
			css['z-index'] = '98';
			// background-position css
			if (value['imgPosition' + device] !== '') {
				if (value['imgPosition' + device] === 'custom') {
					css[`${property}-position`] = `${
						value['imgXPosition' + device]
							? value['imgXPosition' + device]
							: '0'
					}${unitXPositionUnit} ${
						value['imgYPosition' + device]
							? value['imgYPosition' + device]
							: '0'
					}${unitYPositionUnit}`;
				} else {
					css[`${property}-position`] = value['imgPosition' + device];
				}
			}
			// background-attachments css
			if (value['imgAttachment' + device] !== '') {
				css[`${property}-attachment`] = value['imgAttachment' + device];
			}
			// background-repeat css
			if (value['imgRepeat' + device] !== '') {
				css[`${property}-repeat`] = value['imgRepeat' + device];
			}
			// background-size css
			if (value['imgDisplaySize' + device] !== '') {
				if (value['imgDisplaySize' + device] === 'custom') {
					css[`${property}-size`] = `${
						value['imgDisplaySizeWidth' + device]
					}${displaySizeWidthUnit}`;
				} else {
					css[`${property}-size`] = value['imgDisplaySize' + device];
				}
			}
			// opacity css
			if (
				value['opacity' + device] !== '' &&
				value['opacity' + device] !== undefined
			) {
				css.opacity = value['opacity' + device];
			}
			if (value.blendMode !== '' && value.blendMode !== undefined) {
				css['mix-blend-mode'] = value.blendMode;
			}
			// Filter css
			css.filter = Object.values(filterValues).join(' ');
			if (
				value.transitionDuration !== '' &&
				value.transitionDuration !== undefined
			) {
				css.transition = `all ${value.transitionDuration}s`;
			}
		}
	} else if (value.backgroundOverlayType === 'video') {
		// use background overlay video proprety here
	} else if (value.backgroundOverlayType === 'color') {
		// use background overlay color proprety here
	}

	return css;
};

export const getBeforeHoverCSS = (
	attributeValue,
	property = '',
	device = ''
) => {
	const value = {
		...getAttributeDefaultValue(device ? true : false),
		...attributeValue,
	};

	const unitXPositionUnitH = getUnit(
		{
			unit: value.imgXPositionUnitH,
			unitTablet: value.imgXPositionUnitHTablet,
			unitMobile: value.imgXPositionUnitHMobile,
		},
		device
	);
	const unitYPositionUnitH = getUnit(
		{
			unit: value.imgYPositionUnitH,
			unitTablet: value.imgYPositionUnitHTablet,
			unitMobile: value.imgYPositionUnitHMobile,
		},
		device
	);
	const imgDisplaySizeWidthHUnit = getUnit(
		{
			unit: value.imgDisplaySizeWidthHUnit,
			unitTablet: value.imgDisplaySizeWidthHUnitTablet,
			unitMobile: value.imgDisplaySizeWidthHMobile,
		},
		device
	);

	const css = {};

	if (value.backgroundOverlayTypeH === 'image') {
		if (
			value['imgUrlH' + device] !== '' &&
			value['imgUrlH' + device] !== undefined
		) {
			const filterValuesH = {
				brightness: `brightness(${value?.brightnessH ?? 100}%)`,
				contrast: `contrast(${value?.contrastH ?? 100}%)`,
				saturate: `saturate(${value?.saturateH ?? 100}%)`,
				blur: `blur(${value?.blurH ?? 0}px)`,
				hue: `hue-rotate(${value?.hueH ?? 0}deg)`,
			};
			// background image and ::before psoudo element
			css[`${property}-image`] = `url("${value['imgUrlH' + device]}")`;
			css.position = 'absolute';
			css.content = `''`;
			css.top = '0';
			css.left = '0';
			css.width = '100%';
			css.height = '100%';
			css.opacity = '0.5';
			css['z-index'] = '98';
			// background-position hover css
			if (value['imgPositionH' + device] !== '') {
				if (value['imgPositionH' + device] === 'custom') {
					css[`${property}-position`] = `${
						value['imgXPositionH' + device]
							? value['imgXPositionH' + device]
							: '0'
					}${unitXPositionUnitH} ${
						value['imgYPositionH' + device]
							? value['imgYPositionH' + device]
							: '0'
					}${unitYPositionUnitH}`;
				} else {
					css[`${property}-position`] =
						value['imgPositionH' + device];
				}
			}
			// background-attachments hover css
			if (value.imgAttachmentH !== '') {
				css[`${property}-attachment`] = value.imgAttachmentH;
			}
			// background-repeat hover css
			if (value['imgRepeatH' + device] !== '') {
				css[`${property}-repeat`] = value['imgRepeatH' + device];
			}
			// background-size hover css
			if (value['imgDisplaySizeH' + device] !== '') {
				if (value['imgDisplaySizeH' + device] === 'custom') {
					css[`${property}-size`] = `${
						value['imgDisplaySizeWidthH' + device]
					}${imgDisplaySizeWidthHUnit}`;
				} else {
					css[`${property}-size`] = value['imgDisplaySizeH' + device];
				}
			}
			// background image opacity css
			if (
				value['opacityH' + device] !== '' &&
				value['opacityH' + device] !== undefined
			) {
				css.opacity = value['opacityH' + device];
			}
			if (value.blendModeH !== '' && value.blendModeH !== undefined) {
				css['mix-blend-mode'] = value.blendModeH;
			}

			css.filter = Object.values(filterValuesH).join(' ');
		}
	} else if (value.backgroundOverlayTypeH === 'video') {
		// use background overlay video proprety here
	} else if (value.backgroundOverlayTypeH === 'color') {
		// use background overlay color proprety here
	}

	return css;
};
