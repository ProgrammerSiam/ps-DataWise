import React from 'react';
import { __ } from '@wordpress/i18n';
import { InspectorControls } from '@wordpress/block-editor';
import ABlocksPanelBody from '@Components/panel-body';
import InspectorTabs from '@Components/inspector-tabs';
import Separator from '@Components/separator';
import ContentStyleTabs from '@Components/content-style-tabs';
import ABlocksAlignmentControl from '@Controls/alignment';
import ABlocksRangeControl from '@Controls/range';
import ABlocksSelectControl from '@Controls/select';
import ABlocksTextControl from '@Controls/text';
import ABlocksIconUploader from '@Controls/icon-upload';
import ABlocksColorGradient from '@Controls/color-gradient-control';
import ABlocksTypography from '@Controls/typography';
import ABlocksTextStroke from '@Controls/textStroke';
import {
	dividerPatternUrlOptions,
	dividerElementOptions,
	iconTypeOption,
} from './data';
const propTypes = {};
const defaultProps = {};

export default function Settings(props) {
	const { attributes, setAttributes } = props;
	const {
		dividerPatternUrl,
		element,

		alignment,
		color,

		elementText,
		elementTextColor,
		elementTextTypography,
		elementTextStroke,
		elementIconType,
		elementIconPrimaryColor,
		elementIconBackgroundColor,
	} = attributes;
	const dividerFind = dividerPatternUrlOptions?.find(
		(divider) => divider.value === dividerPatternUrl
	);
	const optionalStyleControlsRender = dividerFind?.optionalStyleControls?.map(
		(control, index) => {
			if (control === 'size') {
				return (
					<React.Fragment key={index}>
						<ABlocksRangeControl
							onChangeHandler={(value) =>
								setAttributes({ size: value })
							}
							label={__('Size', 'ablocks')}
							attributeName="size"
							attributeObjectKey="size"
							attributeValue={attributes}
							isInline={false}
							min={1}
							max={100}
							step={1}
							isResponsive={false}
						/>
						<Separator />
					</React.Fragment>
				);
			} else if (control === 'gap') {
				return (
					<React.Fragment key={index}>
						<ABlocksRangeControl
							label={__('Gap', 'ablocks')}
							attributeName="gap"
							attributeObjectKey="value"
							attributeValue={attributes?.gap}
							setAttributes={setAttributes}
							isInline={false}
							min={1}
							max={50}
							step={1}
						/>
					</React.Fragment>
				);
			} else if (control === 'weight') {
				return (
					<React.Fragment key={index}>
						<ABlocksRangeControl
							onChangeHandler={(value) =>
								setAttributes({ weight: value })
							}
							label={__('Weight', 'ablocks')}
							attributeName="weight"
							attributeObjectKey="weight"
							attributeValue={attributes}
							isInline={false}
							min={1}
							max={10}
							step={1}
							isResponsive={false}
						/>
						<Separator />
					</React.Fragment>
				);
			}

			return null;
		}
	);
	return (
		<React.Fragment>
			<InspectorControls>
				<InspectorTabs
					attributes={attributes}
					setAttributes={setAttributes}
				>
					<ABlocksPanelBody
						title={__('Divider', 'ablocks')}
						initialOpen={true}
					>
						<ContentStyleTabs
							content={
								<>
									<Separator />
									<ABlocksSelectControl
										label={__('Style', 'ablocks')}
										options={dividerPatternUrlOptions}
										attributeName="dividerPatternUrl"
										attributeValue={dividerPatternUrl}
										onChangeHandler={(value) => {
											const matchDivider =
												dividerPatternUrlOptions?.find(
													(divider) =>
														divider.value === value
												);
											setAttributes({
												dividerPatternUrl:
													matchDivider.value,
												dividerType: matchDivider.type,
											});
										}}
									/>
									<ABlocksRangeControl
										setAttributes={setAttributes}
										label={__('Width', 'ablocks')}
										attributeName="width"
										attributeObjectKey="value"
										attributeValue={attributes?.width}
										isInline={false}
										min={1}
										max={100}
										step={1}
									/>
									<ABlocksAlignmentControl
										label={__('Alignment', 'ablocks')}
										attributeName="alignment"
										attributeValue={alignment}
										setAttributes={setAttributes}
										isInline={false}
										options={[
											{
												label: 'left',
												value: 'flex-start',
												icon: 'left',
											},
											{
												label: 'center',
												value: 'center',
												icon: 'center',
											},
											{
												label: 'right',
												value: 'flex-end',
												icon: 'right',
											},
										]}
									/>

									<Separator />
									<ABlocksSelectControl
										label={__('Add Element', 'ablocks')}
										options={dividerElementOptions}
										attributeName="element"
										attributeValue={element}
										setAttributes={setAttributes}
									/>
								</>
							}
							style={
								<>
									{optionalStyleControlsRender}
									<ABlocksColorGradient
										label={__('Color', 'ablocks')}
										attributeName="color"
										attributeValue={color}
										setAttributes={setAttributes}
									/>
								</>
							}
						/>
					</ABlocksPanelBody>

					{element === 'text' && (
						<ABlocksPanelBody title={__('Divider Text', 'ablocks')}>
							<ContentStyleTabs
								content={
									<>
										<ABlocksTextControl
											label={__('Text', 'ablocks')}
											attributeName="elementText"
											attributeValue={elementText}
											setAttributes={setAttributes}
										/>
										<ABlocksAlignmentControl
											label={__('Position', 'ablocks')}
											isResponsive={false}
											attributeName="elementTextPosition"
											attributeObjectKey="elementTextPosition"
											attributeValue={attributes}
											setAttributes={setAttributes}
											isInline={false}
											options={[
												{
													label: 'left',
													value: 'left',
													icon: 'left',
												},
												{
													label: 'center',
													value: 'center',
													icon: 'center',
												},
												{
													label: 'right',
													value: 'right',
													icon: 'right',
												},
											]}
										/>
										<ABlocksRangeControl
											label={__('Spacing ', 'ablocks')}
											min={0}
											max={20}
											hasUnit={false}
											isInline={false}
											attributeName="elementTextSpacing"
											attributeValue={
												attributes?.elementTextSpacing
											}
											setAttributes={setAttributes}
										/>
									</>
								}
								style={
									<>
										<ABlocksColorGradient
											label={__('Color', 'ablocks')}
											attributeName="elementTextColor"
											attributeValue={elementTextColor}
											setAttributes={setAttributes}
										/>

										<ABlocksTypography
											label={__('Typography', 'ablocks')}
											attributeName="elementTextTypography"
											attributeValue={
												elementTextTypography
											}
											setAttributes={setAttributes}
											isResponsive={true}
										/>

										<ABlocksTextStroke
											label={__('Text Stroke', 'ablocks')}
											attributeName="elementTextStroke"
											attributeValue={elementTextStroke}
											setAttributes={setAttributes}
											isResponsive={true}
										/>
									</>
								}
							/>
						</ABlocksPanelBody>
					)}
					{element === 'icon' && (
						<ABlocksPanelBody title={__('Divider Icon', 'ablocks')}>
							<ContentStyleTabs
								content={
									<>
										<ABlocksIconUploader
											label={__('Icon', 'ablocks')}
											attributes={attributes}
											setAttributes={setAttributes}
										/>
										<ABlocksSelectControl
											label={__('View', 'ablocks')}
											options={iconTypeOption}
											attributeName="elementIconType"
											attributeValue={elementIconType}
											setAttributes={setAttributes}
										/>
										<ABlocksAlignmentControl
											label={__('Position', 'ablocks')}
											attributeName="elementIconPosition"
											attributeObjectKey="elementIconPosition"
											attributeValue={attributes}
											setAttributes={setAttributes}
											isInline={false}
											isResponsive={false}
											options={[
												{
													label: 'left',
													value: 'left',
													icon: 'left',
												},
												{
													label: 'center',
													value: 'center',
													icon: 'center',
												},
												{
													label: 'right',
													value: 'right',
													icon: 'right',
												},
											]}
										/>
										{/* Icon rotate*/}
										<ABlocksRangeControl
											label={__('Spacing ', 'ablocks')}
											min={0}
											max={20}
											hasUnit={false}
											isInline={false}
											attributeName="elementIconSpacing"
											attributeValue={
												attributes?.elementIconSpacing
											}
											setAttributes={setAttributes}
										/>
									</>
								}
								style={
									<>
										<ABlocksColorGradient
											label={__(
												'Primary color',
												'ablocks'
											)}
											attributeName="elementIconPrimaryColor"
											attributeValue={
												elementIconPrimaryColor
											}
											setAttributes={setAttributes}
										/>
										<ABlocksColorGradient
											label={__(
												'Background color',
												'ablocks'
											)}
											attributeName="elementIconBackgroundColor"
											attributeValue={
												elementIconBackgroundColor
											}
											setAttributes={setAttributes}
										/>
										{/* Icon size*/}
										<ABlocksRangeControl
											label={__('Size', 'ablocks')}
											min={0}
											max={50}
											hasUnit={false}
											isInline={false}
											attributeName="elementIconSize"
											attributeValue={
												attributes?.elementIconSize
											}
											setAttributes={setAttributes}
										/>

										<ABlocksRangeControl
											label={__('Rotate', 'ablocks')}
											min={0}
											max={360}
											hasUnit={false}
											isInline={false}
											attributeName="elementIconRotate"
											attributeValue={
												attributes?.elementIconRotate
											}
											setAttributes={setAttributes}
										/>
									</>
								}
							/>
						</ABlocksPanelBody>
					)}
				</InspectorTabs>
			</InspectorControls>
		</React.Fragment>
	);
}

Settings.propTypes = propTypes;
Settings.defaultProps = defaultProps;
