export const imageSizes = [
	{ label: 'Thumbnail', value: 'thumbnail' },
	{ label: 'Medium', value: 'medium' },
	{ label: 'Large', value: 'large' },
	{ label: 'Full', value: 'full' },
	{ label: 'Custom', value: 'custom' },
];

export const imageCaptions = [
	{ label: 'None', value: 'none' },
	{ label: 'Custom', value: 'custom' },
];

export const imageLinkOptions = [
	{ label: 'None', value: 'none' },
	{ label: 'Media File', value: 'mediaFile' },
	{ label: 'Custom URL', value: 'custom' },
];

export const imageObjectFit = [
	{ label: 'Default', value: 'default' },
	{ label: 'Fill', value: 'fill' },
	{ label: 'Cover', value: 'cover' },
	{ label: 'Contain', value: 'contain' },
];

export const onImageHoverOptions = [
	{ label: 'Static', value: 'static' },
	{ label: 'Zoom in', value: 'zoomin' },
	{ label: 'Slide', value: 'slide' },
	{ label: 'Gray scale', value: 'grayscale' },
	{ label: 'Blur', value: 'blur' },
];

export const aspectRatioOptions = [
	{ label: 'Original', value: 'static' },
	{ label: 'Square - 1:1', value: '1/1' },
	{ label: 'Standard - 4:3', value: '4/3' },
	{ label: 'Portrait - 3:4', value: '3/4' },
	{ label: 'Classic - 3:2', value: '3/2' },
	{ label: 'Classic Portrait - 2:3', value: '2/3' },
	{ label: 'Wide - 16:9', value: '16/9' },
	{ label: 'Tall - 9:16', value: '9/16' },
];

export const imageAlignmentOptions = [
	{
		label: 'editor-alignleft',
		value: 'left',
		icon: 'left',
	},
	{
		label: 'editor-aligncenter',
		value: 'center',
		icon: 'center',
	},
	{
		label: 'editor-alignright',
		value: 'right',
		icon: 'right',
	},
];

export const imageIcon = (
	<svg
		stroke="currentColor"
		fill="currentColor"
		strokeWidth="0"
		viewBox="0 0 24 24"
		height="1em"
		width="1em"
		xmlns="http://www.w3.org/2000/svg"
	>
		<g id="Image_On">
			<g>
				<path d="M18.435,3.06H5.565a2.5,2.5,0,0,0-2.5,2.5V18.44a2.507,2.507,0,0,0,2.5,2.5h12.87a2.507,2.507,0,0,0,2.5-2.5V5.56A2.5,2.5,0,0,0,18.435,3.06ZM4.065,5.56a1.5,1.5,0,0,1,1.5-1.5h12.87a1.5,1.5,0,0,1,1.5,1.5v8.66l-3.88-3.88a1.509,1.509,0,0,0-2.12,0l-4.56,4.57a.513.513,0,0,1-.71,0l-.56-.56a1.522,1.522,0,0,0-2.12,0l-1.92,1.92Zm15.87,12.88a1.5,1.5,0,0,1-1.5,1.5H5.565a1.5,1.5,0,0,1-1.5-1.5v-.75L6.7,15.06a.5.5,0,0,1,.35-.14.524.524,0,0,1,.36.14l.55.56a1.509,1.509,0,0,0,2.12,0l4.57-4.57a.5.5,0,0,1,.71,0l4.58,4.58Z"></path>
				<path d="M8.062,10.565a2.5,2.5,0,1,1,2.5-2.5A2.5,2.5,0,0,1,8.062,10.565Zm0-4a1.5,1.5,0,1,0,1.5,1.5A1.5,1.5,0,0,0,8.062,6.565Z"></path>
			</g>
		</g>
	</svg>
);
