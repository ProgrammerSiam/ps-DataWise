import React from 'react';
import Select from 'react-select';
import PropTypes from 'prop-types';
import './editor.scss';

const propTypes = {
	options: PropTypes.array,
	label: PropTypes.string,
	attributeName: PropTypes.string,
	defaultValue: PropTypes.string,
	className: PropTypes.string,
	changeHandler: PropTypes.func,
	isResponsive: PropTypes.bool,
};

const defaultProps = {
	label: '',
	className: '',
	attributeName: '',
	defaultValue: '',
	deviceType: '',
	options: [],
};

const getValue = (options, val) => options.find((item) => item.value === val);

const ABlocksSelectControl = ({
	className,
	label,
	options,
	attributeValue,
	deviceType,
	changeHandler,
	attributeName,
	defaultValue,
	isResponsive,
}) => {
	const isForResponsiveDevice = isResponsive && deviceType;
	const desktopValue = attributeValue[attributeName] || defaultValue;
	const valsForResponsiveDevice = {};

	if (isForResponsiveDevice) {
		const tabValue = attributeValue[attributeName + 'Tablet'];
		const mobileValue = attributeValue[attributeName + 'Mobile'];

		valsForResponsiveDevice.Tablet = tabValue || desktopValue;
		valsForResponsiveDevice.Mobile =
			mobileValue || valsForResponsiveDevice.Tablet;
	}

	const valForSelected = isForResponsiveDevice
		? valsForResponsiveDevice[deviceType]
		: desktopValue;

	const selectedVal = getValue(options, valForSelected);

	return (
		<Select
			className={`ablocks-select-control ${className}`}
			classNamePrefix="ablocks-select-control"
			label={label}
			options={options}
			onChange={(option) => changeHandler(option.value, attributeName)}
			value={selectedVal}
		/>
	);
};

ABlocksSelectControl.propTypes = propTypes;
ABlocksSelectControl.defaultProps = defaultProps;
export default ABlocksSelectControl;
