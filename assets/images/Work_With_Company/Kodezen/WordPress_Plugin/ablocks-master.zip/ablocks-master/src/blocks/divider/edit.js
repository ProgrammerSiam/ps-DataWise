import React, { useEffect } from 'react';
import Settings from './settings';
import Render from './render';
import CSSGenerator from '@Utils/css-generator';
import {
	getWrapperCSS,
	getDividerElementTextCSS,
	getDividerElementIconWrapperCSS,
	getDividerElementIconCSS,
	getDividerContainerCSS,
	getDividerCSS,
} from './styling';
import getDeviceType from '@Utils/get-device-type';
export default function Edit(props) {
	const { isSelected, attributes, setAttributes, clientId } = props;
	const {
		elementTextColor,
		elementTextSpacing,
		elementIconSize,
		elementIconSpacing,
		elementIconRotate,
	} = attributes;
	const deviceType = getDeviceType();
	useEffect(() => {
		setAttributes({ block_id: clientId });
	}, [clientId, setAttributes]);

	// Generate CSS
	const cssGenerator = new CSSGenerator(attributes);

	cssGenerator.addClassStyles(
		'{{WRAPPER}}',
		getWrapperCSS(attributes),
		getWrapperCSS(attributes, 'Tablet'),
		getWrapperCSS(attributes, 'Mobile')
	);

	cssGenerator.addClassStyles(
		'{{WRAPPER}} .ablocks-block-container',
		getDividerContainerCSS(attributes),
		getDividerContainerCSS(attributes, 'Tablet'),
		getDividerContainerCSS(attributes, 'Mobile')
	);

	cssGenerator.addClassStyles(
		'{{WRAPPER}} .ablocks-divider',
		getDividerCSS(attributes),
		getDividerCSS(attributes, 'Tablet'),
		getDividerCSS(attributes, 'Mobile')
	);

	//element text css
	const dividerTextStyles = getDividerElementTextCSS(attributes);
	if (elementTextColor !== '') {
		dividerTextStyles.color = elementTextColor;
	}
	if (elementTextSpacing['value' + deviceType]) {
		dividerTextStyles.padding = `0 ${
			elementTextSpacing['value' + deviceType]
		}px`;
	}
	cssGenerator.addClassStyles(
		'{{WRAPPER}} .ablocks-divider__element-text',
		dividerTextStyles,
		getDividerElementTextCSS(attributes, 'Tablet'),
		getDividerElementTextCSS(attributes, 'Mobile')
	);

	// element icon css
	const dividerElementIconWrapperStyles =
		getDividerElementIconWrapperCSS(attributes);
	if (elementIconSpacing['value' + deviceType]) {
		dividerElementIconWrapperStyles.margin = `0 ${
			elementIconSpacing['value' + deviceType]
		}px`;
	}
	cssGenerator.addClassStyles(
		'{{WRAPPER}} .ablocks-divider__element-icon',
		dividerElementIconWrapperStyles,
		getDividerElementIconWrapperCSS(attributes, 'Tablet'),
		getDividerElementIconWrapperCSS(attributes, 'Mobile')
	);

	const dividerElementIconStyles = getDividerElementIconCSS(attributes);
	if (elementIconSize['value' + deviceType]) {
		dividerElementIconStyles['font-size'] = `${
			elementIconSize['value' + deviceType]
		}px`;
	}
	if (elementIconRotate['value' + deviceType]) {
		dividerElementIconStyles.rotate = `${
			elementIconRotate['value' + deviceType]
		}deg`;
	}
	cssGenerator.addClassStyles(
		'{{WRAPPER}} .ablocks-divider__element-icon svg.ablocks-svg-icon',
		dividerElementIconStyles,
		getDividerElementIconCSS(attributes, 'Tablet'),
		getDividerElementIconCSS(attributes, 'Mobile')
	);
	const generatedCSS = cssGenerator.generateCSS();
	return (
		<>
			<style>{generatedCSS}</style>
			{isSelected && <Settings {...props} />}
			<Render {...props} />
		</>
	);
}
