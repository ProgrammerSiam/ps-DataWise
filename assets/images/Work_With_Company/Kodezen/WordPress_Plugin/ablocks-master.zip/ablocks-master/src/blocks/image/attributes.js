import globalAttributes from '@Global/AdvancedSettings/attributes';
import { getAttribute as getBorderAttributes } from '@Controls/border/helper';
import { getAttribute as getAlignmentAttributes } from '@Controls/alignment/helper';
import { getAttribute as getDimensionsAttributes } from '@Controls/dimensions/helper';
import { getAttribute as getTypographyAttributes } from '@Controls/typography/helper';

export const defaultWidthAndHeight = {
	imgNaturalWidth: '',
	imgNaturalWidthTablet: '',
	imgNaturalWidthMobile: '',
	imgNaturalHeight: '',
	imgNaturalHeightTablet: '',
	imgNaturalHeightMobile: '',
	width: '',
	widthTablet: '',
	widthMobile: '',
	height: '',
	heightTablet: '',
	heightMobile: '',
	customHeight: false,
	customHeightTablet: false,
	customHeightMobile: false,
};

const attributes = {
	block_id: {
		type: 'string',
	},
	imgId: {
		type: 'string',
		default: '',
	},
	imgIdTablet: {
		type: 'string',
		default: '',
	},
	imgIdMobile: {
		type: 'string',
		default: '',
	},
	imgUrl: {
		type: 'string',
		source: 'attribute',
		selector: '.ablocks-image',
		attribute: 'srcset',
	},
	imgUrlTablet: {
		type: 'string',
		source: 'attribute',
		selector: '.ablocks-image-tablet',
		attribute: 'srcset',
	},
	imgUrlMobile: {
		type: 'string',
		source: 'attribute',
		selector: '.ablocks-image-mobile',
		attribute: 'src',
	},
	imgSize: {
		type: 'object',
		default: {
			value: 'large',
			valueTablet: '',
			valueMobile: '',
		},
	},
	opacity: {
		type: 'number',
		default: 1,
	},
	opacityH: {
		type: 'number',
		default: 1,
	},
	aspectRatio: {
		type: 'string',
		default: 'original',
	},
	widthHeightWidget: {
		type: 'object',
		default: defaultWidthAndHeight,
	},
	objectFit: {
		type: 'object',
		default: {
			value: 'default',
			valueTablet: '',
			valueMobile: '',
		},
	},
	imgCaption: {
		type: 'boolean',
		default: false,
	},
	position: {
		type: 'string',
		default: 'below',
	},
	caption: {
		type: 'string',
		default: '',
	},
	captionBackground: {
		type: 'string',
		default: '',
	},
	captionColor: {
		type: 'string',
		default: '',
	},
	imgLink: {
		type: 'object',
		default: {
			linkDestination: '',
			href: '',
			lightbox: '',
			linkTarget: '',
			rel: '',
			linkClass: '',
		},
	},
	imgAltText: {
		type: 'string',
	},
	onHoverImg: {
		type: 'string',
		default: 'static',
	},
	imgTitle: {
		type: 'string',
	},
	transitionDuration: {
		type: 'number',
		default: 0.3,
	},
	...getAlignmentAttributes('alignment', true, {
		value: 'left',
	}),
	...getAlignmentAttributes('captionAlignment', true, {
		value: 'left',
	}),
	...getTypographyAttributes('captionTypography', true),
	...getAlignmentAttributes('captionPosition', true),
	...getDimensionsAttributes('captionPadding', true),
	...getBorderAttributes('captionBorder', true),
	...getBorderAttributes('border', true),
	...getDimensionsAttributes('padding', true),
	...globalAttributes,
};
export default attributes;
