import React from 'react';
import RenderContainer from '@Components/block-container/render';
import { ResizableBox } from '@wordpress/components';
import metadata from './block.json';
import GetDeviceType from '@Utils/get-device-type';
import { objectUniqueCheck } from '@Utils/helper';
import { spacerHeight as spacerHeightDefaultData } from './attributes';

const propTypes = {};

const defaultProps = {};

export default function Render(props) {
	const { attributes, setAttributes } = props;
	const { block_id, spacerHeight } = attributes;
	const deviceType = GetDeviceType();

	return (
		<React.Fragment>
			<RenderContainer
				blockId={block_id}
				name={metadata.name}
				attributes={attributes}
			>
				<ResizableBox
					size={{
						height: `${
							spacerHeight['value' + deviceType]
								? spacerHeight['value' + deviceType]
								: spacerHeight.value
						}px`,
						width: '100%',
					}}
					minHeight="1"
					enable={{
						bottom: true,
					}}
					maxHeight="500px"
					className="ablocks-spacer__box"
					onResizeStop={(event, direction, elt, delta) => {
						setAttributes({
							spacerHeight: objectUniqueCheck(
								spacerHeightDefaultData.spacerHeight.default,
								{
									...spacerHeight,
									['value' + deviceType]:
										(spacerHeight['value' + deviceType]
											? spacerHeight['value' + deviceType]
											: spacerHeight.value) +
										delta.height,
								}
							),
						});
					}}
				/>
			</RenderContainer>
		</React.Fragment>
	);
}

Render.propTypes = propTypes;
Render.defaultProps = defaultProps;
