import { __ } from '@wordpress/i18n';
const colors = [
	{
		name: __('Black', 'ablocks'),
		color: '#000000',
	},
	{
		name: __('White', 'ablocks'),
		color: '#ffffff',
	},
	{
		name: __('Red', 'ablocks'),
		color: '#ff0000',
	},
	{
		name: __('Green', 'ablocks'),
		color: '#00ff00',
	},
	{
		name: __('Blue', 'ablocks'),
		color: '#0000ff',
	},
	{
		name: __('Yellow', 'ablocks'),
		color: '#ffff00',
	},
];
export default colors;
