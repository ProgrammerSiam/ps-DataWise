const RenderIcon = ({ attributePrefix = 'icon', attributes = {} }) => {
	const iconSvgPath = attributes[attributePrefix + 'SvgPath'];
	const iconSvgViewBox = attributes[attributePrefix + 'SvgViewBox'];
	const iconClass = attributes[attributePrefix + 'Class'];

	if (!iconClass) {
		return <></>;
	}
	return (
		<svg
			xmlns="http://www.w3.org/2000/svg"
			viewBox={iconSvgViewBox}
			className="ablocks-svg-icon"
		>
			<path d={iconSvgPath}></path>
		</svg>
	);
};

export default RenderIcon;
