import React, { useEffect } from 'react';
import CSSGenerator from '@Utils/css-generator';
import Settings from './settings';
import Render from './render';
import {
	getWrapperCSS,
	getImageCSS,
	getImageHoverCSS,
	getImageContainerCSS,
	getImageCaptionCSS,
	getImageCaptionHoverCSS,
} from './styling';

export default function Edit(props) {
	const { isSelected, attributes, setAttributes, clientId } = props;

	useEffect(() => {
		setAttributes({ block_id: clientId });
	}, [clientId, setAttributes]);

	// Generate CSS
	const cssGenerator = new CSSGenerator(attributes);

	// Image wrapper css
	cssGenerator.addClassStyles(
		'{{WRAPPER}}',
		getWrapperCSS(attributes),
		getWrapperCSS(attributes, 'Tablet'),
		getWrapperCSS(attributes, 'Mobile')
	);

	// Image container css
	cssGenerator.addClassStyles(
		'{{WRAPPER}} .ablocks-block-container',
		getImageContainerCSS(attributes),
		getImageContainerCSS(attributes, 'Tablet'),
		getImageContainerCSS(attributes, 'Mobile')
	);

	// Image css
	cssGenerator.addClassStyles(
		'{{WRAPPER}} .ablocks-block-container .ablocks-image-figure img',
		getImageCSS(attributes),
		getImageCSS(attributes, 'Tablet'),
		getImageCSS(attributes, 'Mobile')
	);

	// Image hover css
	cssGenerator.addClassStyles(
		'{{WRAPPER}} .ablocks-block-container .ablocks-image-figure img:hover',
		getImageHoverCSS(attributes),
		getImageHoverCSS(attributes, 'Tablet'),
		getImageHoverCSS(attributes, 'Mobile')
	);

	// Image caption css
	cssGenerator.addClassStyles(
		'{{WRAPPER}} .ablocks-block-container .ablocks-image-figure .ablocks-image-caption',
		getImageCaptionCSS(attributes),
		getImageCaptionCSS(attributes, 'Tablet'),
		getImageCaptionCSS(attributes, 'Mobile')
	);

	// Image caption hover css
	cssGenerator.addClassStyles(
		'{{WRAPPER}} .ablocks-block-container .ablocks-image-figure .ablocks-image-caption:hover',
		getImageCaptionHoverCSS(attributes),
		getImageCaptionHoverCSS(attributes, 'Tablet'),
		getImageCaptionHoverCSS(attributes, 'Mobile')
	);

	const generatedCSS = cssGenerator.generateCSS();
	return (
		<>
			<style>{generatedCSS}</style>
			{isSelected && <Settings {...props} />}
			<Render {...props} />
		</>
	);
}
