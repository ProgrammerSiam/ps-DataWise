import { getAttributeDefaultValue } from '../../helper';
import { objectUniqueCheck } from '@Utils/helper';
import ABlocksImageControl from '@Controls/image-control';

export default function ABlocksBackgroundImage(props) {
	const {
		attributeName,
		setAttributes,
		attributeValue,
		isResponsive,
		hover,
		deviceType,
	} = props;

	const commonProps = {
		...props,
	};

	// setting background image attritibutes
	const onSelectImageHandler = (media, deviceMode) => {
		const updatedValue = {};
		if (!deviceMode) {
			updatedValue[hover ? 'imgIdH' : 'imgId'] = media?.id;
			updatedValue[hover ? 'imgUrlH' : 'imgUrl'] = media?.url;
		} else if (deviceMode === 'Tablet') {
			updatedValue[hover ? 'imgIdH' : 'imgId' + 'Tablet'] = media?.id;
			updatedValue[hover ? 'imgUrlH' : 'imgUrl' + 'Tablet'] = media?.url;
		} else if (deviceMode === 'Mobile') {
			updatedValue[hover ? 'imgIdH' : 'imgId' + 'Mobile'] = media?.id;
			updatedValue[hover ? 'imgUrlH' : 'imgUrl' + 'Mobile'] = media?.url;
		}
		setAttributes({
			[attributeName]: objectUniqueCheck(
				getAttributeDefaultValue(isResponsive),
				{
					...attributeValue,
					...updatedValue,
				}
			),
		});
	};

	// Removing background image attritibutes
	const onRemoveImageHandler = () => {
		setAttributes({
			[attributeName]: objectUniqueCheck(
				getAttributeDefaultValue(isResponsive),
				{
					...attributeValue,
					[hover ? 'imgIdH' : 'imgId' + deviceType]: undefined,
					[hover ? 'imgUrlH' : 'imgUrl' + deviceType]: undefined,
				}
			),
		});
	};

	return (
		<ABlocksImageControl
			{...commonProps}
			onSelectImageHandler={onSelectImageHandler}
			onRemoveImageHandler={onRemoveImageHandler}
		/>
	);
}
