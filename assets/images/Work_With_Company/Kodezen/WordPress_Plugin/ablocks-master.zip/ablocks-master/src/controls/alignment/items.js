import React from 'react';
import Button from '@Components/Button';
import Tooltip from '@Components/tooltip';
import PropTypes from 'prop-types';

const propTypes = {
	changeHandler: PropTypes.func,
	deviceType: PropTypes.string,
	options: PropTypes.array,
	attributeValue: PropTypes.any,
};

const defaultProps = {
	deviceType: '',
};
export default function ABlocksAlignmentItems(props) {
	const { changeHandler, deviceType, options, attributeValue } = props;
	return (
		<React.Fragment>
			<div className="ablocks-control__fields">
				{options.map((item, index) => (
					<Button
						suffix={attributeValue === item.value ? 'active' : ''}
						onClick={() => changeHandler(item.value, deviceType)}
						icon={
							<>
								<Tooltip tooltipText={item.label}>
									<span
										className={`ablocks-icon ablocks-icon--${item.icon}`}
									></span>
								</Tooltip>
							</>
						}
						key={index}
						preset="transparent"
					/>
				))}
			</div>
		</React.Fragment>
	);
}

ABlocksAlignmentItems.propTypes = propTypes;
ABlocksAlignmentItems.defaultProps = defaultProps;
