export const groupedAnimationOptions = [
	{
		label: 'Default',
		options: [],
	},
	{
		label: 'Fading',
		options: [
			{ value: 'fadeIn', label: 'Fade In' },
			{ value: 'fadeInDown', label: 'Fade In Down' },
			{ value: 'fadeInLeft', label: 'Fade In Left' },
			{ value: 'fadeInRight', label: 'Fade In Right' },
			{ value: 'fadeInUp', label: 'Fade In Up' },
		],
	},
	{
		label: 'Zooming',
		options: [
			{ value: 'zoomIn', label: 'Zoom In' },
			{ value: 'zoomInDown', label: 'Zoom In Down' },
			{ value: 'zoomInLeft', label: 'Zoom In Left' },
			{ value: 'zoomInRight', label: 'Zoom In Right' },
			{ value: 'zoomInUp', label: 'Zoom In Up' },
		],
	},
	{
		label: 'Bouncing',
		options: [
			{ value: 'bounceIn', label: 'Bounce In' },
			{ value: 'bounceInDown', label: 'Bounce In Down' },
			{ value: 'bounceInLeft', label: 'Bounce In Left' },
			{ value: 'bounceInRight', label: 'Bounce In Right' },
			{ value: 'bounceInUp', label: 'Bounce In Up' },
		],
	},
	{
		label: 'Sliding',
		options: [
			{ value: 'slideIn', label: 'Slide In' },
			{ value: 'slideInDown', label: 'Slide In Down' },
			{ value: 'slideInLeft', label: 'Slide In Left' },
			{ value: 'slideInRight', label: 'Slide In Right' },
			{ value: 'slideInUp', label: 'Slide In Up' },
		],
	},
	{
		label: 'Rotating',
		options: [
			{ value: 'rotateIn', label: 'Rotate In' },
			{ value: 'rotateInDownLeft', label: 'Rotate In Down Left' },
			{ value: 'rotateInLeftRight', label: 'Rotate In Down Right' },
			{ value: 'rotateInUpLeft', label: 'Rotate In Up Left' },
			{ value: 'rotateInUpRight', label: 'Rotate In Up Right' },
		],
	},
	{
		label: 'AttentionSeekers',
		options: [
			{ value: 'bounce', label: 'Bounce' },
			{ value: 'flash', label: 'Flash' },
			{ value: 'pulse', label: 'Pulse' },
			{ value: 'rubberBrand', label: 'Rubber Brand' },
			{ value: 'shake', label: 'Shake' },
			{ value: 'headShake', label: 'Head Shake' },
			{ value: 'swing', label: 'Swing' },
			{ value: 'teda', label: 'Teda' },
			{ value: 'wobble', label: 'Wobble' },
			{ value: 'jello', label: 'Jello' },
		],
	},
	{
		label: 'LightSpeed',
		options: [{ value: 'lightSpeedIn', label: 'Light Speed In' }],
	},
	{
		label: 'Specials',
		options: [{ value: 'rollIn', label: 'Roll In' }],
	},
];

export const durationOptions = [
	{ value: '0', label: 'Normal' },
	{ value: 'slow', label: 'Slow' },
	{ value: 'fast', label: 'Fast' },
];
