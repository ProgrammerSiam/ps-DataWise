import { getCSS as getTypographyCSS } from '@Controls/typography/helper';
import {
	getCSS as getBackgroundCSS,
	getHoverCSS as getBackgroundHoverCSS,
} from '@Controls/background/helper';
import {
	getCSS as getBorderCSS,
	getHoverCSS as getBorderHoverCSS,
} from '@Controls/border/helper';
import { getCSS as getDimensionCSS } from '@Controls/dimensions/helper';

export const getCourseCardCss = (attributes, device = '') => {
	return {
		...getBackgroundCSS(attributes?.card_background, 'background', device),
		...getBorderCSS(attributes?.card_border, device),
		...getDimensionCSS(attributes?.card_margin, 'margin', device),
		...getDimensionCSS(attributes?.card_padding, 'padding', device),
	};
};

export const getCourseCardHoverCss = (attributes, device = '') => {
	return {
		...getBackgroundHoverCSS(
			attributes?.card_background,
			'background',
			device
		),
		...getBorderHoverCSS(attributes?.card_border, device),
		...getDimensionCSS(attributes?.card_hover_margin, 'margin', device),
		...getDimensionCSS(attributes?.card_hover_padding, 'padding', device),
	};
};

export const getWishListIconCss = (attributes, device = '') => {
	const css = {
		...getBackgroundCSS(
			attributes?.wish_icon_background,
			'background',
			device
		),
	};
	if (attributes?.wish_icon_color) {
		css.color = attributes?.wish_icon_color;
	}
	return css;
};

export const getWishListIconHoverCss = (attributes, device = '') => {
	const css = {
		...getBackgroundHoverCSS(
			attributes?.wish_icon_background,
			'background',
			device
		),
	};
	if (attributes?.wish_icon_hover_color) {
		css.color = attributes?.wish_icon_hover_color;
	}
	return css;
};

export const getCourseCardCategoryCss = (attributes, device = '') => {
	return {
		...getTypographyCSS(attributes?.cat_typography, device),
	};
};

export const getCourseCardTitleCss = (attributes, device = '') => {
	return {
		...getTypographyCSS(attributes?.title_typography, device),
	};
};

export const getCourseCardAuthorCss = (attributes, device = '') => {
	return {
		...getTypographyCSS(attributes?.author_typography, device),
	};
};

export const getCourseCardRatingCss = (attributes, device = '') => {
	return {
		...getTypographyCSS(attributes?.rating_typography, device),
	};
};

export const getCourseCardPriceCss = (attributes, device = '') => {
	return {
		...getTypographyCSS(attributes?.price_typography, device),
	};
};
