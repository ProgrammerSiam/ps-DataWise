import React, { useState, useEffect } from 'react';
import ControlLabel from '@Components/control-label';
import { MediaUpload, MediaUploadCheck } from '@wordpress/block-editor';
import { Button } from '@wordpress/components';
import GetDeviceType from '@Utils/get-device-type';
import PropTypes from 'prop-types';

const { rest_url } = window.ABlocksGlobal;

const propTypes = {
	isResponsive: PropTypes.bool,
	label: PropTypes.string,
	attributeName: PropTypes.string,
	attributeObjectKey: PropTypes.string,
	attributeValue: PropTypes.any,
	onChangeHandler: PropTypes.func,
};

const defaultProps = {
	label: '',
	isResponsive: true,
	attributeObjectKey: 'value',
};

export default function ABlocksUploadImageControl(props) {
	const deviceType = GetDeviceType();
	const {
		isResponsive,
		attributeName,
		attributeValue,
		attributeObjectKey,
		setAttributes,
		label,
	} = props;
	const value =
		attributeValue[`image${deviceType}`] === undefined
			? attributeValue.imageDesktop
			: attributeValue[`image${deviceType}`];
	const dependency = attributeValue[`image${deviceType}`];

	const changeHandler = (controlValue, deviceMode) => {
		setAttributes({
			[attributeName]: {
				...attributeValue,
				[attributeObjectKey + deviceMode]: controlValue,
			},
		});
	};

	const [attachment, setAttachment] = useState({ url: '' });

	useEffect(() => {
		if (value) {
			fetch(`${rest_url}wp/v2/media/${value}`)
				.then((res) => {
					return res.json();
				})
				.then((data) => {
					if (data && data.source_url) {
						setAttachment({ url: data.source_url });
					} else {
						setAttachment({ url: '' });
					}
				});
		} else {
			setAttachment({ url: '' });
		}
	}, [dependency, value]);
	const output = {};
	output.Desktop = (
		<MediaUploadCheck>
			{attachment && <img src={attachment.url} alt="upload" />}
			<MediaUpload
				allowedTypes={['image']}
				value={
					isResponsive
						? attributeValue[`image${deviceType}`]
						: attributeValue
				}
				onSelect={(controlValue) =>
					changeHandler(controlValue.id, 'Desktop')
				}
				render={({ open }) => (
					<Button onClick={open}>
						<span className="dashicons dashicons-plus-alt" />
					</Button>
				)}
			/>
		</MediaUploadCheck>
	);
	if (isResponsive) {
		output.Tablet = (
			<MediaUploadCheck>
				{attachment && <img src={attachment.url} alt="upload" />}
				<MediaUpload
					allowedTypes={['image']}
					value={
						isResponsive
							? attributeValue[`image${deviceType}`]
							: attributeValue[`image${deviceType}`]
					}
					onSelect={(controlValue) =>
						changeHandler(controlValue.id, 'Tablet')
					}
					render={({ open }) => (
						<Button onClick={open}>
							<span className="dashicons dashicons-plus-alt"></span>
						</Button>
					)}
				/>
			</MediaUploadCheck>
		);
		output.Mobile = (
			<MediaUploadCheck>
				{attachment && <img src={attachment.url} alt="upload" />}
				<MediaUpload
					allowedTypes={['image']}
					value={
						isResponsive
							? attributeValue[`image${deviceType}`]
							: attributeValue[`image${deviceType}`]
					}
					onSelect={(controlValue) =>
						changeHandler(controlValue.id, 'Mobile')
					}
					render={({ open }) => (
						<Button onClick={open}>
							<span className="dashicons dashicons-plus-alt"></span>
						</Button>
					)}
				/>
			</MediaUploadCheck>
		);
	}
	return (
		<React.Fragment>
			{label && (
				<ControlLabel label={label} isResponsive={isResponsive} />
			)}
			{output[deviceType] ? output[deviceType] : output.Desktop}
		</React.Fragment>
	);
}
ABlocksUploadImageControl.propTypes = propTypes;
ABlocksUploadImageControl.defaultProps = defaultProps;
