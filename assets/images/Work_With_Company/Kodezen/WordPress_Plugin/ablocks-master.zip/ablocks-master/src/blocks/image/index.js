import { registerBlockType } from '@wordpress/blocks';
import attributes from './attributes';
import Edit from './edit';
import Save from './save';
import metadata from './block.json';

registerBlockType(metadata.name, {
	attributes,
	icon: (
		<svg
			width="24"
			height="25"
			viewBox="0 0 24 25"
			fill="none"
			xmlns="http://www.w3.org/2000/svg"
		>
			<path
				d="M19 3.56091H5C3.9 3.56091 3 4.46091 3 5.56091V19.5609C3 20.6609 3.9 21.5609 5 21.5609H19C20.1 21.5609 21 20.6609 21 19.5609V5.56091C21 4.46091 20.1 3.56091 19 3.56091ZM5 5.06091H19C19.3 5.06091 19.5 5.26091 19.5 5.56091V13.9609L16.5 11.0609C16.2 10.7609 15.7 10.7609 15.5 11.0609L11.9 14.5609L9 12.5609C8.7 12.3609 8.4 12.3609 8.2 12.5609L4.6 15.1609V5.56091C4.5 5.26091 4.7 5.06091 5 5.06091ZM19 20.0609H5C4.7 20.0609 4.5 19.8609 4.5 19.5609V17.1609L8.6 14.1609L11.6 16.0609C11.9 16.2609 12.3 16.2609 12.5 15.9609L16 12.5609L19.5 15.9609V19.5609C19.5 19.8609 19.3 20.0609 19 20.0609Z"
				fill="#E930F0"
			/>
		</svg>
	),
	edit: Edit,
	save: Save,
});
