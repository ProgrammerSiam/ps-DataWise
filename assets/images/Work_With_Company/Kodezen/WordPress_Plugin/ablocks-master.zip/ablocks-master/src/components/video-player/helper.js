export const handleStartAndEndTime = (videoStartTime, videoEndTime) => {
	const formattedStartTime = videoStartTime || 0;
	const formattedEndTime = videoEndTime || '';

	let isVideoTimeSet;
	if (formattedStartTime && formattedEndTime) {
		isVideoTimeSet = `#t=${formattedStartTime},${formattedEndTime}`;
	} else {
		isVideoTimeSet = formattedStartTime ? `#t=${formattedStartTime}` : '';
	}

	return isVideoTimeSet;
};
