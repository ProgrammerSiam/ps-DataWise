import React from 'react';
import ABlocksDevicePreview from '@Components/device-preview';
import PropTypes from 'prop-types';
import './editor.scss';

const propTypes = {
	label: PropTypes.string,
	isResponsive: PropTypes.bool,
};

const defaultProps = {
	isResponsive: true,
};

export default function ControlLabel({ label, isResponsive }) {
	return (
		<React.Fragment>
			<div className="ablocks-components-control-label">
				<span className="ablocks-components-control-label__label">
					{label}
				</span>
				{isResponsive && <ABlocksDevicePreview />}
			</div>
		</React.Fragment>
	);
}

ControlLabel.propTypes = propTypes;
ControlLabel.defaultProps = defaultProps;
