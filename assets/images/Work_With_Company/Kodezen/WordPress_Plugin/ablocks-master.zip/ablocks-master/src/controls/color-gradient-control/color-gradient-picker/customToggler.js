import { TextControl } from '@wordpress/components';
import React, { useState } from 'react';

import {
	getColorObjectDataBasedOnType,
	isValidShortHex,
	isValidHex,
	getTypeAndHsvaObjectFromColorString,
} from '../colorPicker/utils/helperFunctions';
import { hexToHsva, hsvaToHex } from '../colorPicker/utils/convert';

let alertGiven = false;
let ablocksHelperOnChangeTimeoutId = false;

const CustomToggler = ({
	toggleVisible,
	activeColor,
	onColorChange,
	colorType = 'hex',
}) => {
	const { hsva: initialHsva } = getTypeAndHsvaObjectFromColorString(
		activeColor?.colorString
	);
	const initialColorInputData = getColorObjectDataBasedOnType(
		initialHsva,
		colorType
	);
	const [hsva, setHsva] = useState(initialHsva);
	const [colorInputData, setColorInputData] = useState(initialColorInputData);
	const [alpha, setAlpha] = useState(Math.round(initialHsva.a * 100));

	const onInputChange = (name, val) => {
		clearTimeout(ablocksHelperOnChangeTimeoutId);
		alertGiven = false;
		let value = val.trim();
		let newColorInputData = {};
		value = value.startsWith('#') ? value : `#${value}`;
		newColorInputData = {
			...colorInputData,
			[name]: value,
		};
		setColorInputData(newColorInputData);
		const isValid = isValidHex(value);

		if (!isValid) {
			return false;
		}
		const timeOutDuratonInMs = isValidShortHex(value) ? 900 : 500;
		ablocksHelperOnChangeTimeoutId = setTimeout(() => {
			setColorInputData(newColorInputData);
			onColorChange(value);
			const newHsva = hexToHsva(value);
			setHsva(newHsva);
			if ([5, 9].includes(value.length)) {
				setAlpha(Math.round(newHsva.a * 100));
				setColorInputData(
					getColorObjectDataBasedOnType(newHsva, colorType)
				);
			}
		}, timeOutDuratonInMs);
	};

	const handleToggle = () => {
		toggleVisible();
	};

	const handleAphaChange = (val) => {
		const value = parseInt(val);
		if (value > 100 || value < 0) {
			return false;
		}
		setAlpha(value);
		clearTimeout(ablocksHelperOnChangeTimeoutId);
		ablocksHelperOnChangeTimeoutId = setTimeout(() => {
			const newHsva = {
				...hsva,
				a: value / 100,
			};
			const newColorInputData = getColorObjectDataBasedOnType(
				newHsva,
				colorType
			);
			setHsva(newHsva);
			setColorInputData(newColorInputData);
			onColorChange(hsvaToHex(newHsva));
		}, 500);
	};

	const handleBlur = () => {
		if (alertGiven) {
			return false;
		}

		let isColorValid = false;
		if (colorType === 'hex') {
			isColorValid = isValidHex(colorInputData?.hex);
		}

		if (!isColorValid) {
			alertGiven = true;
			// eslint-disable-next-line no-alert
			return window.alert(
				'Input color is not valid. Please give a valid color value.'
			);
		}
	};

	return (
		<div className="ablocks-gradient-active-color-custom-toggler-root">
			<span //eslint-disable-line jsx-a11y/no-static-element-interactions
				className="ablocks-custom-toggler-color"
				style={{ background: activeColor?.colorString }}
				onClick={handleToggle}
				onKeyDown={() => {}}
			></span>
			<div className="ablocks-custom-toggler-color-input-field">
				<TextControl
					onBlur={handleBlur}
					className="ablocks-custom-toggler--hex-field"
					value={colorInputData?.hex}
					onChange={(value) => onInputChange('hex', value)}
				/>
			</div>
			<div className="ablocks-custom-toggler-color--alpha-percentage-input-field">
				<TextControl
					className="ablocks-custom-toggler--alpha-field"
					type="number"
					value={alpha}
					onChange={handleAphaChange}
					min={0}
					max={100}
				/>
				<span className="ablocks-custom-toggler--alpha-percentage-icon">
					%
				</span>
			</div>
		</div>
	);
};

export default CustomToggler;
