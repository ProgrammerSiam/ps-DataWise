import { __ } from '@wordpress/i18n';
export const videoSourceOption = [
	{ label: __('None', 'ablocks'), value: 'none' },
	{ label: __('Vimeo', 'ablocks'), value: 'vimeo' },
	{ label: __('Youtube', 'ablocks'), value: 'youtube' },
	{ label: __('Self hosted', 'ablocks'), value: 'selfHosted' },
];

export const handleStartAndEndTime = (videoStartTime, videoEndTime) => {
	const formattedStartTime = videoStartTime || 0;
	const formattedEndTime = videoEndTime || '';

	let isVideoTimeSet;
	if (formattedStartTime && formattedEndTime) {
		isVideoTimeSet = `#t=${formattedStartTime},${formattedEndTime}`;
	} else {
		isVideoTimeSet = formattedStartTime ? `#t=${formattedStartTime}` : '';
	}

	return isVideoTimeSet;
};

export const handleYTStartAndEndTime = (videoStartTime, videoEndTime) => {
	const formattedStartTime = videoStartTime || 0;
	const formattedEndTime = videoEndTime || '';

	const isVideoTimeSet =
		formattedStartTime || formattedEndTime
			? `&amp;start=${formattedStartTime}&end=${formattedEndTime}`
			: '';

	return isVideoTimeSet;
};

function secondsToVimeoTime(seconds) {
	const hours = Math.floor(seconds / 3600);
	const minutes = Math.floor((seconds % 3600) / 60);
	const remainingSeconds = seconds % 60;

	const timeString = `#t=${hours.toString().padStart(2, '0')}h${minutes
		.toString()
		.padStart(2, '0')}m${remainingSeconds.toString().padStart(2, '0')}s`;

	return timeString;
}

export const handleVimeoVideoTime = (videoStartTime) => {
	const isVideoTimeSet = videoStartTime
		? secondsToVimeoTime(videoStartTime)
		: ``;
	return isVideoTimeSet;
};
