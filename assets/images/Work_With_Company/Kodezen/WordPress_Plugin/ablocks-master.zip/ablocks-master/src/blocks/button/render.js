import React from 'react';
import metadata from './block.json';
import RenderContainer from '@Components/block-container/render';
import { useBlockProps, RichText } from '@wordpress/block-editor';
import RenderIcon from '@Controls/icon-upload/render-icon';
import { getAnchorKeyValueAttributes } from '@Controls/link-control/helper';
import './style.css';

const propTypes = {};
const defaultProps = {};

export default function Render(props) {
	const { attributes, setAttributes } = props;

	const {
		block_id,
		buttonSize,
		iconPosition,
		iconClass,
		link: { linkTarget, noFollow, keyValue },
	} = attributes;
	const blockProps = useBlockProps();

	let anchorTagAttributes = {};

	if (linkTarget) {
		anchorTagAttributes.target = '_blank';
	}
	if (noFollow) {
		anchorTagAttributes.rel = linkTarget
			? 'nofollow noreferrer noopener'
			: 'nofollow';
	} else {
		anchorTagAttributes.rel = 'noopener';
	}
	if (keyValue) {
		anchorTagAttributes = {
			...anchorTagAttributes,
			...getAnchorKeyValueAttributes(keyValue),
		};
	}
	return (
		<React.Fragment>
			<RenderContainer
				blockId={block_id}
				name={metadata.name}
				attributes={attributes}
				typography={[
					{
						fontFamily: attributes.typography?.fontFamily,
						weight: attributes.typography?.weight,
					},
				]}
			>
				<a
					{...anchorTagAttributes}
					className={`ablocks-button ablocks-button--${buttonSize} ${
						iconClass && iconPosition
							? `ablocks-button--icon-${iconPosition}`
							: ''
					}`}
				>
					{iconClass && <RenderIcon attributes={attributes} />}
					<RichText
						{...blockProps}
						tagName={'span'}
						identifier="text"
						value={attributes.text}
						withoutInteractiveFormatting
						placeholder={attributes.text}
						className="ablocks-button__text"
						onChange={(text) => setAttributes({ text })}
					/>
				</a>
			</RenderContainer>
		</React.Fragment>
	);
}

Render.propTypes = propTypes;
Render.defaultProps = defaultProps;
