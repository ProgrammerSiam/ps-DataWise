import { getCSS as getAlignmentCSS } from '@Controls/alignment/helper';
import { getCSS as getDimensionCSS } from '@Controls/dimensions/helper';

export const getWrapperCSS = (attributes, device = '') => {
	return {
		...getAlignmentCSS(attributes?.alignment, 'text-align', device),
	};
};

export const getIconWrapperCSS = (attributes, device = '') => {
	const { iconType, iconShape, backgroundColor, primaryColor } = attributes;
	let iconViewCSS;
	if (iconType !== 'default') {
		if (iconType === 'stacked') {
			if (iconShape === 'circle') {
				iconViewCSS = {
					background: backgroundColor || '#ddd',
					'border-radius': '50px',
					padding: '.5em',
				};
			} else if (iconShape === 'square') {
				iconViewCSS = {
					background: backgroundColor || '#ddd',
					padding: '.5em',
				};
			}
		} else if (iconType === 'framed') {
			if (iconShape === 'circle') {
				iconViewCSS = {
					background: backgroundColor || 'transparent',
					padding: '.5em',
					'border-radius': '50px',
					border: `2px solid ${primaryColor || '#69727d'}`,
				};
			} else if (iconShape === 'square') {
				iconViewCSS = {
					background: backgroundColor || 'transparent',
					padding: '.5em',
					border: `2px solid ${primaryColor || '#69727d'}`,
				};
			}
		}
	}

	return {
		background: attributes?.backgroundColor,
		...iconViewCSS,
		...getDimensionCSS(attributes?.padding, 'padding', device),
		...getDimensionCSS(attributes?.borderRadius, 'border-radius', device),
		...getDimensionCSS(attributes?.borderWidth, 'border-width', device),
	};
};
export const getIconCSS = (attributes) => {
	const { iconType, iconShape, primaryColor, rotate } = attributes;
	let iconViewCSS = {};
	if (iconType !== 'default') {
		if (iconType === 'stacked') {
			if (iconShape === 'circle') {
				iconViewCSS = {
					fill: primaryColor || '#000000',
				};
			} else if (iconShape === 'square') {
				iconViewCSS = {
					fill: primaryColor || '#000000',
				};
			}
		} else if (iconType === 'framed') {
			if (iconShape === 'circle') {
				iconViewCSS = {
					fill: primaryColor || '#69727d',
				};
			} else if (iconShape === 'square') {
				iconViewCSS = {
					fill: primaryColor || '#69727d',
				};
			}
		}
	}

	if (rotate) {
		iconViewCSS.transform = `rotate(${rotate}deg)`;
	}
	return {
		fill: attributes?.primaryColor || '#69727d',
		...iconViewCSS,
	};
};
