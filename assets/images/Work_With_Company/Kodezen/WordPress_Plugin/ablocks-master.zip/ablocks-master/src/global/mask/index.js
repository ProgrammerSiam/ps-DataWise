import React from 'react';
import PropTypes from 'prop-types';
import { getAttributeDefaultValue } from './helper';
import { objectUniqueCheck } from '@Utils/helper';
import GetDeviceType from '@Utils/get-device-type';
import ABlocksToggleControl from '@Controls/toggleButton';
import ABlocksMaskOptions from './options';
import './styles.scss';

const propTypes = {
	isResponsive: PropTypes.bool,
	label: PropTypes.string,
	attributeName: PropTypes.string,
	attributeValue: PropTypes.any,
	onChangeHandler: PropTypes.func,
	setAttributes: PropTypes.func,
};

const defaultProps = {
	label: '',
	isResponsive: true,
};

export default function ABlocksMasks(props) {
	const {
		isResponsive,
		attributeName,
		attributeValue,
		onChangeHandler,
		setAttributes,
		label,
	} = props;
	const deviceType = GetDeviceType() !== 'Desktop' ? GetDeviceType() : '';

	const changeHandler = (controlValue, name, deviceMode = '') => {
		if (onChangeHandler) {
			onChangeHandler(
				controlValue,
				deviceMode,
				getAttributeDefaultValue(isResponsive)
			);
		} else {
			defaultChangeHandler(controlValue, name, deviceMode);
		}
	};

	const defaultChangeHandler = (controlValue, name, deviceMode) => {
		if (isResponsive) {
			return setAttributes({
				[attributeName]: objectUniqueCheck(
					getAttributeDefaultValue(isResponsive),
					{
						...attributeValue,
						[name + deviceMode]: controlValue,
					}
				),
			});
		}
		return setAttributes({
			[attributeName]: {
				...attributeValue,
				[name + deviceMode]: controlValue,
			},
		});
	};

	const commonProps = {
		deviceType,
		attributeValue,
		changeHandler,
		...props,
	};

	return (
		<React.Fragment>
			{
				<>
					<ABlocksToggleControl
						label={label}
						onChangeHandler={changeHandler}
						attributeObjectKey={'mask'}
						attributeValue={attributeValue}
						setAttributes={setAttributes}
						isResponsive={false}
						deviceType={deviceType}
					/>
					{attributeValue.mask && (
						<ABlocksMaskOptions {...commonProps} />
					)}
				</>
			}
		</React.Fragment>
	);
}

ABlocksMasks.propTypes = propTypes;
ABlocksMasks.defaultProps = defaultProps;
