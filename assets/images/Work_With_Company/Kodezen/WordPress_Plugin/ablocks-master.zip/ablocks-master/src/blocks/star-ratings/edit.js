import React, { useEffect } from 'react';
import Settings from './settings';
import Render from './render';
import CSSGenerator from '@Utils/css-generator';
import {
	getWrapperCSS,
	getRatingNumberCSS,
	getRatingCSS,
	getRatingsCSS,
} from './styling';
export default function Edit(props) {
	const { isSelected, attributes, setAttributes, clientId } = props;
	const { ratingNumberColor, ratingNumberGap, ratingNumberPosition } =
		attributes;
	useEffect(() => {
		setAttributes({ block_id: clientId });
	}, [clientId, setAttributes]);
	// Generate CSS
	const cssGenerator = new CSSGenerator(attributes);

	cssGenerator.addClassStyles(
		'{{WRAPPER}}',
		getWrapperCSS(attributes),
		getWrapperCSS(attributes, 'Tablet'),
		getWrapperCSS(attributes, 'Mobile')
	);
	cssGenerator.addClassStyles(
		'{{WRAPPER}} .ablocks-rating',
		getRatingCSS(attributes),
		getRatingCSS(attributes, 'Tablet'),
		getRatingCSS(attributes, 'Mobile')
	);

	cssGenerator.addClassStyles(
		'{{WRAPPER}} .ablocks-star-ratings-icons',
		getRatingsCSS(attributes),
		getRatingsCSS(attributes, 'Tablet'),
		getRatingsCSS(attributes, 'Mobile')
	);

	const getDesktopRatingNumberCSS = getRatingNumberCSS(attributes);
	if (ratingNumberColor) {
		getDesktopRatingNumberCSS.color = ratingNumberColor;
	}
	if (ratingNumberPosition !== '') {
		if (ratingNumberPosition === 'left') {
			getDesktopRatingNumberCSS.order = '-5';
		} else {
			getDesktopRatingNumberCSS.order = '10';
		}
	}
	if (ratingNumberGap) {
		getDesktopRatingNumberCSS.margin = `0 ${ratingNumberGap}px`;
	}
	cssGenerator.addClassStyles(
		'{{WRAPPER}} .ablocks-star-rating-number',
		getDesktopRatingNumberCSS,
		getRatingNumberCSS(attributes, 'Tablet'),
		getRatingNumberCSS(attributes, 'Mobile')
	);
	const generatedCSS = cssGenerator.generateCSS();
	return (
		<>
			<style>{generatedCSS}</style>
			{isSelected && <Settings {...props} />}
			<Render {...props} />
		</>
	);
}
