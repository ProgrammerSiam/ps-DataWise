import React from 'react';
import { __ } from '@wordpress/i18n';
import { InspectorControls } from '@wordpress/block-editor';
import ABlocksPanelBody from '@Components/panel-body';
import { HTMLTagLists } from '@Controls/select/helper';
import ABlocksTextShadow from '@Controls/textShadow';
import ABlocksTextStroke from '@Controls/textStroke';
import ABlocksTypography from '@Controls/typography';
import InspectorTabs from '@Components/inspector-tabs';
import Separator from '@Components/separator';
import ContentStyleTabs from '@Components/content-style-tabs';
import ABlocksTextareaControl from '@Controls/textarea';

// colors
import ABlocksAlignmentControl from '@Controls/alignment';
import ABlocksColorControl from '@Controls/color-gradient-control';
import ABlocksSelectControl from '@Controls/select';
const propTypes = {};
const defaultProps = {};

export default function Settings(props) {
	const { attributes, setAttributes } = props;
	const {
		heading,
		headingTag,
		alignment,
		typography,
		textShadow,
		textStroke,
		textColor,
	} = attributes;

	return (
		<React.Fragment>
			<InspectorControls>
				<InspectorTabs
					attributes={attributes}
					setAttributes={setAttributes}
				>
					<ABlocksPanelBody
						title={__('Title', 'ablocks')}
						initialOpen={true}
					>
						<ContentStyleTabs
							content={
								<>
									<ABlocksTextareaControl
										label={__('Title', 'ablocks')}
										attributeName="heading"
										attributeValue={heading}
										setAttributes={setAttributes}
										placeholder={__('Enter your title')}
									/>
									<Separator />
									<ABlocksSelectControl
										label={__('HTML Tag', 'ablocks')}
										options={HTMLTagLists}
										isSearch={true}
										attributeName="headingTag"
										attributeValue={headingTag}
										setAttributes={setAttributes}
									/>
									<ABlocksAlignmentControl
										label={__('Alignment', 'ablocks')}
										attributeName="alignment"
										attributeValue={alignment}
										setAttributes={setAttributes}
										isInline={false}
									/>
								</>
							}
							style={
								<>
									<ABlocksColorControl
										label={__('Color', 'ablocks')}
										attributeName="textColor"
										attributeValue={textColor}
										setAttributes={setAttributes}
									/>
									<ABlocksTypography
										label={__('Typography', 'ablocks')}
										attributeName="typography"
										attributeValue={typography}
										setAttributes={setAttributes}
										isResponsive={true}
									/>
									<ABlocksTextShadow
										label={__('Text Shadow', 'ablocks')}
										attributeName="textShadow"
										attributeValue={textShadow}
										setAttributes={setAttributes}
										isResponsive={false}
									/>
									<ABlocksTextStroke
										label={__('Text Stroke', 'ablocks')}
										attributeName="textStroke"
										attributeValue={textStroke}
										setAttributes={setAttributes}
										isResponsive={true}
									/>
								</>
							}
						/>
					</ABlocksPanelBody>
				</InspectorTabs>
			</InspectorControls>
		</React.Fragment>
	);
}

Settings.propTypes = propTypes;
Settings.defaultProps = defaultProps;
