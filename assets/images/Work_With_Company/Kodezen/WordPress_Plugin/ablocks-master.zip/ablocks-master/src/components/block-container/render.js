import React, { useRef, useEffect } from 'react';
import { useBlockProps } from '@wordpress/block-editor';
import PropTypes from 'prop-types';
import { loadGoogleFontsInEditor } from '@Controls/typography/helper';

import { getClassNames } from './helper';
import './styles.scss';

const propTypes = {
	name: PropTypes.string,
	blockId: PropTypes.string,
	typography: PropTypes.array,
};

const defaultProps = {
	attributes: {},
};

const allFonts = {};
const insertFontsData = (fontData) => {
	const fontFamily = fontData?.fontFamily;
	const fontWeight = fontData?.weight || '400';
	const existingWeights = allFonts[fontFamily];
	if (!fontFamily || existingWeights?.includes(fontWeight)) {
		return;
	}
	if (existingWeights) {
		if (fontWeight) {
			existingWeights.push(fontWeight);
		}
	} else {
		allFonts[fontFamily] = fontWeight ? [fontWeight] : [];
	}
};
export default function RenderContainer({
	name,
	blockId,
	children,
	attributes,
	typography,
}) {
	const editorContainerRef = useRef(null);
	const editorContainerEl = editorContainerRef?.current;
	const {
		_hide_on_desktop,
		_hide_on_tablet,
		_hide_on_mobile,
		className = '',
	} = attributes;
	const blockProps = useBlockProps({
		className: getClassNames({
			name,
			blockId,
			className,
			_hide_on_desktop,
			_hide_on_tablet,
			_hide_on_mobile,
		}),
	});

	if (Array.isArray(typography)) {
		for (const item of typography) {
			insertFontsData(item);
		}
	} else {
		for (const key in attributes) {
			if (!/typography/i.test(key)) {
				continue;
			}
			insertFontsData(attributes[key]);
		}
	}

	useEffect(
		() => {
			if (Object.keys(allFonts).length > 0) {
				loadGoogleFontsInEditor(allFonts, editorContainerEl);
			}
		},
		// eslint-disable-next-line react-hooks/exhaustive-deps
		Object.keys(allFonts)
			.concat(
				Object.values(allFonts).reduce(
					(accumulator, currentValue) =>
						accumulator.concat(currentValue),
					[]
				)
			)
			.concat(editorContainerEl)
	);

	return (
		<React.Fragment>
			<div {...blockProps}>
				<div
					className="ablocks-block-container"
					ref={editorContainerRef}
				>
					{children}
				</div>
			</div>
		</React.Fragment>
	);
}

RenderContainer.propTypes = propTypes;
RenderContainer.defaultProps = defaultProps;
