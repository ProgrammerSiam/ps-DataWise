import { getCSS as getAlignmentCSS } from '@Controls/alignment/helper';
import { getCSS as getTypographyCSS } from '@Controls/typography/helper';
import { getCSS as getTextShadowCSS } from '@Controls/textShadow/helper';
import { getCSS as getPaddingCSS } from '@Controls/dimensions/helper';
import {
	getCSS as getBorderCSS,
	getHoverCSS as getBorderHoverCSS,
} from '@Controls/border/helper';

export const getWrapperCSS = (attributes, device = '') => {
	return {
		...getAlignmentCSS(attributes?.alignment, 'text-align', device),
	};
};

export const getButtonCSS = (attributes, device = '') => {
	return {
		...getBorderCSS(attributes?.border, device),
		...getTypographyCSS(attributes?.typography, device),
		...getPaddingCSS(attributes?.padding, 'padding', device),
	};
};

export const getButtonHoverCSS = (attributes, device = '') => {
	const css = {};

	if (attributes?.textColorH) {
		css.color = attributes?.textColorH;
	}
	if (attributes?.backgroundH) {
		css.background = attributes?.backgroundH;
	}

	return {
		...css,
		...getBorderHoverCSS(attributes?.border, device),
	};
};

export const getButtonTextCSS = (attributes) => {
	return {
		...getTextShadowCSS(attributes?.textShadow),
	};
};

export const getIconCSS = (attributes) => {
	return {
		transform: `rotate(${attributes?.rotation}deg)`,
	};
};
