import React from 'react';
import PropTypes from 'prop-types';
import GetDeviceType from '@Utils/get-device-type';
import ControlLabel from '@Components/control-label';
import './editor.scss';
import Tooltip from '../tooltip';
const propTypes = {
	isResponsive: PropTypes.bool,
	allowDeselect: PropTypes.bool,
	isInline: PropTypes.bool,
	options: PropTypes.array,
	setAttributes: PropTypes.func,
	attributeName: PropTypes.string,
	onChangeHandler: PropTypes.func,
	attributeValue: PropTypes.string,
	attributeObjectKey: PropTypes.string,
	label: PropTypes.string,
};

const defaultProps = {
	isResponsive: true,
	allowDeselect: true,
	isInline: false,
	options: [],
};

const ABlocksButtonGroup = (props) => {
	const {
		isResponsive,
		allowDeselect,
		isInline,
		options,
		setAttributes,
		attributeName,
		onChangeHandler,
		attributeValue,
		attributeObjectKey,
		label,
	} = props;

	const deviceType = isResponsive ? GetDeviceType() : '';
	const changeHandler = (controlValue) => {
		const newValue =
			allowDeselect && attributeValue === controlValue
				? undefined
				: controlValue;
		if (onChangeHandler) {
			onChangeHandler(
				newValue,
				isResponsive
					? attributeObjectKey + deviceType
					: attributeObjectKey
			);
		} else {
			defaultChangeHandler(newValue, deviceType);
		}
	};

	const defaultChangeHandler = (controlValue) => {
		if (isResponsive) {
			return setAttributes({
				[attributeName + deviceType]: controlValue,
			});
		}
		return setAttributes({ [attributeName]: controlValue });
	};

	return (
		<div
			className={`ablocks-component ablocks-component--buttongroup ${
				isInline ? 'ablocks-component--buttongroup-inline' : ''
			}`}
		>
			{label && (
				<ControlLabel label={label} isResponsive={isResponsive} />
			)}
			<div className="ablocks-component__buttons">
				{options.map((item, index) => (
					<button
						key={index}
						onClick={() => changeHandler(item.value, item)}
						className={`ablocks-component__button ${
							attributeValue === item.value ? 'active' : ''
						}  ${
							item?.icon
								? 'ablocks-component__button--has-icon'
								: ''
						} `}
					>
						{item.icon ? (
							<Tooltip
								position={item?.tooltipPosition}
								tooltipText={item?.label}
							>
								{item.icon}
							</Tooltip>
						) : (
							item?.label
						)}
					</button>
				))}
			</div>
		</div>
	);
};

ABlocksButtonGroup.propTypes = propTypes;
ABlocksButtonGroup.defaultProps = defaultProps;

export default ABlocksButtonGroup;
