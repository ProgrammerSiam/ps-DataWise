import PropTypes from 'prop-types';
import ABlocksVideoStartAndEndTime from './options/start-end-time';
import ABlocksBackgroundVideoFallback from './options/video-fallback';
import ABlocksVideoOptions from './options/video-options';
import ABlockVideoSource from './options/video-source';

const propTypes = {
	changeHandler: PropTypes.func,
	onSelectVideoHandler: PropTypes.func,
	onRemoveVideoHandler: PropTypes.func,
	onSelectFallbackImageHandler: PropTypes.func,
	onRemoveFallbackImageHandler: PropTypes.func,
	isBackgroundControl: PropTypes.bool,
	attributeName: PropTypes.string,
	attributeValue: PropTypes.object,
	setAttributes: PropTypes.func,
};

export default function ABlocksVideoControl(props) {
	const {
		changeHandler,
		onSelectVideoHandler,
		onRemoveVideoHandler,
		onSelectFallbackImageHandler,
		onRemoveFallbackImageHandler,
		isBackgroundControl,
	} = props;

	const commonProps = {
		...props,
	};

	return (
		<>
			{/* Video Sources */}
			<ABlockVideoSource
				{...commonProps}
				changeHandler={changeHandler}
				onSelectVideoHandler={onSelectVideoHandler}
				onRemoveVideoHandler={onRemoveVideoHandler}
			/>

			{/* Video Start and end time */}
			<ABlocksVideoStartAndEndTime {...commonProps} />

			{/* Background Video Options  */}
			<ABlocksVideoOptions
				{...commonProps}
				isBackgroundControl={isBackgroundControl}
			/>

			{/* Background Video Fallback  */}
			<ABlocksBackgroundVideoFallback
				{...commonProps}
				onSelectFallbackImageHandler={onSelectFallbackImageHandler}
				onRemoveFallbackImageHandler={onRemoveFallbackImageHandler}
			/>
		</>
	);
}

ABlocksVideoControl.propTypes = propTypes;
