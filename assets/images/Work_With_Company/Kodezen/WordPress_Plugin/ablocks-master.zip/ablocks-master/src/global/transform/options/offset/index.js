import { __ } from '@wordpress/i18n';
import AblocksPopover from '@Components/popover';
import ABlocksRangeControl from '@Controls/range';
import ControlLabel from '@Components/control-label';
import Button from '@Components/Button';
import { useRef, useState } from 'react';

const ABlocksOffSet = ({ label, hover, resetHandler, ...props }) => {
	const [isVisible, setIsVisible] = useState(false);
	const anchorRef = useRef(null);
	let attributeObjectKeyForOffsetX = 'offsetX';
	let attributeObjectKeyForOffsetY = 'offsetY';

	if (hover) {
		attributeObjectKeyForOffsetX = 'offsetXH';
		attributeObjectKeyForOffsetY = 'offsetYH';
	}

	const handleReset = () =>
		resetHandler({
			[attributeObjectKeyForOffsetX]: '',
			[attributeObjectKeyForOffsetY]: '',
		});

	const togglePopoverVisibility = () => {
		setIsVisible(!isVisible);
	};

	const commonProps = {
		...props,
		// following 'min' & 'max' will be dynamic when 'units' options are added for 'offset'.
		min: -1000,
		max: 1000,
	};

	return (
		<div className="ablocks-control ablocks-control-color-gradient-root-wrapper">
			{label && (
				<div className="ablocks-control-label">
					<ControlLabel label={label} isResponsive={false} />
				</div>
			)}
			<div className="ablocks-control-color-gradient">
				<div className="ablocks-component-popover">
					<div className="ablocks-component-popover__field">
						<div
							className="ablocks-component-popover-toggler-wrapper"
							ref={anchorRef}
						>
							<Button
								ref={anchorRef}
								onClick={togglePopoverVisibility}
								icon={
									<span className="ablocks-icon ablocks-icon--edit"></span>
								}
								preset="transparent"
								className={
									isVisible
										? 'ablocks-component-popover__field--active'
										: ''
								}
							/>
						</div>
					</div>
					{isVisible && (
						<AblocksPopover
							label={__('Offset', 'ablocks')}
							isShowPrimaryLabel={false}
							isReset={true}
							handleReset={handleReset}
							isVisible={isVisible}
							toggleVisible={setIsVisible}
							anchorRef={anchorRef}
						>
							<ABlocksRangeControl
								{...commonProps}
								label={__('Offset X', 'ablocks')}
								isInline={false}
								hasUnit={true}
								attributeObjectKey={
									attributeObjectKeyForOffsetX
								}
							/>
							<ABlocksRangeControl
								{...commonProps}
								label={__('Offset Y', 'ablocks')}
								isInline={false}
								hasUnit={true}
								attributeObjectKey={
									attributeObjectKeyForOffsetY
								}
							/>
						</AblocksPopover>
					)}
				</div>
			</div>
		</div>
	);
};

export default ABlocksOffSet;
