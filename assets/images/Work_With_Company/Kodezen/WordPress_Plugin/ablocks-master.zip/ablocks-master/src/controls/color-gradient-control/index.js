import React, { useState, useRef } from 'react';
import { __ } from '@wordpress/i18n';
import PropTypes from 'prop-types';
import ControlLabel from '@Components/control-label';
import AblocksPopover from '@Components/popover';
import { ColorGradientMain } from './color-gradient-picker';
import { noop } from './commonFunctions';
import './editor.scss';

const propTypes = {
	label: PropTypes.string,
	isGradient: PropTypes.bool,
	attributeName: PropTypes.string,
	attributeValue: PropTypes.string,
	setAttributes: PropTypes.func,
	onChangeHandler: PropTypes.func,
	resetHandler: PropTypes.func,
};

const defaultProps = {
	label: '',
	isGradient: false,
	attributeName: '',
	setAttributes: noop,
};

// Handle Linear color
const LinearGradientIcon = ({ colors }) => {
	const gradient =
		colors && colors.length > 1
			? `linear-gradient(to right, ${colors.join(', ')})`
			: colors[0];

	return (
		<div
			style={{
				width: '20px',
				height: '20px',
				background: gradient,
				borderRadius: '4px',
			}}
		/>
	);
};

// Handle Radial Color
const RadialGradientIcon = ({ colors }) => {
	const gradient =
		colors && colors.length > 1
			? `radial-gradient(circle, ${colors.join(', ')})`
			: colors[0];

	return (
		<div
			style={{
				width: '20px',
				height: '20px',
				background: gradient,
				borderRadius: '4px',
			}}
		/>
	);
};

// Hex or RGB or HSL SVG
const ColorIcon = ({ color }) => (
	<div
		style={{
			width: '20px',
			height: '20px',
			background: color,
			borderRadius: '4px',
		}}
	/>
);

// Default SVG
const DefaultIcon = () => (
	<svg
		xmlns="http://www.w3.org/2000/svg"
		width="14"
		height="14"
		viewBox="0 0 14 14"
		fill="none"
	>
		<mask id="path-1-inside-1_3380_808" fill="white">
			<path d="M6.99996 13.2708C3.54079 13.2708 0.729126 10.4592 0.729126 6.99999C0.729126 3.54082 3.54079 0.729156 6.99996 0.729156C10.4591 0.729156 13.2708 3.54082 13.2708 6.99999C13.2708 10.4592 10.4591 13.2708 6.99996 13.2708ZM6.99996 1.60416C4.02496 1.60416 1.60413 4.02499 1.60413 6.99999C1.60413 9.97499 4.02496 12.3958 6.99996 12.3958C9.97496 12.3958 12.3958 9.97499 12.3958 6.99999C12.3958 4.02499 9.97496 1.60416 6.99996 1.60416Z" />
		</mask>
		<path
			d="M6.99996 13.2708C3.54079 13.2708 0.729126 10.4592 0.729126 6.99999C0.729126 3.54082 3.54079 0.729156 6.99996 0.729156C10.4591 0.729156 13.2708 3.54082 13.2708 6.99999C13.2708 10.4592 10.4591 13.2708 6.99996 13.2708ZM6.99996 1.60416C4.02496 1.60416 1.60413 4.02499 1.60413 6.99999C1.60413 9.97499 4.02496 12.3958 6.99996 12.3958C9.97496 12.3958 12.3958 9.97499 12.3958 6.99999C12.3958 4.02499 9.97496 1.60416 6.99996 1.60416Z"
			fill="#A7AAAD"
		/>
		<path
			d="M6.99996 12.2708C4.09308 12.2708 1.72913 9.90687 1.72913 6.99999H-0.270874C-0.270874 11.0114 2.98851 14.2708 6.99996 14.2708V12.2708ZM1.72913 6.99999C1.72913 4.09311 4.09308 1.72916 6.99996 1.72916V-0.270844C2.98851 -0.270844 -0.270874 2.98854 -0.270874 6.99999H1.72913ZM6.99996 1.72916C9.90684 1.72916 12.2708 4.09311 12.2708 6.99999H14.2708C14.2708 2.98854 11.0114 -0.270844 6.99996 -0.270844V1.72916ZM12.2708 6.99999C12.2708 9.90687 9.90684 12.2708 6.99996 12.2708V14.2708C11.0114 14.2708 14.2708 11.0114 14.2708 6.99999H12.2708ZM6.99996 0.604156C3.47267 0.604156 0.604126 3.47271 0.604126 6.99999H2.60413C2.60413 4.57727 4.57724 2.60416 6.99996 2.60416V0.604156ZM0.604126 6.99999C0.604126 10.5273 3.47267 13.3958 6.99996 13.3958V11.3958C4.57724 11.3958 2.60413 9.4227 2.60413 6.99999H0.604126ZM6.99996 13.3958C10.5272 13.3958 13.3958 10.5273 13.3958 6.99999H11.3958C11.3958 9.4227 9.42267 11.3958 6.99996 11.3958V13.3958ZM13.3958 6.99999C13.3958 3.47271 10.5272 0.604156 6.99996 0.604156V2.60416C9.42267 2.60416 11.3958 4.57727 11.3958 6.99999H13.3958Z"
			fill="#A7AAAD"
			mask="url(#path-1-inside-1_3380_808)"
		/>
		<mask id="path-3-inside-2_3380_808" fill="white">
			<path d="M2.85828 11.5208C2.74745 11.5208 2.63662 11.48 2.54912 11.3925C2.37995 11.2233 2.37995 10.9433 2.54912 10.7742L10.7158 2.6075C10.885 2.43833 11.165 2.43833 11.3341 2.6075C11.5033 2.77666 11.5033 3.05666 11.3341 3.22583L3.16745 11.3925C3.07995 11.48 2.96912 11.5208 2.85828 11.5208Z" />
		</mask>
		<path
			d="M2.85828 11.5208C2.74745 11.5208 2.63662 11.48 2.54912 11.3925C2.37995 11.2233 2.37995 10.9433 2.54912 10.7742L10.7158 2.6075C10.885 2.43833 11.165 2.43833 11.3341 2.6075C11.5033 2.77666 11.5033 3.05666 11.3341 3.22583L3.16745 11.3925C3.07995 11.48 2.96912 11.5208 2.85828 11.5208Z"
			fill="#A7AAAD"
		/>
		<path
			d="M2.54912 10.7742L1.84201 10.0671H1.84201L2.54912 10.7742ZM10.7158 2.6075L11.4229 3.3146L10.7158 2.6075ZM11.3341 3.22583L10.627 2.51872L11.3341 3.22583ZM3.16745 11.3925L3.87456 12.0996L3.16745 11.3925ZM2.85828 10.5208C2.99835 10.5208 3.1463 10.5755 3.25622 10.6854L1.84201 12.0996C2.12693 12.3845 2.49655 12.5208 2.85828 12.5208V10.5208ZM3.25622 10.6854C3.47758 10.9067 3.47758 11.2599 3.25622 11.4813L1.84201 10.0671C1.28232 10.6267 1.28232 11.5399 1.84201 12.0996L3.25622 10.6854ZM3.25622 11.4813L11.4229 3.3146L10.0087 1.90039L1.84201 10.0671L3.25622 11.4813ZM11.4229 3.3146C11.2015 3.53596 10.8484 3.53596 10.627 3.3146L12.0412 1.90039C11.4815 1.3407 10.5684 1.3407 10.0087 1.90039L11.4229 3.3146ZM10.627 3.3146C10.4057 3.09325 10.4057 2.74008 10.627 2.51872L12.0412 3.93294C12.6009 3.37325 12.6009 2.46008 12.0412 1.90039L10.627 3.3146ZM10.627 2.51872L2.46034 10.6854L3.87456 12.0996L12.0412 3.93294L10.627 2.51872ZM2.46034 10.6854C2.57026 10.5755 2.71821 10.5208 2.85828 10.5208V12.5208C3.22002 12.5208 3.58964 12.3845 3.87456 12.0996L2.46034 10.6854Z"
			fill="#A7AAAD"
			mask="url(#path-3-inside-2_3380_808)"
		/>
	</svg>
);

// Extract colors from gradient value
const extractGradientColors = (value) => {
	if (!value) {
		return ['#BE21FF', '#736EC8', '#29A6FE'];
	}

	const colorRegex =
		/#[0-9a-fA-F]{6}|#[0-9a-fA-F]{3}|rgba?\(.*?\)|hsla?\(.*?\)/g;
	const colors = value.match(colorRegex) || [];
	return colors.slice(0, 3);
};

const ABlocksColorControl = ({
	label,
	isGradient,
	attributeName,
	attributeValue,
	setAttributes,
	onChangeHandler,
	resetHandler,
}) => {
	const [isVisible, setIsVisible] = useState(false);
	const [activeTab, setActiveTab] = useState(null);
	const anchorRef = useRef(null);

	const onChange = (value) => {
		if (onChangeHandler) {
			onChangeHandler(attributeName, value);
		} else {
			setAttributes({ [attributeName]: value });
		}
	};

	const handleInputChange = (value) => {
		onChange(value);
	};

	const handleResetColor = () => {
		if (resetHandler) {
			resetHandler();
		} else {
			setAttributes({ [attributeName]: undefined });
		}
	};

	const toggleVisible = (state) => {
		setIsVisible(state);
	};

	const getDisplayValue = (value) => {
		if (!value) {
			return '';
		} // Ensure value is a string
		if (value.startsWith('linear')) {
			return 'Linear';
		} else if (value.startsWith('radial')) {
			return 'Radial';
		} else if (value.startsWith('rgba')) {
			return 'rgba';
		} else if (value.startsWith('hsla')) {
			return 'hsla';
		}
		return value;
	};

	const gradientColors = attributeValue
		? extractGradientColors(attributeValue)
		: [];

	const isLinearGradient =
		attributeValue && attributeValue.startsWith('linear');
	const isRadialGradient =
		attributeValue && attributeValue.startsWith('radial');
	const isRgb = attributeValue && attributeValue.startsWith('rgba');
	const isHsl = attributeValue && attributeValue.startsWith('hsla');
	const isSolidColor =
		attributeValue &&
		!isLinearGradient &&
		!isRadialGradient &&
		!isRgb &&
		!isHsl;

	return (
		<div className="ablocks-control ablocks-control-color-gradient-root-wrapper">
			{label && (
				<div className="ablocks-control-label">
					<ControlLabel label={label} isResponsive={false} />
				</div>
			)}
			<div className="ablocks-control-color-gradient" ref={anchorRef}>
				<div className="ablocks-component-popover">
					<div className="ablocks-component-popover__field">
						<div className="ablocks-component-popover-toggler-wrapper">
							<div className="ablocks-component-popover__input-wrapper">
								<input
									type="text"
									className="ablocks-component-popover__input"
									value={getDisplayValue(
										attributeValue || ''
									)}
									placeholder={__('Add…..', 'ablocks')}
									onChange={(e) =>
										handleInputChange(e.target.value)
									}
									onClick={
										!attributeValue
											? () => toggleVisible(true)
											: undefined
									}
								/>
								{attributeValue && attributeValue.trim() && (
									<span
										className="ablocks-component-popover__clear-button"
										onClick={handleResetColor}
										role="presentation"
									>
										&times;
									</span>
								)}
								<div
									className="ablocks-component-popover__color-button"
									onClick={() => toggleVisible(true)}
									role="presentation"
								>
									{isLinearGradient && (
										<LinearGradientIcon
											colors={gradientColors}
										/>
									)}
									{isRadialGradient && (
										<RadialGradientIcon
											colors={gradientColors}
										/>
									)}
									{isSolidColor && (
										<ColorIcon color={attributeValue} />
									)}
									{isRgb && (
										<ColorIcon color={attributeValue} />
									)}
									{isHsl && (
										<ColorIcon color={attributeValue} />
									)}
									{!attributeValue && <DefaultIcon />}
								</div>
							</div>
						</div>
					</div>
					{isVisible && (
						<AblocksPopover
							className={`ablocks-control-color-gradient-popover ablocks-active-tab-${activeTab}`}
							label={__('Color', 'ablocks')}
							isShowPrimaryLabel={false}
							isReset={true}
							handleReset={handleResetColor}
							isVisible={isVisible}
							toggleVisible={toggleVisible}
							anchorRef={anchorRef} // Pass anchorRef to AblocksPopover
						>
							<div className="ablocks-control--customizable-color-gradient">
								<ColorGradientMain
									setActiveTab={setActiveTab}
									allowGradient={isGradient}
									value={attributeValue || ''}
									onChange={onChange}
								/>
							</div>
						</AblocksPopover>
					)}
				</div>
			</div>
		</div>
	);
};

ABlocksColorControl.propTypes = propTypes;
ABlocksColorControl.defaultProps = defaultProps;

export default ABlocksColorControl;
