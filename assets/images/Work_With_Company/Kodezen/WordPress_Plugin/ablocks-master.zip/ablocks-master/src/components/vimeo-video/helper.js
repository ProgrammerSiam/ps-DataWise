export function getVimeoVideoId(url) {
	const match = url?.match(/vimeo\.com\/(\d+)/);
	return match && match[1];
}

export const generateVimeoVideoSrc = ({
	vimeoVideoId,
	autoplay,
	loop,
	mute,
	introPortrait,
	introTitle,
	introByline,
	isBackground,
	getStartTime,
}) => {
	const baseVimeoURL = 'https://player.vimeo.com/video/';
	const defaultVimeoVideoId = '889428749';
	const commonLink = `?color&autopause=0&muted=${mute ? '1' : '0'}&autoplay=${
		autoplay ? '1' : '0'
	}&portrait=${introPortrait ? '1' : '0'}&title=${
		introTitle ? '1' : '0'
	}&byline=${introByline ? '1' : '0'}&loop=${loop ? '1' : '0'}${
		isBackground ? '&background=1' : '&background=0'
	}${getStartTime || ''}`;

	// &transparent=0

	const videoSrc = vimeoVideoId
		? `${baseVimeoURL}${vimeoVideoId + commonLink}`
		: `${baseVimeoURL}${defaultVimeoVideoId + commonLink}`;

	return videoSrc;
};

function secondsToVimeoTime(seconds) {
	const hours = Math.floor(seconds / 3600);
	const minutes = Math.floor((seconds % 3600) / 60);
	const remainingSeconds = seconds % 60;

	const timeString = `#t=${hours.toString().padStart(2, '0')}h${minutes
		.toString()
		.padStart(2, '0')}m${remainingSeconds.toString().padStart(2, '0')}s`;

	return timeString;
}

export const handleVimeoVideoTime = (videoStartTime) => {
	const isVideoTimeSet = videoStartTime
		? secondsToVimeoTime(videoStartTime)
		: ``;
	return isVideoTimeSet;
};

// https://vimeo.com/889428749
// 'https://player.vimeo.com/video/235215203?color&autopause=0&loop=0&muted=0&title=1&portrait=1&byline=1#t=';
