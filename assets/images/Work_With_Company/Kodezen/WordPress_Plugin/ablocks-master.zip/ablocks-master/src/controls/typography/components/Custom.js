import React, { useEffect, useRef, useState } from 'react';
import AblocksPopover from '@Components/popover';
import { __ } from '@wordpress/i18n';
import ABlocksRangeControl from '@Controls/range';
import ABlocksSelectControl from '@Controls/select';
import ControlLabel from '@Components/control-label';
import {
	fontWeight as defaultFontWeights,
	transform,
	style,
	decoration,
} from '../helper';
import { googleFontsAll, normalFonts } from '../googleFonts';

const { fontVariants } = googleFontsAll;
const noop = () => {};

const DefaultIcon = () => (
	<svg
		xmlns="http://www.w3.org/2000/svg"
		width="12"
		height="12"
		viewBox="0 0 12 12"
		fill="none"
	>
		<path
			d="M10.665 3.96001C10.46 3.96001 10.29 3.79001 10.29 3.58501V2.67501C10.29 2.31001 9.99496 2.01501 9.62996 2.01501H2.36996C2.00496 2.01501 1.70996 2.31001 1.70996 2.67501V3.59001C1.70996 3.79501 1.53996 3.96501 1.33496 3.96501C1.12996 3.96501 0.959961 3.79501 0.959961 3.58501V2.67501C0.959961 1.89501 1.59496 1.26501 2.36996 1.26501H9.62996C10.41 1.26501 11.04 1.90001 11.04 2.67501V3.59001C11.04 3.79501 10.875 3.96001 10.665 3.96001Z"
			fill="#A7AAAD"
		/>
		<path
			d="M6 10.735C5.795 10.735 5.625 10.565 5.625 10.36V2.05499C5.625 1.84999 5.795 1.67999 6 1.67999C6.205 1.67999 6.375 1.84999 6.375 2.05499V10.36C6.375 10.57 6.205 10.735 6 10.735Z"
			fill="#A7AAAD"
		/>
		<path
			d="M7.97003 10.735H4.03003C3.82503 10.735 3.65503 10.565 3.65503 10.36C3.65503 10.155 3.82503 9.98499 4.03003 9.98499H7.97003C8.17503 9.98499 8.34503 10.155 8.34503 10.36C8.34503 10.565 8.17503 10.735 7.97003 10.735Z"
			fill="#A7AAAD"
		/>
	</svg>
);

const ABlockCustomTypography = ({
	attributeValue,
	changeHandler,
	deviceType,
	isResponsive,
	resetHandler,
	attributeName,
	setAttributes,
	label,
}) => {
	const [fontWeights, setFontWeights] = useState(defaultFontWeights);
	const [isVisible, setIsVisible] = useState(false);
	const anchorRef = useRef(null);

	const handleResetTypography = () => {
		resetHandler({
			[`fontFamily${deviceType}`]: '',
			[`fontSize${deviceType}`]: '',
			[`fontSizeUnit${deviceType}`]: 'px',
			weight: '',
			transform: '',
			style: '',
			decoration: '',
			[`lineHeight${deviceType}`]: '',
			[`lineHeightUnit${deviceType}`]: 'px',
			[`letterSpacing${deviceType}`]: '',
			[`letterSpacingUnit${deviceType}`]: 'px',
			[`wordSpacing${deviceType}`]: '',
			[`wordSpacingUnit${deviceType}`]: 'px',
		});
	};

	useEffect(() => {
		const { fontFamily, weight } = attributeValue || {};
		if (fontVariants[fontFamily]) {
			const availableWeights = fontVariants[fontFamily]?.variants;

			if (weight && !availableWeights.includes(weight)) {
				const newAttributeValue = {
					...attributeValue,
					weight: '400',
				};
				setAttributes({
					[attributeName]: newAttributeValue,
				});
			}
			const isSameWeights = fontWeights.every(
				(item, index) => item.value === availableWeights[index]
			);
			if (isSameWeights) {
				return noop;
			}
			const filteredWeights = fontWeights.filter((item) =>
				availableWeights.includes(item.value)
			);
			setFontWeights(filteredWeights);
		} else {
			if (
				JSON.stringify(fontWeights) ===
				JSON.stringify(defaultFontWeights)
			) {
				return noop;
			}
			setFontWeights(defaultFontWeights);
		}
	}, [attributeValue?.fontFamily, attributeValue?.weight, fontWeights]); // eslint-disable-line react-hooks/exhaustive-deps

	const handleResetBoxTypography = () => {
		resetHandler({
			fontFamily: '',
			weight: '',
			transform: '',
			style: '',
			lineHeight: '',
			letterSpacing: '',
			wordSpacing: '',
			fontSize: '',
			fontSizeUnit: '',
		});
	};

	const togglePopoverVisibility = (forceOpen = false) => {
		setIsVisible((prevIsVisible) => forceOpen || !prevIsVisible);
	};

	const handleInputChange = (value) => {
		changeHandler(value, 'text');
	};

	return (
		<div className="ablocks-control ablocks-control--text-shadow">
			{label && (
				<div className="ablocks-control-label">
					<ControlLabel label={label} isResponsive={false} />
				</div>
			)}
			<div className="ablocks-control-color-gradient">
				<div className="ablocks-component-popover">
					<div className="ablocks-component-popover__field">
						<div
							className="ablocks-component-popover-toggler-wrapper"
							ref={anchorRef}
						>
							<div className="ablocks-component-popover__input-wrapper">
								<input
									type="text"
									className="ablocks-component-popover__input"
									value={`${
										attributeValue?.fontFamily?.split(
											' '
										)[0] || 'Default'
									}${
										attributeValue?.fontSize
											? `-${attributeValue.fontSize}${
													attributeValue?.fontSizeUnit ||
													'px'
											  }`
											: ''
									}`}
									placeholder={__('Add…', 'ablocks')}
									onChange={(e) =>
										handleInputChange(e.target.value)
									}
									onClick={() => {
										if (
											!attributeValue?.fontFamily &&
											!attributeValue?.fontSize
										) {
											togglePopoverVisibility(true);
										}
									}}
								/>
								{(attributeValue?.fontFamily ||
									attributeValue?.fontSize) && (
									<span
										className="ablocks-component-popover__clear-button"
										onClick={handleResetBoxTypography}
										role="presentation"
									>
										&times;
									</span>
								)}
								<div
									className="ablocks-component-popover__color-button"
									onClick={() => togglePopoverVisibility()}
									role="presentation"
								>
									<DefaultIcon />
								</div>
							</div>
						</div>
					</div>
				</div>
				{isVisible && (
					<AblocksPopover
						label={__('Typography', 'ablocks')}
						isShowPrimaryLabel={false}
						isReset={true}
						handleReset={handleResetTypography}
						isVisible={isVisible}
						toggleVisible={setIsVisible}
						anchorRef={anchorRef}
					>
						<div className="ablocks-popover__content">
							<ABlocksSelectControl
								options={[
									...normalFonts,
									...googleFontsAll.families,
								]}
								label={__('Family', 'ablocks')}
								attributeObjectKey={'fontFamily'}
								attributeValue={attributeValue}
								attributeName={attributeName}
								setAttributes={setAttributes}
								isSearch
							/>
							<ABlocksRangeControl
								isResponsive={isResponsive}
								attributeName={attributeName}
								attributeValue={attributeValue}
								setAttributes={setAttributes}
								attributeObjectKey="fontSize"
								onChangeHandler={changeHandler}
								label={__('Size', 'ablocks')}
								min={0}
								max={200}
								isInline={false}
								hasUnit={true}
							/>

							<ABlocksSelectControl
								options={fontWeights}
								label={__('Weight', 'ablocks')}
								attributeObjectKey={'weight'}
								attributeValue={attributeValue}
								attributeName={attributeName}
								setAttributes={setAttributes}
							/>

							<ABlocksSelectControl
								label={__('Transform', 'ablocks')}
								options={transform}
								attributeObjectKey={'transform'}
								attributeValue={attributeValue}
								attributeName={attributeName}
								setAttributes={setAttributes}
							/>
							<ABlocksSelectControl
								label={__('Style', 'ablocks')}
								options={style}
								attributeObjectKey={'style'}
								attributeValue={attributeValue}
								attributeName={attributeName}
								setAttributes={setAttributes}
							/>
							<ABlocksSelectControl
								label={__('Decoration', 'ablocks')}
								options={decoration}
								attributeObjectKey={'decoration'}
								attributeValue={attributeValue}
								attributeName={attributeName}
								setAttributes={setAttributes}
							/>
							<ABlocksRangeControl
								isResponsive={isResponsive}
								attributeName={attributeName}
								attributeValue={attributeValue}
								setAttributes={setAttributes}
								attributeObjectKey="lineHeight"
								onChangeHandler={changeHandler}
								label={__('Line-Height', 'ablocks')}
								min={0}
								max={100}
								isInline={false}
								hasUnit={true}
							/>
							<ABlocksRangeControl
								isResponsive={isResponsive}
								attributeName={attributeName}
								attributeValue={attributeValue}
								setAttributes={setAttributes}
								attributeObjectKey="letterSpacing"
								onChangeHandler={changeHandler}
								label={__('Letter Spacing', 'ablocks')}
								min={0}
								max={10}
								isInline={false}
								hasUnit={true}
							/>
							<ABlocksRangeControl
								isResponsive={isResponsive}
								attributeName={attributeName}
								attributeValue={attributeValue}
								setAttributes={setAttributes}
								attributeObjectKey="wordSpacing"
								onChangeHandler={changeHandler}
								label={__('Word spacing', 'ablocks')}
								min={0}
								max={50}
								isInline={false}
								hasUnit={true}
							/>
						</div>
					</AblocksPopover>
				)}
			</div>
		</div>
	);
};

export default ABlockCustomTypography;
