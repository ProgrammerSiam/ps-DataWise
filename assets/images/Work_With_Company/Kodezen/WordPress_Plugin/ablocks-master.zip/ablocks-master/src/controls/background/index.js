import React from 'react';
import PropTypes from 'prop-types';
import { objectUniqueCheck } from '@Utils/helper';
import { getAttributeDefaultValue } from './helper';
import NormalHoverTabs from '@Components/normal-hover-tabs';
import BackgroundAllOptions from './options';
import GetDeviceType from '@Utils/get-device-type';

const propTypes = {
	isResponsive: PropTypes.bool,
	attributeName: PropTypes.string,
	attributeValue: PropTypes.any,
	setAttributes: PropTypes.func,
};

const defaultProps = {
	isResponsive: true,
};
export default function ABlocksBackgroundControl(props) {
	const { attributeName, attributeValue, setAttributes, isResponsive } =
		props;
	const deviceType = GetDeviceType();

	const changeHandler = (paramControlValue, paramAttributeObjectKey) => {
		return setAttributes({
			[attributeName]: objectUniqueCheck(
				getAttributeDefaultValue(isResponsive),
				{
					...attributeValue,
					[paramAttributeObjectKey]: paramControlValue,
				}
			),
		});
	};

	return (
		<div className="ablocks-control ablocks-control--background">
			<NormalHoverTabs
				normal={
					<BackgroundAllOptions
						{...props}
						deviceType={deviceType}
						changeHandler={changeHandler}
					/>
				}
				hover={
					<BackgroundAllOptions
						{...props}
						hover
						deviceType={deviceType}
						changeHandler={changeHandler}
					/>
				}
			/>
		</div>
	);
}
ABlocksBackgroundControl.propTypes = propTypes;
ABlocksBackgroundControl.defaultProps = defaultProps;
