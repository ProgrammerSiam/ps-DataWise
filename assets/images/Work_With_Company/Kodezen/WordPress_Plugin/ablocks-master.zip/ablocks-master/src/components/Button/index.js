import classNames from 'classnames';
import './editor.scss';
const ABlocksButton = (props) => {
	const {
		label,
		icon,
		iconPosition,
		isDisabled,
		onClick,
		buttonStyle,
		className,
		buttonType,
		type,
		link,
		target,
		suffix,
		preset,
		buttonSize,
	} = props;

	const buttonClasses = classNames(`ablocks-btn`, {
		['ablocks-btn--' + suffix]: suffix,
		['ablocks-btn--' + preset]: preset,
		// button position = left, right, top, bottom
		['ablocks-btn--' + iconPosition]: iconPosition,
		// button size = xs, sm, md, lg
		['ablocks-btn--' + buttonSize]: buttonSize,
		'ablocks-btn--primary': !buttonType && label,
		'ablocks-btn--secondary': buttonType === 'secondary' && !isDisabled,
		'ablocks-btn--tertiary': buttonType === 'tertiary' && !isDisabled,
		'ablocks-btn--primary-disabled': isDisabled && !buttonType,
		'ablocks-btn--secondary-disabled':
			isDisabled && buttonType === 'secondary',
		'ablocks-btn--tertiary-disabled':
			isDisabled && buttonType === 'tertiary',
	});

	if (type === 'link') {
		return (
			<>
				<a
					href={link}
					className={className ? className : buttonClasses}
					onClick={onClick}
					disabled={isDisabled}
					style={buttonStyle}
					rel="noreferrer"
					target={target}
				>
					{icon && iconPosition !== 'right' ? icon : ''}
					{label && (
						<span className="ablocks-btn--label">{label}</span>
					)}
					{icon && iconPosition === 'right' && icon}
				</a>
			</>
		);
	}
	return (
		<>
			<button
				className={className ? className : buttonClasses}
				disabled={isDisabled}
				onClick={onClick}
				style={buttonStyle}
			>
				{iconPosition !== 'right' && icon}
				{label && <span className="ablocks-btn--label">{label}</span>}
				{iconPosition === 'right' && icon}
			</button>
		</>
	);
};

export default ABlocksButton;
