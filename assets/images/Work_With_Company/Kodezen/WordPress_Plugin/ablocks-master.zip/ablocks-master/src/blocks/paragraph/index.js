import { registerBlockType } from '@wordpress/blocks';
import attributes from './attributes';
import Edit from './edit';
import Save from './save';
import metadata from './block.json';

registerBlockType(metadata.name, {
	attributes,
	icon: (
		<svg
			width="24"
			height="25"
			viewBox="0 0 24 25"
			fill="none"
			xmlns="http://www.w3.org/2000/svg"
		>
			<path
				d="M9.99609 14.5609V14.3358L10 14.3359V20.5609H11.5V6.06091H14V20.5609H15.5V6.06091H18.5V4.56091H9.99609C7.23467 4.56091 4.99609 6.79949 4.99609 9.56091C4.99609 12.3223 7.23467 14.5609 9.99609 14.5609Z"
				fill="#E930F0"
			/>
		</svg>
	),
	edit: Edit,
	save: Save,
});
