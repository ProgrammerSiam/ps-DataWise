import React, { useEffect } from 'react';
import Settings from './settings';
import Render from './render';
import CSSGenerator from '@Utils/css-generator';

export default function Edit(props) {
	const { isSelected, attributes, setAttributes, clientId } = props;

	useEffect(() => {
		setAttributes({ block_id: clientId });
	}, [clientId, setAttributes]);

	// Generate CSS
	const cssGenerator = new CSSGenerator(attributes);

	const generatedCSS = cssGenerator.generateCSS();

	return (
		<>
			<style>{generatedCSS}</style>
			{isSelected && <Settings {...props} />}
			<Render {...props} />
		</>
	);
}
