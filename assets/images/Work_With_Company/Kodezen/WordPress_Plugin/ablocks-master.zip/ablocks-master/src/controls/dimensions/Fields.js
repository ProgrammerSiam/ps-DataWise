import React from 'react';
import PropTypes from 'prop-types';
import { TextControl } from '@wordpress/components';
import Button from '@Components/Button';
import './editor.scss';
import { getAttributeDefaultValue } from './helper';
import { objectUniqueCheck } from '@Utils/helper';
import { __ } from '@wordpress/i18n';
import Tooltip from '@Components/tooltip';
const propTypes = {
	attributeName: PropTypes.string,
	deviceType: PropTypes.string,
	attributeValue: PropTypes.any,
	changeHandler: PropTypes.func,
	setAttributes: PropTypes.func,
	isResponsive: PropTypes.bool,
	attributeObjectKeySuffix: PropTypes.string,
	isDefaultLinked: PropTypes.bool,
};

const defaultProps = {
	attributeName: '',
	deviceType: '',
	attributeObjectKeySuffix: '',
	isDefaultLinked: true,
};

function ABlocksDimensionFields({
	attributeValue,
	attributeName,
	deviceType,
	changeHandler,
	setAttributes,
	isResponsive,
	attributeObjectKeySuffix,
	isDefaultLinked,
}) {
	const placeholderValue = {};
	const isForResponsiveDevice = isResponsive && deviceType;

	if (isForResponsiveDevice) {
		const common = attributeValue['common' + attributeObjectKeySuffix];
		const commonTablet =
			attributeValue['common' + attributeObjectKeySuffix + 'Tablet'];
		const commonMobile =
			attributeValue['common' + attributeObjectKeySuffix + 'Mobile'];

		const top = attributeValue['top' + attributeObjectKeySuffix];
		const topTablet =
			attributeValue['top' + attributeObjectKeySuffix + 'Tablet'];
		const topMobile =
			attributeValue['top' + attributeObjectKeySuffix + 'Mobile'];

		const right = attributeValue['right' + attributeObjectKeySuffix];
		const rightTablet =
			attributeValue['right' + attributeObjectKeySuffix + 'Tablet'];
		const rightMobile =
			attributeValue['right' + attributeObjectKeySuffix + 'Mobile'];

		const bottom = attributeValue['bottom' + attributeObjectKeySuffix];
		const bottomTablet =
			attributeValue['bottom' + attributeObjectKeySuffix + 'Tablet'];
		const bottomMobile =
			attributeValue['bottom' + attributeObjectKeySuffix + 'Mobile'];

		const left = attributeValue['left' + attributeObjectKeySuffix];
		const leftTablet =
			attributeValue['left' + attributeObjectKeySuffix + 'Tablet'];
		const leftMobile =
			attributeValue['left' + attributeObjectKeySuffix + 'Mobile'];

		const placeTop = commonTablet || topTablet || common || top || '';
		const placeRight = commonTablet || rightTablet || common || right || '';
		const placeBottom =
			commonTablet || bottomTablet || common || bottom || '';
		const placeLeft = commonTablet || leftTablet || common || left || '';

		placeholderValue.Tablet = {
			top: placeTop,
			right: placeRight,
			bottom: placeBottom,
			left: placeLeft,
		};

		placeholderValue.Mobile = {
			top: commonMobile || topMobile || placeTop,
			right: commonMobile || rightMobile || placeRight,
			bottom: commonMobile || bottomMobile || placeBottom,
			left: commonMobile || leftMobile || placeLeft,
		};
	}

	const isLinked =
		typeof attributeValue?.[
			'isLinked' + attributeObjectKeySuffix + deviceType
		] !== 'undefined'
			? attributeValue?.[
					'isLinked' + attributeObjectKeySuffix + deviceType
			  ]
			: isDefaultLinked;

	const getDimensionValue = (direction) => {
		return (
			attributeValue['common' + attributeObjectKeySuffix + deviceType] ||
			attributeValue[direction + attributeObjectKeySuffix + deviceType] ||
			''
		);
	};

	const getDimensionPlaceholderForResponsivePreview = (direction) => {
		return isForResponsiveDevice
			? placeholderValue[deviceType][direction]
			: '';
	};

	const prepareDirectionAttributeValue = (attributeKeyObject, value) => {
		return {
			...attributeKeyObject,
			['top' + attributeObjectKeySuffix + deviceType]: value,
			['right' + attributeObjectKeySuffix + deviceType]: value,
			['bottom' + attributeObjectKeySuffix + deviceType]: value,
			['left' + attributeObjectKeySuffix + deviceType]: value,
		};
	};

	const changeHandlerForDirection = (controlValue, direction) => {
		changeHandler(
			controlValue,
			!isLinked
				? direction + attributeObjectKeySuffix
				: 'common' + attributeObjectKeySuffix
		);
	};

	return (
		<div className="ablocks-control__fields">
			<div className="ablocks-control__field">
				<TextControl
					id={`ablocks-${attributeName}-top`}
					className="ablocks-dimension-control__input ablocks-dimension-control__input--top"
					type="number"
					onChange={(controlValue) =>
						changeHandlerForDirection(controlValue, 'top')
					}
					placeholder={getDimensionPlaceholderForResponsivePreview(
						'top'
					)}
					value={getDimensionValue('top')}
				/>
				<label
					className="ablocks-dimension-control__label"
					htmlFor={`ablocks-${attributeName}-top`}
				>
					{__('Top', 'ablocks')}
				</label>
			</div>
			<div className="ablocks-control__field">
				<TextControl
					id={`ablocks-${attributeName}-right`}
					className="ablocks-dimension-control__input ablocks-dimension-control__input--right"
					type="number"
					onChange={(controlValue) =>
						changeHandlerForDirection(controlValue, 'right')
					}
					placeholder={getDimensionPlaceholderForResponsivePreview(
						'right'
					)}
					value={getDimensionValue('right')}
				/>
				<label
					className="ablocks-dimension-control__label"
					htmlFor={`ablocks-${attributeName}-right`}
				>
					{__('Right', 'ablocks')}
				</label>
			</div>
			<div className="ablocks-control__field">
				<TextControl
					id={`ablocks-${attributeName}-bottom`}
					className="ablocks-dimension-control__input ablocks-dimension-control__input--bottom"
					type="number"
					onChange={(controlValue) =>
						changeHandlerForDirection(controlValue, 'bottom')
					}
					placeholder={getDimensionPlaceholderForResponsivePreview(
						'bottom'
					)}
					value={getDimensionValue('bottom')}
				/>
				<label
					className="ablocks-dimension-control__label"
					htmlFor={`ablocks-${attributeName}-bottom`}
				>
					{__('Bottom', 'ablocks')}
				</label>
			</div>
			<div className="ablocks-control__field">
				<TextControl
					id={`ablocks-${attributeName}-left`}
					className="ablocks-dimension-control__input ablocks-dimension-control__input--left"
					type="number"
					onChange={(controlValue) =>
						changeHandlerForDirection(controlValue, 'left')
					}
					placeholder={getDimensionPlaceholderForResponsivePreview(
						'left'
					)}
					value={getDimensionValue('left')}
				/>
				<label
					className="ablocks-dimension-control__label"
					htmlFor={`ablocks-${attributeName}-left`}
				>
					{__('Left', 'ablocks')}
				</label>
			</div>
			<div className="ablocks-control__field ablocks-control__field--control">
				<Button
					className={`${
						isLinked ? 'ablocks-btn-Linked' : 'ablocks-btn-unlinked'
					}`}
					icon={
						<Tooltip
							tooltipText={__('Link Value Together', 'ablocks')}
							position="bottom-left"
						>
							<span
								className={`ablocks-icon ${
									isLinked
										? 'ablocks-icon--link'
										: 'ablocks-icon--unlink'
								}`}
							/>
						</Tooltip>
					}
					onClick={() => {
						let newAttributeValue = {};
						if (isLinked) {
							const commonValue =
								attributeValue[
									'common' +
										attributeObjectKeySuffix +
										deviceType
								] || '';
							newAttributeValue = prepareDirectionAttributeValue(
								attributeValue,
								commonValue
							);
							newAttributeValue[
								'common' + attributeObjectKeySuffix + deviceType
							] = '';
						} else {
							const commonValueAfterLinked =
								attributeValue[
									'top' +
										attributeObjectKeySuffix +
										deviceType
								] ||
								attributeValue[
									'right' +
										attributeObjectKeySuffix +
										deviceType
								] ||
								attributeValue[
									'bottom' +
										attributeObjectKeySuffix +
										deviceType
								] ||
								attributeValue[
									'left' +
										attributeObjectKeySuffix +
										deviceType
								] ||
								'';
							newAttributeValue = prepareDirectionAttributeValue(
								attributeValue,
								''
							);
							newAttributeValue[
								'common' + attributeObjectKeySuffix + deviceType
							] = commonValueAfterLinked;
						}
						newAttributeValue[
							'isLinked' + attributeObjectKeySuffix + deviceType
						] = !isLinked;
						setAttributes({
							[attributeName]: objectUniqueCheck(
								getAttributeDefaultValue(deviceType),
								newAttributeValue
							),
						});
					}}
				/>
			</div>
		</div>
	);
}

ABlocksDimensionFields.propTypes = propTypes;
ABlocksDimensionFields.defaultProps = defaultProps;
export default ABlocksDimensionFields;
