export const getAttributeDefaultValue = (isResponsive = false) => {
	if (isResponsive) {
		return {
			animationType: '',
			animationTablet: '',
			animationMobile: '',
			animationDuration: '',
			animationDurationTablet: '',
			animationDurationMobile: '',
			animationDelay: '',
			animationDelayTablet: '',
			animationDelayMobile: '',
		};
	}
	return {
		animationType: '',
		animationDuration: '',
		animationDelay: '',
	};
};

export const getAttribute = (attributeName, isResponsive = false) => {
	if (isResponsive) {
		return {
			[attributeName]: {
				type: 'object',
				default: getAttributeDefaultValue(isResponsive),
			},
		};
	}
	return {
		[attributeName]: {
			type: 'object',
			default: getAttributeDefaultValue(isResponsive),
		},
	};
};
