import React from 'react';
import metadata from './block.json';
import { __ } from '@wordpress/i18n';
import RenderContainer from '@Components/block-container/render';
import { RichText } from '@wordpress/block-editor';

import './style.css';

const propTypes = {};
const defaultProps = {};

export default function Render(props) {
	const { attributes, setAttributes } = props;
	const { block_id, paragraph, paragraphTag, dropCaps, paragraphSize } =
		attributes;
	return (
		<React.Fragment>
			<RenderContainer
				blockId={block_id}
				name={metadata.name}
				attributes={attributes}
			>
				<RichText
					tagName={paragraphTag}
					value={paragraph}
					className={`ablocks-paragraph-text ablocks-paragraph-text-${paragraphSize} ${
						dropCaps && 'ablocks-paragraph-text-drop-caps'
					} `}
					onChange={(changeParagraph) =>
						setAttributes({ paragraph: changeParagraph })
					}
					placeholder={__('Enter Text content', 'ablocks')}
				/>
			</RenderContainer>
		</React.Fragment>
	);
}

Render.propTypes = propTypes;
Render.defaultProps = defaultProps;
