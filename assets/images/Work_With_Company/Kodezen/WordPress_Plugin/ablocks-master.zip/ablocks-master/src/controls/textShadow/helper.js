export const getAttributeDefaultValue = () => {
	return {
		color: '',
		blur: '',
		horizontal: '',
		vertical: '',
	};
};

export const getAttribute = (attributeName) => {
	return {
		[attributeName]: {
			type: 'object',
			default: getAttributeDefaultValue(),
		},
	};
};

export const getCSS = (attributeValue) => {
	const value = {
		...getAttributeDefaultValue(),
		...attributeValue,
	};

	if (
		value.color !== '' ||
		value.horizontal !== '' ||
		value.vertical !== '' ||
		value.blur !== ''
	) {
		const css = {};
		css['text-shadow'] = `${value.horizontal || 0}px ${
			value.vertical || 0
		}px ${value.blur || 10}px ${value.color || 'rgba(0, 0, 0, 0.3)'}`;

		return css;
	}
};
