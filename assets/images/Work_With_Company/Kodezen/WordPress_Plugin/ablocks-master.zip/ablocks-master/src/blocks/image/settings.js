import React, { useEffect, useState } from 'react';
import { __ } from '@wordpress/i18n';
import { useSelect } from '@wordpress/data';
import Separator from '@Components/separator';
import ABlocksTextControl from '@Controls/text';
import ABlocksRangeControl from '@Controls/range';
import getDeviceType from '@Utils/get-device-type';
import ABlockSelectControl from '@Controls/select';
import ABlocksBorderControl from '@Controls/border';
import ABlocksTypography from '@Controls/typography';
import ABlocksDimensions from '@Controls/dimensions';
import ControlLabel from '@Components/control-label';
import ABlocksPanelBody from '@Components/panel-body';
import InspectorTabs from '@Components/inspector-tabs';
import MediaUploadField from '@Components/media-upload';
import { store as coreStore } from '@wordpress/core-data';
import ABlocksAlignmentControl from '@Controls/alignment';
import ABlocksToggleControl from '@Controls/toggleButton';
import { InspectorControls } from '@wordpress/block-editor';
import ContentStyleTabs from '@Components/content-style-tabs';
import ABlocksNormalHoverTabs from '@Components/normal-hover-tabs';
import ABlocksColorControl from '@Controls/color-gradient-control';
import {
	updateImageAttributes,
	onSelectImage,
	convertToObjectArray,
} from './utils';
import {
	imageLinkOptions,
	imageObjectFit,
	aspectRatioOptions,
	onImageHoverOptions,
} from './helper';

const propTypes = {};
const defaultProps = {};

export default function Settings(props) {
	const { attributes, setAttributes, isSelected } = props;
	const {
		imgId,
		imgIdTablet,
		imgIdMobile,
		opacity,
		opacityH,
		aspectRatio,
		alignment,
		captionAlignment,
		// captionPosition,
		captionColor,
		captionBackground,
		captionTypography,
		captionPadding,
		captionBorder,
		transitionDuration,
		imgLink: { linkDestination, href },
	} = attributes;
	const [imageSizes, setImageSizes] = useState([]);
	const deviceType = getDeviceType();
	let responsiveImageId;

	if (deviceType === 'Tablet') {
		responsiveImageId = imgIdTablet;
	} else if (deviceType === 'Mobile') {
		responsiveImageId = imgIdMobile;
	} else {
		responsiveImageId = imgId;
	}

	const { image } = useSelect(
		(select) => {
			const { getMedia } = select(coreStore);
			return {
				image:
					responsiveImageId && isSelected
						? getMedia(responsiveImageId)
						: null,
			};
		},
		[imgId, imgIdTablet, imgIdMobile, isSelected, responsiveImageId]
	);

	const setHeightHandler = (controlValue) => {
		return setAttributes({
			widthHeightWidget: {
				...attributes?.widthHeightWidget,
				['height' + deviceType]: controlValue,
				['customHeight' + deviceType]: true,
			},
		});
	};

	const setWidthHandler = (controlValue) => {
		return setAttributes({
			widthHeightWidget: {
				...attributes?.widthHeightWidget,
				['width' + deviceType]: controlValue,
			},
		});
	};

	// Event triggered when remove alt text
	const clearAltText = () => {
		setAttributes({
			imgAltText: '',
		});
	};

	const onImageSizeChange = (controlValue) => {
		const { width, height, url, objectFit } = updateImageAttributes(
			image,
			controlValue,
			setAttributes
		);
		return setAttributes({
			['imgUrl' + deviceType]: url,
			imgSize: {
				...attributes?.imgSize,
				['value' + deviceType]: controlValue,
			},
			widthHeightWidget: {
				...attributes?.widthHeightWidget,
				['width' + deviceType]: width,
				['height' + deviceType]: height,
				['customHeight' + deviceType]: false,
			},
			objectFit: {
				...attributes?.objectFit,
				['value' + deviceType]: objectFit
					? objectFit
					: attributes?.objectFit['value' + deviceType],
			},
		});
	};

	// Event triggered when image Removing
	const onRemoveImage = () => {
		setAttributes({
			imgId: undefined,
			imgIdTablet: undefined,
			imgIdMobile: undefined,
			imgUrl: undefined,
			imgUrlTablet: undefined,
			imgUrlMobile: undefined,
			widthHeightWidget: {
				...attributes?.widthHeightWidget,
				imgNaturalWidth: undefined,
				imgNaturalHeight: undefined,
				width: undefined,
				widthTablet: undefined,
				widthMobile: undefined,
				height: undefined,
				heightTablet: undefined,
				heightMobile: undefined,
			},
		});
	};

	useEffect(() => {
		const mediaDetails = image?.media_details?.sizes;
		const extractImageSizes = convertToObjectArray(mediaDetails);
		setImageSizes(extractImageSizes);
	}, [image]);
	// Image block content tab
	const contentPanel = (
		<>
			<MediaUploadField
				allowedTypes={['image']}
				attributeValue={attributes}
				attributeName="imgUrl"
				deviceType={deviceType}
				onSelectImageHandler={(mediaValue) =>
					onSelectImage(
						mediaValue,
						attributes,
						setAttributes,
						deviceType
					)
				}
				onRemoveImageHandler={onRemoveImage}
			/>

			{imageSizes?.length > 0 && (
				<ABlockSelectControl
					label={__('Image sizes', 'ablocks')}
					isResponsive={true}
					options={imageSizes}
					attributeName="imgSize"
					attributeValue={attributes?.imgSize['value' + deviceType]}
					setAttributes={setAttributes}
					onChangeHandler={onImageSizeChange}
				/>
			)}

			<ABlockSelectControl
				label={__('Aspect ratio', 'ablocks')}
				isResponsive={true}
				options={aspectRatioOptions}
				attributeName="aspectRatio"
				attributeValue={aspectRatio}
				setAttributes={setAttributes}
			/>

			<ABlocksAlignmentControl
				label={__('Alignment', 'ablocks')}
				attributeName="alignment"
				attributeValue={alignment}
				setAttributes={setAttributes}
				isInline={false}
				options={[
					{
						label: 'left',
						value: 'left',
						icon: 'left',
					},
					{
						label: 'center',
						value: 'center',
						icon: 'center',
					},
					{
						label: 'right',
						value: 'right',
						icon: 'right',
					},
				]}
			/>

			<Separator />

			{/* Image Dimensions controls  */}
			<ControlLabel label={'Image Dimensions'} />
			<ABlocksTextControl
				label={__('Width', 'ablocks')}
				attributeName="width"
				attributeValue={
					attributes?.widthHeightWidget['width' + deviceType]
				}
				onChangeHandler={setWidthHandler}
				isInline={false}
			/>
			<ABlocksTextControl
				label={__('Height', 'ablocks')}
				attributeName="height"
				attributeValue={
					attributes?.widthHeightWidget['height' + deviceType]
				}
				onChangeHandler={setHeightHandler}
				isInline={false}
			/>

			{/* Object fit control  */}
			<ABlockSelectControl
				label={__('Object fit', 'ablocks')}
				isResponsive={true}
				options={imageObjectFit}
				attributeName="objectFit"
				attributeValue={attributes.objectFit}
				attributeObjectKey="value"
				setAttributes={setAttributes}
			/>

			<Separator />

			{/* Title control  */}
			<ABlocksTextControl
				label={__('Title', 'ablocks')}
				attributeName="imgTitle"
				attributeValue={attributes.imgTitle}
				setAttributes={setAttributes}
				isInline={false}
			/>

			{/* Link control  */}
			<ABlockSelectControl
				label="Link"
				options={imageLinkOptions}
				attributeObjectKey="linkDestination"
				attributeValue={attributes?.imgLink}
				setAttributes={setAttributes}
				onChangeHandler={(value) => {
					setAttributes({
						imgLink: {
							...attributes?.imgLink,
							linkDestination: value,
						},
					});
				}}
			/>
			{linkDestination === 'custom' && (
				<>
					<ABlocksTextControl
						label={__('Image link', 'ablocks')}
						attributeName="imgLink"
						attributeValue={href}
						isInline={false}
						setAttributes={setAttributes}
						onChangeHandler={(controlValue) => {
							setAttributes({
								imgLink: {
									...attributes?.imgLink,
									href: controlValue,
								},
							});
						}}
					/>

					<ABlocksToggleControl
						isResponsive={false}
						label={__('Open in new tab', 'ablocks')}
						attributeValue={attributes?.imgLink}
						setAttributes={setAttributes}
						attributeName="imgLink"
						attributeObjectKey="linkTarget"
					/>
				</>
			)}

			{/* Alt text control  */}
			<div className="ablocks-alt-text-control">
				<div className="ablocks-alt-text-control__header">
					<span>{__('Alt Text', 'ablocks')}</span>
					<span
						onClick={clearAltText}
						onKeyDown={() => {}}
						role="presentation"
						className="ablocks-alt-text-control__clear"
					>
						{__('clear', 'ablocks')}
					</span>
				</div>

				<ABlocksTextControl
					attributeName="imgAltText"
					attributeValue={attributes.imgAltText}
					setAttributes={setAttributes}
					isInline={false}
				/>
			</div>

			<Separator />
			{/* On Hover image control  */}

			<ABlockSelectControl
				label={__('On Hover image', 'ablocks')}
				options={onImageHoverOptions}
				attributeName="onHoverImg"
				attributeValue={attributes.onHoverImg}
				setAttributes={setAttributes}
			/>
		</>
	);

	// Image block style tab
	const stylePanel = (
		<>
			<ABlocksDimensions
				label={__('Padding', 'ablocks')}
				isResponsive={true}
				attributeName="padding"
				attributeValue={attributes?.padding}
				setAttributes={setAttributes}
			/>
			<Separator margin="20" />

			<ControlLabel label="Border" isResponsive={false} />
			<ABlocksBorderControl
				attributeName="border"
				attributeValue={attributes?.border}
				setAttributes={setAttributes}
			/>

			<Separator margin="20" />
			<ControlLabel label="Opacity" isResponsive={false} />
			<ABlocksNormalHoverTabs
				normal={
					<>
						<ABlocksRangeControl
							label={__('Opacity', 'ablocks')}
							min={0}
							max={1}
							step={0.1}
							hasUnit={false}
							isInline={false}
							isResponsive={false}
							attributeName="opacity"
							attributeValue={opacity}
							setAttributes={setAttributes}
						/>
					</>
				}
				hover={
					<>
						<ABlocksRangeControl
							label={__('Opacity', 'ablocks')}
							min={0}
							max={1}
							step={0.1}
							hasUnit={false}
							isInline={false}
							isResponsive={false}
							attributeName="opacityH"
							attributeValue={opacityH}
							setAttributes={setAttributes}
						/>
						<ABlocksRangeControl
							label={__('Transition duration(ms)', 'ablocks')}
							min={0}
							max={10}
							step={0.5}
							hasUnit={false}
							isInline={false}
							isResponsive={false}
							setAttributes={setAttributes}
							attributeName="transitionDuration"
							attributeValue={transitionDuration}
						/>
					</>
				}
			/>
		</>
	);

	return (
		<React.Fragment>
			<InspectorControls>
				<InspectorTabs
					attributes={attributes}
					setAttributes={setAttributes}
				>
					{imgId && (
						<>
							{/* Image control settings  */}
							<ABlocksPanelBody
								title={__('Image', 'ablocks')}
								initialOpen={true}
							>
								<ContentStyleTabs
									content={contentPanel}
									style={stylePanel}
								/>
							</ABlocksPanelBody>

							{/* Captions control settings  */}
							<ABlocksPanelBody
								title={__('Caption', 'ablocks')}
								initialOpen={false}
							>
								<ContentStyleTabs
									content={
										<>
											<ABlocksToggleControl
												isResponsive={false}
												label={__(
													'Captions',
													'ablocks'
												)}
												attributeValue={
													attributes?.imgCaption
												}
												setAttributes={setAttributes}
												attributeName="imgCaption"
											/>
											{attributes.imgCaption && (
												<>
													<ABlocksTextControl
														label={__(
															'Caption text',
															'ablocks'
														)}
														attributeName="caption"
														attributeValue={
															attributes.caption
														}
														setAttributes={
															setAttributes
														}
														isInline={false}
													/>

													<ABlocksAlignmentControl
														label={__(
															'Alignment',
															'ablocks'
														)}
														attributeName="captionAlignment"
														attributeValue={
															captionAlignment
														}
														setAttributes={
															setAttributes
														}
														isInline={false}
													/>
												</>
											)}
										</>
									}
									style={
										<>
											{/* <ABlocksAlignmentControl
												label={__(
													'Position',
													'ablocks'
												)}
												isResponsive={false}
												options={[
													{
														label: 'overlap',
														value: 'overlap',
														icon: 'align-top',
													},
													{
														label: 'below',
														value: 'below',
														icon: 'align-bottom',
													},
												]}
												setAttributes={setAttributes}
												attributeValue={captionPosition}
												attributeName="captionPosition"
												attributeObjectKey="captionPosition"
												isInline={false}
											/> */}

											<ABlocksColorControl
												label={__('Color', 'ablocks')}
												attributeName="captionColor"
												attributeValue={captionColor}
												setAttributes={setAttributes}
											/>

											<ABlocksColorControl
												label={__(
													'Background color',
													'ablocks'
												)}
												attributeName="captionBackground"
												attributeValue={
													captionBackground
												}
												setAttributes={setAttributes}
											/>
											<ABlocksTypography
												label={__(
													'Typography',
													'ablocks'
												)}
												attributeName="captionTypography"
												attributeValue={
													captionTypography
												}
												setAttributes={setAttributes}
												isResponsive={true}
											/>

											<ABlocksDimensions
												label={__('Padding', 'ablocks')}
												isResponsive={true}
												attributeName="captionPadding"
												attributeValue={captionPadding}
												setAttributes={setAttributes}
											/>

											<Separator margin="20" />
											<ControlLabel
												label="Border"
												isResponsive={false}
											/>

											<ABlocksBorderControl
												attributeName="captionBorder"
												attributeValue={captionBorder}
												setAttributes={setAttributes}
											/>
										</>
									}
								/>
							</ABlocksPanelBody>
						</>
					)}
				</InspectorTabs>
			</InspectorControls>
		</React.Fragment>
	);
}

Settings.propTypes = propTypes;
Settings.defaultProps = defaultProps;
