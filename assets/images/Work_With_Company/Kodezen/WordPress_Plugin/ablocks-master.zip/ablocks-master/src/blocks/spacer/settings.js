import React from 'react';
import { __ } from '@wordpress/i18n';
import { InspectorControls } from '@wordpress/block-editor';
import ABlocksPanelBody from '@Components/panel-body';
import ABlocksRangeControl from '@Controls/range';
import InspectorTabs from '@Components/inspector-tabs';
const propTypes = {};
const defaultProps = {};

export default function Settings(props) {
	const { attributes, setAttributes } = props;
	const { spacerHeight } = attributes;
	return (
		<React.Fragment>
			<InspectorControls>
				<InspectorTabs
					attributes={attributes}
					setAttributes={setAttributes}
				>
					<ABlocksPanelBody
						title={__('Spacer', 'ablocks')}
						initialOpen={true}
					>
						<ABlocksRangeControl
							label={__('Height', 'ablocks')}
							attributeName="spacerHeight"
							attributeObjectKey="value"
							attributeValue={spacerHeight}
							setAttributes={setAttributes}
							isResponsive={true}
							min={1}
							max={500}
							step={1}
							isInline={false}
						/>
					</ABlocksPanelBody>
				</InspectorTabs>
			</InspectorControls>
		</React.Fragment>
	);
}

Settings.propTypes = propTypes;
Settings.defaultProps = defaultProps;
