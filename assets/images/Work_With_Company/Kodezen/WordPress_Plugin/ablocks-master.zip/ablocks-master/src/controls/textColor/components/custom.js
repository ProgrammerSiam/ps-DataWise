import React from 'react';
import { Popover, Button, ColorPicker } from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import PropTypes from 'prop-types';

const propTypes = {
	isResponsive: PropTypes.bool,
	attributeName: PropTypes.string,
	deviceType: PropTypes.string,
	attributeValue: PropTypes.any,
	changeHandler: PropTypes.func,
	setAttributes: PropTypes.func,
};
const defaultProps = {
	isResponsive: true,
	attributeName: '',
};
const ABlockCustomTextColor = ({ changeHandler, setType, className }) => {
	const handleColorChange = (newColor) => {
		// Call the changeHandler to update the value
		changeHandler(newColor);
	};
	return (
		<div>
			<Popover className={className}>
				<div className="ablocks-popover-header">
					<h4 className="ablocks-popover-header__title">
						{__('Color Picker', 'ablocks')}
					</h4>
					<Button
						icon={
							<span className="dashicons dashicons-no-alt"></span>
						}
						onClick={() => setType('')}
					/>
				</div>
				<div>
					<ColorPicker onChange={handleColorChange} />
				</div>
			</Popover>
		</div>
	);
};

export default ABlockCustomTextColor;
ABlockCustomTextColor.propTypes = propTypes;
ABlockCustomTextColor.defaultProps = defaultProps;
