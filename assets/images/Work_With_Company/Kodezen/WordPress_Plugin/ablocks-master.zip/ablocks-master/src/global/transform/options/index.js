import { __ } from '@wordpress/i18n';
import AblocksSeparator from '@Components/separator';
import { objectUniqueCheck } from '@Utils/helper';
import ABlocksRotate from './rotate';
import ABlocksScale from './scale';
import ABlocksOffSet from './offset';
import ABlocksSkew from './skew';
import ABlocksAlignmentControl from '@Controls/alignment';
import ABlocksToggleControl from '@Controls/toggleButton';
import { getAttributeDefaultValue } from './../helper';

import ABlocksRangeControl from '@Controls/range';
import './styles.scss';

const TransformAllOptions = (props) => {
	const { setAttributes, attributeName, attributeValue, hover } = props;

	let attributeObjectKeyForFlipHorizontal = 'flipHorizontal';
	let attributeObjectKeyForFlipVertical = 'flipVertical';
	let attributeObjectKeyForAnchorPointX = 'xAnchorPoint';
	let attributeObjectKeyForAnchorPointY = 'yAnchorPoint';

	if (hover) {
		attributeObjectKeyForFlipHorizontal = 'flipHorizontalH';
		attributeObjectKeyForFlipVertical = 'flipVerticalH';
		attributeObjectKeyForAnchorPointX = 'xAnchorPointH';
		attributeObjectKeyForAnchorPointY = 'yAnchorPointH';
	}

	const resetHandler = (resetObj = {}) => {
		setAttributes({
			[attributeName]: objectUniqueCheck(getAttributeDefaultValue, {
				...attributeValue,
				...resetObj,
			}),
		});
	};
	const commonProps = {
		...props,
		resetHandler,
	};
	return (
		<div
			className={`ablocks-control--transform-all-options-wrapper ablocks-control--transform-all-options-wrapper-${
				hover ? 'hover' : 'normal'
			}`}
		>
			<ABlocksRotate {...commonProps} label={__('Rotate', 'ablocks')} />
			<AblocksSeparator />
			<ABlocksOffSet {...commonProps} label={__('Offset', 'ablocks')} />
			<AblocksSeparator />
			<ABlocksScale {...commonProps} label={__('Scale', 'ablocks')} />
			<AblocksSeparator />
			<ABlocksSkew {...commonProps} label={__('Skew', 'ablocks')} />
			<AblocksSeparator />
			<div className="ablocks-control--transform-options__flip">
				<ABlocksToggleControl
					{...commonProps}
					isResponsive={false}
					label={__('Flip Horizontal', 'ablocks')}
					attributeObjectKey={attributeObjectKeyForFlipHorizontal}
				/>
				<ABlocksToggleControl
					{...commonProps}
					isResponsive={false}
					label={__('Flip Vertical', 'ablocks')}
					attributeObjectKey={attributeObjectKeyForFlipVertical}
				/>
			</div>
			{hover && (
				<div className="ablocks-control--transform-transition-duration">
					<ABlocksRangeControl
						{...commonProps}
						label={__('Transition Duration (ms)', 'ablocks')}
						isResponsive={false}
						isInline={false}
						attributeObjectKey="transitionH"
					/>
				</div>
			)}
			<AblocksSeparator />
			<div className="ablocks-control--transform-options__anchor--point">
				<ABlocksAlignmentControl
					{...commonProps}
					label={__('X Anchor Point', 'ablocks')}
					isResponsive={true}
					attributeObjectKey={attributeObjectKeyForAnchorPointX}
					isInline={false}
					options={[
						{
							label: 'left',
							value: 'left',
							icon: 'left',
						},
						{
							label: 'center',
							value: 'center',
							icon: 'center',
						},
						{
							label: 'right',
							value: 'right',
							icon: 'right',
						},
					]}
				/>
				<ABlocksAlignmentControl
					{...commonProps}
					label={__('Y Anchor Point', 'ablocks')}
					isResponsive={true}
					attributeObjectKey={attributeObjectKeyForAnchorPointY}
					isInline={false}
					options={[
						{
							label: 'align top',
							value: 'top',
							icon: 'align-top',
						},
						{
							label: 'align center',
							value: 'center',
							icon: 'align-center',
						},
						{
							label: 'align bottom',
							value: 'bottom',
							icon: 'align-bottom',
						},
					]}
				/>
			</div>
		</div>
	);
};

export default TransformAllOptions;
