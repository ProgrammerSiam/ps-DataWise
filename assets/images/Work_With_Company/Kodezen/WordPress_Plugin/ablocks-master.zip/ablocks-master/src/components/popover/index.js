import { useRef, useEffect, useState } from '@wordpress/element';
import { Popover } from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import Button from '@Components/Button';
import './editor.scss';
import Tooltip from '@Components/tooltip';

export default function AblocksPopover({
	label = '',
	isShowPrimaryLabel = '',
	CustomToggler,
	isReset,
	handleReset,
	children,
	className = '',
	width = '',
	isVisible,
	toggleVisible,
}) {
	const [popoverAnchor, setPopoverAnchor] = useState();

	const popoverId = useRef(
		`ablocks-popover-${Math.floor(Math.random() * 10000)}`
	).current;

	useEffect(() => {
		const handleClick = (e) => {
			if (!e.target.closest('.ablocks-component-popover__popover')) {
				toggleVisible(false);
			}
		};

		document.addEventListener('mousedown', handleClick);
		return () => {
			document.removeEventListener('mousedown', handleClick);
		};
	}, [width, isVisible, toggleVisible]);

	return (
		<div className="ablocks-component-popover" ref={setPopoverAnchor}>
			<div className="ablocks-component-popover__field">
				{isShowPrimaryLabel && <span>{label}</span>}
				<div className="ablocks-component-popover-toggler-wrapper">
					{CustomToggler && (
						<div className="ablocks-component-popover__custom-toggler-wrapper">
							<CustomToggler
								toggleVisible={toggleVisible}
								isVisible={isVisible}
							/>
						</div>
					)}
				</div>
			</div>
			{isVisible && (
				<Popover
					className={`ablocks-component-popover__popover ${className} ${popoverId}`}
					anchor={popoverAnchor}
					placement="left-end"
				>
					<div className="ablocks-component-popover__head">
						<h4 className="ablocks-component-popover__head-title">
							{label}
						</h4>
						<div className="ablocks-component-popover__head-control">
							{isReset && (
								<Button
									onClick={handleReset}
									icon={
										<Tooltip
											tooltipText={__(
												'Back To Default',
												'ablocks'
											)}
											position="left"
										>
											<span className="ablocks-icon ablocks-icon--reset"></span>
										</Tooltip>
									}
									preset="transparent"
								/>
							)}
							<Button
								onClick={() => toggleVisible(false)}
								icon={
									<span className="ablocks-icon ablocks-icon--close"></span>
								}
								preset="transparent"
							/>
						</div>
					</div>
					<div className="ablocks-component-popover__content">
						{children}
					</div>
				</Popover>
			)}
		</div>
	);
}
