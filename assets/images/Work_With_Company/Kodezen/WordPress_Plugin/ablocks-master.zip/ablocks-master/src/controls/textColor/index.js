import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { Button, ButtonGroup } from '@wordpress/components';
import './styles.scss';
import ABlocsGlobalTextColor from './components/global';
import ABlockCustomTextColor from './components/custom';
const propTypes = {
	isResponsive: PropTypes.bool,
	label: PropTypes.string,
	attributeName: PropTypes.string,
	attributeValue: PropTypes.any,
	onChangeHandler: PropTypes.func,
};
const defaultProps = {
	label: '',
	isResponsive: true,
};
const ABlocksTextColor = (props) => {
	const {
		attributeObjectKey,
		attributeName,
		attributeValue,
		setAttributes,
		label,
	} = props;
	const [type, setType] = useState('');
	const changeHandler = (controlValue) => {
		setAttributes({
			[attributeName]: {
				...attributeValue,
				[type + attributeObjectKey]: controlValue,
			},
		});
	};
	return (
		<React.Fragment>
			<div className="ablocks-text-color">
				<span>{label}</span>
				<ButtonGroup>
					<Button
						icon={
							<span className="dashicons dashicons-admin-site-alt3"></span>
						}
						onClick={() => {
							setType('global');
						}}
					/>
					<Button
						icon={
							<span className="dashicons dashicons-edit"></span>
						}
						onClick={() => {
							setType('custom');
						}}
					/>
				</ButtonGroup>
			</div>

			<div>
				{type === 'global' && (
					<ABlocsGlobalTextColor
						setType={setType}
						className="ablocks-popover ablocks-popover--classic"
						changeHandler={changeHandler}
					/>
				)}
				{type === 'custom' && (
					<ABlockCustomTextColor
						setType={setType}
						className="ablocks-popover ablocks-popover--custom"
						changeHandler={changeHandler}
						attributeName={attributeName}
						attributeValue={attributeValue}
					/>
				)}
			</div>
		</React.Fragment>
	);
};
export default ABlocksTextColor;
ABlocksTextColor.propTypes = propTypes;
ABlocksTextColor.defaultProps = defaultProps;
