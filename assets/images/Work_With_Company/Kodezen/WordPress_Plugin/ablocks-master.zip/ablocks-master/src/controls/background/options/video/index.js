import React from 'react';
import ABlocksVideoControl from '@Controls/video-control';
import { getAttributeDefaultValue } from '../../helper';
import { objectUniqueCheck } from '@Utils/helper';

export default function ABlocksBackgroundVideo(props) {
	const { attributeName, setAttributes, attributeValue, isResponsive } =
		props;

	const commonProps = {
		...props,
	};

	// Added background image attritibutes
	const onSelectVideoHandler = (media) => {
		setAttributes({
			[attributeName]: objectUniqueCheck(
				getAttributeDefaultValue(isResponsive),
				{
					...attributeValue,
					videoUrl: media?.url,
				}
			),
		});
	};

	// Removing background image attritibutes
	const onRemoveVideoHandler = () => {
		setAttributes({
			[attributeName]: objectUniqueCheck(
				getAttributeDefaultValue(isResponsive),
				{
					...attributeValue,
					videoUrl: undefined,
				}
			),
		});
	};

	// Added fallback image for video control
	const onSelectFallbackImageHandler = (mediaValue) => {
		setAttributes({
			[attributeName]: objectUniqueCheck(
				getAttributeDefaultValue(isResponsive),
				{
					...attributeValue,
					fallbackImageUrl: mediaValue?.url,
				}
			),
		});
	};

	// Removing fallback image for video control
	const onRemoveFallbackImageHandler = () => {
		setAttributes({
			[attributeName]: objectUniqueCheck(
				getAttributeDefaultValue(isResponsive),
				{
					...attributeValue,
					fallbackImageUrl: undefined,
				}
			),
		});
	};

	return (
		<ABlocksVideoControl
			{...commonProps}
			onSelectVideoHandler={onSelectVideoHandler}
			onRemoveVideoHandler={onRemoveVideoHandler}
			onSelectFallbackImageHandler={onSelectFallbackImageHandler}
			onRemoveFallbackImageHandler={onRemoveFallbackImageHandler}
			isBackgroundControl={true}
		/>
	);
}
