import React from 'react';
import PropTypes from 'prop-types';
import { __ } from '@wordpress/i18n';
import { blendModeOptions } from './helper';
import ABlocksSelectControl from '@Controls/select';

const propTypes = {
	isResponsive: PropTypes.bool,
	attributeName: PropTypes.string,
	attributeValue: PropTypes.any,
	onChangeHandler: PropTypes.func,
};

const defaultProps = {
	isResponsive: true,
};

export default function ABlocksBlendModeControl(props) {
	const { attributeValue, hover, attributeName, setAttributes } = props;

	return (
		<ABlocksSelectControl
			label={__('Blend mode', 'ablocks')}
			isResponsive={false}
			options={blendModeOptions}
			attributeValue={attributeValue}
			attributeObjectKey={hover ? 'blendModeH' : 'blendMode'}
			attributeName={attributeName}
			setAttributes={setAttributes}
		/>
	);
}

ABlocksBlendModeControl.propTypes = propTypes;
ABlocksBlendModeControl.defaultProps = defaultProps;
