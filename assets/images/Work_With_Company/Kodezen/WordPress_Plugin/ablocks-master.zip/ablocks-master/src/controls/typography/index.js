import React from 'react';
import PropTypes from 'prop-types';
import ControlLabel from '@Components/control-label';
import GetDeviceType from '@Utils/get-device-type';
import { objectUniqueCheck } from '@Utils/helper';
import { getAttributeDefaultValue } from './helper';
import ABlockCustomTypography from './components/Custom';
import './styles.scss';

const propTypes = {
	isResponsive: PropTypes.bool,
	label: PropTypes.string,
	attributeName: PropTypes.string,
	attributeValue: PropTypes.any,
	onChangeHandler: PropTypes.func,
};

const defaultProps = {
	label: '',
	isResponsive: true,
	isInline: true,
};

const ABlocksTypography = (props) => {
	const {
		isResponsive,
		attributeName,
		attributeValue,
		onChangeHandler,
		setAttributes,
		label,
	} = props;

	const deviceType = GetDeviceType();

	const changeHandler = (controlValue, objectKey) => {
		if (onChangeHandler) {
			onChangeHandler(controlValue, objectKey);
		} else {
			return setAttributes({
				[attributeName]: objectUniqueCheck(
					getAttributeDefaultValue(isResponsive),
					{
						...attributeValue,
						[objectKey]: controlValue,
					}
				),
			});
		}
	};

	const resetHandler = (resetObj = {}) => {
		setAttributes({
			[attributeName]: objectUniqueCheck(getAttributeDefaultValue, {
				...attributeValue,
				...resetObj,
			}),
		});
	};

	return (
		<div className={`ablocks-control ablocks-control--typography`}>
			{label && (
				<div className="ablocks-control__label">
					<ControlLabel label={label} isResponsive={false} />
				</div>
			)}
			<div className="ablocks-typography--btn-options">
				<ABlockCustomTypography
					isResponsive={true}
					deviceType={deviceType}
					attributeName={attributeName}
					attributeValue={attributeValue}
					changeHandler={changeHandler}
					resetHandler={resetHandler}
					setAttributes={setAttributes}
				/>
			</div>
		</div>
	);
};

ABlocksTypography.propTypes = propTypes;
ABlocksTypography.defaultProps = defaultProps;

export default ABlocksTypography;
