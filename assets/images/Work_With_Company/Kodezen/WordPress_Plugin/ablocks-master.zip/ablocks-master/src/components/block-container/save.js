import React from 'react';
import { useBlockProps } from '@wordpress/block-editor';
import { getClassNames } from './helper';
import PropTypes from 'prop-types';

const propTypes = {
	name: PropTypes.string,
	blockId: PropTypes.string,
};

const defaultProps = {};

export default function SaveContainer({ blockId, name, children, attributes }) {
	const {
		_hide_on_desktop,
		_hide_on_tablet,
		_hide_on_mobile,
		className = '',
	} = attributes;

	const blockProps = useBlockProps.save();

	const allProps = {
		...blockProps,
		className: getClassNames({
			name,
			blockId,
			className,
			_hide_on_desktop,
			_hide_on_tablet,
			_hide_on_mobile,
		}),
	};

	return (
		<React.Fragment>
			<div {...allProps}>
				<div className="ablocks-block-container">{children}</div>
			</div>
		</React.Fragment>
	);
}

SaveContainer.propTypes = propTypes;
SaveContainer.defaultProps = defaultProps;
