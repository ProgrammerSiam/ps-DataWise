import {
	hslaStringToHsva,
	hexToHsva,
	hsvaToHsla,
	hsvaToHslString,
	hsvaToRgbString,
	rgbStringToHsva,
	hslStringToHsva,
	hslaToHsva,
	hsvaToHex,
	hsvaToRgba,
	hsvaToRgbaString,
	hsvaToHslaString,
	rgbaStringToHsva,
	rgbaToHsva,
} from './convert';

export const convertOpacityIntoHex = (opacity) => {
	const hexOpacity = Math.round(Math.min(opacity, 1) * 255).toString(16);
	if (hexOpacity.length === 1) {
		return hexOpacity.repeat(2);
	}
	return hexOpacity;
};

export const convertHexIntoOpacity = (hex) =>
	parseFloat(Math.round((parseInt(hex, 16) / 255) * 100) / 100);

export const colorStringGetType = (colorString = '') => {
	if (colorString.startsWith('#')) {
		return 'hex';
	}
	if (colorString.startsWith('rgb')) {
		return 'rgb';
	}
	if (colorString.startsWith('hsl')) {
		return 'hsl';
	}
};

export const getTypeAndHsvaObjectFromColorString = (colorString = '') => {
	const trimmedColorString =
		typeof colorString === 'string' ? colorString.trim() : '#90c';

	const type = colorStringGetType(trimmedColorString);
	let hsva;

	switch (type) {
		case 'hex':
			hsva = hexToHsva(trimmedColorString);
			break;

		case 'rgb':
			hsva = rgbaStringToHsva(trimmedColorString);
			break;

		case 'hsl':
			hsva = hslaStringToHsva(trimmedColorString);
			break;
	}

	return {
		type,
		hsva,
	};
};

export const colorStringGetTypeAndHsvaObject = (colorString = '') => {
	if (colorString.includes('gradient')) {
		return false;
	}
	const trimmedColorString =
		typeof colorString === 'string' ? colorString.trim() : '#90c';

	const type = colorStringGetType(trimmedColorString);

	let hsva;
	switch (type) {
		case 'hex':
			hsva = hexToHsva(trimmedColorString);
			break;

		case 'rgb':
			hsva = rgbaStringToHsva(trimmedColorString);
			break;

		case 'hsl':
			hsva = hslaStringToHsva(trimmedColorString);
			break;
	}

	return {
		type,
		hsva,
	};
};

export const colorStringGetTypeAndHslaObject = (colorString = '') => {
	if (colorString.includes('gradient')) {
		return false;
	}
	const trimmedColorString =
		typeof colorString === 'string' ? colorString.trim() : '#90c';

	const type = colorStringGetType(trimmedColorString);
	let hsla;

	switch (type) {
		case 'hex':
			hsla = hsvaToHsla(hexToHsva(trimmedColorString));
			break;

		case 'rgb':
			hsla = hsvaToHsla(rgbaStringToHsva(trimmedColorString));
			break;

		case 'hsl':
			hsla = hsvaToHsla(hslaStringToHsva(trimmedColorString));
			break;
	}

	return {
		type,
		hsla,
	};
};

export const getColorStringWithAlphaBasedOnType = (hsva, type = 'hex') => {
	switch (type) {
		case 'hex': {
			return `${hsvaToHex(hsva)}`;
		}

		case 'hsl': {
			return hsvaToHslaString(hsva);
		}

		case 'rgb': {
			return hsvaToRgbaString(hsva);
		}
	}
};

export const getColorValueBasedOnType = (hsva, type = 'hex') => {
	switch (type) {
		case 'hex': {
			let colorString = `${hsvaToHex(hsva)}`;
			if (colorString.length === 9) {
				colorString = colorString.substring(0, 7);
			}
			return colorString;
		}

		case 'hsl': {
			return hsvaToHslString(hsva);
		}

		case 'rgb': {
			return hsvaToRgbString(hsva);
		}
	}
};
export const getColorObjectDataBasedOnType = (hsva, type = 'hex') => {
	switch (type) {
		case 'hex': {
			let hex = `${hsvaToHex(hsva)}`;
			if (hex.length === 9) {
				hex = hex.substring(0, 7);
			}
			return { hex };
		}

		case 'hsl': {
			return hsvaToHsla(hsva);
		}

		case 'rgb': {
			return hsvaToRgba(hsva);
		}
	}
};

export const convertColordataToHsvaBasedOnType = (colorData, type = 'hex') => {
	switch (type) {
		case 'hex': {
			return hexToHsva(colorData?.hex || '90c');
		}

		case 'hsl': {
			return hslaToHsva(colorData);
		}

		case 'rgb': {
			return rgbaToHsva(colorData);
		}
	}
};

export const getHsvaFromColorString = (colorString, type) => {
	switch (type) {
		case 'hex':
			return hexToHsva(colorString);

		case 'hsl': {
			return hslStringToHsva(colorString);
		}

		case 'rgb': {
			return rgbStringToHsva(colorString);
		}
	}
};

export const onUpdateColorString = ({ hsla, hsva, colorType, onChange }) => {
	let colorString = '#90c';
	if (hsva) {
		colorString = getColorStringWithAlphaBasedOnType(hsva, colorType);
	} else if (hsla) {
		colorString = getColorStringWithAlphaBasedOnType(
			hslaToHsva(hsla),
			colorType
		);
	}
	onChange(colorString);
};

export const isValidHex = (hex) =>
	[4, 7, 5, 9].includes(hex?.length) && /^#[0-9A-F]{3,9}$/i.test(hex);
export const isValidShortHex = (hex) => [4, 5].includes(hex?.length);
