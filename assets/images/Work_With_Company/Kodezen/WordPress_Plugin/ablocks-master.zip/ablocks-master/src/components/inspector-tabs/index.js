import React from 'react';
import { TabPanel } from '@wordpress/components';
import AdvancedSettings from '@Global/AdvancedSettings';

import { __ } from '@wordpress/i18n';
import PropTypes from 'prop-types';

/**
 * Import Css
 */
import './editor.scss';

const propTypes = {
	attributes: PropTypes.object,
	setAttributes: PropTypes.func,
};

const defaultProps = {
	attributes: {},
	setAttributes: () => {},
};

window.aBlocksInspectorTabsState = {};

export default function InspectorTabs(props) {
	const { children, attributes, setAttributes } = props;

	const tabs = [
		{
			name: 'general',
			render: children,
			title: <>{__('General', 'ablocks')}</>,
			className: 'ablocks-inspector-tab__item',
		},
		{
			name: 'advanced',
			render: (
				<AdvancedSettings
					attributes={attributes}
					setAttributes={setAttributes}
				/>
			),
			title: <>{__('Advanced', 'ablocks')}</>,
			className: 'ablocks-inspector-tab__item',
		},
	];

	const { lastBlockId = '', lastSelectedTabName = 'content' } =
		window.aBlocksInspectorTabsState;
	const thisBlockId = attributes.block_id;
	const initialTabName = lastBlockId === thisBlockId && lastSelectedTabName;

	return (
		<React.Fragment>
			<TabPanel
				className="ablocks-inspector-tabs"
				activeClass="ablocks-inspector-tab__item--active"
				tabs={tabs}
				initialTabName={initialTabName}
			>
				{(tab) => {
					{
						const tabNameAndBlockId = {
							lastBlockId: thisBlockId,
							lastSelectedTabName: tab.name,
						};
						window.aBlocksInspectorTabsState = tabNameAndBlockId;
						return tab.render;
					}
				}}
			</TabPanel>
		</React.Fragment>
	);
}

InspectorTabs.propTypes = propTypes;
InspectorTabs.defaultProps = defaultProps;
