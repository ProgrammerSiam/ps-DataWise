import React from 'react';
import ABlocksSelectControl from '@Controls/select';
import { __ } from '@wordpress/i18n';
import MediaUploadField from '@Components/media-upload';
import { objectUniqueCheck } from '@Utils/helper';
import { getAttributeDefaultValue } from '../../helper';

const Shapes = [
	{ value: 'circle', label: __('Circle', 'ablocks') },
	{ value: 'flower', label: __('Flower', 'ablocks') },
	{ value: 'sketch', label: __('Sketch', 'ablocks') },
	{ value: 'triangle', label: __('Triangle', 'ablocks') },
	{ value: 'blob', label: __('Blob', 'ablocks') },
	{ value: 'custom', label: __('Custom', 'ablocks') },
];

const ABlocksMaskShape = (props) => {
	const {
		deviceType,
		attributeValue,
		isResponsive,
		attributeName,
		setAttributes,
	} = props;

	// setting background image attritibutes
	const onSelectImageHandler = (media) => {
		setAttributes({
			[attributeName]: objectUniqueCheck(
				getAttributeDefaultValue(isResponsive),
				{
					...attributeValue,
					['customMaskShape' + deviceType]: media?.url,
				}
			),
		});
	};

	// Removing background image attributes
	const onRemoveImageHandler = () => {
		setAttributes({
			[attributeName]: objectUniqueCheck(
				getAttributeDefaultValue(isResponsive),
				{
					...attributeValue,
					['customMaskShape' + deviceType]: undefined,
				}
			),
		});
	};

	return (
		<>
			<ABlocksSelectControl
				options={Shapes}
				isResponsive={false}
				attributeValue={attributeValue}
				label={__('Shape', 'ablocks')}
				attributeName={attributeName}
				attributeObjectKey="maskShape"
				setAttributes={setAttributes}
			/>

			{attributeValue.maskShape === 'custom' && (
				<MediaUploadField
					allowedTypes={['image']}
					attributeValue={attributeValue}
					attributeName="customMaskShape"
					onSelectImageHandler={onSelectImageHandler}
					onRemoveImageHandler={onRemoveImageHandler}
				/>
			)}
		</>
	);
};

export default ABlocksMaskShape;
