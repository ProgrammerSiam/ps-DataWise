import { __ } from '@wordpress/i18n';
import { objectUniqueCheck } from '@Utils/helper';
import ABlocksSelectControl from '@Controls/select';
import {
	getAttributeDefaultValue,
	typeOptions,
	blendModeOptions,
} from '../helper';

import ABlocksRangeControl from '@Controls/range';
import ABlocksImageControl from '@Controls/image-control';
import BackgroundOverLayCSSFilter from './css-filter';
import AblocksPopover from '@Components/popover';

const BackgroundOverlayAllOptions = (props) => {
	const {
		setAttributes,
		attributeName,
		attributeValue,
		hover,
		onChangeHandler,
		isResponsive,
		deviceType,
	} = props;

	const commonProps = {
		...props,
	};

	// setting background image attritibutes
	const onSelectImageHandler = (media) => {
		setAttributes({
			[attributeName]: objectUniqueCheck(
				getAttributeDefaultValue(isResponsive),
				{
					...attributeValue,
					[hover ? 'imgIdH' : 'imgId' + deviceType]: media?.id,
					[hover ? 'imgUrlH' : 'imgUrl' + deviceType]: media?.url,
				}
			),
		});
	};

	// Removing background image attritibutes
	const onRemoveImageHandler = () => {
		setAttributes({
			[attributeName]: objectUniqueCheck(
				getAttributeDefaultValue(isResponsive),
				{
					...attributeValue,
					[hover ? 'imgIdH' : 'imgId' + deviceType]: undefined,
					[hover ? 'imgUrlH' : 'imgUrl' + deviceType]: undefined,
				}
			),
		});
	};

	return (
		<div
			className={`ablocks-control--backgroundOverlay-all-options-wrapper ablocks-control--backgroundOverlay-all-options-wrapper-${
				hover ? 'hover' : 'normal'
			}`}
		>
			<ABlocksSelectControl
				label={__('Type', 'ablocks')}
				options={typeOptions}
				isResponsive={false}
				attributeValue={attributeValue}
				attributeObjectKey={
					hover ? 'backgroundOverlayTypeH' : 'backgroundOverlayType'
				}
				attributeName={attributeName}
				setAttributes={setAttributes}
			/>
			{!hover && (
				<>
					{attributeValue?.backgroundOverlayType === 'color' && (
						<h2>Color Normal component!!!</h2>
					)}
					{attributeValue?.backgroundOverlayType === 'image' && (
						<ABlocksImageControl
							{...commonProps}
							onSelectImageHandler={onSelectImageHandler}
							onRemoveImageHandler={onRemoveImageHandler}
						/>
					)}
				</>
			)}

			{hover && (
				<>
					{/* Hover controls */}
					{attributeValue?.backgroundOverlayTypeH === 'color' && (
						<h2>Color Hover component!!!</h2>
					)}
					{attributeValue?.backgroundOverlayTypeH === 'image' && (
						<ABlocksImageControl
							{...commonProps}
							hover={hover}
							onSelectImageHandler={onSelectImageHandler}
							onRemoveImageHandler={onRemoveImageHandler}
						/>
					)}
				</>
			)}

			{attributeValue?.imgUrl && (
				<ABlocksRangeControl
					{...commonProps}
					isResponsive={false}
					label={__('Opacity', 'ablocks')}
					min={0}
					max={1}
					step={0.01}
					hasUnit={false}
					isInline={false}
					onChangeHandler={onChangeHandler}
					attributeObjectKey={hover ? 'opacityH' : 'opacity'}
				/>
			)}
			{attributeValue?.imgUrl && (
				<>
					{!hover && (
						<ABlocksSelectControl
							label={__('Blend mode', 'ablocks')}
							options={blendModeOptions}
							isResponsive={false}
							attributeValue={attributeValue}
							attributeObjectKey={
								hover ? 'blendModeH' : 'blendMode'
							}
							attributeName={attributeName}
							setAttributes={setAttributes}
						/>
					)}

					<AblocksPopover
						isShowPrimaryLabel={true}
						label={'CSS Filters'}
					>
						<BackgroundOverLayCSSFilter
							{...commonProps}
							hover={hover}
							deviceType={deviceType}
						/>
					</AblocksPopover>
				</>
			)}
			{hover && (
				<ABlocksRangeControl
					{...commonProps}
					label={__('Transition Duration (ms)', 'ablocks')}
					min={0}
					max={5}
					step={0.01}
					hasUnit={false}
					isInline={false}
					attributeObjectKey="transitionDuration"
				/>
			)}
		</div>
	);
};

export default BackgroundOverlayAllOptions;
