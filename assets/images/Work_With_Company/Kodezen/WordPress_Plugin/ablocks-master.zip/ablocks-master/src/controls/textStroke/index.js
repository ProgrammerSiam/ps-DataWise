import React, { useRef, useState } from 'react';
import PropTypes from 'prop-types';
import { __ } from '@wordpress/i18n';
import AblocksPopover from '@Components/popover';
import { objectUniqueCheck } from '@Utils/helper';
import ABlocksRangeControl from '@Controls/range';
import GetDeviceType from '@Utils/get-device-type';
import { getAttributeDefaultValue } from './helper';
import ControlLabel from '@Components/control-label';
import Button from '@Components/Button';
import ABlocksColorControl from '@Controls/color-gradient-control';
import './styles.scss';

const propTypes = {
	isResponsive: PropTypes.bool,
	label: PropTypes.string,
	attributeName: PropTypes.string,
	attributeValue: PropTypes.any,
	onChangeHandler: PropTypes.func,
};

const defaultProps = {
	label: '',
	isResponsive: true,
};

// const CustomToggler = ( { isVisible, togglePopoverVisibility } ) => (
// 	<Button
// 		onClick={ togglePopoverVisibility }
// 		icon={ <span className="ablocks-icon ablocks-icon--edit"></span> }
// 		preset="transparent"
// 		className={ isVisible ? 'ablocks-component-popover__field--active' : '' }
// 	/>
// );

const ABlocksTextStroke = (props) => {
	const {
		isResponsive,
		attributeName,
		attributeValue,
		setAttributes,
		label,
	} = props;
	const [isVisible, setIsVisible] = useState(false);
	const anchorRef = useRef(null);
	const deviceType = GetDeviceType();

	const changeHandler = (controlValue, deviceMode) => {
		if (isResponsive) {
			return setAttributes({
				[attributeName]: objectUniqueCheck(
					getAttributeDefaultValue(isResponsive),
					{
						...attributeValue,
						[deviceMode]: controlValue,
					}
				),
			});
		}
		return setAttributes({
			[attributeName]: {
				...attributeValue,
				[deviceMode]: controlValue,
			},
		});
	};

	const handleResetTextStroke = () => {
		setAttributes({
			[attributeName]: objectUniqueCheck(getAttributeDefaultValue, {
				...attributeValue,
				[`strokeWidth${deviceType}`]: '',
				stroke: '',
			}),
		});
	};

	const togglePopoverVisibility = () => {
		setIsVisible(!isVisible);
	};

	return (
		<div className="ablocks-control ablocks-control-color-gradient-root-wrapper">
			{label && (
				<div className="ablocks-control-label">
					<ControlLabel label={label} isResponsive={false} />
				</div>
			)}
			<div className="ablocks-control-color-gradient">
				<div className="ablocks-component-popover">
					<div className="ablocks-component-popover__field">
						<div
							className="ablocks-component-popover-toggler-wrapper"
							ref={anchorRef}
						>
							<Button
								ref={anchorRef}
								onClick={togglePopoverVisibility}
								icon={
									<span className="ablocks-icon ablocks-icon--edit"></span>
								}
								preset="transparent"
								className={
									isVisible
										? 'ablocks-component-popover__field--active'
										: ''
								}
							/>
						</div>
					</div>
					{isVisible && (
						<AblocksPopover
							label={__('Text Stroke', 'ablocks')}
							isShowPrimaryLabel={false}
							isReset={true}
							handleReset={handleResetTextStroke}
							isVisible={isVisible}
							toggleVisible={setIsVisible}
							anchorRef={anchorRef}
						>
							<ABlocksColorControl
								label={__('Stroke color', 'ablocks')}
								attributeName="stroke"
								attributeValue={attributeValue.stroke}
								onChangeHandler={(
									attributeObjectKey,
									controlValue
								) => {
									changeHandler(
										controlValue,
										attributeObjectKey
									);
								}}
							/>
							<ABlocksRangeControl
								isResponsive={isResponsive}
								attributeName={attributeName}
								attributeValue={attributeValue}
								attributeObjectKey="strokeWidth"
								onChangeHandler={changeHandler}
								label={__('Stroke width', 'ablocks')}
								min={0}
								max={10}
								isInline={false}
								hasUnit={true}
							/>
						</AblocksPopover>
					)}
				</div>
			</div>
		</div>
	);
};

ABlocksTextStroke.propTypes = propTypes;
ABlocksTextStroke.defaultProps = defaultProps;

export default ABlocksTextStroke;
