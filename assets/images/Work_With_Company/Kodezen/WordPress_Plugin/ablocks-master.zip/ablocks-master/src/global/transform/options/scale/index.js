import { __ } from '@wordpress/i18n';
import ABlocksRangeControl from '@Controls/range';
import ABlocksToggleControl from '@Controls/toggleButton';
import ControlLabel from '@Components/control-label';
import AblocksPopover from '@Components/popover';
import Button from '@Components/Button';
import { useRef, useState } from 'react';

const ABlocksScale = (props) => {
	const [isVisible, setIsVisible] = useState(false);
	const anchorRef = useRef(null);
	const { hover, resetHandler, attributeValue, label } = props;

	let attributeObjectKeyForScaleProportions = 'scaleProportions';
	let attributeObjectKeyForScale = 'scale';
	let attributeObjectKeyForScaleX = 'scaleX';
	let attributeObjectKeyForScaleY = 'scaleY';

	if (hover) {
		attributeObjectKeyForScaleProportions = 'scaleProportionsH';
		attributeObjectKeyForScale = 'scaleH';
		attributeObjectKeyForScaleX = 'scaleXH';
		attributeObjectKeyForScaleY = 'scaleYH';
	}

	const handleReset = () =>
		resetHandler({
			[attributeObjectKeyForScaleProportions]: '',
			[attributeObjectKeyForScale]: '',
			[attributeObjectKeyForScaleX]: '',
			[attributeObjectKeyForScaleY]: '',
		});

	const commonProps = {
		...props,
		min: 0,
		max: 2,
		step: 0.1,
	};

	const togglePopoverVisibility = () => {
		setIsVisible(!isVisible);
	};

	return (
		<div className="ablocks-control ablocks-control-color-gradient-root-wrapper">
			{label && (
				<div className="ablocks-control-label">
					<ControlLabel label={label} isResponsive={false} />
				</div>
			)}
			<div className="ablocks-control-color-gradient">
				<div className="ablocks-component-popover">
					<div className="ablocks-component-popover__field">
						<div
							className="ablocks-component-popover-toggler-wrapper"
							ref={anchorRef}
						>
							<Button
								ref={anchorRef}
								onClick={togglePopoverVisibility}
								icon={
									<span className="ablocks-icon ablocks-icon--edit"></span>
								}
								preset="transparent"
								className={
									isVisible
										? 'ablocks-component-popover__field--active'
										: ''
								}
							/>
						</div>
					</div>
					{isVisible && (
						<AblocksPopover
							label={__('Scale', 'ablocks')}
							isShowPrimaryLabel={false}
							isReset={true}
							handleReset={handleReset}
							isVisible={isVisible}
							toggleVisible={setIsVisible}
							anchorRef={anchorRef}
						>
							<ABlocksToggleControl
								{...commonProps}
								isResponsive={false}
								label={__('Keep Proportions', 'ablocks')}
								attributeObjectKey={
									attributeObjectKeyForScaleProportions
								}
							/>
							{attributeValue[
								attributeObjectKeyForScaleProportions
							] ? (
								<ABlocksRangeControl
									{...commonProps}
									label={__('Scale', 'ablocks')}
									isResponsive={true}
									isInline={false}
									attributeObjectKey={
										attributeObjectKeyForScale
									}
								/>
							) : (
								<>
									<ABlocksRangeControl
										{...commonProps}
										label={__('Scale X', 'ablocks')}
										isResponsive={true}
										isInline={false}
										attributeObjectKey={
											attributeObjectKeyForScaleX
										}
									/>
									<ABlocksRangeControl
										{...commonProps}
										label={__('Scale Y', 'ablocks')}
										isResponsive={true}
										isInline={false}
										attributeObjectKey={
											attributeObjectKeyForScaleY
										}
									/>
								</>
							)}
						</AblocksPopover>
					)}
				</div>
			</div>
		</div>
	);
};

export default ABlocksScale;
