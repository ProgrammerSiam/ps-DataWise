export const offsetOptionName = 'offset';
export const rotateOptionName = 'rotate';
export const scaleOptionName = 'scale';
export const skewOptionName = 'skew';

export const getAttributeDefaultValue = () => {
	return {
		rotate: '',
		rotateTablet: '',
		rotateMobile: '',
		rotate3D: false,
		rotate3DTablet: false,
		rotate3DMobile: false,
		rotateX: '',
		rotateXTablet: '',
		rotateXMobile: '',
		rotateY: '',
		rotateYTablet: '',
		rotateYMobile: '',
		rotateP: '',
		rotatePTablet: '',
		rotatePMobile: '',
		// Offset
		offsetX: '',
		offsetXTablet: '',
		offsetXMobile: '',
		offsetXUnit: '',
		offsetXUnitTablet: '',
		offsetXUnitMobile: '',
		offsetY: '',
		offsetYTablet: '',
		offsetYMobile: '',
		offsetYUnit: '',
		offsetYUnitTablet: '',
		offsetYUnitMobile: '',
		// Scale
		scaleProportions: false,
		scale: '',
		scaleTablet: '',
		scaleMobile: '',
		scaleX: '',
		scaleXTablet: '',
		scaleXMobile: '',
		scaleY: '',
		scaleYTablet: '',
		scaleYMobile: '',
		// Skew
		skewX: '',
		skewXTablet: '',
		skewXMobile: '',
		skewY: '',
		skewYTablet: '',
		skewYMobile: '',
		// Flip
		flipHorizontal: false,
		flipVertical: false,
		// X Anchor
		xAnchorPoint: '',
		xAnchorPointTablet: '',
		xAnchorPointMobile: '',
		// Y Anchor
		yAnchorPoint: '',
		yAnchorPointTablet: '',
		yAnchorPointMobile: '',

		// Rotate - Hover
		rotateH: '',
		rotateHTablet: '',
		rotateHMobile: '',
		rotate3DH: false,
		rotate3DHTablet: false,
		rotate3DHMobile: false,
		rotateXH: '',
		rotateXHTablet: '',
		rotateXHMobile: '',
		rotateYH: '',
		rotateYHTablet: '',
		rotateYHMobile: '',
		rotatePH: '',
		rotatePHTablet: '',
		rotatePHMobile: '',
		// Offset - Hover
		offsetXH: '',
		offsetXHTablet: '',
		offsetXHMobile: '',
		offsetYH: '',
		offsetYHTablet: '',
		offsetYHMobile: '',
		// Scale - Hover
		scaleProportionsH: false,
		scaleH: '',
		scaleHTablet: '',
		scaleHMobile: '',
		scaleXH: '',
		scaleXHTablet: '',
		scaleXHMobile: '',
		scaleYH: '',
		scaleYHTablet: '',
		scaleYHMobile: '',
		// Skew - Hover
		skewXH: '',
		skewXHTablet: '',
		skewXHMobile: '',
		skewYH: '',
		skewYHTablet: '',
		skewYHMobile: '',
		// Flip - Hover
		flipHorizontalH: false,
		flipVerticalH: false,
		// X Anchor - Hover
		xAnchorPointH: '',
		xAnchorPointHTablet: '',
		xAnchorPointHMobile: '',
		// Y Anchor - Hover
		yAnchorPointH: '',
		yAnchorPointHTablet: '',
		yAnchorPointHMobile: '',

		// Transition
		transitionH: '',
	};
};

export const getAttribute = (attributeName) => {
	return {
		[attributeName]: {
			type: 'object',
			default: getAttributeDefaultValue(),
		},
	};
};

export const getCSS = (attributeValue, property = '', device = '') => {
	const value = {
		...getAttributeDefaultValue(device ? true : false),
		...attributeValue,
	};

	const css = {};
	const transformations = [];
	let transformOrigin = '';
	if (
		value['rotate' + device] !== '' &&
		value['rotate' + device] !== undefined
	) {
		transformations.push(`rotate(${value['rotate' + device]}deg)`);
	}

	if (
		value['rotateX' + device] !== '' &&
		value['rotateX' + device] !== undefined
	) {
		transformations.push(`rotateX(${value['rotateX' + device]}deg)`);
	}

	if (
		value['rotateY' + device] !== '' &&
		value['rotateY' + device] !== undefined
	) {
		transformations.push(`rotateY(${value['rotateY' + device]}deg)`);
	}

	if (value['rotate3D' + device] !== false) {
		transformations.push(
			`rotateZ(${
				value['rotate' + device] ? value['rotate' + device] : 0
			}deg)`
		);
	}

	if (value['rotateP' + device] !== '') {
		transformations.push(
			`perspective(${
				value['rotateP' + device] ? value['rotateP' + device] : 0
			}px)`
		);
	}

	if (
		value['scale' + device] !== '' &&
		value['scale' + device] !== undefined
	) {
		transformations.push(`scale(${value['scale' + device]})`);
	}

	if (
		value['scaleX' + device] !== undefined &&
		value['scaleX' + device] !== ''
	) {
		transformations.push(`scaleX(${value['scaleX' + device]})`);
	}

	if (
		value['scaleY' + device] !== undefined &&
		value['scaleY' + device] !== ''
	) {
		transformations.push(`scaleY(${value['scaleY' + device]})`);
	}

	if (
		value['flipHorizontal' + device] !== undefined &&
		value['flipHorizontal' + device] !== false
	) {
		transformations.push(`scaleX(-1)`);
	}

	if (
		value['flipVertical' + device] !== undefined &&
		value['flipVertical' + device] !== false
	) {
		transformations.push(`scaleY(-1)`);
	}

	if (
		value['offsetX' + device] !== '' &&
		value['offsetX' + device] !== undefined
	) {
		transformations.push(`translateX(${value['offsetX' + device]}px)`);
	}

	if (
		value['offsetY' + device] !== '' &&
		value['offsetY' + device] !== undefined
	) {
		transformations.push(`translateY(${value['offsetY' + device]}px)`);
	}

	if (
		value['skewX' + device] !== undefined &&
		value['skewX' + device] !== ''
	) {
		transformations.push(`skewX(${value['skewX' + device]}deg)`);
	}

	if (
		value['skewY' + device] !== undefined &&
		value['skewY' + device] !== ''
	) {
		transformations.push(`skewY(${value['skewY' + device]}deg)`);
	}

	if (value['xAnchorPoint' + device]) {
		transformOrigin = `${value['yAnchorPoint' + device]} ${
			value['xAnchorPoint' + device]
		}`;
	}

	if (value['yAnchorPoint' + device]) {
		transformOrigin = `${value.yAnchorPoint} ${value.xAnchorPoint}`;
	}

	if (transformOrigin) {
		css['transform-origin'] = transformOrigin;
	}

	if (transformations.length > 0) {
		css[property] = transformations.join(' ');
	}

	return css;
};

export const getHoverCSS = (attributeValue, property = '', device = '') => {
	const value = {
		...getAttributeDefaultValue(device ? true : false),
		...attributeValue,
	};

	const css = {};
	const transformations = [];
	let transformOrigin = '';

	if (
		value['rotateH' + device] !== '' &&
		value['rotateH' + device] !== undefined
	) {
		transformations.push(`rotate(${value['rotateH' + device]}deg)`);
	}

	if (
		value['rotateXH' + device] !== '' &&
		value['rotateXH' + device] !== undefined
	) {
		transformations.push(`rotateX(${value['rotateXH' + device]}deg)`);
	}

	if (
		value['rotateYH' + device] !== '' &&
		value['rotateYH' + device] !== undefined
	) {
		transformations.push(`rotateY(${value['rotateYH' + device]}deg)`);
	}

	if (value['rotate3DH' + device] !== false) {
		transformations.push(
			`rotateZ(${
				value['rotateH' + device] ? value['rotateH' + device] : 0
			}deg)`
		);
	}

	if (value['rotatePH' + device] !== '') {
		transformations.push(
			`perspective(${
				value['rotatePH' + device] ? value['rotatePH' + device] : 0
			}px)`
		);
	}

	if (
		value['scaleH' + device] !== '' &&
		value['scaleH' + device] !== undefined
	) {
		transformations.push(`scale(${value['scaleH' + device]})`);
	}

	if (
		value['scaleXH' + device] !== undefined &&
		value['scaleXH' + device] !== ''
	) {
		transformations.push(`scaleX(${value['scaleXH' + device]})`);
	}

	if (
		value['scaleYH' + device] !== undefined &&
		value['scaleYH' + device] !== ''
	) {
		transformations.push(`scaleY(${value['scaleYH' + device]})`);
	}

	if (
		value['flipHorizontalH' + device] !== undefined &&
		value['flipHorizontalH' + device] !== false
	) {
		transformations.push(`scaleX(-1)`);
	}

	if (
		value['flipVerticalH' + device] !== undefined &&
		value['flipVerticalH' + device] !== false
	) {
		transformations.push(`scaleY(-1)`);
	}

	if (
		value['offsetXH' + device] !== '' &&
		value['offsetXH' + device] !== undefined
	) {
		transformations.push(`translateX(${value['offsetXH' + device]}px)`);
	}

	if (
		value['offsetYH' + device] !== '' &&
		value['offsetYH' + device] !== undefined
	) {
		transformations.push(`translateY(${value['offsetYH' + device]}px)`);
	}

	if (
		value['skewXH' + device] !== undefined &&
		value['skewXH' + device] !== ''
	) {
		transformations.push(`skewX(${value['skewXH' + device]}deg)`);
	}

	if (
		value['skewYH' + device] !== undefined &&
		value['skewYH' + device] !== ''
	) {
		transformations.push(`skewY(${value['skewYH' + device]}deg)`);
	}

	if (value['xAnchorPointH' + device]) {
		transformOrigin = `${value['yAnchorPointH' + device]} ${
			value['xAnchorPointH' + device]
		}`;
	}

	if (value['yAnchorPointH' + device]) {
		transformOrigin = `${value['yAnchorPointH' + device]} ${
			value['xAnchorPointH' + device]
		}`;
	}
	if (transformOrigin) {
		css['transform-origin'] = transformOrigin;
	}

	if (transformations.length > 0) {
		css[property] = transformations.join(' ');
	}

	return css;
};
