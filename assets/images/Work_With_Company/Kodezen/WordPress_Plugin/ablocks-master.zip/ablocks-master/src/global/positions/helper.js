import { getUnit } from '@Utils/helper';

export const getAttributeDefaultValue = (isResponsive = false) => {
	if (isResponsive) {
		return {
			positionType: 'relative',
			positionTypeTablet: '',
			positionTypeMobile: '',
			hOrientation: '',
			hOffset: '',
			hOffsetTablet: '',
			hOffsetMobile: '',
			hOffsetUnit: 'px',
			hOffsetUnitTablet: 'px',
			hOffsetUnitMobile: 'px',
			vOrientation: '',
			vOffset: '',
			vOffsetTablet: '',
			vOffsetMobile: '',
			vOffsetUnit: 'px',
			vOffsetUnitTablet: 'px',
			vOffsetUnitMobile: 'px',
		};
	}
	return {
		positionType: 'relative',
		hOrientation: '',
		hOffset: '0',
		hOffsetUnit: 'px',
		vOrientation: '',
		vOffset: '0',
		vOffsetUnit: 'px',
	};
};

export const getAttribute = (attributeName, isResponsive = false) => {
	if (isResponsive) {
		return {
			[attributeName]: {
				type: 'object',
				default: getAttributeDefaultValue(isResponsive),
			},
		};
	}
	return {
		[attributeName]: {
			type: 'object',
			default: getAttributeDefaultValue(isResponsive),
		},
	};
};

export const getCSS = (attributeValue, property = '', device = '') => {
	const value = {
		...getAttributeDefaultValue(device ? true : false),
		...attributeValue,
	};
	const css = {};
	const hOffsetUnit = getUnit(
		{
			unit: value.hOffsetUnit,
			unitTablet: value.hOffsetUnitTablet,
			unitMobile: value.hOffsetUnitMobile,
		},
		device
	);

	const vOffsetUnit = getUnit(
		{
			unit: value.vOffsetUnit,
			unitTablet: value.vOffsetUnitTablet,
			unitMobile: value.vOffsetUnitMobile,
		},
		device
	);

	if (value['positionType' + device]) {
		css[`${property}`] = value['positionType' + device];
	}

	if (value['hOrientation' + device] === 'right') {
		css.right = value['hOffset' + device] + hOffsetUnit;
		delete css.left;
	} else if (value['hOffset' + device]) {
		css.left = value['hOffset' + device] + hOffsetUnit;
		delete css.right;
	}

	if (value['vOrientation' + device] === 'bottom') {
		css.bottom = value['vOffset' + device] + vOffsetUnit;
		delete css.top;
	} else if (value['vOffset' + device]) {
		css.top = value['vOffset' + device] + vOffsetUnit;
		delete css.bottom;
	}

	return css;
};

export const horizontalOrientation = [
	{
		label: 'arrow-left-alt',
		value: 'left',
		icon: 'left',
	},
	{
		label: 'arrow-right-alt',
		value: 'right',
		icon: 'right',
	},
];

export const verticalOrientation = [
	{
		label: 'arrow-up-alt',
		value: 'top',
		icon: 'align-top',
	},
	{
		label: 'arrow-down-alt',
		value: 'bottom',
		icon: 'align-bottom',
	},
];
