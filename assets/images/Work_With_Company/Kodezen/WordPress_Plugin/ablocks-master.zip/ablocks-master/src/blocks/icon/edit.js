import React, { useEffect } from 'react';
import Settings from './settings';
import Render from './render';
import CSSGenerator from '@Utils/css-generator';
import { getWrapperCSS, getIconWrapperCSS, getIconCSS } from './styling';

export default function Edit(props) {
	const { isSelected, attributes, setAttributes, clientId } = props;

	useEffect(() => {
		setAttributes({ block_id: clientId });
	}, [clientId, setAttributes]);

	// Generate CSS
	const cssGenerator = new CSSGenerator(attributes);

	cssGenerator.addClassStyles(
		'{{WRAPPER}}',
		getWrapperCSS(attributes),
		getWrapperCSS(attributes, 'Tablet'),
		getWrapperCSS(attributes, 'Mobile')
	);

	const iconWrapperDesktopCss = getIconWrapperCSS(attributes) || {};

	if (attributes?.iconSize) {
		iconWrapperDesktopCss['font-size'] = `${attributes?.iconSize}px`;
	}
	cssGenerator.addClassStyles(
		'{{WRAPPER}} .ablocks-block-container .ablocks-icon-wrap',
		iconWrapperDesktopCss,
		getIconWrapperCSS(attributes, 'Tablet'),
		getIconWrapperCSS(attributes, 'Mobile')
	);

	cssGenerator.addClassStyles(
		'{{WRAPPER}} .ablocks-block-container .ablocks-icon-wrap svg.ablocks-svg-icon',
		getIconCSS(attributes)
	);

	const generatedCSS = cssGenerator.generateCSS();
	return (
		<>
			<style>{generatedCSS}</style>
			{isSelected && <Settings {...props} />}
			<Render {...props} />
		</>
	);
}
