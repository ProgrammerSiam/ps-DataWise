import React from 'react';
import { __ } from '@wordpress/i18n';
import PropTypes from 'prop-types';
import { SelectControl, TextControl } from '@wordpress/components';
import ControlLabel from '@Components/control-label';
import GetDeviceType from '@Utils/get-device-type';
import { getAttributeDefaultValue } from './helper';
import { objectUniqueCheck } from '@Utils/helper';
import './styles.scss';
import Select from 'react-select';
import { durationOptions, groupedAnimationOptions } from './data';

const propTypes = {
	isResponsive: PropTypes.bool,
	label: PropTypes.string,
	attributeName: PropTypes.string,
	attributeValue: PropTypes.any,
	onChangeHandler: PropTypes.func,
};

const defaultProps = {
	label: '',
	isResponsive: true,
};
const ABlocksAnimationControl = (props) => {
	const {
		isResponsive,
		attributeName,
		attributeValue,
		onChangeHandler,
		setAttributes,
		label,
	} = props;
	const deviceType = GetDeviceType();
	const changeHandler = (controlValue, deviceMode) => {
		if (onChangeHandler) {
			onChangeHandler(
				controlValue,
				deviceMode,
				getAttributeDefaultValue(isResponsive)
			);
		} else {
			defaultChangeHandler(controlValue, deviceMode);
		}
	};

	const defaultChangeHandler = (controlValue, deviceMode) => {
		return setAttributes({
			[attributeName]: objectUniqueCheck(
				getAttributeDefaultValue(isResponsive),
				{
					...attributeValue,
					['animationType' + deviceMode]: controlValue,
				}
			),
		});
	};
	const output = {};
	output.Desktop = (
		<Select
			isClearable
			value={groupedAnimationOptions.find(
				(item) => item.value === attributeValue.animationType
			)}
			options={groupedAnimationOptions}
			isSearchable
			onChange={(controlValue) =>
				changeHandler(controlValue ? controlValue.value : '', '')
			}
		/>
	);
	if (isResponsive) {
		output.Tablet = (
			<Select
				value={groupedAnimationOptions.find(
					(item) => item.value === attributeValue.animationType
				)}
				options={groupedAnimationOptions}
				isSearchable
				onChange={(controlValue) =>
					changeHandler(
						controlValue ? controlValue.value : '',
						'Tablet'
					)
				}
			/>
		);

		output.Mobile = (
			<Select
				value={groupedAnimationOptions.find(
					(item) => item.value === attributeValue.animationType
				)}
				options={groupedAnimationOptions}
				isSearchable
				onChange={(controlValue) =>
					changeHandler(
						controlValue ? controlValue.value : '',
						'Mobile'
					)
				}
			/>
		);
	}
	const showControl = attributeValue.animationType;

	return (
		<React.Fragment>
			<div className="ablocks-control ablocks-animation-control">
				{label && (
					<ControlLabel label={label} isResponsive={isResponsive} />
				)}
				{output[deviceType] ? output[deviceType] : output.Desktop}
				{showControl && (
					<>
						<div className="ablocks-animation-control--duration">
							<span>{__('Animation Duration')}</span>
							<SelectControl
								className="ablocks-animation-control--duration__field"
								options={durationOptions}
								value={
									attributeValue[
										'animationDuration' + deviceType
									]
								}
								deviceMode={
									deviceType ? deviceType.toLowerCase() : ''
								}
								onChange={(durationValue) => {
									setAttributes({
										[attributeName]: objectUniqueCheck(
											getAttributeDefaultValue(
												isResponsive
											),
											{
												...attributeValue,
												['animationDuration' +
												deviceType]: durationValue,
											}
										),
									});
								}}
							/>
						</div>
						<div className="ablocks-animation-control--delay">
							<span>{__('Animation Delay (ms)')}</span>
							<TextControl
								className="ablocks-animation-control--delay__field"
								type="number"
								value={
									attributeValue[
										'animationDelay' + deviceType
									]
								}
								onChange={(delayValue) => {
									setAttributes({
										[attributeName]: objectUniqueCheck(
											getAttributeDefaultValue(
												isResponsive
											),
											{
												...attributeValue,
												['animationDelay' + deviceType]:
													delayValue,
											}
										),
									});
								}}
							/>
						</div>
					</>
				)}
			</div>
		</React.Fragment>
	);
};
ABlocksAnimationControl.propTypes = propTypes;
ABlocksAnimationControl.defaultProps = defaultProps;
export default ABlocksAnimationControl;
