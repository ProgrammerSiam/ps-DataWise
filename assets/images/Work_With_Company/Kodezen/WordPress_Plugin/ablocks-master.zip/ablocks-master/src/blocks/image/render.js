import React, { useRef } from 'react';
import Layouts from './Layouts';
import metadata from './block.json';
import { __ } from '@wordpress/i18n';
import { onSelectImage } from './utils';
import getDeviceType from '@Utils/get-device-type';
import { MediaPlaceholder } from '@wordpress/block-editor';
import RenderContainer from '@Components/block-container/render';
import Toolbar from './toolbar';

const propTypes = {};
const defaultProps = {};

export default function Render(props) {
	const { attributes, setAttributes, isSelected } = props;
	const { block_id, imgUrl } = attributes;
	const deviceType = getDeviceType();
	const addCaptionRef = useRef(null);

	function onSelectURL(url) {
		setAttributes({
			['imgId' + deviceType]: block_id?.split('-')[0],
			['imgUrl' + deviceType]: url,
		});
	}

	const mediaPreview = !!imgUrl && (
		<img
			alt={__('Edit image', 'ablocks')}
			title={__('Edit image', 'ablocks')}
			className={'edit-image-preview'}
			src={imgUrl}
		/>
	);

	return (
		<React.Fragment>
			<Toolbar {...props} addCaptionRef={addCaptionRef} />
			<RenderContainer
				blockId={block_id}
				name={metadata.name}
				attributes={attributes}
			>
				<Layouts
					attributeValue={attributes._image}
					attributes={attributes}
					setAttributes={setAttributes}
					attributeName={'_image'}
					isResponsive={true}
					block_id={block_id}
					isSelected={isSelected}
					addCaptionRef={addCaptionRef}
				/>
				<MediaPlaceholder
					labels={{
						title: __('Image', 'ablocks'),
						instructions: __(
							'Upload an image file, pick one from your media library, or add one with a URL.',
							'ablocks'
						),
					}}
					onSelect={(mediaValue) =>
						onSelectImage(
							mediaValue,
							attributes,
							setAttributes,
							deviceType
						)
					}
					onSelectURL={(url) => onSelectURL(url)}
					accept="image/*"
					allowedTypes={['image']}
					value={{ url: imgUrl }}
					mediaPreview={mediaPreview}
					disableMediaButtons={imgUrl}
				/>
			</RenderContainer>
		</React.Fragment>
	);
}

Render.propTypes = propTypes;
Render.defaultProps = defaultProps;
