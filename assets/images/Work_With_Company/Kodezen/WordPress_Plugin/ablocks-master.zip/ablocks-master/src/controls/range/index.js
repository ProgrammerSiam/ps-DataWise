import React from 'react';
import { RangeControl } from '@wordpress/components';
import ControlLabel from '@Components/control-label';
import ABlocksUnitSelect from '@Components/unit';
import GetDeviceType from '@Utils/get-device-type';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import { objectUniqueCheck } from '@Utils/helper';
import { getAttributeDefaultValue } from '@Controls/range/helper';
import './editor.scss';

const propTypes = {
	isResponsive: PropTypes.bool,
	min: PropTypes.number,
	max: PropTypes.number,
	label: PropTypes.string,
	attributeName: PropTypes.string,
	attributeObjectKey: PropTypes.string,
	attributeValue: PropTypes.any,
	onChangeHandler: PropTypes.func,
	isInline: PropTypes.bool,
	hasUnit: PropTypes.bool,
	unitOptions: PropTypes.array,
};

const defaultProps = {
	label: '',
	isResponsive: true,
	min: -360,
	max: 360,
	attributeObjectKey: 'value',
	isInline: true,
	hasUnit: false,
	unitOptions: [
		{ value: 'px', label: 'px' },
		{ value: '%', label: '%' },
		{ value: 'rem', label: 'rem' },
		{ value: 'em', label: 'em' },
	],
};

export default function ABlocksRangeControl(props) {
	const {
		isResponsive,
		attributeName,
		attributeValue,
		onChangeHandler,
		setAttributes,
		label,
		min,
		max,
		attributeObjectKey,
		step,
		isInline,
		hasUnit,
		unitOptions,
	} = props;

	const deviceType = GetDeviceType();

	let customStep;
	if (hasUnit && !step) {
		const checkUnitType =
			attributeValue[
				isResponsive
					? attributeObjectKey + 'Unit' + deviceType
					: attributeObjectKey + 'Unit'
			];
		if (checkUnitType === 'em' || checkUnitType === 'rem') {
			customStep = 0.1;
		} else {
			customStep = 1;
		}
	}

	const changeHandler = (controlValue, deviceMode) => {
		if (onChangeHandler) {
			onChangeHandler(
				controlValue,
				isResponsive
					? attributeObjectKey + deviceMode
					: attributeObjectKey
			);
		} else {
			defaultChangeHandler(controlValue, deviceMode);
		}
	};

	const defaultChangeHandler = (controlValue, deviceMode) => {
		if (isResponsive) {
			return setAttributes({
				[attributeName]: objectUniqueCheck(
					getAttributeDefaultValue(isResponsive),
					{
						...attributeValue,
						[attributeObjectKey + deviceMode]: controlValue,
					}
				),
			});
		}
		return setAttributes({ [attributeName]: controlValue });
	};

	return (
		<React.Fragment>
			<div
				className={classnames(
					`ablocks-control ablocks-control--range`,
					{ 'ablocks-control--inline': isInline }
				)}
			>
				<div className="ablocks-control__head">
					{label && (
						<ControlLabel
							label={label}
							isResponsive={isResponsive}
						/>
					)}
					{hasUnit && (
						<ABlocksUnitSelect
							attributeName={attributeName}
							attributeObjectKey={attributeObjectKey + 'Unit'}
							attributeValue={attributeValue}
							setAttributes={setAttributes}
							getAttributeDefaultValue={getAttributeDefaultValue}
							options={unitOptions}
						/>
					)}
				</div>
				<RangeControl
					value={
						isResponsive
							? attributeValue[attributeObjectKey + deviceType]
							: attributeValue
					}
					onChange={(controlValue) =>
						changeHandler(controlValue, deviceType)
					}
					min={min || 0}
					max={max}
					step={step ? step : customStep}
				/>
			</div>
		</React.Fragment>
	);
}

ABlocksRangeControl.propTypes = propTypes;
ABlocksRangeControl.defaultProps = defaultProps;
