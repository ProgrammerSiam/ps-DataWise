import React from 'react';
import PropTypes from 'prop-types';
import { handleStartAndEndTime } from './helper';

const propTypes = {
	autoplay: PropTypes.bool,
	mute: PropTypes.bool,
	loop: PropTypes.bool,
	poster: PropTypes.string,
	preload: PropTypes.string,
	videoUrl: PropTypes.string,
	videoStartTime: PropTypes.string,
	videoEndTime: PropTypes.string,
	externalLink: PropTypes.bool,
	selfHostedURL: PropTypes.string,
	playerControl: PropTypes.bool,
	downloadButton: PropTypes.bool,
};

const defaultProps = {
	autoplay: false,
	mute: false,
	loop: false,
	poster: '',
	preload: '',
	videoUrl: '',
	videoStartTime: '',
	videoEndTime: '',
	externalLink: false,
	selfHostedURL: '',
	playerControl: false,
	downloadButton: false,
};

export default function ABlocksVideoPlayer(props) {
	const {
		autoplay,
		mute,
		loop,
		poster,
		preload,
		videoUrl,
		videoStartTime,
		videoEndTime,
		externalLink,
		selfHostedURL,
		playerControl,
		downloadButton,
	} = props;
	const getStartAndEndTime = handleStartAndEndTime(
		videoStartTime,
		videoEndTime
	);

	return (
		<video
			src={(externalLink ? selfHostedURL : videoUrl) + getStartAndEndTime}
			autoPlay={autoplay}
			muted={mute}
			loop={loop}
			poster={poster ? poster : ''}
			preload={preload}
			controls={playerControl}
			controlsList={`${downloadButton ? 'nodownload' : ''}`}
			className="ablocks-video-player"
		></video>
	);
}

ABlocksVideoPlayer.propTypes = propTypes;
ABlocksVideoPlayer.defaultProps = defaultProps;
