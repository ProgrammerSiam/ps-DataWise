import { getCSS as getAlignmentCSS } from '@Controls/alignment/helper';
import { getCSS as getTypographyCSS } from '@Controls/typography/helper';
import { getCSS as getTextStrokeCSS } from '@Controls/textStroke/helper';

export const getWrapperCSS = (attributes, device = '') => {
	return {
		...getAlignmentCSS(attributes?.alignment, 'text-align', device),
	};
};

export const getDividerContainerCSS = (attributes, device = '') => {
	const { gap, alignment } = attributes;
	const dividerContainerCSS = {};
	if (alignment['value' + device]) {
		dividerContainerCSS['justify-content'] = alignment['value' + device];
	}
	if (gap['value' + device]) {
		dividerContainerCSS['padding-block-start'] = `${
			gap['value' + device]
		}px`;
		dividerContainerCSS['padding-block-end'] = `${gap['value' + device]}px`;
	}

	return dividerContainerCSS;
};

export const getDividerCSS = (attributes, device = '') => {
	const { width } = attributes;
	const dividerCSS = {};
	if (width['value' + device]) {
		dividerCSS.width = `${width['value' + device]}%`;
	}
	return dividerCSS;
};

export const getDividerElementTextCSS = (attributes, device = '') => {
	return {
		...getTypographyCSS(attributes?.elementTextTypography, device),
		...getTextStrokeCSS(attributes?.elementTextStroke, device),
	};
};

export const getDividerElementIconWrapperCSS = (attributes) => {
	const {
		elementIconType: iconType,
		elementIconPrimaryColor: primaryColor,
		elementIconBackgroundColor: backgroundColor,
	} = attributes;
	let iconViewCSS;
	if (iconType !== 'default') {
		if (iconType === 'stacked') {
			iconViewCSS = {
				background: backgroundColor || '#ddd',
				padding: '.5em',
			};
		} else if (iconType === 'framed') {
			iconViewCSS = {
				background: backgroundColor || 'transparent',
				padding: '.5em',
				border: `2px solid ${primaryColor || '#69727d'}`,
			};
		}
	}

	return {
		background: backgroundColor,
		...iconViewCSS,
	};
};

export const getDividerElementIconCSS = (attributes) => {
	const { elementIconType: iconType, elementIconPrimaryColor: primaryColor } =
		attributes;
	let iconViewCSS;
	if (iconType !== 'default') {
		if (iconType === 'stacked') {
			iconViewCSS = {
				fill: primaryColor || '#000000',
			};
		} else if (iconType === 'framed') {
			iconViewCSS = {
				fill: primaryColor || '#69727d',
			};
		}
	}

	return {
		fill: primaryColor || '#69727d',
		...iconViewCSS,
	};
};
