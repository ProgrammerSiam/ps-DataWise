import React from 'react';
import { ResizableBox } from '@wordpress/components';
import { store as blockEditorStore } from '@wordpress/block-editor';
import getDeviceType from '@Utils/get-device-type';
import { useSelect, useDispatch } from '@wordpress/data';
import { useClientWidth, useClientHeight } from './utils';

const propTypes = {};
const defaultProps = {};
export default function Image(props) {
	const { toggleSelection } = useDispatch(blockEditorStore);
	const { setAttributes, isSelected, attributes, containerRef } = props;

	const {
		imgAltText,
		imgTitle,
		alignment,
		widthHeightWidget,
		widthHeightWidget: {
			width,
			height,
			widthTablet,
			widthMobile,
			heightTablet,
			heightMobile,
		},
	} = attributes;

	const deviceType = getDeviceType();
	const imgNaturalWidth = widthHeightWidget['imgNaturalWidth' + deviceType];
	const imgNaturalHeight = widthHeightWidget['imgNaturalHeight' + deviceType];
	const responsiveImageWidth = widthHeightWidget['width' + deviceType];
	const responsiveImageHeight = widthHeightWidget['height' + deviceType];
	const responsiveCustomImageHeight =
		widthHeightWidget['customHeight' + deviceType];
	const imageSource =
		attributes[`imgUrl${deviceType}`] ||
		(deviceType === 'Mobile'
			? attributes.imgUrlMobile ||
			  attributes.imgUrlTablet ||
			  attributes.imgUrl
			: attributes.imgUrl);

	const { maxWidth } = useSelect((select) => {
		const { getSettings } = select(blockEditorStore);
		// eslint-disable-next-line no-shadow
		const { maxWidth } = getSettings();
		return {
			maxWidth,
		};
	}, []);

	const minWidth = 50;
	const minHeight = 50;
	const maxWidthBuffer = maxWidth * 2;
	const ratio = imgNaturalWidth / imgNaturalHeight;
	const clientWidth = useClientWidth(containerRef, [alignment, deviceType]);
	const clientHeight = useClientHeight(containerRef, [alignment, deviceType]);
	let rightHandle = true;
	let leftHandle = false;

	if (alignment?.value === 'center') {
		// When the image is centered, show both handles.
		rightHandle = true;
		leftHandle = true;
	} else if (alignment?.value === 'right') {
		// Show the right handle and hide the left handle only when it is
		// aligned right.
		rightHandle = false;
		leftHandle = true;
	}

	let resWidth = '';
	let resHeight = '';
	if (deviceType === 'Tablet') {
		resWidth = widthTablet ? widthTablet : imgNaturalWidth;
		resHeight = heightTablet ? heightTablet : imgNaturalWidth;
	} else if (deviceType === 'Mobile') {
		resWidth = widthMobile ? widthMobile : imgNaturalWidth;
		resHeight = heightMobile ? heightMobile : imgNaturalWidth;
	} else {
		resWidth = width || imgNaturalWidth;
		resHeight = height || imgNaturalWidth;
	}

	function onResizeStart() {
		toggleSelection(false);
	}

	const onResizeStop = (event, direction, elt, delta) => {
		const updatedWidth = Math.abs(
			responsiveImageWidth
				? parseInt(responsiveImageWidth) + delta.width
				: clientWidth + delta.width
		);
		const updatedHeight = Math.abs(
			responsiveImageHeight
				? parseInt(responsiveImageHeight) + delta.height
				: clientHeight + delta.height
		);

		setAttributes({
			widthHeightWidget: {
				...attributes?.widthHeightWidget,
				['width' + deviceType]: updatedWidth,
				['height' + deviceType]: responsiveCustomImageHeight
					? responsiveImageHeight
					: updatedHeight || 'auto',
			},
		});
		toggleSelection(true);
	};

	return (
		<ResizableBox
			size={{
				width: resWidth ? resWidth : 'auto',
				height: resHeight ? resHeight : 'auto',
			}}
			showHandle={isSelected}
			minHeight={minHeight}
			minWidth={minWidth}
			maxWidth={maxWidthBuffer}
			maxHeight={maxWidthBuffer / ratio}
			lockAspectRatio
			enable={{
				top: false,
				bottom: true,
				left: leftHandle,
				right: rightHandle,
			}}
			onResizeStop={(event, direction, elt, delta) => {
				onResizeStop(event, direction, elt, delta);
			}}
			onResizeStart={onResizeStart}
		>
			<img
				src={imageSource}
				alt={imgAltText}
				title={imgTitle}
				loading="lazy"
				style={{
					width: responsiveImageWidth,
				}}
			/>
		</ResizableBox>
	);
}

Image.propTypes = propTypes;
Image.defaultProps = defaultProps;
