import React from 'react';
import {
	generateVimeoVideoSrc,
	getVimeoVideoId,
	handleVimeoVideoTime,
} from './helper';
import PropTypes from 'prop-types';

const propTypes = {
	autoplay: PropTypes.bool,
	mute: PropTypes.bool,
	loop: PropTypes.bool,
	vimeoURL: PropTypes.string,
	videoStartTime: PropTypes.string,
	introPortrait: PropTypes.bool,
	introTitle: PropTypes.bool,
	introByline: PropTypes.bool,
	isBackground: PropTypes.bool,
};

const defaultProps = {
	autoplay: false,
	mute: false,
	loop: false,
	vimeoURL: '',
	videoStartTime: '',
	introPortrait: false,
	introTitle: false,
	introByline: false,
	isBackground: false,
};

export default function VimeoVideo(props) {
	const {
		vimeoURL,
		autoplay,
		videoStartTime,
		loop,
		mute,
		introPortrait,
		introTitle,
		introByline,
		isBackground,
	} = props;
	const vimeoVideoId = getVimeoVideoId(vimeoURL);
	const getStartTime = handleVimeoVideoTime(videoStartTime);
	const vimeoVideoSource = generateVimeoVideoSrc({
		vimeoVideoId,
		autoplay,
		loop,
		introByline,
		mute,
		introPortrait,
		introTitle,
		isBackground,
		getStartTime,
	});

	return (
		<iframe
			title="vimeo-video-player"
			src={vimeoVideoSource}
			frameBorder="0"
			className="ablocks-vimeo-video-player"
			allow="autoplay; fullscreen; picture-in-picture"
			allowFullScreen
		></iframe>
	);
}

VimeoVideo.propTypes = propTypes;
VimeoVideo.defaultProps = defaultProps;
