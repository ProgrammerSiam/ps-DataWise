import React, { useRef, useEffect, useState, memo } from 'react';
import { RangeControl } from '@wordpress/components';

import { arraysEqual, shallowEqual } from './helper';
import { getGradient } from './utils';
import { getTypeAndHsvaObjectFromColorString } from '../colorPicker/utils/helperFunctions';
import Button from '@Components/Button';

let ablocksHelperOnChangeTimeoutId;

const Markers = ({ color, setColor, activeColor, setActiveColor }) => {
	const node = useRef();

	const [needDeleteActive, setNeedDeleteActive] = useState(false);
	const [hideStop, setHideStop] = useState(false);
	const [activeStopPositionValue, setActiveStopPositionValue] = useState(
		activeColor?.loc || 0
	);

	const { stops, type, modifier } = color;

	const onAddColorStop = (e) => {
		e.stopPropagation();
		const target = e.target;

		if (target.className !== 'gradient-marker') {
			const rect = target.getBoundingClientRect();
			const clickPos = e.clientX - rect.left;
			const loc =
				Number(((100 / rect.width) * clickPos).toFixed(0)) / 100;

			const newStops = [
				...color.stops,
				[activeColor.colorString, loc, color.stops.length],
			]
				.sort((a, b) => a[1] - b[1])
				.map((item, index) => {
					item[2] = index;
					return item;
				});

			const newGradient = `${getGradient(type, newStops, modifier)}`;
			const newColor = {
				...color,
				gradient: newGradient,
				stops: newStops,
			};
			setColor(newColor);

			const activeIndex = newStops.find((item) => item[1] === loc)[2];
			const newActiveColor = {
				...activeColor,
				loc,
				index: activeIndex,
			};
			setActiveColor(newActiveColor);
		}
	};

	const removeListeners = () => {
		window.removeEventListener('mousemove', onDrag);
		window.removeEventListener('mouseup', onDragEnd);
	};

	const removeTouchListeners = () => {
		window.removeEventListener('touchmove', onTouchMove);
		window.removeEventListener('touchend', onTouchEnd);
	};

	const onMouseDown = (e, mousePointColor) => {
		e.preventDefault();
		e.stopPropagation();
		e.nativeEvent.stopImmediatePropagation();
		if (e.detail === 2) {
			return;
		}
		if (e.button !== 0) {
			return;
		}
		const colorString = mousePointColor[0];
		const { hsva } = getTypeAndHsvaObjectFromColorString(colorString);
		setActiveColor({
			colorString,
			alpha: hsva.a * 100,
			loc: mousePointColor[1],
			index: mousePointColor[2],
		});
		const x = e.clientX;
		const y = e.clientY;
		pointMoveTo({ x, y });
		window.addEventListener('mousemove', onDrag);
		window.addEventListener('mouseup', onDragEnd);
	};

	const onDrag = (e) => {
		const x = e.clientX;
		const y = e.clientY;
		const rect = node?.current?.getBoundingClientRect();
		const rootDistance = y - rect.y;
		if (rootDistance > 80 && stops.length > 2) {
			setHideStop(true);
			return;
		}
		setHideStop(false);
		pointMoveTo({ x, y });
	};

	const onDragEnd = (e) => {
		const x = e.clientX;
		const y = e.clientY;

		const rect = node?.current?.getBoundingClientRect();
		const rootDistance = y - rect.y;
		if (rootDistance > 80 && stops.length > 2) {
			setNeedDeleteActive(true);
		}
		pointMoveTo({ x, y });
		removeListeners();
	};

	const onTouchStart = (e, touchStartColor) => {
		if (e.cancelable) {
			e.preventDefault();
		}
		if (e.touches.length !== 1) {
			return;
		}
		removeTouchListeners();
		const colorString = touchStartColor[0];
		const { hsva } = getTypeAndHsvaObjectFromColorString(colorString);
		setActiveColor({
			colorString,
			alpha: hsva.a * 100,
			loc: touchStartColor[1],
			index: touchStartColor[2],
		});
		const x = e.targetTouches[0].clientX;
		const y = e.targetTouches[0].clientY;
		pointMoveTo({ x, y });
		window.addEventListener('touchmove', onTouchMove, { passive: false });
		window.addEventListener('touchend', onTouchEnd, { passive: false });
	};

	const onTouchMove = (e) => {
		if (e.cancelable) {
			e.preventDefault();
		}
		const x = e.targetTouches[0].clientX;
		const y = e.targetTouches[0].clientY;
		const rect = node?.current?.getBoundingClientRect();
		const rootDistance = y - rect.y;
		if (rootDistance > 80 && stops.length > 2) {
			setHideStop(true);
			return;
		}
		setHideStop(false);
		pointMoveTo({ x, y });
	};

	const onTouchEnd = () => {
		removeTouchListeners();
	};

	const pointMoveTo = (coords) => {
		const rect = node && node.current.getBoundingClientRect();
		const width = rect.width;
		let pos = coords.x - rect.left;
		pos = Math.max(0, pos);
		pos = Math.min(pos, width);
		const location = Number(((100 / rect.width) * pos).toFixed(0)) / 100;
		setActiveColor((prev) => {
			return {
				...prev,
				loc: location,
			};
		});
	};

	const deleteColorStop = () => {
		if (stops.length <= 2) {
			return;
		}
		const newStops = stops
			.filter((stop) => stop[2] !== activeColor.index)
			.map((stop, index) => {
				stop[2] = index;
				return stop;
			});
		const lastStopIndex = newStops.length - 1;
		const lastStopColorString = newStops[lastStopIndex][0];
		const { hsva } =
			getTypeAndHsvaObjectFromColorString(lastStopColorString);
		const lastStopLoc = newStops[lastStopIndex][1];
		setNeedDeleteActive(false);
		setHideStop(false);
		setActiveColor({
			colorString: lastStopColorString,
			alpha: hsva.a * 100,
			loc: lastStopLoc,
			index: lastStopIndex,
		});
		const gradient = getGradient(type, newStops, modifier);
		return setColor({
			...color,
			gradient,
			stops: newStops,
		});
	};

	useEffect(() => {
		if (needDeleteActive) {
			return deleteColorStop();
		}
		clearTimeout(ablocksHelperOnChangeTimeoutId);
		const newStops = stops.map((item) => {
			if (activeColor.index === item[2]) {
				return [item[0], activeColor.loc, item[2]];
			}
			return item;
		});
		const gradient = getGradient(type, newStops, modifier);
		const newColor = {
			...color,
			gradient,
			stops: newStops,
		};
		setColor(newColor);
		ablocksHelperOnChangeTimeoutId = setTimeout(() => {
			setActiveStopPositionValue(activeColor.loc * 100);
		}, 300);
		return () => {
			clearTimeout(ablocksHelperOnChangeTimeoutId);
		};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [activeColor.loc, needDeleteActive]);

	useEffect(() => {
		return () => {
			removeListeners();
			removeTouchListeners();
		};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	const onActiveColorStopPositionChange = (value) => {
		if (value > 100 || value < 0) {
			return false;
		}
		setActiveColor((prev) => ({
			...prev,
			loc: value / 100,
		}));
		setActiveStopPositionValue(value);
	};
	const parsedGradient = `linear-gradient(to right, ${stops
		.map((stopColor) => `${stopColor[0]} ${stopColor[1] * 100}%`)
		.join(', ')})`;

	return (
		<>
			<div className="ablocks-gradient-stops-wrapper">
				{/* eslint-disable-next-line jsx-a11y/click-events-have-key-events */}
				<div
					role="presentation"
					className="ablocks-gradient-stops"
					onClick={(e) => onAddColorStop(e)}
					ref={node}
				>
					<div
						className="gradient-stop-preview"
						style={{
							background: parsedGradient,
						}}
					/>
					<div className="gradient-stop-marker">
						{stops.map((stopColor) => {
							const position = stopColor[1] * 100;
							const rgba = stopColor[0];

							return (
								<div
									role="presentation"
									key={rgba + position + Math.random() * 100}
									className={`gradient-marker${
										hideStop &&
										activeColor.index === stopColor[2]
											? ' hide'
											: ''
									}${
										!hideStop &&
										activeColor.index === stopColor[2]
											? ' active'
											: ''
									}`}
									style={{
										left:
											Math.abs(Math.min(position, 100)) +
											'%',
										color: rgba,
									}}
									onTouchStart={(e) =>
										onTouchStart(e, stopColor)
									}
									onMouseDown={(e) =>
										onMouseDown(e, stopColor)
									}
									onClick={(e) => e.stopPropagation()}
									onDoubleClick={deleteColorStop}
									onKeyDown={() => {}}
								/>
							);
						})}
					</div>
				</div>
				{/* <button
					onClick={deleteColorStop}
					disabled={stops.length < 3}
					className="ablocks-gradient-stop-delete-icon dashicons dashicons-trash"
				></button> */}

				<Button
					onClick={deleteColorStop}
					disabled={stops.length < 3}
					icon={
						<span className="ablocks-icon ablocks-icon--delete"></span>
					}
				/>
			</div>
			<div className="ablocks-gradient-stop-custom-input-wrapper">
				<RangeControl
					className="ablocks-gradient-reversed-range-control"
					label="Location"
					value={activeStopPositionValue}
					onChange={onActiveColorStopPositionChange}
					min={0}
					max={100}
					step={1}
				/>
			</div>
		</>
	);
};

const arePropsEqual = (prevProps, nextProps) => {
	if (
		arraysEqual(prevProps.color.stops, nextProps.color.stops) &&
		prevProps.color.modifier === nextProps.color.modifier &&
		prevProps.color.type === nextProps.color.type &&
		shallowEqual(prevProps.activeColor, nextProps.activeColor)
	) {
		return true;
	}

	return false;
};

export default memo(Markers, arePropsEqual);
