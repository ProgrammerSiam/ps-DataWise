import React from 'react';
import { PanelBody } from '@wordpress/components';

/**
 * Import Css
 */
import './editor.scss';

const propTypes = {};

const defaultProps = {};

export default function ABlocksPanelBody({ title, initialOpen, children }) {
	return (
		<React.Fragment>
			<PanelBody
				title={title}
				initialOpen={initialOpen}
				className="ablocks-panel-body"
			>
				{children}
			</PanelBody>
		</React.Fragment>
	);
}

ABlocksPanelBody.propTypes = propTypes;
ABlocksPanelBody.defaultProps = defaultProps;
