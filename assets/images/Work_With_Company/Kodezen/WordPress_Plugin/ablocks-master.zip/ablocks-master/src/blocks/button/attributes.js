import globalAttributes from '@Global/AdvancedSettings/attributes';
import { getAttribute as getAlignmentAttributes } from '@Controls/alignment/helper';
import { getAttribute as getTypographyAttributes } from '@Controls/typography/helper';
import { getAttribute as getTextShadowAttributes } from '@Controls/textShadow/helper';
import { getAttribute as getDimensionsAttributes } from '@Controls/dimensions/helper';
import { getAttribute as getBorderAttributes } from '@Controls/border/helper';
import { getAttribute as iconPickerAttributes } from '@Controls/icon-upload/helper';
import { getAttribute as getLinkAttributes } from '@Controls/link-control/helper';

const attributes = {
	block_id: {
		type: 'string',
	},
	text: {
		type: 'string',
		default: 'Click here',
	},
	buttonType: {
		type: 'string',
		default: '#ddd',
	},
	buttonSize: {
		type: 'string',
		default: 'small',
	},
	textColor: {
		type: 'string',
		default: '#000000',
	},
	textColorH: {
		type: 'string',
	},
	background: {
		type: 'string',
	},
	backgroundH: {
		type: 'string',
	},
	iconPosition: {
		type: 'string',
		default: 'left',
	},
	iconSpace: {
		type: 'number',
	},
	rotation: {
		type: 'number',
	},
	...iconPickerAttributes('icon', {
		className: '',
	}),
	...getLinkAttributes('link'),
	...getAlignmentAttributes('alignment', true, {
		value: 'left',
	}),
	...getTypographyAttributes('typography', true),
	...getTextShadowAttributes('textShadow'),
	...getDimensionsAttributes('padding', true),
	...getBorderAttributes('border', true),
	...globalAttributes,
};

export default attributes;
