import React from 'react';
import { __ } from '@wordpress/i18n';
import ABlocksPanelBody from '@Components/panel-body';
import InspectorTabs from '@Components/inspector-tabs';
import ABlocksAlignmentControl from '@Controls/alignment';
import { InspectorControls } from '@wordpress/block-editor';
import ContentStyleTabs from '@Components/content-style-tabs';
import ABlocksColorControl from '@Controls/color-gradient-control';
import ABlocksIconUploader from '@Controls/icon-upload';
import ABlocksCustomSelect from '@Components/custom-select';
import ABlocksRangeControl from '@Controls/range';
import ABlocksDimensions from '@Controls/dimensions';

export const iconTypeOption = [
	{ value: 'default', label: 'Default' },
	{ value: 'stacked', label: 'Stacked' },
	{ value: 'framed', label: 'Framed' },
];

const propTypes = {};
const defaultProps = {};

export default function Settings(props) {
	const { attributes, setAttributes } = props;
	const {
		alignment,
		primaryColor,
		iconType,
		iconShape,
		padding,
		borderRadius,
		borderWidth,
		backgroundColor,
	} = attributes;
	const isIconType = iconType === 'stacked' || iconType === 'framed';

	return (
		<React.Fragment>
			<InspectorControls>
				<InspectorTabs
					attributes={attributes}
					setAttributes={setAttributes}
				>
					<ABlocksPanelBody
						title={__('Icon', 'ablocks')}
						initialOpen={true}
					>
						<ContentStyleTabs
							content={
								<>
									<ABlocksIconUploader
										label={__('Icon', 'ablocks')}
										attributes={attributes}
										setAttributes={setAttributes}
									/>
									{/* Icon type*/}
									<ABlocksCustomSelect
										label={__('View', 'ablocks')}
										attributeObjectKey="iconType"
										attributeValue={iconType || 'default'}
										options={iconTypeOption}
										changeHandler={(
											controlValue,
											attributeObjectKey
										) => {
											return setAttributes({
												[attributeObjectKey]:
													controlValue,
											});
										}}
									/>
									{isIconType && (
										<ABlocksCustomSelect
											label={__('Shape', 'ablocks')}
											attributeObjectKey="iconShape"
											attributeValue={
												iconShape || 'circle'
											}
											options={[
												{
													label: 'Circle',
													value: 'circle',
												},
												{
													label: 'Square',
													value: 'square',
												},
											]}
											changeHandler={(
												controlValue,
												attributeObjectKey
											) => {
												return setAttributes({
													[attributeObjectKey]:
														controlValue,
												});
											}}
										/>
									)}
									<ABlocksAlignmentControl
										label={__('Alignment', 'ablocks')}
										attributeName="alignment"
										attributeValue={alignment}
										setAttributes={setAttributes}
										isInline={false}
										options={[
											{
												label: 'left',
												value: 'left',
												icon: 'left',
											},
											{
												label: 'center',
												value: 'center',
												icon: 'center',
											},
											{
												label: 'right',
												value: 'right',
												icon: 'right',
											},
										]}
									/>
								</>
							}
							style={
								<>
									<ABlocksColorControl
										label={__('Primary color', 'ablocks')}
										attributeName="primaryColor"
										attributeValue={primaryColor}
										setAttributes={setAttributes}
									/>
									{isIconType && (
										<ABlocksColorControl
											label={__(
												'Background color',
												'ablocks'
											)}
											attributeName="backgroundColor"
											attributeValue={backgroundColor}
											setAttributes={setAttributes}
										/>
									)}

									{/* Icon size*/}
									<ABlocksRangeControl
										label={__('Size', 'ablocks')}
										min={0}
										max={300}
										hasUnit={false}
										isInline={false}
										isResponsive={false}
										attributeName="iconSize"
										attributeValue={attributes}
										setAttributes={setAttributes}
										attributeObjectKey="iconSize"
									/>
									{/* Icon rotate*/}
									<ABlocksRangeControl
										label={__('Rotate', 'ablocks')}
										min={0}
										max={300}
										hasUnit={false}
										isInline={false}
										isResponsive={false}
										attributeName="rotate"
										attributeValue={attributes}
										setAttributes={setAttributes}
										attributeObjectKey="rotate"
									/>
									{isIconType && (
										<>
											<ABlocksDimensions
												label={__('Padding', 'ablocks')}
												isResponsive={false}
												attributeName="padding"
												attributeValue={padding}
												setAttributes={setAttributes}
											/>

											{iconType === 'framed' && (
												<ABlocksDimensions
													label={__(
														'Border width',
														'ablocks'
													)}
													isResponsive={false}
													attributeName="borderWidth"
													attributeValue={borderWidth}
													setAttributes={
														setAttributes
													}
												/>
											)}

											<ABlocksDimensions
												label={__(
													'Border radius',
													'ablocks'
												)}
												isResponsive={true}
												attributeName="borderRadius"
												attributeValue={borderRadius}
												setAttributes={setAttributes}
											/>
										</>
									)}
								</>
							}
						/>
					</ABlocksPanelBody>
				</InspectorTabs>
			</InspectorControls>
		</React.Fragment>
	);
}

Settings.propTypes = propTypes;
Settings.defaultProps = defaultProps;
