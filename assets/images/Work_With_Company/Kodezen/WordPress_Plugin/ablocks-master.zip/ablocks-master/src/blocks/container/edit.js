import React, { useEffect } from 'react';
import Settings from './settings';
import Render from './render';
import {
	//
	getMainWrapperCss,
	getBlockContainerCSS,
	getInnerBlocksClosestParentCss,
} from './styling';
import CSSGenerator from '@Utils/css-generator';
import { useSelect } from '@wordpress/data';
import { VariationPicker } from './variationPicker';
export default function Edit(props) {
	const { isSelected, attributes, setAttributes, clientId } = props;
	const { isRootContainer, containerWidthType, className } = attributes;
	const { blockParents } = useSelect((select) => {
		const coreBlockEditor = select('core/block-editor');
		return {
			blockParents: coreBlockEditor?.getBlockParents(clientId),
		};
	});

	useEffect(() => {
		setAttributes({ block_id: clientId });
	}, [clientId, setAttributes]);

	useEffect(() => {
		if (0 === blockParents?.length) {
			setAttributes({ isRootContainer: true });
		}
	}, []); // eslint-disable-line react-hooks/exhaustive-deps

	useEffect(() => {
		const newClassList = ['ablocks-block--container-block'];

		if (isRootContainer) {
			newClassList.push('ablocks-container-block-root-container');
			if ('default' !== containerWidthType) {
				newClassList.push(containerWidthType);
			}
		}

		const newClassName = newClassList.join(' ');
		if (newClassName !== className) {
			setAttributes({ className: newClassName });
		}
	}, [containerWidthType, isRootContainer, className]); // eslint-disable-line react-hooks/exhaustive-deps

	const cssGenerator = new CSSGenerator(attributes);

	cssGenerator.addClassStyles(
		'{{WRAPPER}}.ablocks-block--container-block.ablocks-block--container-block.ablocks-block--container-block',
		getMainWrapperCss(attributes),
		getMainWrapperCss(attributes, 'Tablet'),
		getMainWrapperCss(attributes, 'Mobile')
	);

	cssGenerator.addClassStyles(
		'{{WRAPPER}} > .ablocks-block-container',
		getBlockContainerCSS(attributes),
		getBlockContainerCSS(attributes, 'Tablet'),
		getBlockContainerCSS(attributes, 'Mobile')
	);

	cssGenerator.addClassStyles(
		'{{WRAPPER}} > .ablocks-block-container > .ablocks-container-block-wrapper > .block-editor-inner-blocks > .block-editor-block-list__layout',
		getInnerBlocksClosestParentCss(attributes),
		getInnerBlocksClosestParentCss(attributes, 'Tablet'),
		getInnerBlocksClosestParentCss(attributes, 'Mobile')
	);

	const generatedCSS = cssGenerator.generateCSS();

	if (attributes.variationSelected && 0 === blockParents.length) {
		return <VariationPicker {...props} />;
	}
	return (
		<>
			<style>{generatedCSS}</style>
			{isSelected && <Settings {...props} />}
			<Render {...props} />
		</>
	);
}
