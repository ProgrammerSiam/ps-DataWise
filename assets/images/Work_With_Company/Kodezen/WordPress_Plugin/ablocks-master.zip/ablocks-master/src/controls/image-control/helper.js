export const typeOptions = [
	{ label: 'None', value: 'none' },
	{ label: 'Color', value: 'color' },
	{ label: 'Image', value: 'image' },
	{ label: 'Video', value: 'video' },
];

export const imageSizeOptions = [
	{ label: 'Default', value: 'default' },
	{ label: 'Full', value: '100%' },
	{ label: 'Large', value: '1024px' },
	{ label: 'Medium', value: '300px' },
	{ label: 'Thumbnail', value: '150px' },
];

export const imagePositions = [
	{ label: 'Default', value: 'default' },
	{ label: 'Center', value: 'center' },
	{ label: 'Center Left', value: 'center left' },
	{ label: 'Center Right', value: 'center right' },
	{ label: 'Top Center', value: 'top center' },
	{ label: 'Top Left', value: 'top left' },
	{ label: 'Top Right', value: 'top right' },
	{ label: 'Bottom center', value: 'bottom center' },
	{ label: 'Bottom left', value: 'bottom left' },
	{ label: 'Bottom Right', value: 'bottom right' },
	{ label: 'Custom', value: 'custom' },
];

export const imageAttachment = [
	{ label: 'Default', value: 'default' },
	{ label: 'Scroll', value: 'scroll' },
	{ label: 'Fixed', value: 'fixed' },
];

export const imageRepeatOptions = [
	{ label: 'Default', value: 'default' },
	{ label: 'No repeat', value: 'no-repeat' },
	{ label: 'Repeat', value: 'repeat' },
	{ label: 'Repeat x', value: 'repeat-x' },
	{ label: 'Repeat y', value: 'repeat-y' },
];

export const displaySizeOptions = [
	{ label: 'Default', value: 'default' },
	{ label: 'Auto', value: 'auto' },
	{ label: 'Cover', value: 'cover' },
	{ label: 'Contain', value: 'contain' },
	{ label: 'Custom', value: 'custom' },
];

export const unitOptions = [
	{ value: 'px', label: 'px' },
	{ value: '%', label: '%' },
	{ value: 'rem', label: 'rem' },
	{ value: 'em', label: 'em' },
];
