import React from 'react';
import SaveContainer from '@Components/block-container/save';
import metadata from './block.json';

const propTypes = {};

const defaultProps = {};

export default function Save(props) {
	const { attributes } = props;
	const { block_id } = attributes;
	return (
		<React.Fragment>
			<SaveContainer
				blockId={block_id}
				name={metadata.name}
				attributes={attributes}
			>
				<div className="ablocks-spacer__box"></div>
			</SaveContainer>
		</React.Fragment>
	);
}

Save.propTypes = propTypes;
Save.defaultProps = defaultProps;
