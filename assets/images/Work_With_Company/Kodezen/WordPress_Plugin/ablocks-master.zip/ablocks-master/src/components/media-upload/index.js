import './styles.scss';
import { __ } from '@wordpress/i18n';
import Button from '@Components/Button';
import { MediaUpload } from '@wordpress/block-editor';
import { plugin_root_url as PluginURL } from '@Utils/helper';

export default function MediaUploadField(props) {
	const {
		attributeValue,
		attributeName,
		onSelectImageHandler,
		onRemoveImageHandler,
		deviceType = '',
	} = props;

	let imageUploaderAndPreview;
	const imageAttributeValue =
		attributeValue[attributeName + deviceType] ||
		attributeValue[attributeName];

	const imageSource =
		attributeValue[attributeName + deviceType] ||
		(deviceType === 'Mobile'
			? attributeValue[attributeName + 'Mobile'] ||
			  attributeValue[attributeName + 'Tablet'] ||
			  attributeValue[attributeName]
			: attributeValue[attributeName]);

	const replaceImage = (
		<>
			<MediaUpload
				allowedTypes={['image']}
				value={null}
				onSelect={(mediaValue) => {
					onSelectImageHandler(mediaValue, deviceType);
				}}
				render={({ open }) => (
					<div className="ablocks-background-image--upload__replace">
						<Button
							onClick={open}
							label={__('Replace Image', 'ablocks')}
							isShowPrimaryLabel
						/>
					</div>
				)}
			/>
			<div className="ablocks-delete-icon-wrapper">
				<Button
					onClick={() => onRemoveImageHandler()}
					icon={
						<span className="ablocks-icon ablocks-icon--delete"></span>
					}
				/>
			</div>
		</>
	);

	if (imageAttributeValue) {
		imageUploaderAndPreview = (
			<div className="ablocks-image-wrapper">
				<img
					src={imageSource}
					alt="Preview"
					className="ablocks-image"
				/>
				{replaceImage}
			</div>
		);
	} else {
		imageUploaderAndPreview = (
			<MediaUpload
				allowedTypes={['image']}
				value={attributeName + deviceType}
				onSelect={(mediaValue) => {
					onSelectImageHandler(mediaValue, deviceType);
				}}
				render={({ open }) => (
					<div className="ablocks-placeholder-image-wrapper">
						<img
							className="ablocks-placeholder-image"
							src={
								PluginURL +
								'/assets/images/placeholder-image.svg'
							}
							alt=""
						/>
						<div className="ablocks-background-image--upload__replace">
							<Button
								onClick={open}
								label={__('Choose Image…', 'ablocks')}
								isShowPrimaryLabel
							/>
						</div>
					</div>
				)}
			/>
		);
	}

	return imageUploaderAndPreview;
}
