import React from 'react';
import { __ } from '@wordpress/i18n';
import ABlocksRangeControl from '@Controls/range';

export default function BackgroundOverLayCSSFilter(props) {
	const { hover } = props;
	return (
		<React.Fragment>
			<ABlocksRangeControl
				{...props}
				min={0}
				max={5}
				step={0.01}
				hasUnit={false}
				isInline={false}
				label={__('Blur', 'ablocks')}
				attributeObjectKey={hover ? 'blurH' : 'blur'}
			/>
			<ABlocksRangeControl
				{...props}
				min={0}
				max={200}
				step={1}
				hasUnit={false}
				isInline={false}
				label={__('Brightness', 'ablocks')}
				attributeObjectKey={hover ? 'brightnessH' : 'brightness'}
			/>

			<ABlocksRangeControl
				{...props}
				min={0}
				max={200}
				step={1}
				hasUnit={false}
				isInline={false}
				label={__('Contrast', 'ablocks')}
				attributeObjectKey={hover ? 'contrastH' : 'contrast'}
			/>

			<ABlocksRangeControl
				{...props}
				min={0}
				max={200}
				step={1}
				hasUnit={false}
				isInline={false}
				label={__('Saturate', 'ablocks')}
				attributeObjectKey={hover ? 'saturateH' : 'saturate'}
			/>

			<ABlocksRangeControl
				{...props}
				min={0}
				max={360}
				step={1}
				hasUnit={false}
				isInline={false}
				label={__('Hue', 'ablocks')}
				attributeObjectKey={hover ? 'hueH' : 'hue'}
			/>
		</React.Fragment>
	);
}
