export { default as getGradient } from './getGradient';
export { default as parseGradient } from './parseGradient';
