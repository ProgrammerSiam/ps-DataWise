import ABlocksToggleControl from '@Controls/toggleButton';
import { __ } from '@wordpress/i18n';
import '../../options/styles.scss';

export default function ABlocksVideoOptions(props) {
	const { onChangeHandler, isBackgroundControl } = props;

	const commonProps = {
		...props,
	};

	if (isBackgroundControl) {
		return (
			<>
				<div className="ablocks-control--background__video--options">
					<p>{__('Play once', 'ablocks')}</p>
					<ABlocksToggleControl
						{...commonProps}
						onChangeHandler={onChangeHandler}
						attributeObjectKey="videoPlayOnce"
					/>
				</div>
				{/* <div>
					<p>{__('Play on mobile ', 'ablocks')}</p>
					<ABlocksToggleControl
						{...commonProps}
						onChangeHandler={onChangeHandler}
						attributeObjectKey="playOnMobile"
					/>
				</div> */}
				<div className="ablocks-control--background__video--options">
					<p>{__('Privacy mode', 'ablocks')}</p>
					<ABlocksToggleControl
						{...commonProps}
						onChangeHandler={onChangeHandler}
						attributeObjectKey="videoPrivacyMode"
					/>
				</div>
			</>
		);
	}

	return (
		<>
			<div>
				<p>{__('Autoplay', 'ablocks')}</p>
				<ABlocksToggleControl
					{...commonProps}
					onChangeHandler={onChangeHandler}
					attributeObjectKey="videoAutoPlay"
				/>
			</div>
			<div>
				<p>{__('Mute', 'ablocks')}</p>
				<ABlocksToggleControl
					{...commonProps}
					onChangeHandler={onChangeHandler}
					attributeObjectKey="videoMute"
				/>
			</div>
			<div>
				<p>{__('Loop', 'ablocks')}</p>
				<ABlocksToggleControl
					{...commonProps}
					onChangeHandler={onChangeHandler}
					attributeObjectKey="videoLoop"
				/>
			</div>
			<div>
				<p>{__('Player controls', 'ablocks')}</p>
				<ABlocksToggleControl
					{...commonProps}
					onChangeHandler={onChangeHandler}
					attributeObjectKey="videoPlayerControls"
				/>
			</div>
			<div>
				<p>{__('Download button', 'ablocks')}</p>
				<ABlocksToggleControl
					{...commonProps}
					onChangeHandler={onChangeHandler}
					attributeObjectKey="videoDownloadButton"
				/>
			</div>
		</>
	);
}
