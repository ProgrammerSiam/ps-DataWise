import { useEffect } from '@wordpress/element';
import GradientPicker from './gradientPicker';

const ActiveTabTypeWrapper = ({ setActiveTab, children, type }) => {
	useEffect(() => {
		setActiveTab(type);
	}, [type]); // eslint-disable-line react-hooks/exhaustive-deps
	return <>{children}</>;
};

const TabTitle = ({ type = 'solid' }) => {
	return (
		<div
			className={`ablocks-control-color-gradient-tabpanel-tab-title ablocks-control-color-gradient-tabpanel-tab-title--${type}`}
		>
			<span className="ablocks-tab-span-circle"></span>
		</div>
	);
};

export const setTabsForColorGradientTabpanel = ({
	setActiveTab,
	solidPicker,
	value,
	onChange,
	setTabs,
}) => {
	const gcTabs = [
		{
			name: 'solid',
			render: (
				<ActiveTabTypeWrapper type="solid" setActiveTab={setActiveTab}>
					{solidPicker}
				</ActiveTabTypeWrapper>
			),
			title: <TabTitle type="solid" />,
		},
		{
			name: 'linear-gradient',
			render: (
				<ActiveTabTypeWrapper
					type="linear-gradient"
					setActiveTab={setActiveTab}
				>
					<GradientPicker
						value={value}
						onChange={onChange}
						type={'linear-gradient'}
					/>
				</ActiveTabTypeWrapper>
			),
			title: <TabTitle type="linear-gradient" />,
		},
		{
			name: 'radial-gradient',
			render: (
				<ActiveTabTypeWrapper
					type="radial-gradient"
					setActiveTab={setActiveTab}
				>
					<GradientPicker
						value={value}
						onChange={onChange}
						type={'radial-gradient'}
					/>
				</ActiveTabTypeWrapper>
			),
			title: <TabTitle type="radial-gradient" />,
		},
	];
	setTabs(gcTabs);
};
