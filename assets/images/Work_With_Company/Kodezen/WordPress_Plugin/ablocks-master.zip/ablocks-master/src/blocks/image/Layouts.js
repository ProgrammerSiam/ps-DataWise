import React, { useRef } from 'react';
import { __ } from '@wordpress/i18n';
import Image from './Image';
import { RichText } from '@wordpress/block-editor';

const propTypes = {};
const defaultProps = {};

export default function Layouts(props) {
	const ref = useRef();
	const { setAttributes, attributes, addCaptionRef } = props;
	const {
		imgUrl,
		caption,
		imgCaption,
		imgLink: { linkDestination, href, linkTarget },
	} = attributes;

	const changeHandler = (newValue, attributeName) => {
		return setAttributes({
			[attributeName]: newValue,
		});
	};

	const handlePreventLink = (event) => {
		event.preventDefault();
	};

	let layout;

	if (imgUrl) {
		layout = <Image {...props} containerRef={ref} />;
	}
	if (imgUrl && linkDestination === 'custom') {
		layout = (
			<a href={href} target={linkTarget} onClick={handlePreventLink}>
				<Image {...props} containerRef={ref} />
			</a>
		);
	}
	if (imgUrl && imgCaption) {
		layout = (
			<>
				<Image {...props} containerRef={ref} />
				<RichText
					tagName="figcaption"
					className="ablocks-image-caption"
					aria-label={__('Image caption text', 'ablocks')}
					placeholder={__('Add caption', 'ablocks')}
					value={caption}
					ref={addCaptionRef}
					onChange={(value) => changeHandler(value, 'caption')}
				/>
			</>
		);
	}
	if (imgUrl && imgCaption && linkDestination === 'custom') {
		layout = (
			<a href={href} target={linkTarget} onClick={handlePreventLink}>
				<Image {...props} containerRef={ref} />
				<RichText
					tagName="figcaption"
					className="ablocks-image-caption"
					aria-label={__('Image caption text', 'ablocks')}
					placeholder={__('Add caption', 'ablocks')}
					value={caption}
					onChange={(value) => changeHandler(value, 'caption')}
				/>
			</a>
		);
	}

	return (
		<figure className="ablocks-image-figure" ref={ref}>
			{layout}
		</figure>
	);
}

Layouts.propTypes = propTypes;
Layouts.defaultProps = defaultProps;
