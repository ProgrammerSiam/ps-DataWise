import { __ } from '@wordpress/i18n';

export const normalFonts = [
	{
		value: 'Default',
		label: __('Default', 'ablocks'),
		weight: [
			'Default',
			'100',
			'200',
			'300',
			'400',
			'500',
			'600',
			'700',
			'800',
			'900',
		],
		google: false,
	},
	{
		value: 'Arial',
		label: 'Arial',
		weight: [
			'Default',
			'100',
			'200',
			'300',
			'400',
			'500',
			'600',
			'700',
			'800',
			'900',
		],
		google: false,
	},
	{
		value: 'Helvetica',
		label: 'Helvetica',
		weight: [
			'Default',
			'100',
			'200',
			'300',
			'400',
			'500',
			'600',
			'700',
			'800',
			'900',
		],
		google: false,
	},
	{
		value: 'Times New Roman',
		label: 'Times New Roman',
		weight: [
			'Default',
			'100',
			'200',
			'300',
			'400',
			'500',
			'600',
			'700',
			'800',
			'900',
		],
		google: false,
	},
	{
		value: 'Georgia',
		label: 'Georgia',
		weight: [
			'Default',
			'100',
			'200',
			'300',
			'400',
			'500',
			'600',
			'700',
			'800',
			'900',
		],
		google: false,
	},
];

export const googleFontsAll = {
	fontVariants: {
		Roboto: {
			variants: ['100', '300', '400', '500', '700', '900'],
		},
		'Open Sans': {
			variants: ['300', '400', '500', '600', '700', '800'],
		},
		'Noto Sans JP': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Montserrat: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Lato: {
			variants: ['100', '300', '400', '700', '900'],
		},
		Poppins: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Roboto Condensed': {
			variants: ['300', '400', '700'],
		},
		'Material Icons': {
			variants: ['400'],
		},
		Inter: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Roboto Mono': {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		Oswald: {
			variants: ['200', '300', '400', '500', '600', '700'],
		},
		Raleway: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Noto Sans': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Nunito Sans': {
			variants: ['200', '300', '400', '500', '600', '700', '800', '900'],
		},
		'Roboto Slab': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Ubuntu: {
			variants: ['300', '400', '500', '700'],
		},
		Nunito: {
			variants: ['200', '300', '400', '500', '600', '700', '800', '900'],
		},
		'Playfair Display': {
			variants: ['400', '500', '600', '700', '800', '900'],
		},
		Merriweather: {
			variants: ['300', '400', '700', '900'],
		},
		Rubik: {
			variants: ['300', '400', '500', '600', '700', '800', '900'],
		},
		'PT Sans': {
			variants: ['400', '700'],
		},
		'Noto Sans KR': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Kanit: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Work Sans': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Lora: {
			variants: ['400', '500', '600', '700'],
		},
		Mukta: {
			variants: ['200', '300', '400', '500', '600', '700', '800'],
		},
		'Noto Sans TC': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Fira Sans': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Quicksand: {
			variants: ['300', '400', '500', '600', '700'],
		},
		Barlow: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'DM Sans': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Mulish: {
			variants: ['200', '300', '400', '500', '600', '700', '800', '900'],
		},
		Heebo: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'IBM Plex Sans': {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		Inconsolata: {
			variants: ['200', '300', '400', '500', '600', '700', '800', '900'],
		},
		'PT Serif': {
			variants: ['400', '700'],
		},
		'Titillium Web': {
			variants: ['200', '300', '400', '600', '700', '900'],
		},
		'Noto Serif': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Manrope: {
			variants: ['200', '300', '400', '500', '600', '700', '800'],
		},
		'Libre Franklin': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Karla: {
			variants: ['200', '300', '400', '500', '600', '700', '800'],
		},
		'Hind Siliguri': {
			variants: ['300', '400', '500', '600', '700'],
		},
		'Nanum Gothic': {
			variants: ['400', '700', '800'],
		},
		'Josefin Sans': {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		'Material Icons Outlined': {
			variants: ['400'],
		},
		'Noto Color Emoji': {
			variants: ['400'],
		},
		Arimo: {
			variants: ['400', '500', '600', '700'],
		},
		'Libre Baskerville': {
			variants: ['400', '700'],
		},
		Dosis: {
			variants: ['200', '300', '400', '500', '600', '700', '800'],
		},
		'PT Sans Narrow': {
			variants: ['400', '700'],
		},
		'Bebas Neue': {
			variants: ['400'],
		},
		Oxygen: {
			variants: ['300', '400', '700'],
		},
		Bitter: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Cabin: {
			variants: ['400', '500', '600', '700'],
		},
		'Material Symbols Outlined': {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		Abel: {
			variants: ['400'],
		},
		'Dancing Script': {
			variants: ['400', '500', '600', '700'],
		},
		Anton: {
			variants: ['400'],
		},
		'Source Code Pro': {
			variants: ['200', '300', '400', '500', '600', '700', '800', '900'],
		},
		Cairo: {
			variants: ['200', '300', '400', '500', '600', '700', '800', '900'],
		},
		'Maven Pro': {
			variants: ['400', '500', '600', '700', '800', '900'],
		},
		'EB Garamond': {
			variants: ['400', '500', '600', '700', '800'],
		},
		Hind: {
			variants: ['300', '400', '500', '600', '700'],
		},
		Assistant: {
			variants: ['200', '300', '400', '500', '600', '700', '800'],
		},
		'Noto Sans SC': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Barlow Condensed': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Jost: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Rajdhani: {
			variants: ['300', '400', '500', '600', '700'],
		},
		Pacifico: {
			variants: ['400'],
		},
		'Noto Serif JP': {
			variants: ['200', '300', '400', '500', '600', '700', '900'],
		},
		Prompt: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Exo 2': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Crimson Text': {
			variants: ['400', '600', '700'],
		},
		Lobster: {
			variants: ['400'],
		},
		'Space Grotesk': {
			variants: ['300', '400', '500', '600', '700'],
		},
		Teko: {
			variants: ['300', '400', '500', '600', '700'],
		},
		'Signika Negative': {
			variants: ['300', '400', '500', '600', '700'],
		},
		'Fjalla One': {
			variants: ['400'],
		},
		'Public Sans': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Material Icons Round': {
			variants: ['400'],
		},
		Archivo: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Comfortaa: {
			variants: ['300', '400', '500', '600', '700'],
		},
		'Varela Round': {
			variants: ['400'],
		},
		Arvo: {
			variants: ['400', '700'],
		},
		'Slabo 27px': {
			variants: ['400'],
		},
		Overpass: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'M PLUS Rounded 1c': {
			variants: ['100', '300', '400', '500', '700', '800', '900'],
		},
		'IBM Plex Mono': {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		Caveat: {
			variants: ['400', '500', '600', '700'],
		},
		'Abril Fatface': {
			variants: ['400'],
		},
		Outfit: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Cormorant Garamond': {
			variants: ['300', '400', '500', '600', '700'],
		},
		'Merriweather Sans': {
			variants: ['300', '400', '500', '600', '700', '800'],
		},
		'Shadows Into Light': {
			variants: ['400'],
		},
		Asap: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Fira Sans Condensed': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Tajawal: {
			variants: ['200', '300', '400', '500', '700', '800', '900'],
		},
		'Noto Sans Arabic': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Material Icons Sharp': {
			variants: ['400'],
		},
		'Asap Condensed': {
			variants: ['200', '300', '400', '500', '600', '700', '800', '900'],
		},
		'Red Hat Display': {
			variants: ['300', '400', '500', '600', '700', '800', '900'],
		},
		Play: {
			variants: ['400', '700'],
		},
		'Indie Flower': {
			variants: ['400'],
		},
		'Hind Madurai': {
			variants: ['300', '400', '500', '600', '700'],
		},
		Satisfy: {
			variants: ['400'],
		},
		Catamaran: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Zilla Slab': {
			variants: ['300', '400', '500', '600', '700'],
		},
		'Nanum Myeongjo': {
			variants: ['400', '700', '800'],
		},
		'Archivo Black': {
			variants: ['400'],
		},
		'Chakra Petch': {
			variants: ['300', '400', '500', '600', '700'],
		},
		'Material Icons Two Tone': {
			variants: ['400'],
		},
		'Saira Condensed': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Barlow Semi Condensed': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Noto Sans HK': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Signika: {
			variants: ['300', '400', '500', '600', '700'],
		},
		Questrial: {
			variants: ['400'],
		},
		Almarai: {
			variants: ['300', '400', '700', '800'],
		},
		'Yanone Kaffeesatz': {
			variants: ['200', '300', '400', '500', '600', '700'],
		},
		Vollkorn: {
			variants: ['400', '500', '600', '700', '800', '900'],
		},
		'IBM Plex Sans Arabic': {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		'Frank Ruhl Libre': {
			variants: ['300', '400', '500', '600', '700', '800', '900'],
		},
		'IBM Plex Serif': {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		'M PLUS 1p': {
			variants: ['100', '300', '400', '500', '700', '800', '900'],
		},
		Domine: {
			variants: ['400', '500', '600', '700'],
		},
		'Lilita One': {
			variants: ['400'],
		},
		Sarabun: {
			variants: ['100', '200', '300', '400', '500', '600', '700', '800'],
		},
		Acme: {
			variants: ['400'],
		},
		Alegreya: {
			variants: ['400', '500', '600', '700', '800', '900'],
		},
		'Noto Kufi Arabic': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Plus Jakarta Sans': {
			variants: ['200', '300', '400', '500', '600', '700', '800'],
		},
		'Russo One': {
			variants: ['400'],
		},
		'Didact Gothic': {
			variants: ['400'],
		},
		Exo: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Archivo Narrow': {
			variants: ['400', '500', '600', '700'],
		},
		'Amatic SC': {
			variants: ['400', '700'],
		},
		'Permanent Marker': {
			variants: ['400'],
		},
		'Bree Serif': {
			variants: ['400'],
		},
		Rowdies: {
			variants: ['300', '400', '700'],
		},
		Cinzel: {
			variants: ['400', '500', '600', '700', '800', '900'],
		},
		'DM Serif Display': {
			variants: ['400'],
		},
		'Alegreya Sans': {
			variants: ['100', '300', '400', '500', '700', '800', '900'],
		},
		ABeeZee: {
			variants: ['400'],
		},
		'Alfa Slab One': {
			variants: ['400'],
		},
		Orbitron: {
			variants: ['400', '500', '600', '700', '800', '900'],
		},
		Righteous: {
			variants: ['400'],
		},
		'Source Serif 4': {
			variants: ['200', '300', '400', '500', '600', '700', '800', '900'],
		},
		Urbanist: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Lexend: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Chivo: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Sora: {
			variants: ['100', '200', '300', '400', '500', '600', '700', '800'],
		},
		Courgette: {
			variants: ['400'],
		},
		'Montserrat Alternates': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Kalam: {
			variants: ['300', '400', '700'],
		},
		'Great Vibes': {
			variants: ['400'],
		},
		Yantramanav: {
			variants: ['100', '300', '400', '500', '700', '900'],
		},
		Tinos: {
			variants: ['400', '700'],
		},
		Figtree: {
			variants: ['300', '400', '500', '600', '700', '800', '900'],
		},
		Martel: {
			variants: ['200', '300', '400', '600', '700', '800', '900'],
		},
		'Material Symbols Rounded': {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		Cantarell: {
			variants: ['400', '700'],
		},
		'Noticia Text': {
			variants: ['400', '700'],
		},
		'Lobster Two': {
			variants: ['400', '700'],
		},
		Zeyada: {
			variants: ['400'],
		},
		Neuton: {
			variants: ['200', '300', '400', '700', '800'],
		},
		Amiri: {
			variants: ['400', '700'],
		},
		Cardo: {
			variants: ['400', '700'],
		},
		Changa: {
			variants: ['200', '300', '400', '500', '600', '700', '800'],
		},
		'Noto Serif TC': {
			variants: ['200', '300', '400', '500', '600', '700', '900'],
		},
		Spectral: {
			variants: ['200', '300', '400', '500', '600', '700', '800'],
		},
		'PT Sans Caption': {
			variants: ['400', '700'],
		},
		'Space Mono': {
			variants: ['400', '700'],
		},
		Cormorant: {
			variants: ['300', '400', '500', '600', '700'],
		},
		Philosopher: {
			variants: ['400', '700'],
		},
		'Source Sans 3': {
			variants: ['200', '300', '400', '500', '600', '700', '800', '900'],
		},
		'Patua One': {
			variants: ['400'],
		},
		'Crete Round': {
			variants: ['400'],
		},
		'Ubuntu Condensed': {
			variants: ['400'],
		},
		Prata: {
			variants: ['400'],
		},
		'Passion One': {
			variants: ['400', '700', '900'],
		},
		'Roboto Flex': {
			variants: ['400'],
		},
		Marcellus: {
			variants: ['400'],
		},
		'Encode Sans': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Sawarabi Mincho': {
			variants: ['400'],
		},
		'Kaushan Script': {
			variants: ['400'],
		},
		'Pathway Gothic One': {
			variants: ['400'],
		},
		'Francois One': {
			variants: ['400'],
		},
		Sacramento: {
			variants: ['400'],
		},
		'Noto Serif KR': {
			variants: ['200', '300', '400', '500', '600', '700', '900'],
		},
		Alice: {
			variants: ['400'],
		},
		'Bodoni Moda': {
			variants: ['400', '500', '600', '700', '800', '900'],
		},
		Arsenal: {
			variants: ['400', '700'],
		},
		Alata: {
			variants: ['400'],
		},
		'Gloria Hallelujah': {
			variants: ['400'],
		},
		'El Messiri': {
			variants: ['400', '500', '600', '700'],
		},
		'Noto Sans Display': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Old Standard TT': {
			variants: ['400', '700'],
		},
		Gruppo: {
			variants: ['400'],
		},
		'Concert One': {
			variants: ['400'],
		},
		'Architects Daughter': {
			variants: ['400'],
		},
		'Fira Sans Extra Condensed': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Sanchez: {
			variants: ['400'],
		},
		'Sawarabi Gothic': {
			variants: ['400'],
		},
		Yellowtail: {
			variants: ['400'],
		},
		Khand: {
			variants: ['300', '400', '500', '600', '700'],
		},
		'Crimson Pro': {
			variants: ['200', '300', '400', '500', '600', '700', '800', '900'],
		},
		Cookie: {
			variants: ['400'],
		},
		'Gothic A1': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Rokkitt: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Sen: {
			variants: ['400', '500', '600', '700', '800'],
		},
		'Secular One': {
			variants: ['400'],
		},
		'Press Start 2P': {
			variants: ['400'],
		},
		'Quattrocento Sans': {
			variants: ['400', '700'],
		},
		'Josefin Slab': {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		'Ubuntu Mono': {
			variants: ['400', '700'],
		},
		'Paytone One': {
			variants: ['400'],
		},
		'Alegreya Sans SC': {
			variants: ['100', '300', '400', '500', '700', '800', '900'],
		},
		'IBM Plex Sans Condensed': {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		'Lexend Deca': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Gelasio: {
			variants: ['400', '500', '600', '700'],
		},
		Commissioner: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Handlee: {
			variants: ['400'],
		},
		'Antic Slab': {
			variants: ['400'],
		},
		Aleo: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Unna: {
			variants: ['400', '700'],
		},
		'Advent Pro': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Poiret One': {
			variants: ['400'],
		},
		Staatliches: {
			variants: ['400'],
		},
		Mate: {
			variants: ['400'],
		},
		'Readex Pro': {
			variants: ['200', '300', '400', '500', '600', '700'],
		},
		'Yeseva One': {
			variants: ['400'],
		},
		'Luckiest Guy': {
			variants: ['400'],
		},
		'Noto Sans Thai': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Quattrocento: {
			variants: ['400', '700'],
		},
		'Tenor Sans': {
			variants: ['400'],
		},
		Tangerine: {
			variants: ['400', '700'],
		},
		Saira: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Cuprum: {
			variants: ['400', '500', '600', '700'],
		},
		'Baloo 2': {
			variants: ['400', '500', '600', '700', '800'],
		},
		'Encode Sans Condensed': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Titan One': {
			variants: ['400'],
		},
		'Noto Naskh Arabic': {
			variants: ['400', '500', '600', '700'],
		},
		'Special Elite': {
			variants: ['400'],
		},
		'Rubik Mono One': {
			variants: ['400'],
		},
		Vidaloka: {
			variants: ['400'],
		},
		'News Cycle': {
			variants: ['400', '700'],
		},
		Literata: {
			variants: ['200', '300', '400', '500', '600', '700', '800', '900'],
		},
		'Yatra One': {
			variants: ['400'],
		},
		'Mate SC': {
			variants: ['400'],
		},
		Faustina: {
			variants: ['300', '400', '500', '600', '700', '800'],
		},
		Allura: {
			variants: ['400'],
		},
		'Roboto Serif': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Bangers: {
			variants: ['400'],
		},
		Caladea: {
			variants: ['400', '700'],
		},
		'Playfair Display SC': {
			variants: ['400', '700', '900'],
		},
		'Mukta Malar': {
			variants: ['200', '300', '400', '500', '600', '700', '800'],
		},
		Itim: {
			variants: ['400'],
		},
		'Carter One': {
			variants: ['400'],
		},
		'Comic Neue': {
			variants: ['300', '400', '700'],
		},
		'Libre Caslon Text': {
			variants: ['400', '700'],
		},
		Mitr: {
			variants: ['200', '300', '400', '500', '600', '700'],
		},
		Eczar: {
			variants: ['400', '500', '600', '700', '800'],
		},
		'Patrick Hand': {
			variants: ['400'],
		},
		Bungee: {
			variants: ['400'],
		},
		'Gochi Hand': {
			variants: ['400'],
		},
		'Kosugi Maru': {
			variants: ['400'],
		},
		'Ropa Sans': {
			variants: ['400'],
		},
		Ultra: {
			variants: ['400'],
		},
		Viga: {
			variants: ['400'],
		},
		'Be Vietnam Pro': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Noto Sans Devanagari': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Inter Tight': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Unbounded: {
			variants: ['200', '300', '400', '500', '600', '700', '800', '900'],
		},
		Taviraj: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Macondo: {
			variants: ['400'],
		},
		'PT Mono': {
			variants: ['400'],
		},
		Blinker: {
			variants: ['100', '200', '300', '400', '600', '700', '800', '900'],
		},
		'Nanum Gothic Coding': {
			variants: ['400', '700'],
		},
		Antonio: {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		Neucha: {
			variants: ['400'],
		},
		'Bai Jamjuree': {
			variants: ['200', '300', '400', '500', '600', '700'],
		},
		Ruda: {
			variants: ['400', '500', '600', '700', '800', '900'],
		},
		'DM Serif Text': {
			variants: ['400'],
		},
		Gudea: {
			variants: ['400', '700'],
		},
		'Red Hat Text': {
			variants: ['300', '400', '500', '600', '700'],
		},
		'Marck Script': {
			variants: ['400'],
		},
		'Hind Vadodara': {
			variants: ['300', '400', '500', '600', '700'],
		},
		Volkhov: {
			variants: ['400', '700'],
		},
		'Hammersmith One': {
			variants: ['400'],
		},
		'League Spartan': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Parisienne: {
			variants: ['400'],
		},
		'Homemade Apple': {
			variants: ['400'],
		},
		'Mr Dafoe': {
			variants: ['400'],
		},
		Shrikhand: {
			variants: ['400'],
		},
		'Abhaya Libre': {
			variants: ['400', '500', '600', '700', '800'],
		},
		Adamina: {
			variants: ['400'],
		},
		Amaranth: {
			variants: ['400', '700'],
		},
		'Zen Kaku Gothic New': {
			variants: ['300', '400', '500', '700', '900'],
		},
		'Istok Web': {
			variants: ['400', '700'],
		},
		Cousine: {
			variants: ['400', '700'],
		},
		'Rock Salt': {
			variants: ['400'],
		},
		Playball: {
			variants: ['400'],
		},
		Merienda: {
			variants: ['300', '400', '500', '600', '700', '800', '900'],
		},
		'Courier Prime': {
			variants: ['400', '700'],
		},
		Laila: {
			variants: ['300', '400', '500', '600', '700'],
		},
		'Noto Serif SC': {
			variants: ['200', '300', '400', '500', '600', '700', '900'],
		},
		'Alex Brush': {
			variants: ['400'],
		},
		Epilogue: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Nanum Pen Script': {
			variants: ['400'],
		},
		'Saira Semi Condensed': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Creepster: {
			variants: ['400'],
		},
		Calistoga: {
			variants: ['400'],
		},
		Petrona: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Monoton: {
			variants: ['400'],
		},
		Electrolize: {
			variants: ['400'],
		},
		'Bad Script': {
			variants: ['400'],
		},
		Pridi: {
			variants: ['200', '300', '400', '500', '600', '700'],
		},
		'Unica One': {
			variants: ['400'],
		},
		Lalezar: {
			variants: ['400'],
		},
		Mada: {
			variants: ['200', '300', '400', '500', '600', '700', '800', '900'],
		},
		Castoro: {
			variants: ['400'],
		},
		Voltaire: {
			variants: ['400'],
		},
		'BIZ UDPGothic': {
			variants: ['400', '700'],
		},
		'Zen Maru Gothic': {
			variants: ['300', '400', '500', '700', '900'],
		},
		Niramit: {
			variants: ['200', '300', '400', '500', '600', '700'],
		},
		Lusitana: {
			variants: ['400', '700'],
		},
		'Share Tech Mono': {
			variants: ['400'],
		},
		Pangolin: {
			variants: ['400'],
		},
		Monda: {
			variants: ['400', '700'],
		},
		Audiowide: {
			variants: ['400'],
		},
		'Anonymous Pro': {
			variants: ['400', '700'],
		},
		Sriracha: {
			variants: ['400'],
		},
		'Noto Serif Bengali': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Pragati Narrow': {
			variants: ['400', '700'],
		},
		Jura: {
			variants: ['300', '400', '500', '600', '700'],
		},
		'Fira Mono': {
			variants: ['400', '500', '700'],
		},
		'Oleo Script': {
			variants: ['400', '700'],
		},
		'Cabin Condensed': {
			variants: ['400', '500', '600', '700'],
		},
		'Black Ops One': {
			variants: ['400'],
		},
		'Fugaz One': {
			variants: ['400'],
		},
		BenchNine: {
			variants: ['300', '400', '700'],
		},
		'Kumbh Sans': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Noto Sans Malayalam': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Londrina Solid': {
			variants: ['100', '300', '400', '900'],
		},
		Varela: {
			variants: ['400'],
		},
		'Reem Kufi': {
			variants: ['400', '500', '600', '700'],
		},
		'Big Shoulders Display': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Mandali: {
			variants: ['400'],
		},
		'Shippori Mincho': {
			variants: ['400', '500', '600', '700', '800'],
		},
		'Julius Sans One': {
			variants: ['400'],
		},
		Jaldi: {
			variants: ['400', '700'],
		},
		'Martel Sans': {
			variants: ['200', '300', '400', '600', '700', '800', '900'],
		},
		Sansita: {
			variants: ['400', '700', '800', '900'],
		},
		Actor: {
			variants: ['400'],
		},
		Khula: {
			variants: ['300', '400', '600', '700', '800'],
		},
		'Noto Sans Tamil': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Black Han Sans': {
			variants: ['400'],
		},
		'Squada One': {
			variants: ['400'],
		},
		'Albert Sans': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Nothing You Could Do': {
			variants: ['400'],
		},
		Economica: {
			variants: ['400', '700'],
		},
		Sarala: {
			variants: ['400', '700'],
		},
		Damion: {
			variants: ['400'],
		},
		Baskervville: {
			variants: ['400'],
		},
		Italianno: {
			variants: ['400'],
		},
		'Pontano Sans': {
			variants: ['300', '400', '500', '600', '700'],
		},
		Rufina: {
			variants: ['400', '700'],
		},
		Forum: {
			variants: ['400'],
		},
		'Reenie Beanie': {
			variants: ['400'],
		},
		Alef: {
			variants: ['400', '700'],
		},
		Alatsi: {
			variants: ['400'],
		},
		Koulen: {
			variants: ['400'],
		},
		'Sorts Mill Goudy': {
			variants: ['400'],
		},
		Newsreader: {
			variants: ['200', '300', '400', '500', '600', '700', '800'],
		},
		Athiti: {
			variants: ['200', '300', '400', '500', '600', '700'],
		},
		'Gilda Display': {
			variants: ['400'],
		},
		'Libre Barcode 39': {
			variants: ['400'],
		},
		'Six Caps': {
			variants: ['400'],
		},
		Quantico: {
			variants: ['400', '700'],
		},
		Krub: {
			variants: ['200', '300', '400', '500', '600', '700'],
		},
		'Leckerli One': {
			variants: ['400'],
		},
		Syne: {
			variants: ['400', '500', '600', '700', '800'],
		},
		Sintony: {
			variants: ['400', '700'],
		},
		Glegoo: {
			variants: ['400', '700'],
		},
		'Pinyon Script': {
			variants: ['400'],
		},
		'Cutive Mono': {
			variants: ['400'],
		},
		VT323: {
			variants: ['400'],
		},
		Palanquin: {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		'Holtwood One SC': {
			variants: ['400'],
		},
		Antic: {
			variants: ['400'],
		},
		Armata: {
			variants: ['400'],
		},
		Karma: {
			variants: ['300', '400', '500', '600', '700'],
		},
		'DM Mono': {
			variants: ['300', '400', '500'],
		},
		'Days One': {
			variants: ['400'],
		},
		Fraunces: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Aclonica: {
			variants: ['400'],
		},
		Chewy: {
			variants: ['400'],
		},
		Ramabhadra: {
			variants: ['400'],
		},
		Lemonada: {
			variants: ['300', '400', '500', '600', '700'],
		},
		Basic: {
			variants: ['400'],
		},
		'Noto Sans Mono': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Arapey: {
			variants: ['400'],
		},
		'Saira Extra Condensed': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Hind Guntur': {
			variants: ['300', '400', '500', '600', '700'],
		},
		'STIX Two Text': {
			variants: ['400', '500', '600', '700'],
		},
		'Markazi Text': {
			variants: ['400', '500', '600', '700'],
		},
		Oxanium: {
			variants: ['200', '300', '400', '500', '600', '700', '800'],
		},
		'Berkshire Swash': {
			variants: ['400'],
		},
		K2D: {
			variants: ['100', '200', '300', '400', '500', '600', '700', '800'],
		},
		Amita: {
			variants: ['400', '700'],
		},
		'Carrois Gothic': {
			variants: ['400'],
		},
		Livvic: {
			variants: ['100', '200', '300', '400', '500', '600', '700', '900'],
		},
		Charm: {
			variants: ['400', '700'],
		},
		Julee: {
			variants: ['400'],
		},
		'Fredericka the Great': {
			variants: ['400'],
		},
		Kreon: {
			variants: ['300', '400', '500', '600', '700'],
		},
		Yrsa: {
			variants: ['300', '400', '500', '600', '700'],
		},
		'Rammetto One': {
			variants: ['400'],
		},
		'JetBrains Mono': {
			variants: ['100', '200', '300', '400', '500', '600', '700', '800'],
		},
		'Short Stack': {
			variants: ['400'],
		},
		'Just Another Hand': {
			variants: ['400'],
		},
		'Cabin Sketch': {
			variants: ['400', '700'],
		},
		'Cantata One': {
			variants: ['400'],
		},
		'PT Serif Caption': {
			variants: ['400'],
		},
		Aldrich: {
			variants: ['400'],
		},
		'Kiwi Maru': {
			variants: ['300', '400', '500'],
		},
		Playfair: {
			variants: ['300', '400', '500', '600', '700', '800', '900'],
		},
		'Cinzel Decorative': {
			variants: ['400', '700', '900'],
		},
		'Nanum Brush Script': {
			variants: ['400'],
		},
		Coda: {
			variants: ['400', '800'],
		},
		'GFS Didot': {
			variants: ['400'],
		},
		'Covered By Your Grace': {
			variants: ['400'],
		},
		Michroma: {
			variants: ['400'],
		},
		'Libre Bodoni': {
			variants: ['400', '500', '600', '700'],
		},
		Rancho: {
			variants: ['400'],
		},
		'La Belle Aurore': {
			variants: ['400'],
		},
		Syncopate: {
			variants: ['400', '700'],
		},
		BioRhyme: {
			variants: ['200', '300', '400', '700', '800'],
		},
		Candal: {
			variants: ['400'],
		},
		Overlock: {
			variants: ['400', '700', '900'],
		},
		Scada: {
			variants: ['400', '700'],
		},
		'Palanquin Dark': {
			variants: ['400', '500', '600', '700'],
		},
		'Headland One': {
			variants: ['400'],
		},
		'Fira Code': {
			variants: ['300', '400', '500', '600', '700'],
		},
		'Caveat Brush': {
			variants: ['400'],
		},
		'Mrs Saint Delafield': {
			variants: ['400'],
		},
		Mali: {
			variants: ['200', '300', '400', '500', '600', '700'],
		},
		'Allerta Stencil': {
			variants: ['400'],
		},
		Quintessential: {
			variants: ['400'],
		},
		'Averia Serif Libre': {
			variants: ['300', '400', '700'],
		},
		'Noto Sans Hebrew': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Jua: {
			variants: ['400'],
		},
		Oranienbaum: {
			variants: ['400'],
		},
		'Shadows Into Light Two': {
			variants: ['400'],
		},
		Capriola: {
			variants: ['400'],
		},
		'Changa One': {
			variants: ['400'],
		},
		'Bowlby One SC': {
			variants: ['400'],
		},
		Trirong: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Racing Sans One': {
			variants: ['400'],
		},
		Bellefair: {
			variants: ['400'],
		},
		'Average Sans': {
			variants: ['400'],
		},
		'Pathway Extreme': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Boogaloo: {
			variants: ['400'],
		},
		'Herr Von Muellerhoff': {
			variants: ['400'],
		},
		'Krona One': {
			variants: ['400'],
		},
		Bevan: {
			variants: ['400'],
		},
		Graduate: {
			variants: ['400'],
		},
		Arizonia: {
			variants: ['400'],
		},
		'Atkinson Hyperlegible': {
			variants: ['400', '700'],
		},
		Pattaya: {
			variants: ['400'],
		},
		'Cormorant Infant': {
			variants: ['300', '400', '500', '600', '700'],
		},
		'Rozha One': {
			variants: ['400'],
		},
		Knewave: {
			variants: ['400'],
		},
		Allerta: {
			variants: ['400'],
		},
		'Monsieur La Doulaise': {
			variants: ['400'],
		},
		'Noto Nastaliq Urdu': {
			variants: ['400', '500', '600', '700'],
		},
		'Annie Use Your Telescope': {
			variants: ['400'],
		},
		Alexandria: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Corben: {
			variants: ['400', '700'],
		},
		'Arbutus Slab': {
			variants: ['400'],
		},
		Lustria: {
			variants: ['400'],
		},
		'Marcellus SC': {
			variants: ['400'],
		},
		Belleza: {
			variants: ['400'],
		},
		Niconne: {
			variants: ['400'],
		},
		Kurale: {
			variants: ['400'],
		},
		'Overpass Mono': {
			variants: ['300', '400', '500', '600', '700'],
		},
		Norican: {
			variants: ['400'],
		},
		'Noto Serif Devanagari': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Noto Serif Display': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Do Hyeon': {
			variants: ['400'],
		},
		'Bubblegum Sans': {
			variants: ['400'],
		},
		'Cedarville Cursive': {
			variants: ['400'],
		},
		Yesteryear: {
			variants: ['400'],
		},
		Hanuman: {
			variants: ['100', '300', '400', '700', '900'],
		},
		'Coming Soon': {
			variants: ['400'],
		},
		'Rubik Moonrocks': {
			variants: ['400'],
		},
		Enriqueta: {
			variants: ['400', '500', '600', '700'],
		},
		Telex: {
			variants: ['400'],
		},
		'Darker Grotesque': {
			variants: ['300', '400', '500', '600', '700', '800', '900'],
		},
		Marvel: {
			variants: ['400', '700'],
		},
		Rambla: {
			variants: ['400', '700'],
		},
		Grandstander: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Chonburi: {
			variants: ['400'],
		},
		'Seaweed Script': {
			variants: ['400'],
		},
		Kristi: {
			variants: ['400'],
		},
		'Golos Text': {
			variants: ['400', '500', '600', '700', '800', '900'],
		},
		'Alegreya SC': {
			variants: ['400', '500', '700', '800', '900'],
		},
		Smokum: {
			variants: ['400'],
		},
		'Hanken Grotesk': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Rye: {
			variants: ['400'],
		},
		Biryani: {
			variants: ['200', '300', '400', '600', '700', '800', '900'],
		},
		Wallpoet: {
			variants: ['400'],
		},
		Nobile: {
			variants: ['400', '500', '700'],
		},
		Coustard: {
			variants: ['400', '900'],
		},
		Maitree: {
			variants: ['200', '300', '400', '500', '600', '700'],
		},
		'Averia Libre': {
			variants: ['300', '400', '700'],
		},
		'Contrail One': {
			variants: ['400'],
		},
		Halant: {
			variants: ['300', '400', '500', '600', '700'],
		},
		'Vollkorn SC': {
			variants: ['400', '600', '700', '900'],
		},
		Spinnaker: {
			variants: ['400'],
		},
		'Proza Libre': {
			variants: ['400', '500', '600', '700', '800'],
		},
		Kosugi: {
			variants: ['400'],
		},
		Caudex: {
			variants: ['400', '700'],
		},
		Marmelad: {
			variants: ['400'],
		},
		'Bungee Inline': {
			variants: ['400'],
		},
		Ovo: {
			variants: ['400'],
		},
		Kameron: {
			variants: ['400', '700'],
		},
		Manjari: {
			variants: ['100', '400', '700'],
		},
		Amiko: {
			variants: ['400', '600', '700'],
		},
		'IBM Plex Sans Thai': {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		'M PLUS 1': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Grand Hotel': {
			variants: ['400'],
		},
		Limelight: {
			variants: ['400'],
		},
		Podkova: {
			variants: ['400', '500', '600', '700', '800'],
		},
		Cambay: {
			variants: ['400', '700'],
		},
		Alike: {
			variants: ['400'],
		},
		Arya: {
			variants: ['400', '700'],
		},
		Average: {
			variants: ['400'],
		},
		'Petit Formal Script': {
			variants: ['400'],
		},
		Rochester: {
			variants: ['400'],
		},
		'Klee One': {
			variants: ['400', '600'],
		},
		Lateef: {
			variants: ['200', '300', '400', '500', '600', '700', '800'],
		},
		'Suez One': {
			variants: ['400'],
		},
		Sofia: {
			variants: ['400'],
		},
		'Material Symbols Sharp': {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		'Henny Penny': {
			variants: ['400'],
		},
		Fredoka: {
			variants: ['300', '400', '500', '600', '700'],
		},
		'Pirata One': {
			variants: ['400'],
		},
		Aladin: {
			variants: ['400'],
		},
		B612: {
			variants: ['400', '700'],
		},
		'Mochiy Pop One': {
			variants: ['400'],
		},
		'Balsamiq Sans': {
			variants: ['400', '700'],
		},
		Delius: {
			variants: ['400'],
		},
		Schoolbell: {
			variants: ['400'],
		},
		'Brygada 1918': {
			variants: ['400', '500', '600', '700'],
		},
		'Shippori Mincho B1': {
			variants: ['400', '500', '600', '700', '800'],
		},
		Judson: {
			variants: ['400', '700'],
		},
		Magra: {
			variants: ['400', '700'],
		},
		'Miriam Libre': {
			variants: ['400', '700'],
		},
		'League Gothic': {
			variants: ['400'],
		},
		Trykker: {
			variants: ['400'],
		},
		'Irish Grover': {
			variants: ['400'],
		},
		Thasadith: {
			variants: ['400', '700'],
		},
		'Cormorant Upright': {
			variants: ['300', '400', '500', '600', '700'],
		},
		Amethysta: {
			variants: ['400'],
		},
		'Hepta Slab': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Quando: {
			variants: ['400'],
		},
		Georama: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Rasa: {
			variants: ['300', '400', '500', '600', '700'],
		},
		Trocchi: {
			variants: ['400'],
		},
		'ZCOOL QingKe HuangYou': {
			variants: ['400'],
		},
		'Encode Sans Semi Condensed': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Stardos Stencil': {
			variants: ['400', '700'],
		},
		'Alumni Sans': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Tillana: {
			variants: ['400', '500', '600', '700', '800'],
		},
		'Nixie One': {
			variants: ['400'],
		},
		'Jockey One': {
			variants: ['400'],
		},
		'B612 Mono': {
			variants: ['400', '700'],
		},
		Vazirmatn: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Sofia Sans Condensed': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Baloo Da 2': {
			variants: ['400', '500', '600', '700', '800'],
		},
		Sniglet: {
			variants: ['400', '800'],
		},
		'Spectral SC': {
			variants: ['200', '300', '400', '500', '600', '700', '800'],
		},
		'Dawning of a New Day': {
			variants: ['400'],
		},
		Metrophobic: {
			variants: ['400'],
		},
		Fahkwang: {
			variants: ['200', '300', '400', '500', '600', '700'],
		},
		Calligraffitti: {
			variants: ['400'],
		},
		Mallanna: {
			variants: ['400'],
		},
		NTR: {
			variants: ['400'],
		},
		'Fauna One': {
			variants: ['400'],
		},
		'Love Ya Like A Sister': {
			variants: ['400'],
		},
		Sunflower: {
			variants: ['300', '500', '700'],
		},
		Rakkas: {
			variants: ['400'],
		},
		'Grenze Gotisch': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Lemon: {
			variants: ['400'],
		},
		Padauk: {
			variants: ['400', '700'],
		},
		'Oxygen Mono': {
			variants: ['400'],
		},
		'Zen Old Mincho': {
			variants: ['400', '500', '600', '700', '900'],
		},
		'Big Shoulders Text': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Qwigley: {
			variants: ['400'],
		},
		'Fjord One': {
			variants: ['400'],
		},
		Molengo: {
			variants: ['400'],
		},
		Share: {
			variants: ['400', '700'],
		},
		'IM Fell English SC': {
			variants: ['400'],
		},
		Gurajada: {
			variants: ['400'],
		},
		Rosario: {
			variants: ['300', '400', '500', '600', '700'],
		},
		'Odibee Sans': {
			variants: ['400'],
		},
		'Sofia Sans': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Mansalva: {
			variants: ['400'],
		},
		Italiana: {
			variants: ['400'],
		},
		'Anek Malayalam': {
			variants: ['100', '200', '300', '400', '500', '600', '700', '800'],
		},
		'Sigmar One': {
			variants: ['400'],
		},
		Brawler: {
			variants: ['400', '700'],
		},
		Gabriela: {
			variants: ['400'],
		},
		'Turret Road': {
			variants: ['200', '300', '400', '500', '700', '800'],
		},
		'Style Script': {
			variants: ['400'],
		},
		'IBM Plex Sans KR': {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		'David Libre': {
			variants: ['400', '500', '700'],
		},
		'IM Fell English': {
			variants: ['400'],
		},
		'Sansita Swashed': {
			variants: ['300', '400', '500', '600', '700', '800', '900'],
		},
		'Aref Ruqaa': {
			variants: ['400', '700'],
		},
		'Slabo 13px': {
			variants: ['400'],
		},
		'Noto Sans Bengali': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'IM Fell DW Pica': {
			variants: ['400'],
		},
		'Dela Gothic One': {
			variants: ['400'],
		},
		'Goudy Bookletter 1911': {
			variants: ['400'],
		},
		'Cormorant SC': {
			variants: ['300', '400', '500', '600', '700'],
		},
		'Baloo Paaji 2': {
			variants: ['400', '500', '600', '700', '800'],
		},
		Homenaje: {
			variants: ['400'],
		},
		'Waiting for the Sunrise': {
			variants: ['400'],
		},
		'Baloo Thambi 2': {
			variants: ['400', '500', '600', '700', '800'],
		},
		Copse: {
			variants: ['400'],
		},
		'Montserrat Subrayada': {
			variants: ['400', '700'],
		},
		Bentham: {
			variants: ['400'],
		},
		Hahmlet: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Raleway Dots': {
			variants: ['400'],
		},
		Megrim: {
			variants: ['400'],
		},
		'Gravitas One': {
			variants: ['400'],
		},
		'Oleo Script Swash Caps': {
			variants: ['400', '700'],
		},
		Silkscreen: {
			variants: ['400', '700'],
		},
		'Patrick Hand SC': {
			variants: ['400'],
		},
		'Kaisei Decol': {
			variants: ['400', '500', '700'],
		},
		Allison: {
			variants: ['400'],
		},
		'Bowlby One': {
			variants: ['400'],
		},
		KoHo: {
			variants: ['200', '300', '400', '500', '600', '700'],
		},
		'Zen Kaku Gothic Antique': {
			variants: ['300', '400', '500', '700', '900'],
		},
		'Tenali Ramakrishna': {
			variants: ['400'],
		},
		Cutive: {
			variants: ['400'],
		},
		'Tulpen One': {
			variants: ['400'],
		},
		'Kelly Slab': {
			variants: ['400'],
		},
		UnifrakturMaguntia: {
			variants: ['400'],
		},
		'Noto Sans Kannada': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Inder: {
			variants: ['400'],
		},
		'ZCOOL XiaoWei': {
			variants: ['400'],
		},
		'Della Respira': {
			variants: ['400'],
		},
		Suranna: {
			variants: ['400'],
		},
		'Oooh Baby': {
			variants: ['400'],
		},
		Fondamento: {
			variants: ['400'],
		},
		'Lexend Zetta': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Almendra: {
			variants: ['400', '700'],
		},
		'Chelsea Market': {
			variants: ['400'],
		},
		'Zen Antique': {
			variants: ['400'],
		},
		'Antic Didone': {
			variants: ['400'],
		},
		'Germania One': {
			variants: ['400'],
		},
		Tomorrow: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Andika: {
			variants: ['400', '700'],
		},
		'Baloo Tamma 2': {
			variants: ['400', '500', '600', '700', '800'],
		},
		Montez: {
			variants: ['400'],
		},
		'Fanwood Text': {
			variants: ['400'],
		},
		Kadwa: {
			variants: ['400', '700'],
		},
		'Stint Ultra Condensed': {
			variants: ['400'],
		},
		Kodchasan: {
			variants: ['200', '300', '400', '500', '600', '700'],
		},
		'Mr De Haviland': {
			variants: ['400'],
		},
		'Sedgwick Ave': {
			variants: ['400'],
		},
		Radley: {
			variants: ['400'],
		},
		Notable: {
			variants: ['400'],
		},
		'Syne Mono': {
			variants: ['400'],
		},
		Mirza: {
			variants: ['400', '500', '600', '700'],
		},
		Akshar: {
			variants: ['300', '400', '500', '600', '700'],
		},
		Flamenco: {
			variants: ['300', '400'],
		},
		'Tilt Prism': {
			variants: ['400'],
		},
		'Zen Kurenaido': {
			variants: ['400'],
		},
		'Saira Stencil One': {
			variants: ['400'],
		},
		'Loved by the King': {
			variants: ['400'],
		},
		Goldman: {
			variants: ['400', '700'],
		},
		'Mukta Vaani': {
			variants: ['200', '300', '400', '500', '600', '700', '800'],
		},
		Glory: {
			variants: ['100', '200', '300', '400', '500', '600', '700', '800'],
		},
		'Sulphur Point': {
			variants: ['300', '400', '700'],
		},
		Galada: {
			variants: ['400'],
		},
		'Ma Shan Zheng': {
			variants: ['400'],
		},
		Farro: {
			variants: ['300', '400', '500', '700'],
		},
		'Bungee Shade': {
			variants: ['400'],
		},
		Buenard: {
			variants: ['400', '700'],
		},
		'RocknRoll One': {
			variants: ['400'],
		},
		Modak: {
			variants: ['400'],
		},
		'Rouge Script': {
			variants: ['400'],
		},
		Harmattan: {
			variants: ['400', '500', '600', '700'],
		},
		Oregano: {
			variants: ['400'],
		},
		'Bellota Text': {
			variants: ['300', '400', '700'],
		},
		Cambo: {
			variants: ['400'],
		},
		'BhuTuka Expanded One': {
			variants: ['400'],
		},
		'Original Surfer': {
			variants: ['400'],
		},
		'Alike Angular': {
			variants: ['400'],
		},
		'Noto Sans Sinhala': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Mouse Memoirs': {
			variants: ['400'],
		},
		'Kite One': {
			variants: ['400'],
		},
		'Chivo Mono': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Vesper Libre': {
			variants: ['400', '500', '700', '900'],
		},
		'Encode Sans Expanded': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Dokdo: {
			variants: ['400'],
		},
		Jomhuria: {
			variants: ['400'],
		},
		Pompiere: {
			variants: ['400'],
		},
		'Azeret Mono': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		DotGothic16: {
			variants: ['400'],
		},
		Anuphan: {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		'Baloo Chettan 2': {
			variants: ['400', '500', '600', '700', '800'],
		},
		Poly: {
			variants: ['400'],
		},
		'Ms Madi': {
			variants: ['400'],
		},
		'Supermercado One': {
			variants: ['400'],
		},
		'Nova Mono': {
			variants: ['400'],
		},
		Federo: {
			variants: ['400'],
		},
		Meddon: {
			variants: ['400'],
		},
		Skranji: {
			variants: ['400', '700'],
		},
		Carme: {
			variants: ['400'],
		},
		'Duru Sans': {
			variants: ['400'],
		},
		Codystar: {
			variants: ['300', '400'],
		},
		'Mukta Mahee': {
			variants: ['200', '300', '400', '500', '600', '700', '800'],
		},
		'Meera Inimai': {
			variants: ['400'],
		},
		'Happy Monkey': {
			variants: ['400'],
		},
		McLaren: {
			variants: ['400'],
		},
		'Andada Pro': {
			variants: ['400', '500', '600', '700', '800'],
		},
		'Libre Barcode 39 Extended Text': {
			variants: ['400'],
		},
		'Schibsted Grotesk': {
			variants: ['400', '500', '600', '700', '800', '900'],
		},
		Battambang: {
			variants: ['100', '300', '400', '700', '900'],
		},
		Amarante: {
			variants: ['400'],
		},
		'Sue Ellen Francisco': {
			variants: ['400'],
		},
		'Noto Sans Chorasmian': {
			variants: ['400'],
		},
		'Rampart One': {
			variants: ['400'],
		},
		'Ceviche One': {
			variants: ['400'],
		},
		'Expletus Sans': {
			variants: ['400', '500', '600', '700'],
		},
		'Bakbak One': {
			variants: ['400'],
		},
		Numans: {
			variants: ['400'],
		},
		'Clicker Script': {
			variants: ['400'],
		},
		Aboreto: {
			variants: ['400'],
		},
		Gugi: {
			variants: ['400'],
		},
		Freehand: {
			variants: ['400'],
		},
		'Goblin One': {
			variants: ['400'],
		},
		'Sofia Sans Semi Condensed': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Over the Rainbow': {
			variants: ['400'],
		},
		Allan: {
			variants: ['400', '700'],
		},
		Anaheim: {
			variants: ['400'],
		},
		Tienne: {
			variants: ['400', '700', '900'],
		},
		Lekton: {
			variants: ['400', '700'],
		},
		'Aguafina Script': {
			variants: ['400'],
		},
		Esteban: {
			variants: ['400'],
		},
		'Give You Glory': {
			variants: ['400'],
		},
		'Yusei Magic': {
			variants: ['400'],
		},
		Ledger: {
			variants: ['400'],
		},
		Kufam: {
			variants: ['400', '500', '600', '700', '800', '900'],
		},
		'Euphoria Script': {
			variants: ['400'],
		},
		'BIZ UDPMincho': {
			variants: ['400', '700'],
		},
		Shojumaru: {
			variants: ['400'],
		},
		Montaga: {
			variants: ['400'],
		},
		'Averia Sans Libre': {
			variants: ['300', '400', '700'],
		},
		Besley: {
			variants: ['400', '500', '600', '700', '800', '900'],
		},
		Elsie: {
			variants: ['400', '900'],
		},
		Mako: {
			variants: ['400'],
		},
		'Prosto One': {
			variants: ['400'],
		},
		'Doppio One': {
			variants: ['400'],
		},
		'Inknut Antiqua': {
			variants: ['300', '400', '500', '600', '700', '800', '900'],
		},
		Ephesis: {
			variants: ['400'],
		},
		'Chau Philomene One': {
			variants: ['400'],
		},
		Convergence: {
			variants: ['400'],
		},
		'Noto Sans Telugu': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Asul: {
			variants: ['400', '700'],
		},
		Metamorphous: {
			variants: ['400'],
		},
		Geo: {
			variants: ['400'],
		},
		'Ibarra Real Nova': {
			variants: ['400', '500', '600', '700'],
		},
		'Bricolage Grotesque': {
			variants: ['200', '300', '400', '500', '600', '700', '800'],
		},
		'Vast Shadow': {
			variants: ['400'],
		},
		Frijole: {
			variants: ['400'],
		},
		'Shantell Sans': {
			variants: ['300', '400', '500', '600', '700', '800'],
		},
		'Emilys Candy': {
			variants: ['400'],
		},
		'Walter Turncoat': {
			variants: ['400'],
		},
		'Freckle Face': {
			variants: ['400'],
		},
		Fasthand: {
			variants: ['400'],
		},
		'Nova Round': {
			variants: ['400'],
		},
		'Wendy One': {
			variants: ['400'],
		},
		Bayon: {
			variants: ['400'],
		},
		Hurricane: {
			variants: ['400'],
		},
		'Spline Sans': {
			variants: ['300', '400', '500', '600', '700'],
		},
		Gloock: {
			variants: ['400'],
		},
		'Finger Paint': {
			variants: ['400'],
		},
		Timmana: {
			variants: ['400'],
		},
		'Reggae One': {
			variants: ['400'],
		},
		'Hi Melody': {
			variants: ['400'],
		},
		'Cormorant Unicase': {
			variants: ['300', '400', '500', '600', '700'],
		},
		Gaegu: {
			variants: ['300', '400', '700'],
		},
		'Port Lligat Slab': {
			variants: ['400'],
		},
		Mogra: {
			variants: ['400'],
		},
		'Ruslan Display': {
			variants: ['400'],
		},
		Solway: {
			variants: ['300', '400', '500', '700', '800'],
		},
		Baumans: {
			variants: ['400'],
		},
		Sail: {
			variants: ['400'],
		},
		Coiny: {
			variants: ['400'],
		},
		Ruwudu: {
			variants: ['400', '500', '600', '700'],
		},
		'Scope One': {
			variants: ['400'],
		},
		'M PLUS 2': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Sarpanch: {
			variants: ['400', '500', '600', '700', '800', '900'],
		},
		Prociono: {
			variants: ['400'],
		},
		'Londrina Shadow': {
			variants: ['400'],
		},
		'Mountains of Christmas': {
			variants: ['400', '700'],
		},
		Pavanam: {
			variants: ['400'],
		},
		'Lexend Exa': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Balthazar: {
			variants: ['400'],
		},
		Orienta: {
			variants: ['400'],
		},
		'Noto Sans Georgian': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Fresca: {
			variants: ['400'],
		},
		'Share Tech': {
			variants: ['400'],
		},
		Recursive: {
			variants: ['300', '400', '500', '600', '700', '800', '900'],
		},
		Nokora: {
			variants: ['100', '300', '400', '700', '900'],
		},
		Imprima: {
			variants: ['400'],
		},
		Puritan: {
			variants: ['400', '700'],
		},
		Barriecito: {
			variants: ['400'],
		},
		'Delius Unicase': {
			variants: ['400', '700'],
		},
		'Faster One': {
			variants: ['400'],
		},
		'Nerko One': {
			variants: ['400'],
		},
		Dynalight: {
			variants: ['400'],
		},
		Gluten: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Xanh Mono': {
			variants: ['400'],
		},
		'Anek Tamil': {
			variants: ['100', '200', '300', '400', '500', '600', '700', '800'],
		},
		Charmonman: {
			variants: ['400', '700'],
		},
		'Bilbo Swash Caps': {
			variants: ['400'],
		},
		'Life Savers': {
			variants: ['400', '700', '800'],
		},
		'Baloo Bhaina 2': {
			variants: ['400', '500', '600', '700', '800'],
		},
		Shalimar: {
			variants: ['400'],
		},
		Sono: {
			variants: ['200', '300', '400', '500', '600', '700', '800'],
		},
		Atma: {
			variants: ['300', '400', '500', '600', '700'],
		},
		Eater: {
			variants: ['400'],
		},
		Chango: {
			variants: ['400'],
		},
		'Libre Barcode 128': {
			variants: ['400'],
		},
		'Gemunu Libre': {
			variants: ['200', '300', '400', '500', '600', '700', '800'],
		},
		'Radio Canada': {
			variants: ['300', '400', '500', '600', '700'],
		},
		'Kaisei Tokumin': {
			variants: ['400', '500', '700', '800'],
		},
		Katibeh: {
			variants: ['400'],
		},
		'Red Rose': {
			variants: ['300', '400', '500', '600', '700'],
		},
		'Sonsie One': {
			variants: ['400'],
		},
		'Poller One': {
			variants: ['400'],
		},
		'Libre Caslon Display': {
			variants: ['400'],
		},
		'Libre Barcode 39 Text': {
			variants: ['400'],
		},
		Sumana: {
			variants: ['400', '700'],
		},
		'Rubik Dirt': {
			variants: ['400'],
		},
		'Noto Serif Malayalam': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Salsa: {
			variants: ['400'],
		},
		'Inria Serif': {
			variants: ['300', '400', '700'],
		},
		'Cherry Cream Soda': {
			variants: ['400'],
		},
		'Londrina Outline': {
			variants: ['400'],
		},
		Mina: {
			variants: ['400', '700'],
		},
		'Gamja Flower': {
			variants: ['400'],
		},
		Vibur: {
			variants: ['400'],
		},
		'ZCOOL KuaiLe': {
			variants: ['400'],
		},
		'Noto Sans Myanmar': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Delius Swash Caps': {
			variants: ['400'],
		},
		'Cherry Swash': {
			variants: ['400', '700'],
		},
		'League Script': {
			variants: ['400'],
		},
		'Major Mono Display': {
			variants: ['400'],
		},
		Bellota: {
			variants: ['300', '400', '700'],
		},
		'Encode Sans Semi Expanded': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Ranchers: {
			variants: ['400'],
		},
		'Lexend Giga': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Belgrano: {
			variants: ['400'],
		},
		'Bigshot One': {
			variants: ['400'],
		},
		'Edu SA Beginner': {
			variants: ['400', '500', '600', '700'],
		},
		'Lexend Peta': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Gayathri: {
			variants: ['100', '400', '700'],
		},
		Dongle: {
			variants: ['300', '400', '700'],
		},
		MuseoModerno: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Medula One': {
			variants: ['400'],
		},
		'Crafty Girls': {
			variants: ['400'],
		},
		'Comforter Brush': {
			variants: ['400'],
		},
		'Orelega One': {
			variants: ['400'],
		},
		Slackey: {
			variants: ['400'],
		},
		'Potta One': {
			variants: ['400'],
		},
		'Just Me Again Down Here': {
			variants: ['400'],
		},
		Ranga: {
			variants: ['400', '700'],
		},
		'Inria Sans': {
			variants: ['300', '400', '700'],
		},
		Kranky: {
			variants: ['400'],
		},
		'Lovers Quarrel': {
			variants: ['400'],
		},
		'Port Lligat Sans': {
			variants: ['400'],
		},
		'IM Fell French Canon': {
			variants: ['400'],
		},
		Birthstone: {
			variants: ['400'],
		},
		'Familjen Grotesk': {
			variants: ['400', '500', '600', '700'],
		},
		Peralta: {
			variants: ['400'],
		},
		Voces: {
			variants: ['400'],
		},
		'Wix Madefor Display': {
			variants: ['400', '500', '600', '700', '800'],
		},
		'Noto Serif Hebrew': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Baloo Bhaijaan 2': {
			variants: ['400', '500', '600', '700', '800'],
		},
		Ribeye: {
			variants: ['400'],
		},
		'Spicy Rice': {
			variants: ['400'],
		},
		Sura: {
			variants: ['400', '700'],
		},
		Corinthia: {
			variants: ['400', '700'],
		},
		'Trade Winds': {
			variants: ['400'],
		},
		'Baloo Bhai 2': {
			variants: ['400', '500', '600', '700', '800'],
		},
		'Anek Telugu': {
			variants: ['100', '200', '300', '400', '500', '600', '700', '800'],
		},
		'Song Myung': {
			variants: ['400'],
		},
		Gantari: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Ruthie: {
			variants: ['400'],
		},
		'Kaisei Opti': {
			variants: ['400', '500', '700'],
		},
		Stick: {
			variants: ['400'],
		},
		'Macondo Swash Caps': {
			variants: ['400'],
		},
		Varta: {
			variants: ['300', '400', '500', '600', '700'],
		},
		'The Girl Next Door': {
			variants: ['400'],
		},
		'Sree Krushnadevaraya': {
			variants: ['400'],
		},
		'Lily Script One': {
			variants: ['400'],
		},
		Asar: {
			variants: ['400'],
		},
		Ramaraja: {
			variants: ['400'],
		},
		'Abyssinica SIL': {
			variants: ['400'],
		},
		Galdeano: {
			variants: ['400'],
		},
		Artifika: {
			variants: ['400'],
		},
		'Noto Sans Armenian': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Hachi Maru Pop': {
			variants: ['400'],
		},
		'Noto Sans Symbols': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Piazzolla: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Stylish: {
			variants: ['400'],
		},
		'Tilt Warp': {
			variants: ['400'],
		},
		'Uncial Antiqua': {
			variants: ['400'],
		},
		'Bubbler One': {
			variants: ['400'],
		},
		'IBM Plex Sans Thai Looped': {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		Monofett: {
			variants: ['400'],
		},
		'Overlock SC': {
			variants: ['400'],
		},
		Strait: {
			variants: ['400'],
		},
		'Carrois Gothic SC': {
			variants: ['400'],
		},
		Khmer: {
			variants: ['400'],
		},
		Tauri: {
			variants: ['400'],
		},
		Piedra: {
			variants: ['400'],
		},
		UnifrakturCook: {
			variants: ['700'],
		},
		Geologica: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Gowun Dodum': {
			variants: ['400'],
		},
		'Red Hat Mono': {
			variants: ['300', '400', '500', '600', '700'],
		},
		Miniver: {
			variants: ['400'],
		},
		'Noto Serif Thai': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'IM Fell Double Pica': {
			variants: ['400'],
		},
		'Kotta One': {
			variants: ['400'],
		},
		'Qwitcher Grypen': {
			variants: ['400', '700'],
		},
		Gotu: {
			variants: ['400'],
		},
		'Akaya Telivigala': {
			variants: ['400'],
		},
		Gafata: {
			variants: ['400'],
		},
		Iceland: {
			variants: ['400'],
		},
		Akronim: {
			variants: ['400'],
		},
		'Wire One': {
			variants: ['400'],
		},
		'Flow Circular': {
			variants: ['400'],
		},
		'Cute Font': {
			variants: ['400'],
		},
		Suwannaphum: {
			variants: ['100', '300', '400', '700', '900'],
		},
		'Denk One': {
			variants: ['400'],
		},
		'Square Peg': {
			variants: ['400'],
		},
		Rationale: {
			variants: ['400'],
		},
		Farsan: {
			variants: ['400'],
		},
		'Tiro Devanagari Hindi': {
			variants: ['400'],
		},
		'Rum Raisin': {
			variants: ['400'],
		},
		Caprasimo: {
			variants: ['400'],
		},
		Sahitya: {
			variants: ['400', '700'],
		},
		'Hina Mincho': {
			variants: ['400'],
		},
		Unlock: {
			variants: ['400'],
		},
		'East Sea Dokdo': {
			variants: ['400'],
		},
		'Gowun Batang': {
			variants: ['400', '700'],
		},
		'Kulim Park': {
			variants: ['200', '300', '400', '600', '700'],
		},
		Habibi: {
			variants: ['400'],
		},
		Kavoon: {
			variants: ['400'],
		},
		'Sofia Sans Extra Condensed': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Odor Mean Chey': {
			variants: ['400'],
		},
		Unkempt: {
			variants: ['400', '700'],
		},
		Paprika: {
			variants: ['400'],
		},
		'Baloo Tammudu 2': {
			variants: ['400', '500', '600', '700', '800'],
		},
		'Donegal One': {
			variants: ['400'],
		},
		'Road Rage': {
			variants: ['400'],
		},
		Alkalami: {
			variants: ['400'],
		},
		Moul: {
			variants: ['400'],
		},
		'Black And White Picture': {
			variants: ['400'],
		},
		'Lexend Mega': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'IBM Plex Sans Devanagari': {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		Redressed: {
			variants: ['400'],
		},
		Shanti: {
			variants: ['400'],
		},
		Manuale: {
			variants: ['300', '400', '500', '600', '700', '800'],
		},
		'Nova Square': {
			variants: ['400'],
		},
		'Mystery Quest': {
			variants: ['400'],
		},
		Sancreek: {
			variants: ['400'],
		},
		Barrio: {
			variants: ['400'],
		},
		'Autour One': {
			variants: ['400'],
		},
		'Yuji Syuku': {
			variants: ['400'],
		},
		Murecho: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Rosarivo: {
			variants: ['400'],
		},
		'Viaoda Libre': {
			variants: ['400'],
		},
		'BIZ UDGothic': {
			variants: ['400', '700'],
		},
		'Fontdiner Swanky': {
			variants: ['400'],
		},
		'Grape Nuts': {
			variants: ['400'],
		},
		'Fragment Mono': {
			variants: ['400'],
		},
		'IBM Plex Sans JP': {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		'Noto Sans Math': {
			variants: ['400'],
		},
		'Noto Sans Lao': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Inspiration: {
			variants: ['400'],
		},
		'Zen Dots': {
			variants: ['400'],
		},
		Karantina: {
			variants: ['300', '400', '700'],
		},
		Akatab: {
			variants: ['400', '500', '600', '700', '800', '900'],
		},
		Chathura: {
			variants: ['100', '300', '400', '700', '800'],
		},
		'Zhi Mang Xing': {
			variants: ['400'],
		},
		Dorsa: {
			variants: ['400'],
		},
		'Montagu Slab': {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		Stoke: {
			variants: ['300', '400'],
		},
		'Cantora One': {
			variants: ['400'],
		},
		'Noto Emoji': {
			variants: ['300', '400', '500', '600', '700'],
		},
		Chicle: {
			variants: ['400'],
		},
		'Moon Dance': {
			variants: ['400'],
		},
		Stalemate: {
			variants: ['400'],
		},
		Molle: {
			variants: [],
		},
		Dekko: {
			variants: ['400'],
		},
		'Princess Sofia': {
			variants: ['400'],
		},
		Trispace: {
			variants: ['100', '200', '300', '400', '500', '600', '700', '800'],
		},
		Engagement: {
			variants: ['400'],
		},
		WindSong: {
			variants: ['400', '500'],
		},
		Jomolhari: {
			variants: ['400'],
		},
		Bilbo: {
			variants: ['400'],
		},
		'Zilla Slab Highlight': {
			variants: ['400', '700'],
		},
		'Beth Ellen': {
			variants: ['400'],
		},
		'Beau Rivage': {
			variants: ['400'],
		},
		Iceberg: {
			variants: ['400'],
		},
		'Meow Script': {
			variants: ['400'],
		},
		'Nova Flat': {
			variants: ['400'],
		},
		Yaldevi: {
			variants: ['200', '300', '400', '500', '600', '700'],
		},
		'Stint Ultra Expanded': {
			variants: ['400'],
		},
		'Meie Script': {
			variants: ['400'],
		},
		'IM Fell Great Primer': {
			variants: ['400'],
		},
		Crushed: {
			variants: ['400'],
		},
		'Vujahday Script': {
			variants: ['400'],
		},
		MonteCarlo: {
			variants: ['400'],
		},
		'Train One': {
			variants: ['400'],
		},
		Offside: {
			variants: ['400'],
		},
		'Anek Devanagari': {
			variants: ['100', '200', '300', '400', '500', '600', '700', '800'],
		},
		Fenix: {
			variants: ['400'],
		},
		Sarina: {
			variants: ['400'],
		},
		Comforter: {
			variants: ['400'],
		},
		'Jolly Lodger': {
			variants: ['400'],
		},
		'Smooch Sans': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Fuzzy Bubbles': {
			variants: ['400', '700'],
		},
		'Noto Serif Georgian': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Stalinist One': {
			variants: ['400'],
		},
		'Bigelow Rules': {
			variants: ['400'],
		},
		'Mrs Sheppards': {
			variants: ['400'],
		},
		Gulzar: {
			variants: ['400'],
		},
		'Instrument Serif': {
			variants: ['400'],
		},
		Margarine: {
			variants: ['400'],
		},
		'Mochiy Pop P One': {
			variants: ['400'],
		},
		MedievalSharp: {
			variants: ['400'],
		},
		Angkor: {
			variants: ['400'],
		},
		'Bona Nova': {
			variants: ['400', '700'],
		},
		Cagliostro: {
			variants: ['400'],
		},
		'Tiro Kannada': {
			variants: ['400'],
		},
		Wellfleet: {
			variants: ['400'],
		},
		'New Rocker': {
			variants: ['400'],
		},
		'Shippori Antique': {
			variants: ['400'],
		},
		'Akaya Kanadaka': {
			variants: ['400'],
		},
		Milonga: {
			variants: ['400'],
		},
		Waterfall: {
			variants: ['400'],
		},
		'Poor Story': {
			variants: ['400'],
		},
		'Vampiro One': {
			variants: ['400'],
		},
		'Scheherazade New': {
			variants: ['400', '500', '600', '700'],
		},
		Benne: {
			variants: ['400'],
		},
		'Kaisei HarunoUmi': {
			variants: ['400', '500', '700'],
		},
		'Anek Bangla': {
			variants: ['100', '200', '300', '400', '500', '600', '700', '800'],
		},
		REM: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Yomogi: {
			variants: ['400'],
		},
		Kavivanar: {
			variants: ['400'],
		},
		'Rhodium Libre': {
			variants: ['400'],
		},
		Srisakdi: {
			variants: ['400', '700'],
		},
		'Alumni Sans Inline One': {
			variants: ['400'],
		},
		'Noto Sans Multani': {
			variants: ['400'],
		},
		'Eagle Lake': {
			variants: ['400'],
		},
		Arima: {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		'Seymour One': {
			variants: ['400'],
		},
		'Bruno Ace SC': {
			variants: ['400'],
		},
		'Spline Sans Mono': {
			variants: ['300', '400', '500', '600', '700'],
		},
		Underdog: {
			variants: ['400'],
		},
		Carattere: {
			variants: ['400'],
		},
		'Long Cang': {
			variants: ['400'],
		},
		'Libre Barcode 128 Text': {
			variants: ['400'],
		},
		Mohave: {
			variants: ['300', '400', '500', '600', '700'],
		},
		'Anek Latin': {
			variants: ['100', '200', '300', '400', '500', '600', '700', '800'],
		},
		Buda: {
			variants: ['300'],
		},
		'Instrument Sans': {
			variants: ['400', '500', '600', '700'],
		},
		'Linden Hill': {
			variants: ['400'],
		},
		'Noto Sans Anatolian Hieroglyphs': {
			variants: ['400'],
		},
		'Ravi Prakash': {
			variants: ['400'],
		},
		'Shippori Antique B1': {
			variants: ['400'],
		},
		Gorditas: {
			variants: ['400', '700'],
		},
		Diplomata: {
			variants: ['400'],
		},
		Content: {
			variants: ['400', '700'],
		},
		'Swanky and Moo Moo': {
			variants: ['400'],
		},
		Fascinate: {
			variants: ['400'],
		},
		Licorice: {
			variants: ['400'],
		},
		'Caesar Dressing': {
			variants: ['400'],
		},
		'Noto Serif HK': {
			variants: ['200', '300', '400', '500', '600', '700', '800', '900'],
		},
		'Liu Jian Mao Cao': {
			variants: ['400'],
		},
		Felipa: {
			variants: ['400'],
		},
		'The Nautigal': {
			variants: ['400', '700'],
		},
		'Tiro Bangla': {
			variants: ['400'],
		},
		Dangrek: {
			variants: ['400'],
		},
		Spirax: {
			variants: ['400'],
		},
		Condiment: {
			variants: ['400'],
		},
		Nosifer: {
			variants: ['400'],
		},
		'Modern Antiqua': {
			variants: ['400'],
		},
		Simonetta: {
			variants: ['400', '900'],
		},
		'Kantumruy Pro': {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		'Noto Sans Khmer': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Joti One': {
			variants: ['400'],
		},
		'Noto Serif Lao': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		DynaPuff: {
			variants: ['400', '500', '600', '700'],
		},
		Ruluko: {
			variants: ['400'],
		},
		'Jacques Francois Shadow': {
			variants: ['400'],
		},
		'Chela One': {
			variants: ['400'],
		},
		'Text Me One': {
			variants: ['400'],
		},
		Girassol: {
			variants: ['400'],
		},
		Romanesco: {
			variants: ['400'],
		},
		'Metal Mania': {
			variants: ['400'],
		},
		Plaster: {
			variants: ['400'],
		},
		Handjet: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Griffy: {
			variants: ['400'],
		},
		'Encode Sans SC': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Kirang Haerang': {
			variants: ['400'],
		},
		'Passions Conflict': {
			variants: ['400'],
		},
		Chilanka: {
			variants: ['400'],
		},
		'Noto Sans Oriya': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Englebert: {
			variants: ['400'],
		},
		Junge: {
			variants: ['400'],
		},
		Inika: {
			variants: ['400', '700'],
		},
		Risque: {
			variants: ['400'],
		},
		'Marko One': {
			variants: ['400'],
		},
		'Elsie Swash Caps': {
			variants: ['400', '900'],
		},
		'Keania One': {
			variants: ['400'],
		},
		'Noto Sans Gujarati': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Aoboshi One': {
			variants: ['400'],
		},
		'Hanalei Fill': {
			variants: ['400'],
		},
		Bahiana: {
			variants: ['400'],
		},
		'Zen Tokyo Zoo': {
			variants: ['400'],
		},
		'Sirin Stencil': {
			variants: ['400'],
		},
		Lancelot: {
			variants: ['400'],
		},
		Anybody: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Snippet: {
			variants: ['400'],
		},
		'M PLUS 1 Code': {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		'Fascinate Inline': {
			variants: ['400'],
		},
		'Kumar One': {
			variants: ['400'],
		},
		'Single Day': {
			variants: ['400'],
		},
		'Averia Gruesa Libre': {
			variants: ['400'],
		},
		Arbutus: {
			variants: ['400'],
		},
		'Atomic Age': {
			variants: ['400'],
		},
		'Jacques Francois': {
			variants: ['400'],
		},
		'Diplomata SC': {
			variants: ['400'],
		},
		Smooch: {
			variants: ['400'],
		},
		'Maiden Orange': {
			variants: ['400'],
		},
		Siemreap: {
			variants: ['400'],
		},
		Alkatra: {
			variants: ['400', '500', '600', '700'],
		},
		Borel: {
			variants: ['400'],
		},
		'Zen Antique Soft': {
			variants: ['400'],
		},
		'Birthstone Bounce': {
			variants: ['400', '500'],
		},
		Sunshiney: {
			variants: ['400'],
		},
		'Glass Antiqua': {
			variants: ['400'],
		},
		Peddana: {
			variants: ['400'],
		},
		'Noto Sans Ethiopic': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Redacted: {
			variants: ['400'],
		},
		Tektur: {
			variants: ['400', '500', '600', '700', '800', '900'],
		},
		'New Tegomin': {
			variants: ['400'],
		},
		Grenze: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Tiro Gurmukhi': {
			variants: ['400'],
		},
		'Rubik Wet Paint': {
			variants: ['400'],
		},
		'Croissant One': {
			variants: ['400'],
		},
		Preahvihear: {
			variants: ['400'],
		},
		'IBM Plex Sans Hebrew': {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		'Yeon Sung': {
			variants: ['400'],
		},
		'Delicious Handrawn': {
			variants: ['400'],
		},
		'Dr Sugiyama': {
			variants: ['400'],
		},
		'Passero One': {
			variants: ['400'],
		},
		Belanosima: {
			variants: ['400', '600', '700'],
		},
		'Noto Serif Armenian': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Charis SIL': {
			variants: ['400', '700'],
		},
		'IM Fell DW Pica SC': {
			variants: ['400'],
		},
		'Jim Nightshade': {
			variants: ['400'],
		},
		Joan: {
			variants: ['400'],
		},
		'Braah One': {
			variants: ['400'],
		},
		'Cherry Bomb One': {
			variants: ['400'],
		},
		'BIZ UDMincho': {
			variants: ['400', '700'],
		},
		Ewert: {
			variants: ['400'],
		},
		'BioRhyme Expanded': {
			variants: ['200', '300', '400', '700', '800'],
		},
		'Ribeye Marrow': {
			variants: ['400'],
		},
		Flavors: {
			variants: ['400'],
		},
		'Nuosu SIL': {
			variants: ['400'],
		},
		Genos: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Festive: {
			variants: ['400'],
		},
		Qahiri: {
			variants: ['400'],
		},
		'Stick No Bills': {
			variants: ['200', '300', '400', '500', '600', '700', '800'],
		},
		'Noto Serif Sinhala': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Sedgwick Ave Display': {
			variants: ['400'],
		},
		Metal: {
			variants: ['400'],
		},
		'Bungee Hairline': {
			variants: ['400'],
		},
		Imbue: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Labrada: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Lakki Reddy': {
			variants: ['400'],
		},
		Smythe: {
			variants: ['400'],
		},
		Devonshire: {
			variants: ['400'],
		},
		'Kumar One Outline': {
			variants: ['400'],
		},
		'IM Fell French Canon SC': {
			variants: ['400'],
		},
		'Emblema One': {
			variants: ['400'],
		},
		'Purple Purse': {
			variants: ['400'],
		},
		Combo: {
			variants: ['400'],
		},
		Oldenburg: {
			variants: ['400'],
		},
		Bokor: {
			variants: ['400'],
		},
		'Wix Madefor Text': {
			variants: ['400', '500', '600', '700', '800'],
		},
		Whisper: {
			variants: ['400'],
		},
		Gidugu: {
			variants: ['400'],
		},
		'Water Brush': {
			variants: ['400'],
		},
		Revalia: {
			variants: ['400'],
		},
		Trochut: {
			variants: ['400', '700'],
		},
		'Victor Mono': {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		'Noto Serif Kannada': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Almendra SC': {
			variants: ['400'],
		},
		'Lisu Bosa': {
			variants: ['200', '300', '400', '500', '600', '700', '800', '900'],
		},
		'Sassy Frass': {
			variants: ['400'],
		},
		'Nova Slim': {
			variants: ['400'],
		},
		Federant: {
			variants: ['400'],
		},
		'Bungee Outline': {
			variants: ['400'],
		},
		'Noto Sans Symbols 2': {
			variants: ['400'],
		},
		Fuggles: {
			variants: ['400'],
		},
		'IM Fell Great Primer SC': {
			variants: ['400'],
		},
		Texturina: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Phudu: {
			variants: ['300', '400', '500', '600', '700', '800', '900'],
		},
		'Amiri Quran': {
			variants: ['400'],
		},
		Carlito: {
			variants: ['400', '700'],
		},
		'Noto Sans Gothic': {
			variants: ['400'],
		},
		'Gentium Plus': {
			variants: ['400', '700'],
		},
		Galindo: {
			variants: ['400'],
		},
		'Noto Serif Vithkuqi': {
			variants: ['400', '500', '600', '700'],
		},
		'Anek Gujarati': {
			variants: ['100', '200', '300', '400', '500', '600', '700', '800'],
		},
		Bahianita: {
			variants: ['400'],
		},
		Kenia: {
			variants: ['400'],
		},
		Mynerve: {
			variants: ['400'],
		},
		Praise: {
			variants: ['400'],
		},
		'Butterfly Kids': {
			variants: ['400'],
		},
		'Tiro Devanagari Marathi': {
			variants: ['400'],
		},
		'Lavishly Yours': {
			variants: ['400'],
		},
		Solitreo: {
			variants: ['400'],
		},
		Asset: {
			variants: ['400'],
		},
		Langar: {
			variants: ['400'],
		},
		'Miss Fajardose': {
			variants: ['400'],
		},
		'Big Shoulders Stencil Display': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Ysabeau Infant': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Libre Barcode 39 Extended': {
			variants: ['400'],
		},
		'Erica One': {
			variants: ['400'],
		},
		'Geostar Fill': {
			variants: ['400'],
		},
		'Tiro Devanagari Sanskrit': {
			variants: ['400'],
		},
		'Almendra Display': {
			variants: ['400'],
		},
		'Big Shoulders Stencil Text': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Poltawski Nowy': {
			variants: ['400', '500', '600', '700'],
		},
		'Noto Sans Samaritan': {
			variants: ['400'],
		},
		Lumanosimo: {
			variants: ['400'],
		},
		'Luxurious Script': {
			variants: ['400'],
		},
		Agdasima: {
			variants: ['400', '700'],
		},
		'Bonheur Royale': {
			variants: ['400'],
		},
		Gupter: {
			variants: ['400', '500', '700'],
		},
		'Kdam Thmor Pro': {
			variants: ['400'],
		},
		Astloch: {
			variants: ['400', '700'],
		},
		Nabla: {
			variants: ['400'],
		},
		Foldit: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Dai Banna SIL': {
			variants: ['300', '400', '500', '600', '700'],
		},
		Neonderthaw: {
			variants: ['400'],
		},
		'Rubik Glitch': {
			variants: ['400'],
		},
		'Noto Sans Adlam Unjoined': {
			variants: ['400', '500', '600', '700'],
		},
		Ysabeau: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Nova Oval': {
			variants: ['400'],
		},
		'Mea Culpa': {
			variants: ['400'],
		},
		'Mr Bedfort': {
			variants: ['400'],
		},
		Lacquer: {
			variants: ['400'],
		},
		Aubrey: {
			variants: ['400'],
		},
		'Vina Sans': {
			variants: ['400'],
		},
		Butcherman: {
			variants: ['400'],
		},
		'Bungee Spice': {
			variants: ['400'],
		},
		'Ysabeau Office': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Noto Serif Gujarati': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Ballet: {
			variants: ['400'],
		},
		'Climate Crisis': {
			variants: ['400'],
		},
		'Bruno Ace': {
			variants: ['400'],
		},
		'Monomaniac One': {
			variants: ['400'],
		},
		'Rubik Beastly': {
			variants: ['400'],
		},
		'Gentium Book Plus': {
			variants: ['400', '700'],
		},
		'GFS Neohellenic': {
			variants: ['400', '700'],
		},
		'Lexend Tera': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Ysabeau SC': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Babylonica: {
			variants: ['400'],
		},
		Truculenta: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Noto Sans Thai Looped': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Ruge Boogie': {
			variants: ['400'],
		},
		'Noto Serif Khmer': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Anek Gurmukhi': {
			variants: ['100', '200', '300', '400', '500', '600', '700', '800'],
		},
		Chenla: {
			variants: ['400'],
		},
		'Londrina Sketch': {
			variants: ['400'],
		},
		'Rubik Distressed': {
			variants: ['400'],
		},
		Taprom: {
			variants: ['400'],
		},
		Caramel: {
			variants: ['400'],
		},
		'Tilt Neon': {
			variants: ['400'],
		},
		'Gideon Roman': {
			variants: ['400'],
		},
		Fruktur: {
			variants: ['400'],
		},
		'Tai Heritage Pro': {
			variants: ['400', '700'],
		},
		'Cairo Play': {
			variants: ['200', '300', '400', '500', '600', '700', '800', '900'],
		},
		Gwendolyn: {
			variants: ['400', '700'],
		},
		'IM Fell Double Pica SC': {
			variants: ['400'],
		},
		'Sofadi One': {
			variants: ['400'],
		},
		'Noto Sans Meetei Mayek': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Martian Mono': {
			variants: ['100', '200', '300', '400', '500', '600', '700', '800'],
		},
		Bonbon: {
			variants: ['400'],
		},
		Vibes: {
			variants: ['400'],
		},
		'Snowburst One': {
			variants: ['400'],
		},
		'Nova Cut': {
			variants: ['400'],
		},
		'Imperial Script': {
			variants: ['400'],
		},
		'Rubik Puddles': {
			variants: ['400'],
		},
		'Noto Serif Khojki': {
			variants: ['400', '500', '600', '700'],
		},
		'Koh Santepheap': {
			variants: ['100', '300', '400', '700', '900'],
		},
		Dhurjati: {
			variants: ['400'],
		},
		'Darumadrop One': {
			variants: ['400'],
		},
		'Yuji Boku': {
			variants: ['400'],
		},
		Lugrasimo: {
			variants: ['400'],
		},
		Updock: {
			variants: ['400'],
		},
		Hubballi: {
			variants: ['400'],
		},
		Lunasima: {
			variants: ['400', '700'],
		},
		Finlandica: {
			variants: ['400', '500', '600', '700'],
		},
		'Nova Script': {
			variants: ['400'],
		},
		Suravaram: {
			variants: ['400'],
		},
		'Big Shoulders Inline Text': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Noto Serif Tangut': {
			variants: ['400'],
		},
		Comme: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Estonia: {
			variants: ['400'],
		},
		Moulpali: {
			variants: ['400'],
		},
		'Edu QLD Beginner': {
			variants: ['400', '500', '600', '700'],
		},
		Geostar: {
			variants: ['400'],
		},
		Uchen: {
			variants: ['400'],
		},
		'Rubik Bubbles': {
			variants: ['400'],
		},
		'Tiro Tamil': {
			variants: ['400'],
		},
		'Rubik Vinyl': {
			variants: ['400'],
		},
		'Miltonian Tattoo': {
			variants: ['400'],
		},
		Marhey: {
			variants: ['300', '400', '500', '600', '700'],
		},
		'Bacasime Antique': {
			variants: ['400'],
		},
		Miltonian: {
			variants: ['400'],
		},
		'Big Shoulders Inline Display': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Tourney: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Sevillana: {
			variants: ['400'],
		},
		'Island Moments': {
			variants: ['400'],
		},
		'Noto Sans Javanese': {
			variants: ['400', '500', '600', '700'],
		},
		'Luxurious Roman': {
			variants: ['400'],
		},
		Kablammo: {
			variants: ['400'],
		},
		'Edu NSW ACT Foundation': {
			variants: ['400', '500', '600', '700'],
		},
		'Anek Kannada': {
			variants: ['100', '200', '300', '400', '500', '600', '700', '800'],
		},
		'Blaka Hollow': {
			variants: ['400'],
		},
		Oi: {
			variants: ['400'],
		},
		'Alumni Sans Collegiate One': {
			variants: ['400'],
		},
		'Noto Sans Syriac Eastern': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Fleur De Leah': {
			variants: ['400'],
		},
		Blaka: {
			variants: ['400'],
		},
		'Anek Odia': {
			variants: ['100', '200', '300', '400', '500', '600', '700', '800'],
		},
		'Edu VIC WA NT Beginner': {
			variants: ['400', '500', '600', '700'],
		},
		'Aref Ruqaa Ink': {
			variants: ['400', '700'],
		},
		'Edu TAS Beginner': {
			variants: ['400', '500', '600', '700'],
		},
		'Redacted Script': {
			variants: ['300', '400', '700'],
		},
		'Konkhmer Sleokchher': {
			variants: ['400'],
		},
		'Noto Sans Cypro Minoan': {
			variants: ['400'],
		},
		'Alumni Sans Pinstripe': {
			variants: ['400'],
		},
		'Reem Kufi Ink': {
			variants: ['400'],
		},
		Sigmar: {
			variants: ['400'],
		},
		'Rubik Pixels': {
			variants: ['400'],
		},
		'Castoro Titling': {
			variants: ['400'],
		},
		Splash: {
			variants: ['400'],
		},
		'Noto Sans Coptic': {
			variants: ['400'],
		},
		Diphylleia: {
			variants: ['400'],
		},
		'Kolker Brush': {
			variants: ['400'],
		},
		'Noto Serif Ottoman Siyaq': {
			variants: ['400'],
		},
		'Bagel Fat One': {
			variants: ['400'],
		},
		Narnoor: {
			variants: ['400'],
		},
		'Rubik Spray Paint': {
			variants: ['400'],
		},
		'Zen Loop': {
			variants: ['400'],
		},
		'Send Flowers': {
			variants: ['400'],
		},
		'Rubik Iso': {
			variants: ['400'],
		},
		'Noto Sans Gurmukhi': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Noto Serif Tamil': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Noto Serif Myanmar': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Grechen Fuemen': {
			variants: ['400'],
		},
		'Libre Barcode EAN13 Text': {
			variants: ['400'],
		},
		'Noto Sans Adlam': {
			variants: ['400', '500', '600', '700'],
		},
		'Noto Serif Khitan Small Script': {
			variants: ['400'],
		},
		'Syne Tactile': {
			variants: ['400'],
		},
		'Tsukimi Rounded': {
			variants: ['300', '400', '500', '600', '700'],
		},
		'Rubik 80s Fade': {
			variants: ['400'],
		},
		'Flow Block': {
			variants: ['400'],
		},
		'Palette Mosaic': {
			variants: ['400'],
		},
		'Reem Kufi Fun': {
			variants: ['400', '500', '600', '700'],
		},
		Petemoss: {
			variants: ['400'],
		},
		Orbit: {
			variants: ['400'],
		},
		'Noto Rashi Hebrew': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Tiro Telugu': {
			variants: ['400'],
		},
		'Noto Serif Tibetan': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Yuji Mai': {
			variants: ['400'],
		},
		'Noto Serif Telugu': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Love Light': {
			variants: ['400'],
		},
		'Noto Serif Makasar': {
			variants: ['400'],
		},
		'Grey Qo': {
			variants: ['400'],
		},
		'Gajraj One': {
			variants: ['400'],
		},
		Hanalei: {
			variants: ['400'],
		},
		'Are You Serious': {
			variants: ['400'],
		},
		'Noto Sans Syloti Nagri': {
			variants: ['400'],
		},
		'Moirai One': {
			variants: ['400'],
		},
		Tapestry: {
			variants: ['400'],
		},
		'Slackside One': {
			variants: ['400'],
		},
		'Rubik Microbe': {
			variants: ['400'],
		},
		Warnes: {
			variants: ['400'],
		},
		'Noto Sans Mongolian': {
			variants: ['400'],
		},
		'Noto Sans Mro': {
			variants: ['400'],
		},
		Chokokutai: {
			variants: ['400'],
		},
		'Rubik Storm': {
			variants: ['400'],
		},
		'Noto Sans Indic Siyaq Numbers': {
			variants: ['400'],
		},
		'My Soul': {
			variants: ['400'],
		},
		'Noto Sans Cypriot': {
			variants: ['400'],
		},
		'Noto Sans Nag Mundari': {
			variants: ['400', '500', '600', '700'],
		},
		'Gasoek One': {
			variants: ['400'],
		},
		'Noto Serif Ethiopic': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Noto Sans Lepcha': {
			variants: ['400'],
		},
		'Noto Serif Ahom': {
			variants: ['400'],
		},
		Explora: {
			variants: ['400'],
		},
		'Noto Sans Sora Sompeng': {
			variants: ['400', '500', '600', '700'],
		},
		'Noto Sans Vithkuqi': {
			variants: ['400', '500', '600', '700'],
		},
		'Grandiflora One': {
			variants: ['400'],
		},
		'Rock 3D': {
			variants: ['400'],
		},
		'Noto Sans Thaana': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Kings: {
			variants: ['400'],
		},
		'Noto Sans Old Hungarian': {
			variants: ['400'],
		},
		'Noto Music': {
			variants: ['400'],
		},
		'Twinkle Star': {
			variants: ['400'],
		},
		'Noto Sans Canadian Aboriginal': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		Shizuru: {
			variants: ['400'],
		},
		Cherish: {
			variants: ['400'],
		},
		Ole: {
			variants: ['400'],
		},
		'Noto Sans Lao Looped': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Noto Sans Nandinagari': {
			variants: ['400'],
		},
		'Puppies Play': {
			variants: ['400'],
		},
		'Noto Sans Carian': {
			variants: ['400'],
		},
		'Moo Lah Lah': {
			variants: ['400'],
		},
		'Noto Sans Old Italic': {
			variants: ['400'],
		},
		'Noto Sans Tagalog': {
			variants: ['400'],
		},
		'Rubik Marker Hatch': {
			variants: ['400'],
		},
		'Rubik Gemstones': {
			variants: ['400'],
		},
		'Noto Sans Miao': {
			variants: ['400'],
		},
		'M PLUS Code Latin': {
			variants: ['100', '200', '300', '400', '500', '600', '700'],
		},
		'Noto Sans Deseret': {
			variants: ['400'],
		},
		'Noto Sans Imperial Aramaic': {
			variants: ['400'],
		},
		'Rubik Burned': {
			variants: ['400'],
		},
		'Flow Rounded': {
			variants: ['400'],
		},
		'Noto Sans Cherokee': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Noto Sans Tai Viet': {
			variants: ['400'],
		},
		'Noto Sans Sundanese': {
			variants: ['400', '500', '600', '700'],
		},
		'Ingrid Darling': {
			variants: ['400'],
		},
		'Yuji Hentaigana Akari': {
			variants: ['400'],
		},
		Mingzat: {
			variants: ['400'],
		},
		'Noto Sans Tifinagh': {
			variants: ['400'],
		},
		'Noto Serif Toto': {
			variants: ['400', '500', '600', '700'],
		},
		'Noto Sans Tangsa': {
			variants: ['400', '500', '600', '700'],
		},
		'Blaka Ink': {
			variants: ['400'],
		},
		'Noto Sans Egyptian Hieroglyphs': {
			variants: ['400'],
		},
		'Noto Sans New Tai Lue': {
			variants: ['400', '500', '600', '700'],
		},
		'Noto Sans Kayah Li': {
			variants: ['400', '500', '600', '700'],
		},
		'Noto Sans Cham': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Rubik Maze': {
			variants: ['400'],
		},
		'Noto Sans Bamum': {
			variants: ['400', '500', '600', '700'],
		},
		'Noto Traditional Nushu': {
			variants: ['300', '400', '500', '600', '700'],
		},
		'Noto Sans Old Persian': {
			variants: ['400'],
		},
		'Noto Serif Gurmukhi': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Noto Sans Avestan': {
			variants: ['400'],
		},
		'Noto Sans Tai Tham': {
			variants: ['400', '500', '600', '700'],
		},
		'Noto Sans Ugaritic': {
			variants: ['400'],
		},
		'Noto Serif NP Hmong': {
			variants: ['400', '500', '600', '700'],
		},
		'Noto Sans Cuneiform': {
			variants: ['400'],
		},
		'Noto Sans Balinese': {
			variants: ['400', '500', '600', '700'],
		},
		'Noto Sans Marchen': {
			variants: ['400'],
		},
		'Noto Sans Yi': {
			variants: ['400'],
		},
		'Yuji Hentaigana Akebono': {
			variants: ['400'],
		},
		'Noto Sans Sharada': {
			variants: ['400'],
		},
		'Noto Sans Takri': {
			variants: ['400'],
		},
		'Noto Sans Brahmi': {
			variants: ['400'],
		},
		'Noto Sans Glagolitic': {
			variants: ['400'],
		},
		'Noto Sans Ol Chiki': {
			variants: ['400', '500', '600', '700'],
		},
		'Noto Sans Limbu': {
			variants: ['400'],
		},
		'Noto Sans Tagbanwa': {
			variants: ['400'],
		},
		'Noto Sans Inscriptional Pahlavi': {
			variants: ['400'],
		},
		'Noto Sans Hanunoo': {
			variants: ['400'],
		},
		'Noto Sans Pahawh Hmong': {
			variants: ['400'],
		},
		'Noto Sans Medefaidrin': {
			variants: ['400', '500', '600', '700'],
		},
		'Noto Sans Saurashtra': {
			variants: ['400'],
		},
		'Noto Serif Grantha': {
			variants: ['400'],
		},
		'Noto Serif Balinese': {
			variants: ['400'],
		},
		'Noto Sans Old Turkic': {
			variants: ['400'],
		},
		'Noto Sans Lisu': {
			variants: ['400', '500', '600', '700'],
		},
		'Noto Sans Buhid': {
			variants: ['400'],
		},
		'Noto Sans Osage': {
			variants: ['400'],
		},
		'Noto Sans Bassa Vah': {
			variants: ['400', '500', '600', '700'],
		},
		'Padyakke Expanded One': {
			variants: ['400'],
		},
		'Noto Sans Psalter Pahlavi': {
			variants: ['400'],
		},
		'Noto Sans Vai': {
			variants: ['400'],
		},
		'Noto Sans Mayan Numerals': {
			variants: ['400'],
		},
		'Noto Sans Tirhuta': {
			variants: ['400'],
		},
		'Noto Sans Chakma': {
			variants: ['400'],
		},
		'Noto Sans Mende Kikakui': {
			variants: ['400'],
		},
		'Noto Sans Khudawadi': {
			variants: ['400'],
		},
		'Noto Sans Tai Le': {
			variants: ['400'],
		},
		'Noto Sans Newa': {
			variants: ['400'],
		},
		'Noto Serif Oriya': {
			variants: ['400', '500', '600', '700'],
		},
		'Noto Sans Buginese': {
			variants: ['400'],
		},
		'Noto Sans Bhaiksuki': {
			variants: ['400'],
		},
		'Noto Sans Palmyrene': {
			variants: ['400'],
		},
		'Noto Sans Masaram Gondi': {
			variants: ['400'],
		},
		'Noto Sans Modi': {
			variants: ['400'],
		},
		'Noto Sans Lydian': {
			variants: ['400'],
		},
		'Noto Serif Yezidi': {
			variants: ['400', '500', '600', '700'],
		},
		'Noto Sans Warang Citi': {
			variants: ['400'],
		},
		'Noto Sans Hatran': {
			variants: ['400'],
		},
		'Noto Sans Rejang': {
			variants: ['400'],
		},
		'Noto Sans Shavian': {
			variants: ['400'],
		},
		'Noto Sans Zanabazar Square': {
			variants: ['400'],
		},
		'Noto Sans Phoenician': {
			variants: ['400'],
		},
		'Noto Sans Siddham': {
			variants: ['400'],
		},
		'Noto Sans Lycian': {
			variants: ['400'],
		},
		'Noto Sans Inscriptional Parthian': {
			variants: ['400'],
		},
		'Noto Sans Grantha': {
			variants: ['400'],
		},
		'Noto Sans Wancho': {
			variants: ['400'],
		},
		'Noto Serif Dogra': {
			variants: ['400'],
		},
		'Noto Sans Batak': {
			variants: ['400'],
		},
		'Noto Sans Old South Arabian': {
			variants: ['400'],
		},
		'Noto Sans Linear A': {
			variants: ['400'],
		},
		'Noto Sans SignWriting': {
			variants: ['400'],
		},
		'Noto Sans Old North Arabian': {
			variants: ['400'],
		},
		'Noto Sans Osmanya': {
			variants: ['400'],
		},
		'Noto Sans Syriac': {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'Noto Sans Runic': {
			variants: ['400'],
		},
		'Noto Sans Caucasian Albanian': {
			variants: ['400'],
		},
		'Noto Sans Khojki': {
			variants: ['400'],
		},
		'Noto Sans Kaithi': {
			variants: ['400'],
		},
		'Noto Sans Tamil Supplement': {
			variants: ['400'],
		},
		'Noto Sans Gunjala Gondi': {
			variants: ['400'],
		},
		'Noto Sans Ogham': {
			variants: ['400'],
		},
		'Noto Sans Mandaic': {
			variants: ['400'],
		},
		'Noto Sans Hanifi Rohingya': {
			variants: ['400', '500', '600', '700'],
		},
		'Noto Sans Old Sogdian': {
			variants: ['400'],
		},
		'Noto Sans Elymaic': {
			variants: ['400'],
		},
		'Noto Sans NKo': {
			variants: ['400'],
		},
		'Noto Sans Duployan': {
			variants: ['400', '700'],
		},
		'Noto Sans Kharoshthi': {
			variants: ['400'],
		},
		'Noto Sans Nushu': {
			variants: ['400'],
		},
		'Noto Sans Old Permic': {
			variants: ['400'],
		},
		'Noto Sans Linear B': {
			variants: ['400'],
		},
		'Noto Sans Elbasan': {
			variants: ['400'],
		},
		'Noto Sans Soyombo': {
			variants: ['400'],
		},
		'Noto Sans Pau Cin Hau': {
			variants: ['400'],
		},
		'Noto Sans Phags Pa': {
			variants: ['400'],
		},
		'Noto Sans Nabataean': {
			variants: ['400'],
		},
		'Noto Sans Manichaean': {
			variants: ['400'],
		},
		'Noto Sans Meroitic': {
			variants: ['400'],
		},
		'Noto Sans Sogdian': {
			variants: ['400'],
		},
		'Noto Sans Mahajani': {
			variants: ['400'],
		},
		Wavefont: {
			variants: [
				'100',
				'200',
				'300',
				'400',
				'500',
				'600',
				'700',
				'800',
				'900',
			],
		},
		'ADLaM Display': {
			variants: ['400'],
		},
	},
	families: [
		{
			label: 'Roboto',
			value: 'Roboto',
		},
		{
			label: 'Open Sans',
			value: 'Open Sans',
		},
		{
			label: 'Noto Sans JP',
			value: 'Noto Sans JP',
		},
		{
			label: 'Montserrat',
			value: 'Montserrat',
		},
		{
			label: 'Lato',
			value: 'Lato',
		},
		{
			label: 'Poppins',
			value: 'Poppins',
		},
		{
			label: 'Roboto Condensed',
			value: 'Roboto Condensed',
		},
		{
			label: 'Material Icons',
			value: 'Material Icons',
		},
		{
			label: 'Inter',
			value: 'Inter',
		},
		{
			label: 'Roboto Mono',
			value: 'Roboto Mono',
		},
		{
			label: 'Oswald',
			value: 'Oswald',
		},
		{
			label: 'Raleway',
			value: 'Raleway',
		},
		{
			label: 'Noto Sans',
			value: 'Noto Sans',
		},
		{
			label: 'Nunito Sans',
			value: 'Nunito Sans',
		},
		{
			label: 'Roboto Slab',
			value: 'Roboto Slab',
		},
		{
			label: 'Ubuntu',
			value: 'Ubuntu',
		},
		{
			label: 'Nunito',
			value: 'Nunito',
		},
		{
			label: 'Playfair Display',
			value: 'Playfair Display',
		},
		{
			label: 'Merriweather',
			value: 'Merriweather',
		},
		{
			label: 'Rubik',
			value: 'Rubik',
		},
		{
			label: 'PT Sans',
			value: 'PT Sans',
		},
		{
			label: 'Noto Sans KR',
			value: 'Noto Sans KR',
		},
		{
			label: 'Kanit',
			value: 'Kanit',
		},
		{
			label: 'Work Sans',
			value: 'Work Sans',
		},
		{
			label: 'Lora',
			value: 'Lora',
		},
		{
			label: 'Mukta',
			value: 'Mukta',
		},
		{
			label: 'Noto Sans TC',
			value: 'Noto Sans TC',
		},
		{
			label: 'Fira Sans',
			value: 'Fira Sans',
		},
		{
			label: 'Quicksand',
			value: 'Quicksand',
		},
		{
			label: 'Barlow',
			value: 'Barlow',
		},
		{
			label: 'DM Sans',
			value: 'DM Sans',
		},
		{
			label: 'Mulish',
			value: 'Mulish',
		},
		{
			label: 'Heebo',
			value: 'Heebo',
		},
		{
			label: 'IBM Plex Sans',
			value: 'IBM Plex Sans',
		},
		{
			label: 'Inconsolata',
			value: 'Inconsolata',
		},
		{
			label: 'PT Serif',
			value: 'PT Serif',
		},
		{
			label: 'Titillium Web',
			value: 'Titillium Web',
		},
		{
			label: 'Noto Serif',
			value: 'Noto Serif',
		},
		{
			label: 'Manrope',
			value: 'Manrope',
		},
		{
			label: 'Libre Franklin',
			value: 'Libre Franklin',
		},
		{
			label: 'Karla',
			value: 'Karla',
		},
		{
			label: 'Hind Siliguri',
			value: 'Hind Siliguri',
		},
		{
			label: 'Nanum Gothic',
			value: 'Nanum Gothic',
		},
		{
			label: 'Josefin Sans',
			value: 'Josefin Sans',
		},
		{
			label: 'Material Icons Outlined',
			value: 'Material Icons Outlined',
		},
		{
			label: 'Noto Color Emoji',
			value: 'Noto Color Emoji',
		},
		{
			label: 'Arimo',
			value: 'Arimo',
		},
		{
			label: 'Libre Baskerville',
			value: 'Libre Baskerville',
		},
		{
			label: 'Dosis',
			value: 'Dosis',
		},
		{
			label: 'PT Sans Narrow',
			value: 'PT Sans Narrow',
		},
		{
			label: 'Bebas Neue',
			value: 'Bebas Neue',
		},
		{
			label: 'Oxygen',
			value: 'Oxygen',
		},
		{
			label: 'Bitter',
			value: 'Bitter',
		},
		{
			label: 'Cabin',
			value: 'Cabin',
		},
		{
			label: 'Material Symbols Outlined',
			value: 'Material Symbols Outlined',
		},
		{
			label: 'Abel',
			value: 'Abel',
		},
		{
			label: 'Dancing Script',
			value: 'Dancing Script',
		},
		{
			label: 'Anton',
			value: 'Anton',
		},
		{
			label: 'Source Code Pro',
			value: 'Source Code Pro',
		},
		{
			label: 'Cairo',
			value: 'Cairo',
		},
		{
			label: 'Maven Pro',
			value: 'Maven Pro',
		},
		{
			label: 'EB Garamond',
			value: 'EB Garamond',
		},
		{
			label: 'Hind',
			value: 'Hind',
		},
		{
			label: 'Assistant',
			value: 'Assistant',
		},
		{
			label: 'Noto Sans SC',
			value: 'Noto Sans SC',
		},
		{
			label: 'Barlow Condensed',
			value: 'Barlow Condensed',
		},
		{
			label: 'Jost',
			value: 'Jost',
		},
		{
			label: 'Rajdhani',
			value: 'Rajdhani',
		},
		{
			label: 'Pacifico',
			value: 'Pacifico',
		},
		{
			label: 'Noto Serif JP',
			value: 'Noto Serif JP',
		},
		{
			label: 'Prompt',
			value: 'Prompt',
		},
		{
			label: 'Exo 2',
			value: 'Exo 2',
		},
		{
			label: 'Crimson Text',
			value: 'Crimson Text',
		},
		{
			label: 'Lobster',
			value: 'Lobster',
		},
		{
			label: 'Space Grotesk',
			value: 'Space Grotesk',
		},
		{
			label: 'Teko',
			value: 'Teko',
		},
		{
			label: 'Signika Negative',
			value: 'Signika Negative',
		},
		{
			label: 'Fjalla One',
			value: 'Fjalla One',
		},
		{
			label: 'Public Sans',
			value: 'Public Sans',
		},
		{
			label: 'Material Icons Round',
			value: 'Material Icons Round',
		},
		{
			label: 'Archivo',
			value: 'Archivo',
		},
		{
			label: 'Comfortaa',
			value: 'Comfortaa',
		},
		{
			label: 'Varela Round',
			value: 'Varela Round',
		},
		{
			label: 'Arvo',
			value: 'Arvo',
		},
		{
			label: 'Slabo 27px',
			value: 'Slabo 27px',
		},
		{
			label: 'Overpass',
			value: 'Overpass',
		},
		{
			label: 'M PLUS Rounded 1c',
			value: 'M PLUS Rounded 1c',
		},
		{
			label: 'IBM Plex Mono',
			value: 'IBM Plex Mono',
		},
		{
			label: 'Caveat',
			value: 'Caveat',
		},
		{
			label: 'Abril Fatface',
			value: 'Abril Fatface',
		},
		{
			label: 'Outfit',
			value: 'Outfit',
		},
		{
			label: 'Cormorant Garamond',
			value: 'Cormorant Garamond',
		},
		{
			label: 'Merriweather Sans',
			value: 'Merriweather Sans',
		},
		{
			label: 'Shadows Into Light',
			value: 'Shadows Into Light',
		},
		{
			label: 'Asap',
			value: 'Asap',
		},
		{
			label: 'Fira Sans Condensed',
			value: 'Fira Sans Condensed',
		},
		{
			label: 'Tajawal',
			value: 'Tajawal',
		},
		{
			label: 'Noto Sans Arabic',
			value: 'Noto Sans Arabic',
		},
		{
			label: 'Material Icons Sharp',
			value: 'Material Icons Sharp',
		},
		{
			label: 'Asap Condensed',
			value: 'Asap Condensed',
		},
		{
			label: 'Red Hat Display',
			value: 'Red Hat Display',
		},
		{
			label: 'Play',
			value: 'Play',
		},
		{
			label: 'Indie Flower',
			value: 'Indie Flower',
		},
		{
			label: 'Hind Madurai',
			value: 'Hind Madurai',
		},
		{
			label: 'Satisfy',
			value: 'Satisfy',
		},
		{
			label: 'Catamaran',
			value: 'Catamaran',
		},
		{
			label: 'Zilla Slab',
			value: 'Zilla Slab',
		},
		{
			label: 'Nanum Myeongjo',
			value: 'Nanum Myeongjo',
		},
		{
			label: 'Archivo Black',
			value: 'Archivo Black',
		},
		{
			label: 'Chakra Petch',
			value: 'Chakra Petch',
		},
		{
			label: 'Material Icons Two Tone',
			value: 'Material Icons Two Tone',
		},
		{
			label: 'Saira Condensed',
			value: 'Saira Condensed',
		},
		{
			label: 'Barlow Semi Condensed',
			value: 'Barlow Semi Condensed',
		},
		{
			label: 'Noto Sans HK',
			value: 'Noto Sans HK',
		},
		{
			label: 'Signika',
			value: 'Signika',
		},
		{
			label: 'Questrial',
			value: 'Questrial',
		},
		{
			label: 'Almarai',
			value: 'Almarai',
		},
		{
			label: 'Yanone Kaffeesatz',
			value: 'Yanone Kaffeesatz',
		},
		{
			label: 'Vollkorn',
			value: 'Vollkorn',
		},
		{
			label: 'IBM Plex Sans Arabic',
			value: 'IBM Plex Sans Arabic',
		},
		{
			label: 'Frank Ruhl Libre',
			value: 'Frank Ruhl Libre',
		},
		{
			label: 'IBM Plex Serif',
			value: 'IBM Plex Serif',
		},
		{
			label: 'M PLUS 1p',
			value: 'M PLUS 1p',
		},
		{
			label: 'Domine',
			value: 'Domine',
		},
		{
			label: 'Lilita One',
			value: 'Lilita One',
		},
		{
			label: 'Sarabun',
			value: 'Sarabun',
		},
		{
			label: 'Acme',
			value: 'Acme',
		},
		{
			label: 'Alegreya',
			value: 'Alegreya',
		},
		{
			label: 'Noto Kufi Arabic',
			value: 'Noto Kufi Arabic',
		},
		{
			label: 'Plus Jakarta Sans',
			value: 'Plus Jakarta Sans',
		},
		{
			label: 'Russo One',
			value: 'Russo One',
		},
		{
			label: 'Didact Gothic',
			value: 'Didact Gothic',
		},
		{
			label: 'Exo',
			value: 'Exo',
		},
		{
			label: 'Archivo Narrow',
			value: 'Archivo Narrow',
		},
		{
			label: 'Amatic SC',
			value: 'Amatic SC',
		},
		{
			label: 'Permanent Marker',
			value: 'Permanent Marker',
		},
		{
			label: 'Bree Serif',
			value: 'Bree Serif',
		},
		{
			label: 'Rowdies',
			value: 'Rowdies',
		},
		{
			label: 'Cinzel',
			value: 'Cinzel',
		},
		{
			label: 'DM Serif Display',
			value: 'DM Serif Display',
		},
		{
			label: 'Alegreya Sans',
			value: 'Alegreya Sans',
		},
		{
			label: 'ABeeZee',
			value: 'ABeeZee',
		},
		{
			label: 'Alfa Slab One',
			value: 'Alfa Slab One',
		},
		{
			label: 'Orbitron',
			value: 'Orbitron',
		},
		{
			label: 'Righteous',
			value: 'Righteous',
		},
		{
			label: 'Source Serif 4',
			value: 'Source Serif 4',
		},
		{
			label: 'Urbanist',
			value: 'Urbanist',
		},
		{
			label: 'Lexend',
			value: 'Lexend',
		},
		{
			label: 'Chivo',
			value: 'Chivo',
		},
		{
			label: 'Sora',
			value: 'Sora',
		},
		{
			label: 'Courgette',
			value: 'Courgette',
		},
		{
			label: 'Montserrat Alternates',
			value: 'Montserrat Alternates',
		},
		{
			label: 'Kalam',
			value: 'Kalam',
		},
		{
			label: 'Great Vibes',
			value: 'Great Vibes',
		},
		{
			label: 'Yantramanav',
			value: 'Yantramanav',
		},
		{
			label: 'Tinos',
			value: 'Tinos',
		},
		{
			label: 'Figtree',
			value: 'Figtree',
		},
		{
			label: 'Martel',
			value: 'Martel',
		},
		{
			label: 'Material Symbols Rounded',
			value: 'Material Symbols Rounded',
		},
		{
			label: 'Cantarell',
			value: 'Cantarell',
		},
		{
			label: 'Noticia Text',
			value: 'Noticia Text',
		},
		{
			label: 'Lobster Two',
			value: 'Lobster Two',
		},
		{
			label: 'Zeyada',
			value: 'Zeyada',
		},
		{
			label: 'Neuton',
			value: 'Neuton',
		},
		{
			label: 'Amiri',
			value: 'Amiri',
		},
		{
			label: 'Cardo',
			value: 'Cardo',
		},
		{
			label: 'Changa',
			value: 'Changa',
		},
		{
			label: 'Noto Serif TC',
			value: 'Noto Serif TC',
		},
		{
			label: 'Spectral',
			value: 'Spectral',
		},
		{
			label: 'PT Sans Caption',
			value: 'PT Sans Caption',
		},
		{
			label: 'Space Mono',
			value: 'Space Mono',
		},
		{
			label: 'Cormorant',
			value: 'Cormorant',
		},
		{
			label: 'Philosopher',
			value: 'Philosopher',
		},
		{
			label: 'Source Sans 3',
			value: 'Source Sans 3',
		},
		{
			label: 'Patua One',
			value: 'Patua One',
		},
		{
			label: 'Crete Round',
			value: 'Crete Round',
		},
		{
			label: 'Ubuntu Condensed',
			value: 'Ubuntu Condensed',
		},
		{
			label: 'Prata',
			value: 'Prata',
		},
		{
			label: 'Passion One',
			value: 'Passion One',
		},
		{
			label: 'Roboto Flex',
			value: 'Roboto Flex',
		},
		{
			label: 'Marcellus',
			value: 'Marcellus',
		},
		{
			label: 'Encode Sans',
			value: 'Encode Sans',
		},
		{
			label: 'Sawarabi Mincho',
			value: 'Sawarabi Mincho',
		},
		{
			label: 'Kaushan Script',
			value: 'Kaushan Script',
		},
		{
			label: 'Pathway Gothic One',
			value: 'Pathway Gothic One',
		},
		{
			label: 'Francois One',
			value: 'Francois One',
		},
		{
			label: 'Sacramento',
			value: 'Sacramento',
		},
		{
			label: 'Noto Serif KR',
			value: 'Noto Serif KR',
		},
		{
			label: 'Alice',
			value: 'Alice',
		},
		{
			label: 'Bodoni Moda',
			value: 'Bodoni Moda',
		},
		{
			label: 'Arsenal',
			value: 'Arsenal',
		},
		{
			label: 'Alata',
			value: 'Alata',
		},
		{
			label: 'Gloria Hallelujah',
			value: 'Gloria Hallelujah',
		},
		{
			label: 'El Messiri',
			value: 'El Messiri',
		},
		{
			label: 'Noto Sans Display',
			value: 'Noto Sans Display',
		},
		{
			label: 'Old Standard TT',
			value: 'Old Standard TT',
		},
		{
			label: 'Gruppo',
			value: 'Gruppo',
		},
		{
			label: 'Concert One',
			value: 'Concert One',
		},
		{
			label: 'Architects Daughter',
			value: 'Architects Daughter',
		},
		{
			label: 'Fira Sans Extra Condensed',
			value: 'Fira Sans Extra Condensed',
		},
		{
			label: 'Sanchez',
			value: 'Sanchez',
		},
		{
			label: 'Sawarabi Gothic',
			value: 'Sawarabi Gothic',
		},
		{
			label: 'Yellowtail',
			value: 'Yellowtail',
		},
		{
			label: 'Khand',
			value: 'Khand',
		},
		{
			label: 'Crimson Pro',
			value: 'Crimson Pro',
		},
		{
			label: 'Cookie',
			value: 'Cookie',
		},
		{
			label: 'Gothic A1',
			value: 'Gothic A1',
		},
		{
			label: 'Rokkitt',
			value: 'Rokkitt',
		},
		{
			label: 'Sen',
			value: 'Sen',
		},
		{
			label: 'Secular One',
			value: 'Secular One',
		},
		{
			label: 'Press Start 2P',
			value: 'Press Start 2P',
		},
		{
			label: 'Quattrocento Sans',
			value: 'Quattrocento Sans',
		},
		{
			label: 'Josefin Slab',
			value: 'Josefin Slab',
		},
		{
			label: 'Ubuntu Mono',
			value: 'Ubuntu Mono',
		},
		{
			label: 'Paytone One',
			value: 'Paytone One',
		},
		{
			label: 'Alegreya Sans SC',
			value: 'Alegreya Sans SC',
		},
		{
			label: 'IBM Plex Sans Condensed',
			value: 'IBM Plex Sans Condensed',
		},
		{
			label: 'Lexend Deca',
			value: 'Lexend Deca',
		},
		{
			label: 'Gelasio',
			value: 'Gelasio',
		},
		{
			label: 'Commissioner',
			value: 'Commissioner',
		},
		{
			label: 'Handlee',
			value: 'Handlee',
		},
		{
			label: 'Antic Slab',
			value: 'Antic Slab',
		},
		{
			label: 'Aleo',
			value: 'Aleo',
		},
		{
			label: 'Unna',
			value: 'Unna',
		},
		{
			label: 'Advent Pro',
			value: 'Advent Pro',
		},
		{
			label: 'Poiret One',
			value: 'Poiret One',
		},
		{
			label: 'Staatliches',
			value: 'Staatliches',
		},
		{
			label: 'Mate',
			value: 'Mate',
		},
		{
			label: 'Readex Pro',
			value: 'Readex Pro',
		},
		{
			label: 'Yeseva One',
			value: 'Yeseva One',
		},
		{
			label: 'Luckiest Guy',
			value: 'Luckiest Guy',
		},
		{
			label: 'Noto Sans Thai',
			value: 'Noto Sans Thai',
		},
		{
			label: 'Quattrocento',
			value: 'Quattrocento',
		},
		{
			label: 'Tenor Sans',
			value: 'Tenor Sans',
		},
		{
			label: 'Tangerine',
			value: 'Tangerine',
		},
		{
			label: 'Saira',
			value: 'Saira',
		},
		{
			label: 'Cuprum',
			value: 'Cuprum',
		},
		{
			label: 'Baloo 2',
			value: 'Baloo 2',
		},
		{
			label: 'Encode Sans Condensed',
			value: 'Encode Sans Condensed',
		},
		{
			label: 'Titan One',
			value: 'Titan One',
		},
		{
			label: 'Noto Naskh Arabic',
			value: 'Noto Naskh Arabic',
		},
		{
			label: 'Special Elite',
			value: 'Special Elite',
		},
		{
			label: 'Rubik Mono One',
			value: 'Rubik Mono One',
		},
		{
			label: 'Vidaloka',
			value: 'Vidaloka',
		},
		{
			label: 'News Cycle',
			value: 'News Cycle',
		},
		{
			label: 'Literata',
			value: 'Literata',
		},
		{
			label: 'Yatra One',
			value: 'Yatra One',
		},
		{
			label: 'Mate SC',
			value: 'Mate SC',
		},
		{
			label: 'Faustina',
			value: 'Faustina',
		},
		{
			label: 'Allura',
			value: 'Allura',
		},
		{
			label: 'Roboto Serif',
			value: 'Roboto Serif',
		},
		{
			label: 'Bangers',
			value: 'Bangers',
		},
		{
			label: 'Caladea',
			value: 'Caladea',
		},
		{
			label: 'Playfair Display SC',
			value: 'Playfair Display SC',
		},
		{
			label: 'Mukta Malar',
			value: 'Mukta Malar',
		},
		{
			label: 'Itim',
			value: 'Itim',
		},
		{
			label: 'Carter One',
			value: 'Carter One',
		},
		{
			label: 'Comic Neue',
			value: 'Comic Neue',
		},
		{
			label: 'Libre Caslon Text',
			value: 'Libre Caslon Text',
		},
		{
			label: 'Mitr',
			value: 'Mitr',
		},
		{
			label: 'Eczar',
			value: 'Eczar',
		},
		{
			label: 'Patrick Hand',
			value: 'Patrick Hand',
		},
		{
			label: 'Bungee',
			value: 'Bungee',
		},
		{
			label: 'Gochi Hand',
			value: 'Gochi Hand',
		},
		{
			label: 'Kosugi Maru',
			value: 'Kosugi Maru',
		},
		{
			label: 'Ropa Sans',
			value: 'Ropa Sans',
		},
		{
			label: 'Ultra',
			value: 'Ultra',
		},
		{
			label: 'Viga',
			value: 'Viga',
		},
		{
			label: 'Be Vietnam Pro',
			value: 'Be Vietnam Pro',
		},
		{
			label: 'Noto Sans Devanagari',
			value: 'Noto Sans Devanagari',
		},
		{
			label: 'Inter Tight',
			value: 'Inter Tight',
		},
		{
			label: 'Unbounded',
			value: 'Unbounded',
		},
		{
			label: 'Taviraj',
			value: 'Taviraj',
		},
		{
			label: 'Macondo',
			value: 'Macondo',
		},
		{
			label: 'PT Mono',
			value: 'PT Mono',
		},
		{
			label: 'Blinker',
			value: 'Blinker',
		},
		{
			label: 'Nanum Gothic Coding',
			value: 'Nanum Gothic Coding',
		},
		{
			label: 'Antonio',
			value: 'Antonio',
		},
		{
			label: 'Neucha',
			value: 'Neucha',
		},
		{
			label: 'Bai Jamjuree',
			value: 'Bai Jamjuree',
		},
		{
			label: 'Ruda',
			value: 'Ruda',
		},
		{
			label: 'DM Serif Text',
			value: 'DM Serif Text',
		},
		{
			label: 'Gudea',
			value: 'Gudea',
		},
		{
			label: 'Red Hat Text',
			value: 'Red Hat Text',
		},
		{
			label: 'Marck Script',
			value: 'Marck Script',
		},
		{
			label: 'Hind Vadodara',
			value: 'Hind Vadodara',
		},
		{
			label: 'Volkhov',
			value: 'Volkhov',
		},
		{
			label: 'Hammersmith One',
			value: 'Hammersmith One',
		},
		{
			label: 'League Spartan',
			value: 'League Spartan',
		},
		{
			label: 'Parisienne',
			value: 'Parisienne',
		},
		{
			label: 'Homemade Apple',
			value: 'Homemade Apple',
		},
		{
			label: 'Mr Dafoe',
			value: 'Mr Dafoe',
		},
		{
			label: 'Shrikhand',
			value: 'Shrikhand',
		},
		{
			label: 'Abhaya Libre',
			value: 'Abhaya Libre',
		},
		{
			label: 'Adamina',
			value: 'Adamina',
		},
		{
			label: 'Amaranth',
			value: 'Amaranth',
		},
		{
			label: 'Zen Kaku Gothic New',
			value: 'Zen Kaku Gothic New',
		},
		{
			label: 'Istok Web',
			value: 'Istok Web',
		},
		{
			label: 'Cousine',
			value: 'Cousine',
		},
		{
			label: 'Rock Salt',
			value: 'Rock Salt',
		},
		{
			label: 'Playball',
			value: 'Playball',
		},
		{
			label: 'Merienda',
			value: 'Merienda',
		},
		{
			label: 'Courier Prime',
			value: 'Courier Prime',
		},
		{
			label: 'Laila',
			value: 'Laila',
		},
		{
			label: 'Noto Serif SC',
			value: 'Noto Serif SC',
		},
		{
			label: 'Alex Brush',
			value: 'Alex Brush',
		},
		{
			label: 'Epilogue',
			value: 'Epilogue',
		},
		{
			label: 'Nanum Pen Script',
			value: 'Nanum Pen Script',
		},
		{
			label: 'Saira Semi Condensed',
			value: 'Saira Semi Condensed',
		},
		{
			label: 'Creepster',
			value: 'Creepster',
		},
		{
			label: 'Calistoga',
			value: 'Calistoga',
		},
		{
			label: 'Petrona',
			value: 'Petrona',
		},
		{
			label: 'Monoton',
			value: 'Monoton',
		},
		{
			label: 'Electrolize',
			value: 'Electrolize',
		},
		{
			label: 'Bad Script',
			value: 'Bad Script',
		},
		{
			label: 'Pridi',
			value: 'Pridi',
		},
		{
			label: 'Unica One',
			value: 'Unica One',
		},
		{
			label: 'Lalezar',
			value: 'Lalezar',
		},
		{
			label: 'Mada',
			value: 'Mada',
		},
		{
			label: 'Castoro',
			value: 'Castoro',
		},
		{
			label: 'Voltaire',
			value: 'Voltaire',
		},
		{
			label: 'BIZ UDPGothic',
			value: 'BIZ UDPGothic',
		},
		{
			label: 'Zen Maru Gothic',
			value: 'Zen Maru Gothic',
		},
		{
			label: 'Niramit',
			value: 'Niramit',
		},
		{
			label: 'Lusitana',
			value: 'Lusitana',
		},
		{
			label: 'Share Tech Mono',
			value: 'Share Tech Mono',
		},
		{
			label: 'Pangolin',
			value: 'Pangolin',
		},
		{
			label: 'Monda',
			value: 'Monda',
		},
		{
			label: 'Audiowide',
			value: 'Audiowide',
		},
		{
			label: 'Anonymous Pro',
			value: 'Anonymous Pro',
		},
		{
			label: 'Sriracha',
			value: 'Sriracha',
		},
		{
			label: 'Noto Serif Bengali',
			value: 'Noto Serif Bengali',
		},
		{
			label: 'Pragati Narrow',
			value: 'Pragati Narrow',
		},
		{
			label: 'Jura',
			value: 'Jura',
		},
		{
			label: 'Fira Mono',
			value: 'Fira Mono',
		},
		{
			label: 'Oleo Script',
			value: 'Oleo Script',
		},
		{
			label: 'Cabin Condensed',
			value: 'Cabin Condensed',
		},
		{
			label: 'Black Ops One',
			value: 'Black Ops One',
		},
		{
			label: 'Fugaz One',
			value: 'Fugaz One',
		},
		{
			label: 'BenchNine',
			value: 'BenchNine',
		},
		{
			label: 'Kumbh Sans',
			value: 'Kumbh Sans',
		},
		{
			label: 'Noto Sans Malayalam',
			value: 'Noto Sans Malayalam',
		},
		{
			label: 'Londrina Solid',
			value: 'Londrina Solid',
		},
		{
			label: 'Varela',
			value: 'Varela',
		},
		{
			label: 'Reem Kufi',
			value: 'Reem Kufi',
		},
		{
			label: 'Big Shoulders Display',
			value: 'Big Shoulders Display',
		},
		{
			label: 'Mandali',
			value: 'Mandali',
		},
		{
			label: 'Shippori Mincho',
			value: 'Shippori Mincho',
		},
		{
			label: 'Julius Sans One',
			value: 'Julius Sans One',
		},
		{
			label: 'Jaldi',
			value: 'Jaldi',
		},
		{
			label: 'Martel Sans',
			value: 'Martel Sans',
		},
		{
			label: 'Sansita',
			value: 'Sansita',
		},
		{
			label: 'Actor',
			value: 'Actor',
		},
		{
			label: 'Khula',
			value: 'Khula',
		},
		{
			label: 'Noto Sans Tamil',
			value: 'Noto Sans Tamil',
		},
		{
			label: 'Black Han Sans',
			value: 'Black Han Sans',
		},
		{
			label: 'Squada One',
			value: 'Squada One',
		},
		{
			label: 'Albert Sans',
			value: 'Albert Sans',
		},
		{
			label: 'Nothing You Could Do',
			value: 'Nothing You Could Do',
		},
		{
			label: 'Economica',
			value: 'Economica',
		},
		{
			label: 'Sarala',
			value: 'Sarala',
		},
		{
			label: 'Damion',
			value: 'Damion',
		},
		{
			label: 'Baskervville',
			value: 'Baskervville',
		},
		{
			label: 'Italianno',
			value: 'Italianno',
		},
		{
			label: 'Pontano Sans',
			value: 'Pontano Sans',
		},
		{
			label: 'Rufina',
			value: 'Rufina',
		},
		{
			label: 'Forum',
			value: 'Forum',
		},
		{
			label: 'Reenie Beanie',
			value: 'Reenie Beanie',
		},
		{
			label: 'Alef',
			value: 'Alef',
		},
		{
			label: 'Alatsi',
			value: 'Alatsi',
		},
		{
			label: 'Koulen',
			value: 'Koulen',
		},
		{
			label: 'Sorts Mill Goudy',
			value: 'Sorts Mill Goudy',
		},
		{
			label: 'Newsreader',
			value: 'Newsreader',
		},
		{
			label: 'Athiti',
			value: 'Athiti',
		},
		{
			label: 'Gilda Display',
			value: 'Gilda Display',
		},
		{
			label: 'Libre Barcode 39',
			value: 'Libre Barcode 39',
		},
		{
			label: 'Six Caps',
			value: 'Six Caps',
		},
		{
			label: 'Quantico',
			value: 'Quantico',
		},
		{
			label: 'Krub',
			value: 'Krub',
		},
		{
			label: 'Leckerli One',
			value: 'Leckerli One',
		},
		{
			label: 'Syne',
			value: 'Syne',
		},
		{
			label: 'Sintony',
			value: 'Sintony',
		},
		{
			label: 'Glegoo',
			value: 'Glegoo',
		},
		{
			label: 'Pinyon Script',
			value: 'Pinyon Script',
		},
		{
			label: 'Cutive Mono',
			value: 'Cutive Mono',
		},
		{
			label: 'VT323',
			value: 'VT323',
		},
		{
			label: 'Palanquin',
			value: 'Palanquin',
		},
		{
			label: 'Holtwood One SC',
			value: 'Holtwood One SC',
		},
		{
			label: 'Antic',
			value: 'Antic',
		},
		{
			label: 'Armata',
			value: 'Armata',
		},
		{
			label: 'Karma',
			value: 'Karma',
		},
		{
			label: 'DM Mono',
			value: 'DM Mono',
		},
		{
			label: 'Days One',
			value: 'Days One',
		},
		{
			label: 'Fraunces',
			value: 'Fraunces',
		},
		{
			label: 'Aclonica',
			value: 'Aclonica',
		},
		{
			label: 'Chewy',
			value: 'Chewy',
		},
		{
			label: 'Ramabhadra',
			value: 'Ramabhadra',
		},
		{
			label: 'Lemonada',
			value: 'Lemonada',
		},
		{
			label: 'Basic',
			value: 'Basic',
		},
		{
			label: 'Noto Sans Mono',
			value: 'Noto Sans Mono',
		},
		{
			label: 'Arapey',
			value: 'Arapey',
		},
		{
			label: 'Saira Extra Condensed',
			value: 'Saira Extra Condensed',
		},
		{
			label: 'Hind Guntur',
			value: 'Hind Guntur',
		},
		{
			label: 'STIX Two Text',
			value: 'STIX Two Text',
		},
		{
			label: 'Markazi Text',
			value: 'Markazi Text',
		},
		{
			label: 'Oxanium',
			value: 'Oxanium',
		},
		{
			label: 'Berkshire Swash',
			value: 'Berkshire Swash',
		},
		{
			label: 'K2D',
			value: 'K2D',
		},
		{
			label: 'Amita',
			value: 'Amita',
		},
		{
			label: 'Carrois Gothic',
			value: 'Carrois Gothic',
		},
		{
			label: 'Livvic',
			value: 'Livvic',
		},
		{
			label: 'Charm',
			value: 'Charm',
		},
		{
			label: 'Julee',
			value: 'Julee',
		},
		{
			label: 'Fredericka the Great',
			value: 'Fredericka the Great',
		},
		{
			label: 'Kreon',
			value: 'Kreon',
		},
		{
			label: 'Yrsa',
			value: 'Yrsa',
		},
		{
			label: 'Rammetto One',
			value: 'Rammetto One',
		},
		{
			label: 'JetBrains Mono',
			value: 'JetBrains Mono',
		},
		{
			label: 'Short Stack',
			value: 'Short Stack',
		},
		{
			label: 'Just Another Hand',
			value: 'Just Another Hand',
		},
		{
			label: 'Cabin Sketch',
			value: 'Cabin Sketch',
		},
		{
			label: 'Cantata One',
			value: 'Cantata One',
		},
		{
			label: 'PT Serif Caption',
			value: 'PT Serif Caption',
		},
		{
			label: 'Aldrich',
			value: 'Aldrich',
		},
		{
			label: 'Kiwi Maru',
			value: 'Kiwi Maru',
		},
		{
			label: 'Playfair',
			value: 'Playfair',
		},
		{
			label: 'Cinzel Decorative',
			value: 'Cinzel Decorative',
		},
		{
			label: 'Nanum Brush Script',
			value: 'Nanum Brush Script',
		},
		{
			label: 'Coda',
			value: 'Coda',
		},
		{
			label: 'GFS Didot',
			value: 'GFS Didot',
		},
		{
			label: 'Covered By Your Grace',
			value: 'Covered By Your Grace',
		},
		{
			label: 'Michroma',
			value: 'Michroma',
		},
		{
			label: 'Libre Bodoni',
			value: 'Libre Bodoni',
		},
		{
			label: 'Rancho',
			value: 'Rancho',
		},
		{
			label: 'La Belle Aurore',
			value: 'La Belle Aurore',
		},
		{
			label: 'Syncopate',
			value: 'Syncopate',
		},
		{
			label: 'BioRhyme',
			value: 'BioRhyme',
		},
		{
			label: 'Candal',
			value: 'Candal',
		},
		{
			label: 'Overlock',
			value: 'Overlock',
		},
		{
			label: 'Scada',
			value: 'Scada',
		},
		{
			label: 'Palanquin Dark',
			value: 'Palanquin Dark',
		},
		{
			label: 'Headland One',
			value: 'Headland One',
		},
		{
			label: 'Fira Code',
			value: 'Fira Code',
		},
		{
			label: 'Caveat Brush',
			value: 'Caveat Brush',
		},
		{
			label: 'Mrs Saint Delafield',
			value: 'Mrs Saint Delafield',
		},
		{
			label: 'Mali',
			value: 'Mali',
		},
		{
			label: 'Allerta Stencil',
			value: 'Allerta Stencil',
		},
		{
			label: 'Quintessential',
			value: 'Quintessential',
		},
		{
			label: 'Averia Serif Libre',
			value: 'Averia Serif Libre',
		},
		{
			label: 'Noto Sans Hebrew',
			value: 'Noto Sans Hebrew',
		},
		{
			label: 'Jua',
			value: 'Jua',
		},
		{
			label: 'Oranienbaum',
			value: 'Oranienbaum',
		},
		{
			label: 'Shadows Into Light Two',
			value: 'Shadows Into Light Two',
		},
		{
			label: 'Capriola',
			value: 'Capriola',
		},
		{
			label: 'Changa One',
			value: 'Changa One',
		},
		{
			label: 'Bowlby One SC',
			value: 'Bowlby One SC',
		},
		{
			label: 'Trirong',
			value: 'Trirong',
		},
		{
			label: 'Racing Sans One',
			value: 'Racing Sans One',
		},
		{
			label: 'Bellefair',
			value: 'Bellefair',
		},
		{
			label: 'Average Sans',
			value: 'Average Sans',
		},
		{
			label: 'Pathway Extreme',
			value: 'Pathway Extreme',
		},
		{
			label: 'Boogaloo',
			value: 'Boogaloo',
		},
		{
			label: 'Herr Von Muellerhoff',
			value: 'Herr Von Muellerhoff',
		},
		{
			label: 'Krona One',
			value: 'Krona One',
		},
		{
			label: 'Bevan',
			value: 'Bevan',
		},
		{
			label: 'Graduate',
			value: 'Graduate',
		},
		{
			label: 'Arizonia',
			value: 'Arizonia',
		},
		{
			label: 'Atkinson Hyperlegible',
			value: 'Atkinson Hyperlegible',
		},
		{
			label: 'Pattaya',
			value: 'Pattaya',
		},
		{
			label: 'Cormorant Infant',
			value: 'Cormorant Infant',
		},
		{
			label: 'Rozha One',
			value: 'Rozha One',
		},
		{
			label: 'Knewave',
			value: 'Knewave',
		},
		{
			label: 'Allerta',
			value: 'Allerta',
		},
		{
			label: 'Monsieur La Doulaise',
			value: 'Monsieur La Doulaise',
		},
		{
			label: 'Noto Nastaliq Urdu',
			value: 'Noto Nastaliq Urdu',
		},
		{
			label: 'Annie Use Your Telescope',
			value: 'Annie Use Your Telescope',
		},
		{
			label: 'Alexandria',
			value: 'Alexandria',
		},
		{
			label: 'Corben',
			value: 'Corben',
		},
		{
			label: 'Arbutus Slab',
			value: 'Arbutus Slab',
		},
		{
			label: 'Lustria',
			value: 'Lustria',
		},
		{
			label: 'Marcellus SC',
			value: 'Marcellus SC',
		},
		{
			label: 'Belleza',
			value: 'Belleza',
		},
		{
			label: 'Niconne',
			value: 'Niconne',
		},
		{
			label: 'Kurale',
			value: 'Kurale',
		},
		{
			label: 'Overpass Mono',
			value: 'Overpass Mono',
		},
		{
			label: 'Norican',
			value: 'Norican',
		},
		{
			label: 'Noto Serif Devanagari',
			value: 'Noto Serif Devanagari',
		},
		{
			label: 'Noto Serif Display',
			value: 'Noto Serif Display',
		},
		{
			label: 'Do Hyeon',
			value: 'Do Hyeon',
		},
		{
			label: 'Bubblegum Sans',
			value: 'Bubblegum Sans',
		},
		{
			label: 'Cedarville Cursive',
			value: 'Cedarville Cursive',
		},
		{
			label: 'Yesteryear',
			value: 'Yesteryear',
		},
		{
			label: 'Hanuman',
			value: 'Hanuman',
		},
		{
			label: 'Coming Soon',
			value: 'Coming Soon',
		},
		{
			label: 'Rubik Moonrocks',
			value: 'Rubik Moonrocks',
		},
		{
			label: 'Enriqueta',
			value: 'Enriqueta',
		},
		{
			label: 'Telex',
			value: 'Telex',
		},
		{
			label: 'Darker Grotesque',
			value: 'Darker Grotesque',
		},
		{
			label: 'Marvel',
			value: 'Marvel',
		},
		{
			label: 'Rambla',
			value: 'Rambla',
		},
		{
			label: 'Grandstander',
			value: 'Grandstander',
		},
		{
			label: 'Chonburi',
			value: 'Chonburi',
		},
		{
			label: 'Seaweed Script',
			value: 'Seaweed Script',
		},
		{
			label: 'Kristi',
			value: 'Kristi',
		},
		{
			label: 'Golos Text',
			value: 'Golos Text',
		},
		{
			label: 'Alegreya SC',
			value: 'Alegreya SC',
		},
		{
			label: 'Smokum',
			value: 'Smokum',
		},
		{
			label: 'Hanken Grotesk',
			value: 'Hanken Grotesk',
		},
		{
			label: 'Rye',
			value: 'Rye',
		},
		{
			label: 'Biryani',
			value: 'Biryani',
		},
		{
			label: 'Wallpoet',
			value: 'Wallpoet',
		},
		{
			label: 'Nobile',
			value: 'Nobile',
		},
		{
			label: 'Coustard',
			value: 'Coustard',
		},
		{
			label: 'Maitree',
			value: 'Maitree',
		},
		{
			label: 'Averia Libre',
			value: 'Averia Libre',
		},
		{
			label: 'Contrail One',
			value: 'Contrail One',
		},
		{
			label: 'Halant',
			value: 'Halant',
		},
		{
			label: 'Vollkorn SC',
			value: 'Vollkorn SC',
		},
		{
			label: 'Spinnaker',
			value: 'Spinnaker',
		},
		{
			label: 'Proza Libre',
			value: 'Proza Libre',
		},
		{
			label: 'Kosugi',
			value: 'Kosugi',
		},
		{
			label: 'Caudex',
			value: 'Caudex',
		},
		{
			label: 'Marmelad',
			value: 'Marmelad',
		},
		{
			label: 'Bungee Inline',
			value: 'Bungee Inline',
		},
		{
			label: 'Ovo',
			value: 'Ovo',
		},
		{
			label: 'Kameron',
			value: 'Kameron',
		},
		{
			label: 'Manjari',
			value: 'Manjari',
		},
		{
			label: 'Amiko',
			value: 'Amiko',
		},
		{
			label: 'IBM Plex Sans Thai',
			value: 'IBM Plex Sans Thai',
		},
		{
			label: 'M PLUS 1',
			value: 'M PLUS 1',
		},
		{
			label: 'Grand Hotel',
			value: 'Grand Hotel',
		},
		{
			label: 'Limelight',
			value: 'Limelight',
		},
		{
			label: 'Podkova',
			value: 'Podkova',
		},
		{
			label: 'Cambay',
			value: 'Cambay',
		},
		{
			label: 'Alike',
			value: 'Alike',
		},
		{
			label: 'Arya',
			value: 'Arya',
		},
		{
			label: 'Average',
			value: 'Average',
		},
		{
			label: 'Petit Formal Script',
			value: 'Petit Formal Script',
		},
		{
			label: 'Rochester',
			value: 'Rochester',
		},
		{
			label: 'Klee One',
			value: 'Klee One',
		},
		{
			label: 'Lateef',
			value: 'Lateef',
		},
		{
			label: 'Suez One',
			value: 'Suez One',
		},
		{
			label: 'Sofia',
			value: 'Sofia',
		},
		{
			label: 'Material Symbols Sharp',
			value: 'Material Symbols Sharp',
		},
		{
			label: 'Henny Penny',
			value: 'Henny Penny',
		},
		{
			label: 'Fredoka',
			value: 'Fredoka',
		},
		{
			label: 'Pirata One',
			value: 'Pirata One',
		},
		{
			label: 'Aladin',
			value: 'Aladin',
		},
		{
			label: 'B612',
			value: 'B612',
		},
		{
			label: 'Mochiy Pop One',
			value: 'Mochiy Pop One',
		},
		{
			label: 'Balsamiq Sans',
			value: 'Balsamiq Sans',
		},
		{
			label: 'Delius',
			value: 'Delius',
		},
		{
			label: 'Schoolbell',
			value: 'Schoolbell',
		},
		{
			label: 'Brygada 1918',
			value: 'Brygada 1918',
		},
		{
			label: 'Shippori Mincho B1',
			value: 'Shippori Mincho B1',
		},
		{
			label: 'Judson',
			value: 'Judson',
		},
		{
			label: 'Magra',
			value: 'Magra',
		},
		{
			label: 'Miriam Libre',
			value: 'Miriam Libre',
		},
		{
			label: 'League Gothic',
			value: 'League Gothic',
		},
		{
			label: 'Trykker',
			value: 'Trykker',
		},
		{
			label: 'Irish Grover',
			value: 'Irish Grover',
		},
		{
			label: 'Thasadith',
			value: 'Thasadith',
		},
		{
			label: 'Cormorant Upright',
			value: 'Cormorant Upright',
		},
		{
			label: 'Amethysta',
			value: 'Amethysta',
		},
		{
			label: 'Hepta Slab',
			value: 'Hepta Slab',
		},
		{
			label: 'Quando',
			value: 'Quando',
		},
		{
			label: 'Georama',
			value: 'Georama',
		},
		{
			label: 'Rasa',
			value: 'Rasa',
		},
		{
			label: 'Trocchi',
			value: 'Trocchi',
		},
		{
			label: 'ZCOOL QingKe HuangYou',
			value: 'ZCOOL QingKe HuangYou',
		},
		{
			label: 'Encode Sans Semi Condensed',
			value: 'Encode Sans Semi Condensed',
		},
		{
			label: 'Stardos Stencil',
			value: 'Stardos Stencil',
		},
		{
			label: 'Alumni Sans',
			value: 'Alumni Sans',
		},
		{
			label: 'Tillana',
			value: 'Tillana',
		},
		{
			label: 'Nixie One',
			value: 'Nixie One',
		},
		{
			label: 'Jockey One',
			value: 'Jockey One',
		},
		{
			label: 'B612 Mono',
			value: 'B612 Mono',
		},
		{
			label: 'Vazirmatn',
			value: 'Vazirmatn',
		},
		{
			label: 'Sofia Sans Condensed',
			value: 'Sofia Sans Condensed',
		},
		{
			label: 'Baloo Da 2',
			value: 'Baloo Da 2',
		},
		{
			label: 'Sniglet',
			value: 'Sniglet',
		},
		{
			label: 'Spectral SC',
			value: 'Spectral SC',
		},
		{
			label: 'Dawning of a New Day',
			value: 'Dawning of a New Day',
		},
		{
			label: 'Metrophobic',
			value: 'Metrophobic',
		},
		{
			label: 'Fahkwang',
			value: 'Fahkwang',
		},
		{
			label: 'Calligraffitti',
			value: 'Calligraffitti',
		},
		{
			label: 'Mallanna',
			value: 'Mallanna',
		},
		{
			label: 'NTR',
			value: 'NTR',
		},
		{
			label: 'Fauna One',
			value: 'Fauna One',
		},
		{
			label: 'Love Ya Like A Sister',
			value: 'Love Ya Like A Sister',
		},
		{
			label: 'Sunflower',
			value: 'Sunflower',
		},
		{
			label: 'Rakkas',
			value: 'Rakkas',
		},
		{
			label: 'Grenze Gotisch',
			value: 'Grenze Gotisch',
		},
		{
			label: 'Lemon',
			value: 'Lemon',
		},
		{
			label: 'Padauk',
			value: 'Padauk',
		},
		{
			label: 'Oxygen Mono',
			value: 'Oxygen Mono',
		},
		{
			label: 'Zen Old Mincho',
			value: 'Zen Old Mincho',
		},
		{
			label: 'Big Shoulders Text',
			value: 'Big Shoulders Text',
		},
		{
			label: 'Qwigley',
			value: 'Qwigley',
		},
		{
			label: 'Fjord One',
			value: 'Fjord One',
		},
		{
			label: 'Molengo',
			value: 'Molengo',
		},
		{
			label: 'Share',
			value: 'Share',
		},
		{
			label: 'IM Fell English SC',
			value: 'IM Fell English SC',
		},
		{
			label: 'Gurajada',
			value: 'Gurajada',
		},
		{
			label: 'Rosario',
			value: 'Rosario',
		},
		{
			label: 'Odibee Sans',
			value: 'Odibee Sans',
		},
		{
			label: 'Sofia Sans',
			value: 'Sofia Sans',
		},
		{
			label: 'Mansalva',
			value: 'Mansalva',
		},
		{
			label: 'Italiana',
			value: 'Italiana',
		},
		{
			label: 'Anek Malayalam',
			value: 'Anek Malayalam',
		},
		{
			label: 'Sigmar One',
			value: 'Sigmar One',
		},
		{
			label: 'Brawler',
			value: 'Brawler',
		},
		{
			label: 'Gabriela',
			value: 'Gabriela',
		},
		{
			label: 'Turret Road',
			value: 'Turret Road',
		},
		{
			label: 'Style Script',
			value: 'Style Script',
		},
		{
			label: 'IBM Plex Sans KR',
			value: 'IBM Plex Sans KR',
		},
		{
			label: 'David Libre',
			value: 'David Libre',
		},
		{
			label: 'IM Fell English',
			value: 'IM Fell English',
		},
		{
			label: 'Sansita Swashed',
			value: 'Sansita Swashed',
		},
		{
			label: 'Aref Ruqaa',
			value: 'Aref Ruqaa',
		},
		{
			label: 'Slabo 13px',
			value: 'Slabo 13px',
		},
		{
			label: 'Noto Sans Bengali',
			value: 'Noto Sans Bengali',
		},
		{
			label: 'IM Fell DW Pica',
			value: 'IM Fell DW Pica',
		},
		{
			label: 'Dela Gothic One',
			value: 'Dela Gothic One',
		},
		{
			label: 'Goudy Bookletter 1911',
			value: 'Goudy Bookletter 1911',
		},
		{
			label: 'Cormorant SC',
			value: 'Cormorant SC',
		},
		{
			label: 'Baloo Paaji 2',
			value: 'Baloo Paaji 2',
		},
		{
			label: 'Homenaje',
			value: 'Homenaje',
		},
		{
			label: 'Waiting for the Sunrise',
			value: 'Waiting for the Sunrise',
		},
		{
			label: 'Baloo Thambi 2',
			value: 'Baloo Thambi 2',
		},
		{
			label: 'Copse',
			value: 'Copse',
		},
		{
			label: 'Montserrat Subrayada',
			value: 'Montserrat Subrayada',
		},
		{
			label: 'Bentham',
			value: 'Bentham',
		},
		{
			label: 'Hahmlet',
			value: 'Hahmlet',
		},
		{
			label: 'Raleway Dots',
			value: 'Raleway Dots',
		},
		{
			label: 'Megrim',
			value: 'Megrim',
		},
		{
			label: 'Gravitas One',
			value: 'Gravitas One',
		},
		{
			label: 'Oleo Script Swash Caps',
			value: 'Oleo Script Swash Caps',
		},
		{
			label: 'Silkscreen',
			value: 'Silkscreen',
		},
		{
			label: 'Patrick Hand SC',
			value: 'Patrick Hand SC',
		},
		{
			label: 'Kaisei Decol',
			value: 'Kaisei Decol',
		},
		{
			label: 'Allison',
			value: 'Allison',
		},
		{
			label: 'Bowlby One',
			value: 'Bowlby One',
		},
		{
			label: 'KoHo',
			value: 'KoHo',
		},
		{
			label: 'Zen Kaku Gothic Antique',
			value: 'Zen Kaku Gothic Antique',
		},
		{
			label: 'Tenali Ramakrishna',
			value: 'Tenali Ramakrishna',
		},
		{
			label: 'Cutive',
			value: 'Cutive',
		},
		{
			label: 'Tulpen One',
			value: 'Tulpen One',
		},
		{
			label: 'Kelly Slab',
			value: 'Kelly Slab',
		},
		{
			label: 'UnifrakturMaguntia',
			value: 'UnifrakturMaguntia',
		},
		{
			label: 'Noto Sans Kannada',
			value: 'Noto Sans Kannada',
		},
		{
			label: 'Inder',
			value: 'Inder',
		},
		{
			label: 'ZCOOL XiaoWei',
			value: 'ZCOOL XiaoWei',
		},
		{
			label: 'Della Respira',
			value: 'Della Respira',
		},
		{
			label: 'Suranna',
			value: 'Suranna',
		},
		{
			label: 'Oooh Baby',
			value: 'Oooh Baby',
		},
		{
			label: 'Fondamento',
			value: 'Fondamento',
		},
		{
			label: 'Lexend Zetta',
			value: 'Lexend Zetta',
		},
		{
			label: 'Almendra',
			value: 'Almendra',
		},
		{
			label: 'Chelsea Market',
			value: 'Chelsea Market',
		},
		{
			label: 'Zen Antique',
			value: 'Zen Antique',
		},
		{
			label: 'Antic Didone',
			value: 'Antic Didone',
		},
		{
			label: 'Germania One',
			value: 'Germania One',
		},
		{
			label: 'Tomorrow',
			value: 'Tomorrow',
		},
		{
			label: 'Andika',
			value: 'Andika',
		},
		{
			label: 'Baloo Tamma 2',
			value: 'Baloo Tamma 2',
		},
		{
			label: 'Montez',
			value: 'Montez',
		},
		{
			label: 'Fanwood Text',
			value: 'Fanwood Text',
		},
		{
			label: 'Kadwa',
			value: 'Kadwa',
		},
		{
			label: 'Stint Ultra Condensed',
			value: 'Stint Ultra Condensed',
		},
		{
			label: 'Kodchasan',
			value: 'Kodchasan',
		},
		{
			label: 'Mr De Haviland',
			value: 'Mr De Haviland',
		},
		{
			label: 'Sedgwick Ave',
			value: 'Sedgwick Ave',
		},
		{
			label: 'Radley',
			value: 'Radley',
		},
		{
			label: 'Notable',
			value: 'Notable',
		},
		{
			label: 'Syne Mono',
			value: 'Syne Mono',
		},
		{
			label: 'Mirza',
			value: 'Mirza',
		},
		{
			label: 'Akshar',
			value: 'Akshar',
		},
		{
			label: 'Flamenco',
			value: 'Flamenco',
		},
		{
			label: 'Tilt Prism',
			value: 'Tilt Prism',
		},
		{
			label: 'Zen Kurenaido',
			value: 'Zen Kurenaido',
		},
		{
			label: 'Saira Stencil One',
			value: 'Saira Stencil One',
		},
		{
			label: 'Loved by the King',
			value: 'Loved by the King',
		},
		{
			label: 'Goldman',
			value: 'Goldman',
		},
		{
			label: 'Mukta Vaani',
			value: 'Mukta Vaani',
		},
		{
			label: 'Glory',
			value: 'Glory',
		},
		{
			label: 'Sulphur Point',
			value: 'Sulphur Point',
		},
		{
			label: 'Galada',
			value: 'Galada',
		},
		{
			label: 'Ma Shan Zheng',
			value: 'Ma Shan Zheng',
		},
		{
			label: 'Farro',
			value: 'Farro',
		},
		{
			label: 'Bungee Shade',
			value: 'Bungee Shade',
		},
		{
			label: 'Buenard',
			value: 'Buenard',
		},
		{
			label: 'RocknRoll One',
			value: 'RocknRoll One',
		},
		{
			label: 'Modak',
			value: 'Modak',
		},
		{
			label: 'Rouge Script',
			value: 'Rouge Script',
		},
		{
			label: 'Harmattan',
			value: 'Harmattan',
		},
		{
			label: 'Oregano',
			value: 'Oregano',
		},
		{
			label: 'Bellota Text',
			value: 'Bellota Text',
		},
		{
			label: 'Cambo',
			value: 'Cambo',
		},
		{
			label: 'BhuTuka Expanded One',
			value: 'BhuTuka Expanded One',
		},
		{
			label: 'Original Surfer',
			value: 'Original Surfer',
		},
		{
			label: 'Alike Angular',
			value: 'Alike Angular',
		},
		{
			label: 'Noto Sans Sinhala',
			value: 'Noto Sans Sinhala',
		},
		{
			label: 'Mouse Memoirs',
			value: 'Mouse Memoirs',
		},
		{
			label: 'Kite One',
			value: 'Kite One',
		},
		{
			label: 'Chivo Mono',
			value: 'Chivo Mono',
		},
		{
			label: 'Vesper Libre',
			value: 'Vesper Libre',
		},
		{
			label: 'Encode Sans Expanded',
			value: 'Encode Sans Expanded',
		},
		{
			label: 'Dokdo',
			value: 'Dokdo',
		},
		{
			label: 'Jomhuria',
			value: 'Jomhuria',
		},
		{
			label: 'Pompiere',
			value: 'Pompiere',
		},
		{
			label: 'Azeret Mono',
			value: 'Azeret Mono',
		},
		{
			label: 'DotGothic16',
			value: 'DotGothic16',
		},
		{
			label: 'Anuphan',
			value: 'Anuphan',
		},
		{
			label: 'Baloo Chettan 2',
			value: 'Baloo Chettan 2',
		},
		{
			label: 'Poly',
			value: 'Poly',
		},
		{
			label: 'Ms Madi',
			value: 'Ms Madi',
		},
		{
			label: 'Supermercado One',
			value: 'Supermercado One',
		},
		{
			label: 'Nova Mono',
			value: 'Nova Mono',
		},
		{
			label: 'Federo',
			value: 'Federo',
		},
		{
			label: 'Meddon',
			value: 'Meddon',
		},
		{
			label: 'Skranji',
			value: 'Skranji',
		},
		{
			label: 'Carme',
			value: 'Carme',
		},
		{
			label: 'Duru Sans',
			value: 'Duru Sans',
		},
		{
			label: 'Codystar',
			value: 'Codystar',
		},
		{
			label: 'Mukta Mahee',
			value: 'Mukta Mahee',
		},
		{
			label: 'Meera Inimai',
			value: 'Meera Inimai',
		},
		{
			label: 'Happy Monkey',
			value: 'Happy Monkey',
		},
		{
			label: 'McLaren',
			value: 'McLaren',
		},
		{
			label: 'Andada Pro',
			value: 'Andada Pro',
		},
		{
			label: 'Libre Barcode 39 Extended Text',
			value: 'Libre Barcode 39 Extended Text',
		},
		{
			label: 'Schibsted Grotesk',
			value: 'Schibsted Grotesk',
		},
		{
			label: 'Battambang',
			value: 'Battambang',
		},
		{
			label: 'Amarante',
			value: 'Amarante',
		},
		{
			label: 'Sue Ellen Francisco',
			value: 'Sue Ellen Francisco',
		},
		{
			label: 'Noto Sans Chorasmian',
			value: 'Noto Sans Chorasmian',
		},
		{
			label: 'Rampart One',
			value: 'Rampart One',
		},
		{
			label: 'Ceviche One',
			value: 'Ceviche One',
		},
		{
			label: 'Expletus Sans',
			value: 'Expletus Sans',
		},
		{
			label: 'Bakbak One',
			value: 'Bakbak One',
		},
		{
			label: 'Numans',
			value: 'Numans',
		},
		{
			label: 'Clicker Script',
			value: 'Clicker Script',
		},
		{
			label: 'Aboreto',
			value: 'Aboreto',
		},
		{
			label: 'Gugi',
			value: 'Gugi',
		},
		{
			label: 'Freehand',
			value: 'Freehand',
		},
		{
			label: 'Goblin One',
			value: 'Goblin One',
		},
		{
			label: 'Sofia Sans Semi Condensed',
			value: 'Sofia Sans Semi Condensed',
		},
		{
			label: 'Over the Rainbow',
			value: 'Over the Rainbow',
		},
		{
			label: 'Allan',
			value: 'Allan',
		},
		{
			label: 'Anaheim',
			value: 'Anaheim',
		},
		{
			label: 'Tienne',
			value: 'Tienne',
		},
		{
			label: 'Lekton',
			value: 'Lekton',
		},
		{
			label: 'Aguafina Script',
			value: 'Aguafina Script',
		},
		{
			label: 'Esteban',
			value: 'Esteban',
		},
		{
			label: 'Give You Glory',
			value: 'Give You Glory',
		},
		{
			label: 'Yusei Magic',
			value: 'Yusei Magic',
		},
		{
			label: 'Ledger',
			value: 'Ledger',
		},
		{
			label: 'Kufam',
			value: 'Kufam',
		},
		{
			label: 'Euphoria Script',
			value: 'Euphoria Script',
		},
		{
			label: 'BIZ UDPMincho',
			value: 'BIZ UDPMincho',
		},
		{
			label: 'Shojumaru',
			value: 'Shojumaru',
		},
		{
			label: 'Montaga',
			value: 'Montaga',
		},
		{
			label: 'Averia Sans Libre',
			value: 'Averia Sans Libre',
		},
		{
			label: 'Besley',
			value: 'Besley',
		},
		{
			label: 'Elsie',
			value: 'Elsie',
		},
		{
			label: 'Mako',
			value: 'Mako',
		},
		{
			label: 'Prosto One',
			value: 'Prosto One',
		},
		{
			label: 'Doppio One',
			value: 'Doppio One',
		},
		{
			label: 'Inknut Antiqua',
			value: 'Inknut Antiqua',
		},
		{
			label: 'Ephesis',
			value: 'Ephesis',
		},
		{
			label: 'Chau Philomene One',
			value: 'Chau Philomene One',
		},
		{
			label: 'Convergence',
			value: 'Convergence',
		},
		{
			label: 'Noto Sans Telugu',
			value: 'Noto Sans Telugu',
		},
		{
			label: 'Asul',
			value: 'Asul',
		},
		{
			label: 'Metamorphous',
			value: 'Metamorphous',
		},
		{
			label: 'Geo',
			value: 'Geo',
		},
		{
			label: 'Ibarra Real Nova',
			value: 'Ibarra Real Nova',
		},
		{
			label: 'Bricolage Grotesque',
			value: 'Bricolage Grotesque',
		},
		{
			label: 'Vast Shadow',
			value: 'Vast Shadow',
		},
		{
			label: 'Frijole',
			value: 'Frijole',
		},
		{
			label: 'Shantell Sans',
			value: 'Shantell Sans',
		},
		{
			label: 'Emilys Candy',
			value: 'Emilys Candy',
		},
		{
			label: 'Walter Turncoat',
			value: 'Walter Turncoat',
		},
		{
			label: 'Freckle Face',
			value: 'Freckle Face',
		},
		{
			label: 'Fasthand',
			value: 'Fasthand',
		},
		{
			label: 'Nova Round',
			value: 'Nova Round',
		},
		{
			label: 'Wendy One',
			value: 'Wendy One',
		},
		{
			label: 'Bayon',
			value: 'Bayon',
		},
		{
			label: 'Hurricane',
			value: 'Hurricane',
		},
		{
			label: 'Spline Sans',
			value: 'Spline Sans',
		},
		{
			label: 'Gloock',
			value: 'Gloock',
		},
		{
			label: 'Finger Paint',
			value: 'Finger Paint',
		},
		{
			label: 'Timmana',
			value: 'Timmana',
		},
		{
			label: 'Reggae One',
			value: 'Reggae One',
		},
		{
			label: 'Hi Melody',
			value: 'Hi Melody',
		},
		{
			label: 'Cormorant Unicase',
			value: 'Cormorant Unicase',
		},
		{
			label: 'Gaegu',
			value: 'Gaegu',
		},
		{
			label: 'Port Lligat Slab',
			value: 'Port Lligat Slab',
		},
		{
			label: 'Mogra',
			value: 'Mogra',
		},
		{
			label: 'Ruslan Display',
			value: 'Ruslan Display',
		},
		{
			label: 'Solway',
			value: 'Solway',
		},
		{
			label: 'Baumans',
			value: 'Baumans',
		},
		{
			label: 'Sail',
			value: 'Sail',
		},
		{
			label: 'Coiny',
			value: 'Coiny',
		},
		{
			label: 'Ruwudu',
			value: 'Ruwudu',
		},
		{
			label: 'Scope One',
			value: 'Scope One',
		},
		{
			label: 'M PLUS 2',
			value: 'M PLUS 2',
		},
		{
			label: 'Sarpanch',
			value: 'Sarpanch',
		},
		{
			label: 'Prociono',
			value: 'Prociono',
		},
		{
			label: 'Londrina Shadow',
			value: 'Londrina Shadow',
		},
		{
			label: 'Mountains of Christmas',
			value: 'Mountains of Christmas',
		},
		{
			label: 'Pavanam',
			value: 'Pavanam',
		},
		{
			label: 'Lexend Exa',
			value: 'Lexend Exa',
		},
		{
			label: 'Balthazar',
			value: 'Balthazar',
		},
		{
			label: 'Orienta',
			value: 'Orienta',
		},
		{
			label: 'Noto Sans Georgian',
			value: 'Noto Sans Georgian',
		},
		{
			label: 'Fresca',
			value: 'Fresca',
		},
		{
			label: 'Share Tech',
			value: 'Share Tech',
		},
		{
			label: 'Recursive',
			value: 'Recursive',
		},
		{
			label: 'Nokora',
			value: 'Nokora',
		},
		{
			label: 'Imprima',
			value: 'Imprima',
		},
		{
			label: 'Puritan',
			value: 'Puritan',
		},
		{
			label: 'Barriecito',
			value: 'Barriecito',
		},
		{
			label: 'Delius Unicase',
			value: 'Delius Unicase',
		},
		{
			label: 'Faster One',
			value: 'Faster One',
		},
		{
			label: 'Nerko One',
			value: 'Nerko One',
		},
		{
			label: 'Dynalight',
			value: 'Dynalight',
		},
		{
			label: 'Gluten',
			value: 'Gluten',
		},
		{
			label: 'Xanh Mono',
			value: 'Xanh Mono',
		},
		{
			label: 'Anek Tamil',
			value: 'Anek Tamil',
		},
		{
			label: 'Charmonman',
			value: 'Charmonman',
		},
		{
			label: 'Bilbo Swash Caps',
			value: 'Bilbo Swash Caps',
		},
		{
			label: 'Life Savers',
			value: 'Life Savers',
		},
		{
			label: 'Baloo Bhaina 2',
			value: 'Baloo Bhaina 2',
		},
		{
			label: 'Shalimar',
			value: 'Shalimar',
		},
		{
			label: 'Sono',
			value: 'Sono',
		},
		{
			label: 'Atma',
			value: 'Atma',
		},
		{
			label: 'Eater',
			value: 'Eater',
		},
		{
			label: 'Chango',
			value: 'Chango',
		},
		{
			label: 'Libre Barcode 128',
			value: 'Libre Barcode 128',
		},
		{
			label: 'Gemunu Libre',
			value: 'Gemunu Libre',
		},
		{
			label: 'Radio Canada',
			value: 'Radio Canada',
		},
		{
			label: 'Kaisei Tokumin',
			value: 'Kaisei Tokumin',
		},
		{
			label: 'Katibeh',
			value: 'Katibeh',
		},
		{
			label: 'Red Rose',
			value: 'Red Rose',
		},
		{
			label: 'Sonsie One',
			value: 'Sonsie One',
		},
		{
			label: 'Poller One',
			value: 'Poller One',
		},
		{
			label: 'Libre Caslon Display',
			value: 'Libre Caslon Display',
		},
		{
			label: 'Libre Barcode 39 Text',
			value: 'Libre Barcode 39 Text',
		},
		{
			label: 'Sumana',
			value: 'Sumana',
		},
		{
			label: 'Rubik Dirt',
			value: 'Rubik Dirt',
		},
		{
			label: 'Noto Serif Malayalam',
			value: 'Noto Serif Malayalam',
		},
		{
			label: 'Salsa',
			value: 'Salsa',
		},
		{
			label: 'Inria Serif',
			value: 'Inria Serif',
		},
		{
			label: 'Cherry Cream Soda',
			value: 'Cherry Cream Soda',
		},
		{
			label: 'Londrina Outline',
			value: 'Londrina Outline',
		},
		{
			label: 'Mina',
			value: 'Mina',
		},
		{
			label: 'Gamja Flower',
			value: 'Gamja Flower',
		},
		{
			label: 'Vibur',
			value: 'Vibur',
		},
		{
			label: 'ZCOOL KuaiLe',
			value: 'ZCOOL KuaiLe',
		},
		{
			label: 'Noto Sans Myanmar',
			value: 'Noto Sans Myanmar',
		},
		{
			label: 'Delius Swash Caps',
			value: 'Delius Swash Caps',
		},
		{
			label: 'Cherry Swash',
			value: 'Cherry Swash',
		},
		{
			label: 'League Script',
			value: 'League Script',
		},
		{
			label: 'Major Mono Display',
			value: 'Major Mono Display',
		},
		{
			label: 'Bellota',
			value: 'Bellota',
		},
		{
			label: 'Encode Sans Semi Expanded',
			value: 'Encode Sans Semi Expanded',
		},
		{
			label: 'Ranchers',
			value: 'Ranchers',
		},
		{
			label: 'Lexend Giga',
			value: 'Lexend Giga',
		},
		{
			label: 'Belgrano',
			value: 'Belgrano',
		},
		{
			label: 'Bigshot One',
			value: 'Bigshot One',
		},
		{
			label: 'Edu SA Beginner',
			value: 'Edu SA Beginner',
		},
		{
			label: 'Lexend Peta',
			value: 'Lexend Peta',
		},
		{
			label: 'Gayathri',
			value: 'Gayathri',
		},
		{
			label: 'Dongle',
			value: 'Dongle',
		},
		{
			label: 'MuseoModerno',
			value: 'MuseoModerno',
		},
		{
			label: 'Medula One',
			value: 'Medula One',
		},
		{
			label: 'Crafty Girls',
			value: 'Crafty Girls',
		},
		{
			label: 'Comforter Brush',
			value: 'Comforter Brush',
		},
		{
			label: 'Orelega One',
			value: 'Orelega One',
		},
		{
			label: 'Slackey',
			value: 'Slackey',
		},
		{
			label: 'Potta One',
			value: 'Potta One',
		},
		{
			label: 'Just Me Again Down Here',
			value: 'Just Me Again Down Here',
		},
		{
			label: 'Ranga',
			value: 'Ranga',
		},
		{
			label: 'Inria Sans',
			value: 'Inria Sans',
		},
		{
			label: 'Kranky',
			value: 'Kranky',
		},
		{
			label: 'Lovers Quarrel',
			value: 'Lovers Quarrel',
		},
		{
			label: 'Port Lligat Sans',
			value: 'Port Lligat Sans',
		},
		{
			label: 'IM Fell French Canon',
			value: 'IM Fell French Canon',
		},
		{
			label: 'Birthstone',
			value: 'Birthstone',
		},
		{
			label: 'Familjen Grotesk',
			value: 'Familjen Grotesk',
		},
		{
			label: 'Peralta',
			value: 'Peralta',
		},
		{
			label: 'Voces',
			value: 'Voces',
		},
		{
			label: 'Wix Madefor Display',
			value: 'Wix Madefor Display',
		},
		{
			label: 'Noto Serif Hebrew',
			value: 'Noto Serif Hebrew',
		},
		{
			label: 'Baloo Bhaijaan 2',
			value: 'Baloo Bhaijaan 2',
		},
		{
			label: 'Ribeye',
			value: 'Ribeye',
		},
		{
			label: 'Spicy Rice',
			value: 'Spicy Rice',
		},
		{
			label: 'Sura',
			value: 'Sura',
		},
		{
			label: 'Corinthia',
			value: 'Corinthia',
		},
		{
			label: 'Trade Winds',
			value: 'Trade Winds',
		},
		{
			label: 'Baloo Bhai 2',
			value: 'Baloo Bhai 2',
		},
		{
			label: 'Anek Telugu',
			value: 'Anek Telugu',
		},
		{
			label: 'Song Myung',
			value: 'Song Myung',
		},
		{
			label: 'Gantari',
			value: 'Gantari',
		},
		{
			label: 'Ruthie',
			value: 'Ruthie',
		},
		{
			label: 'Kaisei Opti',
			value: 'Kaisei Opti',
		},
		{
			label: 'Stick',
			value: 'Stick',
		},
		{
			label: 'Macondo Swash Caps',
			value: 'Macondo Swash Caps',
		},
		{
			label: 'Varta',
			value: 'Varta',
		},
		{
			label: 'The Girl Next Door',
			value: 'The Girl Next Door',
		},
		{
			label: 'Sree Krushnadevaraya',
			value: 'Sree Krushnadevaraya',
		},
		{
			label: 'Lily Script One',
			value: 'Lily Script One',
		},
		{
			label: 'Asar',
			value: 'Asar',
		},
		{
			label: 'Ramaraja',
			value: 'Ramaraja',
		},
		{
			label: 'Abyssinica SIL',
			value: 'Abyssinica SIL',
		},
		{
			label: 'Galdeano',
			value: 'Galdeano',
		},
		{
			label: 'Artifika',
			value: 'Artifika',
		},
		{
			label: 'Noto Sans Armenian',
			value: 'Noto Sans Armenian',
		},
		{
			label: 'Hachi Maru Pop',
			value: 'Hachi Maru Pop',
		},
		{
			label: 'Noto Sans Symbols',
			value: 'Noto Sans Symbols',
		},
		{
			label: 'Piazzolla',
			value: 'Piazzolla',
		},
		{
			label: 'Stylish',
			value: 'Stylish',
		},
		{
			label: 'Tilt Warp',
			value: 'Tilt Warp',
		},
		{
			label: 'Uncial Antiqua',
			value: 'Uncial Antiqua',
		},
		{
			label: 'Bubbler One',
			value: 'Bubbler One',
		},
		{
			label: 'IBM Plex Sans Thai Looped',
			value: 'IBM Plex Sans Thai Looped',
		},
		{
			label: 'Monofett',
			value: 'Monofett',
		},
		{
			label: 'Overlock SC',
			value: 'Overlock SC',
		},
		{
			label: 'Strait',
			value: 'Strait',
		},
		{
			label: 'Carrois Gothic SC',
			value: 'Carrois Gothic SC',
		},
		{
			label: 'Khmer',
			value: 'Khmer',
		},
		{
			label: 'Tauri',
			value: 'Tauri',
		},
		{
			label: 'Piedra',
			value: 'Piedra',
		},
		{
			label: 'UnifrakturCook',
			value: 'UnifrakturCook',
		},
		{
			label: 'Geologica',
			value: 'Geologica',
		},
		{
			label: 'Gowun Dodum',
			value: 'Gowun Dodum',
		},
		{
			label: 'Red Hat Mono',
			value: 'Red Hat Mono',
		},
		{
			label: 'Miniver',
			value: 'Miniver',
		},
		{
			label: 'Noto Serif Thai',
			value: 'Noto Serif Thai',
		},
		{
			label: 'IM Fell Double Pica',
			value: 'IM Fell Double Pica',
		},
		{
			label: 'Kotta One',
			value: 'Kotta One',
		},
		{
			label: 'Qwitcher Grypen',
			value: 'Qwitcher Grypen',
		},
		{
			label: 'Gotu',
			value: 'Gotu',
		},
		{
			label: 'Akaya Telivigala',
			value: 'Akaya Telivigala',
		},
		{
			label: 'Gafata',
			value: 'Gafata',
		},
		{
			label: 'Iceland',
			value: 'Iceland',
		},
		{
			label: 'Akronim',
			value: 'Akronim',
		},
		{
			label: 'Wire One',
			value: 'Wire One',
		},
		{
			label: 'Flow Circular',
			value: 'Flow Circular',
		},
		{
			label: 'Cute Font',
			value: 'Cute Font',
		},
		{
			label: 'Suwannaphum',
			value: 'Suwannaphum',
		},
		{
			label: 'Denk One',
			value: 'Denk One',
		},
		{
			label: 'Square Peg',
			value: 'Square Peg',
		},
		{
			label: 'Rationale',
			value: 'Rationale',
		},
		{
			label: 'Farsan',
			value: 'Farsan',
		},
		{
			label: 'Tiro Devanagari Hindi',
			value: 'Tiro Devanagari Hindi',
		},
		{
			label: 'Rum Raisin',
			value: 'Rum Raisin',
		},
		{
			label: 'Caprasimo',
			value: 'Caprasimo',
		},
		{
			label: 'Sahitya',
			value: 'Sahitya',
		},
		{
			label: 'Hina Mincho',
			value: 'Hina Mincho',
		},
		{
			label: 'Unlock',
			value: 'Unlock',
		},
		{
			label: 'East Sea Dokdo',
			value: 'East Sea Dokdo',
		},
		{
			label: 'Gowun Batang',
			value: 'Gowun Batang',
		},
		{
			label: 'Kulim Park',
			value: 'Kulim Park',
		},
		{
			label: 'Habibi',
			value: 'Habibi',
		},
		{
			label: 'Kavoon',
			value: 'Kavoon',
		},
		{
			label: 'Sofia Sans Extra Condensed',
			value: 'Sofia Sans Extra Condensed',
		},
		{
			label: 'Odor Mean Chey',
			value: 'Odor Mean Chey',
		},
		{
			label: 'Unkempt',
			value: 'Unkempt',
		},
		{
			label: 'Paprika',
			value: 'Paprika',
		},
		{
			label: 'Baloo Tammudu 2',
			value: 'Baloo Tammudu 2',
		},
		{
			label: 'Donegal One',
			value: 'Donegal One',
		},
		{
			label: 'Road Rage',
			value: 'Road Rage',
		},
		{
			label: 'Alkalami',
			value: 'Alkalami',
		},
		{
			label: 'Moul',
			value: 'Moul',
		},
		{
			label: 'Black And White Picture',
			value: 'Black And White Picture',
		},
		{
			label: 'Lexend Mega',
			value: 'Lexend Mega',
		},
		{
			label: 'IBM Plex Sans Devanagari',
			value: 'IBM Plex Sans Devanagari',
		},
		{
			label: 'Redressed',
			value: 'Redressed',
		},
		{
			label: 'Shanti',
			value: 'Shanti',
		},
		{
			label: 'Manuale',
			value: 'Manuale',
		},
		{
			label: 'Nova Square',
			value: 'Nova Square',
		},
		{
			label: 'Mystery Quest',
			value: 'Mystery Quest',
		},
		{
			label: 'Sancreek',
			value: 'Sancreek',
		},
		{
			label: 'Barrio',
			value: 'Barrio',
		},
		{
			label: 'Autour One',
			value: 'Autour One',
		},
		{
			label: 'Yuji Syuku',
			value: 'Yuji Syuku',
		},
		{
			label: 'Murecho',
			value: 'Murecho',
		},
		{
			label: 'Rosarivo',
			value: 'Rosarivo',
		},
		{
			label: 'Viaoda Libre',
			value: 'Viaoda Libre',
		},
		{
			label: 'BIZ UDGothic',
			value: 'BIZ UDGothic',
		},
		{
			label: 'Fontdiner Swanky',
			value: 'Fontdiner Swanky',
		},
		{
			label: 'Grape Nuts',
			value: 'Grape Nuts',
		},
		{
			label: 'Fragment Mono',
			value: 'Fragment Mono',
		},
		{
			label: 'IBM Plex Sans JP',
			value: 'IBM Plex Sans JP',
		},
		{
			label: 'Noto Sans Math',
			value: 'Noto Sans Math',
		},
		{
			label: 'Noto Sans Lao',
			value: 'Noto Sans Lao',
		},
		{
			label: 'Inspiration',
			value: 'Inspiration',
		},
		{
			label: 'Zen Dots',
			value: 'Zen Dots',
		},
		{
			label: 'Karantina',
			value: 'Karantina',
		},
		{
			label: 'Akatab',
			value: 'Akatab',
		},
		{
			label: 'Chathura',
			value: 'Chathura',
		},
		{
			label: 'Zhi Mang Xing',
			value: 'Zhi Mang Xing',
		},
		{
			label: 'Dorsa',
			value: 'Dorsa',
		},
		{
			label: 'Montagu Slab',
			value: 'Montagu Slab',
		},
		{
			label: 'Stoke',
			value: 'Stoke',
		},
		{
			label: 'Cantora One',
			value: 'Cantora One',
		},
		{
			label: 'Noto Emoji',
			value: 'Noto Emoji',
		},
		{
			label: 'Chicle',
			value: 'Chicle',
		},
		{
			label: 'Moon Dance',
			value: 'Moon Dance',
		},
		{
			label: 'Stalemate',
			value: 'Stalemate',
		},
		{
			label: 'Molle',
			value: 'Molle',
		},
		{
			label: 'Dekko',
			value: 'Dekko',
		},
		{
			label: 'Princess Sofia',
			value: 'Princess Sofia',
		},
		{
			label: 'Trispace',
			value: 'Trispace',
		},
		{
			label: 'Engagement',
			value: 'Engagement',
		},
		{
			label: 'WindSong',
			value: 'WindSong',
		},
		{
			label: 'Jomolhari',
			value: 'Jomolhari',
		},
		{
			label: 'Bilbo',
			value: 'Bilbo',
		},
		{
			label: 'Zilla Slab Highlight',
			value: 'Zilla Slab Highlight',
		},
		{
			label: 'Beth Ellen',
			value: 'Beth Ellen',
		},
		{
			label: 'Beau Rivage',
			value: 'Beau Rivage',
		},
		{
			label: 'Iceberg',
			value: 'Iceberg',
		},
		{
			label: 'Meow Script',
			value: 'Meow Script',
		},
		{
			label: 'Nova Flat',
			value: 'Nova Flat',
		},
		{
			label: 'Yaldevi',
			value: 'Yaldevi',
		},
		{
			label: 'Stint Ultra Expanded',
			value: 'Stint Ultra Expanded',
		},
		{
			label: 'Meie Script',
			value: 'Meie Script',
		},
		{
			label: 'IM Fell Great Primer',
			value: 'IM Fell Great Primer',
		},
		{
			label: 'Crushed',
			value: 'Crushed',
		},
		{
			label: 'Vujahday Script',
			value: 'Vujahday Script',
		},
		{
			label: 'MonteCarlo',
			value: 'MonteCarlo',
		},
		{
			label: 'Train One',
			value: 'Train One',
		},
		{
			label: 'Offside',
			value: 'Offside',
		},
		{
			label: 'Anek Devanagari',
			value: 'Anek Devanagari',
		},
		{
			label: 'Fenix',
			value: 'Fenix',
		},
		{
			label: 'Sarina',
			value: 'Sarina',
		},
		{
			label: 'Comforter',
			value: 'Comforter',
		},
		{
			label: 'Jolly Lodger',
			value: 'Jolly Lodger',
		},
		{
			label: 'Smooch Sans',
			value: 'Smooch Sans',
		},
		{
			label: 'Fuzzy Bubbles',
			value: 'Fuzzy Bubbles',
		},
		{
			label: 'Noto Serif Georgian',
			value: 'Noto Serif Georgian',
		},
		{
			label: 'Stalinist One',
			value: 'Stalinist One',
		},
		{
			label: 'Bigelow Rules',
			value: 'Bigelow Rules',
		},
		{
			label: 'Mrs Sheppards',
			value: 'Mrs Sheppards',
		},
		{
			label: 'Gulzar',
			value: 'Gulzar',
		},
		{
			label: 'Instrument Serif',
			value: 'Instrument Serif',
		},
		{
			label: 'Margarine',
			value: 'Margarine',
		},
		{
			label: 'Mochiy Pop P One',
			value: 'Mochiy Pop P One',
		},
		{
			label: 'MedievalSharp',
			value: 'MedievalSharp',
		},
		{
			label: 'Angkor',
			value: 'Angkor',
		},
		{
			label: 'Bona Nova',
			value: 'Bona Nova',
		},
		{
			label: 'Cagliostro',
			value: 'Cagliostro',
		},
		{
			label: 'Tiro Kannada',
			value: 'Tiro Kannada',
		},
		{
			label: 'Wellfleet',
			value: 'Wellfleet',
		},
		{
			label: 'New Rocker',
			value: 'New Rocker',
		},
		{
			label: 'Shippori Antique',
			value: 'Shippori Antique',
		},
		{
			label: 'Akaya Kanadaka',
			value: 'Akaya Kanadaka',
		},
		{
			label: 'Milonga',
			value: 'Milonga',
		},
		{
			label: 'Waterfall',
			value: 'Waterfall',
		},
		{
			label: 'Poor Story',
			value: 'Poor Story',
		},
		{
			label: 'Vampiro One',
			value: 'Vampiro One',
		},
		{
			label: 'Scheherazade New',
			value: 'Scheherazade New',
		},
		{
			label: 'Benne',
			value: 'Benne',
		},
		{
			label: 'Kaisei HarunoUmi',
			value: 'Kaisei HarunoUmi',
		},
		{
			label: 'Anek Bangla',
			value: 'Anek Bangla',
		},
		{
			label: 'REM',
			value: 'REM',
		},
		{
			label: 'Yomogi',
			value: 'Yomogi',
		},
		{
			label: 'Kavivanar',
			value: 'Kavivanar',
		},
		{
			label: 'Rhodium Libre',
			value: 'Rhodium Libre',
		},
		{
			label: 'Srisakdi',
			value: 'Srisakdi',
		},
		{
			label: 'Alumni Sans Inline One',
			value: 'Alumni Sans Inline One',
		},
		{
			label: 'Noto Sans Multani',
			value: 'Noto Sans Multani',
		},
		{
			label: 'Eagle Lake',
			value: 'Eagle Lake',
		},
		{
			label: 'Arima',
			value: 'Arima',
		},
		{
			label: 'Seymour One',
			value: 'Seymour One',
		},
		{
			label: 'Bruno Ace SC',
			value: 'Bruno Ace SC',
		},
		{
			label: 'Spline Sans Mono',
			value: 'Spline Sans Mono',
		},
		{
			label: 'Underdog',
			value: 'Underdog',
		},
		{
			label: 'Carattere',
			value: 'Carattere',
		},
		{
			label: 'Long Cang',
			value: 'Long Cang',
		},
		{
			label: 'Libre Barcode 128 Text',
			value: 'Libre Barcode 128 Text',
		},
		{
			label: 'Mohave',
			value: 'Mohave',
		},
		{
			label: 'Anek Latin',
			value: 'Anek Latin',
		},
		{
			label: 'Buda',
			value: 'Buda',
		},
		{
			label: 'Instrument Sans',
			value: 'Instrument Sans',
		},
		{
			label: 'Linden Hill',
			value: 'Linden Hill',
		},
		{
			label: 'Noto Sans Anatolian Hieroglyphs',
			value: 'Noto Sans Anatolian Hieroglyphs',
		},
		{
			label: 'Ravi Prakash',
			value: 'Ravi Prakash',
		},
		{
			label: 'Shippori Antique B1',
			value: 'Shippori Antique B1',
		},
		{
			label: 'Gorditas',
			value: 'Gorditas',
		},
		{
			label: 'Diplomata',
			value: 'Diplomata',
		},
		{
			label: 'Content',
			value: 'Content',
		},
		{
			label: 'Swanky and Moo Moo',
			value: 'Swanky and Moo Moo',
		},
		{
			label: 'Fascinate',
			value: 'Fascinate',
		},
		{
			label: 'Licorice',
			value: 'Licorice',
		},
		{
			label: 'Caesar Dressing',
			value: 'Caesar Dressing',
		},
		{
			label: 'Noto Serif HK',
			value: 'Noto Serif HK',
		},
		{
			label: 'Liu Jian Mao Cao',
			value: 'Liu Jian Mao Cao',
		},
		{
			label: 'Felipa',
			value: 'Felipa',
		},
		{
			label: 'The Nautigal',
			value: 'The Nautigal',
		},
		{
			label: 'Tiro Bangla',
			value: 'Tiro Bangla',
		},
		{
			label: 'Dangrek',
			value: 'Dangrek',
		},
		{
			label: 'Spirax',
			value: 'Spirax',
		},
		{
			label: 'Condiment',
			value: 'Condiment',
		},
		{
			label: 'Nosifer',
			value: 'Nosifer',
		},
		{
			label: 'Modern Antiqua',
			value: 'Modern Antiqua',
		},
		{
			label: 'Simonetta',
			value: 'Simonetta',
		},
		{
			label: 'Kantumruy Pro',
			value: 'Kantumruy Pro',
		},
		{
			label: 'Noto Sans Khmer',
			value: 'Noto Sans Khmer',
		},
		{
			label: 'Joti One',
			value: 'Joti One',
		},
		{
			label: 'Noto Serif Lao',
			value: 'Noto Serif Lao',
		},
		{
			label: 'DynaPuff',
			value: 'DynaPuff',
		},
		{
			label: 'Ruluko',
			value: 'Ruluko',
		},
		{
			label: 'Jacques Francois Shadow',
			value: 'Jacques Francois Shadow',
		},
		{
			label: 'Chela One',
			value: 'Chela One',
		},
		{
			label: 'Text Me One',
			value: 'Text Me One',
		},
		{
			label: 'Girassol',
			value: 'Girassol',
		},
		{
			label: 'Romanesco',
			value: 'Romanesco',
		},
		{
			label: 'Metal Mania',
			value: 'Metal Mania',
		},
		{
			label: 'Plaster',
			value: 'Plaster',
		},
		{
			label: 'Handjet',
			value: 'Handjet',
		},
		{
			label: 'Griffy',
			value: 'Griffy',
		},
		{
			label: 'Encode Sans SC',
			value: 'Encode Sans SC',
		},
		{
			label: 'Kirang Haerang',
			value: 'Kirang Haerang',
		},
		{
			label: 'Passions Conflict',
			value: 'Passions Conflict',
		},
		{
			label: 'Chilanka',
			value: 'Chilanka',
		},
		{
			label: 'Noto Sans Oriya',
			value: 'Noto Sans Oriya',
		},
		{
			label: 'Englebert',
			value: 'Englebert',
		},
		{
			label: 'Junge',
			value: 'Junge',
		},
		{
			label: 'Inika',
			value: 'Inika',
		},
		{
			label: 'Risque',
			value: 'Risque',
		},
		{
			label: 'Marko One',
			value: 'Marko One',
		},
		{
			label: 'Elsie Swash Caps',
			value: 'Elsie Swash Caps',
		},
		{
			label: 'Keania One',
			value: 'Keania One',
		},
		{
			label: 'Noto Sans Gujarati',
			value: 'Noto Sans Gujarati',
		},
		{
			label: 'Aoboshi One',
			value: 'Aoboshi One',
		},
		{
			label: 'Hanalei Fill',
			value: 'Hanalei Fill',
		},
		{
			label: 'Bahiana',
			value: 'Bahiana',
		},
		{
			label: 'Zen Tokyo Zoo',
			value: 'Zen Tokyo Zoo',
		},
		{
			label: 'Sirin Stencil',
			value: 'Sirin Stencil',
		},
		{
			label: 'Lancelot',
			value: 'Lancelot',
		},
		{
			label: 'Anybody',
			value: 'Anybody',
		},
		{
			label: 'Snippet',
			value: 'Snippet',
		},
		{
			label: 'M PLUS 1 Code',
			value: 'M PLUS 1 Code',
		},
		{
			label: 'Fascinate Inline',
			value: 'Fascinate Inline',
		},
		{
			label: 'Kumar One',
			value: 'Kumar One',
		},
		{
			label: 'Single Day',
			value: 'Single Day',
		},
		{
			label: 'Averia Gruesa Libre',
			value: 'Averia Gruesa Libre',
		},
		{
			label: 'Arbutus',
			value: 'Arbutus',
		},
		{
			label: 'Atomic Age',
			value: 'Atomic Age',
		},
		{
			label: 'Jacques Francois',
			value: 'Jacques Francois',
		},
		{
			label: 'Diplomata SC',
			value: 'Diplomata SC',
		},
		{
			label: 'Smooch',
			value: 'Smooch',
		},
		{
			label: 'Maiden Orange',
			value: 'Maiden Orange',
		},
		{
			label: 'Siemreap',
			value: 'Siemreap',
		},
		{
			label: 'Alkatra',
			value: 'Alkatra',
		},
		{
			label: 'Borel',
			value: 'Borel',
		},
		{
			label: 'Zen Antique Soft',
			value: 'Zen Antique Soft',
		},
		{
			label: 'Birthstone Bounce',
			value: 'Birthstone Bounce',
		},
		{
			label: 'Sunshiney',
			value: 'Sunshiney',
		},
		{
			label: 'Glass Antiqua',
			value: 'Glass Antiqua',
		},
		{
			label: 'Peddana',
			value: 'Peddana',
		},
		{
			label: 'Noto Sans Ethiopic',
			value: 'Noto Sans Ethiopic',
		},
		{
			label: 'Redacted',
			value: 'Redacted',
		},
		{
			label: 'Tektur',
			value: 'Tektur',
		},
		{
			label: 'New Tegomin',
			value: 'New Tegomin',
		},
		{
			label: 'Grenze',
			value: 'Grenze',
		},
		{
			label: 'Tiro Gurmukhi',
			value: 'Tiro Gurmukhi',
		},
		{
			label: 'Rubik Wet Paint',
			value: 'Rubik Wet Paint',
		},
		{
			label: 'Croissant One',
			value: 'Croissant One',
		},
		{
			label: 'Preahvihear',
			value: 'Preahvihear',
		},
		{
			label: 'IBM Plex Sans Hebrew',
			value: 'IBM Plex Sans Hebrew',
		},
		{
			label: 'Yeon Sung',
			value: 'Yeon Sung',
		},
		{
			label: 'Delicious Handrawn',
			value: 'Delicious Handrawn',
		},
		{
			label: 'Dr Sugiyama',
			value: 'Dr Sugiyama',
		},
		{
			label: 'Passero One',
			value: 'Passero One',
		},
		{
			label: 'Belanosima',
			value: 'Belanosima',
		},
		{
			label: 'Noto Serif Armenian',
			value: 'Noto Serif Armenian',
		},
		{
			label: 'Charis SIL',
			value: 'Charis SIL',
		},
		{
			label: 'IM Fell DW Pica SC',
			value: 'IM Fell DW Pica SC',
		},
		{
			label: 'Jim Nightshade',
			value: 'Jim Nightshade',
		},
		{
			label: 'Joan',
			value: 'Joan',
		},
		{
			label: 'Braah One',
			value: 'Braah One',
		},
		{
			label: 'Cherry Bomb One',
			value: 'Cherry Bomb One',
		},
		{
			label: 'BIZ UDMincho',
			value: 'BIZ UDMincho',
		},
		{
			label: 'Ewert',
			value: 'Ewert',
		},
		{
			label: 'BioRhyme Expanded',
			value: 'BioRhyme Expanded',
		},
		{
			label: 'Ribeye Marrow',
			value: 'Ribeye Marrow',
		},
		{
			label: 'Flavors',
			value: 'Flavors',
		},
		{
			label: 'Nuosu SIL',
			value: 'Nuosu SIL',
		},
		{
			label: 'Genos',
			value: 'Genos',
		},
		{
			label: 'Festive',
			value: 'Festive',
		},
		{
			label: 'Qahiri',
			value: 'Qahiri',
		},
		{
			label: 'Stick No Bills',
			value: 'Stick No Bills',
		},
		{
			label: 'Noto Serif Sinhala',
			value: 'Noto Serif Sinhala',
		},
		{
			label: 'Sedgwick Ave Display',
			value: 'Sedgwick Ave Display',
		},
		{
			label: 'Metal',
			value: 'Metal',
		},
		{
			label: 'Bungee Hairline',
			value: 'Bungee Hairline',
		},
		{
			label: 'Imbue',
			value: 'Imbue',
		},
		{
			label: 'Labrada',
			value: 'Labrada',
		},
		{
			label: 'Lakki Reddy',
			value: 'Lakki Reddy',
		},
		{
			label: 'Smythe',
			value: 'Smythe',
		},
		{
			label: 'Devonshire',
			value: 'Devonshire',
		},
		{
			label: 'Kumar One Outline',
			value: 'Kumar One Outline',
		},
		{
			label: 'IM Fell French Canon SC',
			value: 'IM Fell French Canon SC',
		},
		{
			label: 'Emblema One',
			value: 'Emblema One',
		},
		{
			label: 'Purple Purse',
			value: 'Purple Purse',
		},
		{
			label: 'Combo',
			value: 'Combo',
		},
		{
			label: 'Oldenburg',
			value: 'Oldenburg',
		},
		{
			label: 'Bokor',
			value: 'Bokor',
		},
		{
			label: 'Wix Madefor Text',
			value: 'Wix Madefor Text',
		},
		{
			label: 'Whisper',
			value: 'Whisper',
		},
		{
			label: 'Gidugu',
			value: 'Gidugu',
		},
		{
			label: 'Water Brush',
			value: 'Water Brush',
		},
		{
			label: 'Revalia',
			value: 'Revalia',
		},
		{
			label: 'Trochut',
			value: 'Trochut',
		},
		{
			label: 'Victor Mono',
			value: 'Victor Mono',
		},
		{
			label: 'Noto Serif Kannada',
			value: 'Noto Serif Kannada',
		},
		{
			label: 'Almendra SC',
			value: 'Almendra SC',
		},
		{
			label: 'Lisu Bosa',
			value: 'Lisu Bosa',
		},
		{
			label: 'Sassy Frass',
			value: 'Sassy Frass',
		},
		{
			label: 'Nova Slim',
			value: 'Nova Slim',
		},
		{
			label: 'Federant',
			value: 'Federant',
		},
		{
			label: 'Bungee Outline',
			value: 'Bungee Outline',
		},
		{
			label: 'Noto Sans Symbols 2',
			value: 'Noto Sans Symbols 2',
		},
		{
			label: 'Fuggles',
			value: 'Fuggles',
		},
		{
			label: 'IM Fell Great Primer SC',
			value: 'IM Fell Great Primer SC',
		},
		{
			label: 'Texturina',
			value: 'Texturina',
		},
		{
			label: 'Phudu',
			value: 'Phudu',
		},
		{
			label: 'Amiri Quran',
			value: 'Amiri Quran',
		},
		{
			label: 'Carlito',
			value: 'Carlito',
		},
		{
			label: 'Noto Sans Gothic',
			value: 'Noto Sans Gothic',
		},
		{
			label: 'Gentium Plus',
			value: 'Gentium Plus',
		},
		{
			label: 'Galindo',
			value: 'Galindo',
		},
		{
			label: 'Noto Serif Vithkuqi',
			value: 'Noto Serif Vithkuqi',
		},
		{
			label: 'Anek Gujarati',
			value: 'Anek Gujarati',
		},
		{
			label: 'Bahianita',
			value: 'Bahianita',
		},
		{
			label: 'Kenia',
			value: 'Kenia',
		},
		{
			label: 'Mynerve',
			value: 'Mynerve',
		},
		{
			label: 'Praise',
			value: 'Praise',
		},
		{
			label: 'Butterfly Kids',
			value: 'Butterfly Kids',
		},
		{
			label: 'Tiro Devanagari Marathi',
			value: 'Tiro Devanagari Marathi',
		},
		{
			label: 'Lavishly Yours',
			value: 'Lavishly Yours',
		},
		{
			label: 'Solitreo',
			value: 'Solitreo',
		},
		{
			label: 'Asset',
			value: 'Asset',
		},
		{
			label: 'Langar',
			value: 'Langar',
		},
		{
			label: 'Miss Fajardose',
			value: 'Miss Fajardose',
		},
		{
			label: 'Big Shoulders Stencil Display',
			value: 'Big Shoulders Stencil Display',
		},
		{
			label: 'Ysabeau Infant',
			value: 'Ysabeau Infant',
		},
		{
			label: 'Libre Barcode 39 Extended',
			value: 'Libre Barcode 39 Extended',
		},
		{
			label: 'Erica One',
			value: 'Erica One',
		},
		{
			label: 'Geostar Fill',
			value: 'Geostar Fill',
		},
		{
			label: 'Tiro Devanagari Sanskrit',
			value: 'Tiro Devanagari Sanskrit',
		},
		{
			label: 'Almendra Display',
			value: 'Almendra Display',
		},
		{
			label: 'Big Shoulders Stencil Text',
			value: 'Big Shoulders Stencil Text',
		},
		{
			label: 'Poltawski Nowy',
			value: 'Poltawski Nowy',
		},
		{
			label: 'Noto Sans Samaritan',
			value: 'Noto Sans Samaritan',
		},
		{
			label: 'Lumanosimo',
			value: 'Lumanosimo',
		},
		{
			label: 'Luxurious Script',
			value: 'Luxurious Script',
		},
		{
			label: 'Agdasima',
			value: 'Agdasima',
		},
		{
			label: 'Bonheur Royale',
			value: 'Bonheur Royale',
		},
		{
			label: 'Gupter',
			value: 'Gupter',
		},
		{
			label: 'Kdam Thmor Pro',
			value: 'Kdam Thmor Pro',
		},
		{
			label: 'Astloch',
			value: 'Astloch',
		},
		{
			label: 'Nabla',
			value: 'Nabla',
		},
		{
			label: 'Foldit',
			value: 'Foldit',
		},
		{
			label: 'Dai Banna SIL',
			value: 'Dai Banna SIL',
		},
		{
			label: 'Neonderthaw',
			value: 'Neonderthaw',
		},
		{
			label: 'Rubik Glitch',
			value: 'Rubik Glitch',
		},
		{
			label: 'Noto Sans Adlam Unjoined',
			value: 'Noto Sans Adlam Unjoined',
		},
		{
			label: 'Ysabeau',
			value: 'Ysabeau',
		},
		{
			label: 'Nova Oval',
			value: 'Nova Oval',
		},
		{
			label: 'Mea Culpa',
			value: 'Mea Culpa',
		},
		{
			label: 'Mr Bedfort',
			value: 'Mr Bedfort',
		},
		{
			label: 'Lacquer',
			value: 'Lacquer',
		},
		{
			label: 'Aubrey',
			value: 'Aubrey',
		},
		{
			label: 'Vina Sans',
			value: 'Vina Sans',
		},
		{
			label: 'Butcherman',
			value: 'Butcherman',
		},
		{
			label: 'Bungee Spice',
			value: 'Bungee Spice',
		},
		{
			label: 'Ysabeau Office',
			value: 'Ysabeau Office',
		},
		{
			label: 'Noto Serif Gujarati',
			value: 'Noto Serif Gujarati',
		},
		{
			label: 'Ballet',
			value: 'Ballet',
		},
		{
			label: 'Climate Crisis',
			value: 'Climate Crisis',
		},
		{
			label: 'Bruno Ace',
			value: 'Bruno Ace',
		},
		{
			label: 'Monomaniac One',
			value: 'Monomaniac One',
		},
		{
			label: 'Rubik Beastly',
			value: 'Rubik Beastly',
		},
		{
			label: 'Gentium Book Plus',
			value: 'Gentium Book Plus',
		},
		{
			label: 'GFS Neohellenic',
			value: 'GFS Neohellenic',
		},
		{
			label: 'Lexend Tera',
			value: 'Lexend Tera',
		},
		{
			label: 'Ysabeau SC',
			value: 'Ysabeau SC',
		},
		{
			label: 'Babylonica',
			value: 'Babylonica',
		},
		{
			label: 'Truculenta',
			value: 'Truculenta',
		},
		{
			label: 'Noto Sans Thai Looped',
			value: 'Noto Sans Thai Looped',
		},
		{
			label: 'Ruge Boogie',
			value: 'Ruge Boogie',
		},
		{
			label: 'Noto Serif Khmer',
			value: 'Noto Serif Khmer',
		},
		{
			label: 'Anek Gurmukhi',
			value: 'Anek Gurmukhi',
		},
		{
			label: 'Chenla',
			value: 'Chenla',
		},
		{
			label: 'Londrina Sketch',
			value: 'Londrina Sketch',
		},
		{
			label: 'Rubik Distressed',
			value: 'Rubik Distressed',
		},
		{
			label: 'Taprom',
			value: 'Taprom',
		},
		{
			label: 'Caramel',
			value: 'Caramel',
		},
		{
			label: 'Tilt Neon',
			value: 'Tilt Neon',
		},
		{
			label: 'Gideon Roman',
			value: 'Gideon Roman',
		},
		{
			label: 'Fruktur',
			value: 'Fruktur',
		},
		{
			label: 'Tai Heritage Pro',
			value: 'Tai Heritage Pro',
		},
		{
			label: 'Cairo Play',
			value: 'Cairo Play',
		},
		{
			label: 'Gwendolyn',
			value: 'Gwendolyn',
		},
		{
			label: 'IM Fell Double Pica SC',
			value: 'IM Fell Double Pica SC',
		},
		{
			label: 'Sofadi One',
			value: 'Sofadi One',
		},
		{
			label: 'Noto Sans Meetei Mayek',
			value: 'Noto Sans Meetei Mayek',
		},
		{
			label: 'Martian Mono',
			value: 'Martian Mono',
		},
		{
			label: 'Bonbon',
			value: 'Bonbon',
		},
		{
			label: 'Vibes',
			value: 'Vibes',
		},
		{
			label: 'Snowburst One',
			value: 'Snowburst One',
		},
		{
			label: 'Nova Cut',
			value: 'Nova Cut',
		},
		{
			label: 'Imperial Script',
			value: 'Imperial Script',
		},
		{
			label: 'Rubik Puddles',
			value: 'Rubik Puddles',
		},
		{
			label: 'Noto Serif Khojki',
			value: 'Noto Serif Khojki',
		},
		{
			label: 'Koh Santepheap',
			value: 'Koh Santepheap',
		},
		{
			label: 'Dhurjati',
			value: 'Dhurjati',
		},
		{
			label: 'Darumadrop One',
			value: 'Darumadrop One',
		},
		{
			label: 'Yuji Boku',
			value: 'Yuji Boku',
		},
		{
			label: 'Lugrasimo',
			value: 'Lugrasimo',
		},
		{
			label: 'Updock',
			value: 'Updock',
		},
		{
			label: 'Hubballi',
			value: 'Hubballi',
		},
		{
			label: 'Lunasima',
			value: 'Lunasima',
		},
		{
			label: 'Finlandica',
			value: 'Finlandica',
		},
		{
			label: 'Nova Script',
			value: 'Nova Script',
		},
		{
			label: 'Suravaram',
			value: 'Suravaram',
		},
		{
			label: 'Big Shoulders Inline Text',
			value: 'Big Shoulders Inline Text',
		},
		{
			label: 'Noto Serif Tangut',
			value: 'Noto Serif Tangut',
		},
		{
			label: 'Comme',
			value: 'Comme',
		},
		{
			label: 'Estonia',
			value: 'Estonia',
		},
		{
			label: 'Moulpali',
			value: 'Moulpali',
		},
		{
			label: 'Edu QLD Beginner',
			value: 'Edu QLD Beginner',
		},
		{
			label: 'Geostar',
			value: 'Geostar',
		},
		{
			label: 'Uchen',
			value: 'Uchen',
		},
		{
			label: 'Rubik Bubbles',
			value: 'Rubik Bubbles',
		},
		{
			label: 'Tiro Tamil',
			value: 'Tiro Tamil',
		},
		{
			label: 'Rubik Vinyl',
			value: 'Rubik Vinyl',
		},
		{
			label: 'Miltonian Tattoo',
			value: 'Miltonian Tattoo',
		},
		{
			label: 'Marhey',
			value: 'Marhey',
		},
		{
			label: 'Bacasime Antique',
			value: 'Bacasime Antique',
		},
		{
			label: 'Miltonian',
			value: 'Miltonian',
		},
		{
			label: 'Big Shoulders Inline Display',
			value: 'Big Shoulders Inline Display',
		},
		{
			label: 'Tourney',
			value: 'Tourney',
		},
		{
			label: 'Sevillana',
			value: 'Sevillana',
		},
		{
			label: 'Island Moments',
			value: 'Island Moments',
		},
		{
			label: 'Noto Sans Javanese',
			value: 'Noto Sans Javanese',
		},
		{
			label: 'Luxurious Roman',
			value: 'Luxurious Roman',
		},
		{
			label: 'Kablammo',
			value: 'Kablammo',
		},
		{
			label: 'Edu NSW ACT Foundation',
			value: 'Edu NSW ACT Foundation',
		},
		{
			label: 'Anek Kannada',
			value: 'Anek Kannada',
		},
		{
			label: 'Blaka Hollow',
			value: 'Blaka Hollow',
		},
		{
			label: 'Oi',
			value: 'Oi',
		},
		{
			label: 'Alumni Sans Collegiate One',
			value: 'Alumni Sans Collegiate One',
		},
		{
			label: 'Noto Sans Syriac Eastern',
			value: 'Noto Sans Syriac Eastern',
		},
		{
			label: 'Fleur De Leah',
			value: 'Fleur De Leah',
		},
		{
			label: 'Blaka',
			value: 'Blaka',
		},
		{
			label: 'Anek Odia',
			value: 'Anek Odia',
		},
		{
			label: 'Edu VIC WA NT Beginner',
			value: 'Edu VIC WA NT Beginner',
		},
		{
			label: 'Aref Ruqaa Ink',
			value: 'Aref Ruqaa Ink',
		},
		{
			label: 'Edu TAS Beginner',
			value: 'Edu TAS Beginner',
		},
		{
			label: 'Redacted Script',
			value: 'Redacted Script',
		},
		{
			label: 'Konkhmer Sleokchher',
			value: 'Konkhmer Sleokchher',
		},
		{
			label: 'Noto Sans Cypro Minoan',
			value: 'Noto Sans Cypro Minoan',
		},
		{
			label: 'Alumni Sans Pinstripe',
			value: 'Alumni Sans Pinstripe',
		},
		{
			label: 'Reem Kufi Ink',
			value: 'Reem Kufi Ink',
		},
		{
			label: 'Sigmar',
			value: 'Sigmar',
		},
		{
			label: 'Rubik Pixels',
			value: 'Rubik Pixels',
		},
		{
			label: 'Castoro Titling',
			value: 'Castoro Titling',
		},
		{
			label: 'Splash',
			value: 'Splash',
		},
		{
			label: 'Noto Sans Coptic',
			value: 'Noto Sans Coptic',
		},
		{
			label: 'Diphylleia',
			value: 'Diphylleia',
		},
		{
			label: 'Kolker Brush',
			value: 'Kolker Brush',
		},
		{
			label: 'Noto Serif Ottoman Siyaq',
			value: 'Noto Serif Ottoman Siyaq',
		},
		{
			label: 'Bagel Fat One',
			value: 'Bagel Fat One',
		},
		{
			label: 'Narnoor',
			value: 'Narnoor',
		},
		{
			label: 'Rubik Spray Paint',
			value: 'Rubik Spray Paint',
		},
		{
			label: 'Zen Loop',
			value: 'Zen Loop',
		},
		{
			label: 'Send Flowers',
			value: 'Send Flowers',
		},
		{
			label: 'Rubik Iso',
			value: 'Rubik Iso',
		},
		{
			label: 'Noto Sans Gurmukhi',
			value: 'Noto Sans Gurmukhi',
		},
		{
			label: 'Noto Serif Tamil',
			value: 'Noto Serif Tamil',
		},
		{
			label: 'Noto Serif Myanmar',
			value: 'Noto Serif Myanmar',
		},
		{
			label: 'Grechen Fuemen',
			value: 'Grechen Fuemen',
		},
		{
			label: 'Libre Barcode EAN13 Text',
			value: 'Libre Barcode EAN13 Text',
		},
		{
			label: 'Noto Sans Adlam',
			value: 'Noto Sans Adlam',
		},
		{
			label: 'Noto Serif Khitan Small Script',
			value: 'Noto Serif Khitan Small Script',
		},
		{
			label: 'Syne Tactile',
			value: 'Syne Tactile',
		},
		{
			label: 'Tsukimi Rounded',
			value: 'Tsukimi Rounded',
		},
		{
			label: 'Rubik 80s Fade',
			value: 'Rubik 80s Fade',
		},
		{
			label: 'Flow Block',
			value: 'Flow Block',
		},
		{
			label: 'Palette Mosaic',
			value: 'Palette Mosaic',
		},
		{
			label: 'Reem Kufi Fun',
			value: 'Reem Kufi Fun',
		},
		{
			label: 'Petemoss',
			value: 'Petemoss',
		},
		{
			label: 'Orbit',
			value: 'Orbit',
		},
		{
			label: 'Noto Rashi Hebrew',
			value: 'Noto Rashi Hebrew',
		},
		{
			label: 'Tiro Telugu',
			value: 'Tiro Telugu',
		},
		{
			label: 'Noto Serif Tibetan',
			value: 'Noto Serif Tibetan',
		},
		{
			label: 'Yuji Mai',
			value: 'Yuji Mai',
		},
		{
			label: 'Noto Serif Telugu',
			value: 'Noto Serif Telugu',
		},
		{
			label: 'Love Light',
			value: 'Love Light',
		},
		{
			label: 'Noto Serif Makasar',
			value: 'Noto Serif Makasar',
		},
		{
			label: 'Grey Qo',
			value: 'Grey Qo',
		},
		{
			label: 'Gajraj One',
			value: 'Gajraj One',
		},
		{
			label: 'Hanalei',
			value: 'Hanalei',
		},
		{
			label: 'Are You Serious',
			value: 'Are You Serious',
		},
		{
			label: 'Noto Sans Syloti Nagri',
			value: 'Noto Sans Syloti Nagri',
		},
		{
			label: 'Moirai One',
			value: 'Moirai One',
		},
		{
			label: 'Tapestry',
			value: 'Tapestry',
		},
		{
			label: 'Slackside One',
			value: 'Slackside One',
		},
		{
			label: 'Rubik Microbe',
			value: 'Rubik Microbe',
		},
		{
			label: 'Warnes',
			value: 'Warnes',
		},
		{
			label: 'Noto Sans Mongolian',
			value: 'Noto Sans Mongolian',
		},
		{
			label: 'Noto Sans Mro',
			value: 'Noto Sans Mro',
		},
		{
			label: 'Chokokutai',
			value: 'Chokokutai',
		},
		{
			label: 'Rubik Storm',
			value: 'Rubik Storm',
		},
		{
			label: 'Noto Sans Indic Siyaq Numbers',
			value: 'Noto Sans Indic Siyaq Numbers',
		},
		{
			label: 'My Soul',
			value: 'My Soul',
		},
		{
			label: 'Noto Sans Cypriot',
			value: 'Noto Sans Cypriot',
		},
		{
			label: 'Noto Sans Nag Mundari',
			value: 'Noto Sans Nag Mundari',
		},
		{
			label: 'Gasoek One',
			value: 'Gasoek One',
		},
		{
			label: 'Noto Serif Ethiopic',
			value: 'Noto Serif Ethiopic',
		},
		{
			label: 'Noto Sans Lepcha',
			value: 'Noto Sans Lepcha',
		},
		{
			label: 'Noto Serif Ahom',
			value: 'Noto Serif Ahom',
		},
		{
			label: 'Explora',
			value: 'Explora',
		},
		{
			label: 'Noto Sans Sora Sompeng',
			value: 'Noto Sans Sora Sompeng',
		},
		{
			label: 'Noto Sans Vithkuqi',
			value: 'Noto Sans Vithkuqi',
		},
		{
			label: 'Grandiflora One',
			value: 'Grandiflora One',
		},
		{
			label: 'Rock 3D',
			value: 'Rock 3D',
		},
		{
			label: 'Noto Sans Thaana',
			value: 'Noto Sans Thaana',
		},
		{
			label: 'Kings',
			value: 'Kings',
		},
		{
			label: 'Noto Sans Old Hungarian',
			value: 'Noto Sans Old Hungarian',
		},
		{
			label: 'Noto Music',
			value: 'Noto Music',
		},
		{
			label: 'Twinkle Star',
			value: 'Twinkle Star',
		},
		{
			label: 'Noto Sans Canadian Aboriginal',
			value: 'Noto Sans Canadian Aboriginal',
		},
		{
			label: 'Shizuru',
			value: 'Shizuru',
		},
		{
			label: 'Cherish',
			value: 'Cherish',
		},
		{
			label: 'Ole',
			value: 'Ole',
		},
		{
			label: 'Noto Sans Lao Looped',
			value: 'Noto Sans Lao Looped',
		},
		{
			label: 'Noto Sans Nandinagari',
			value: 'Noto Sans Nandinagari',
		},
		{
			label: 'Puppies Play',
			value: 'Puppies Play',
		},
		{
			label: 'Noto Sans Carian',
			value: 'Noto Sans Carian',
		},
		{
			label: 'Moo Lah Lah',
			value: 'Moo Lah Lah',
		},
		{
			label: 'Noto Sans Old Italic',
			value: 'Noto Sans Old Italic',
		},
		{
			label: 'Noto Sans Tagalog',
			value: 'Noto Sans Tagalog',
		},
		{
			label: 'Rubik Marker Hatch',
			value: 'Rubik Marker Hatch',
		},
		{
			label: 'Rubik Gemstones',
			value: 'Rubik Gemstones',
		},
		{
			label: 'Noto Sans Miao',
			value: 'Noto Sans Miao',
		},
		{
			label: 'M PLUS Code Latin',
			value: 'M PLUS Code Latin',
		},
		{
			label: 'Noto Sans Deseret',
			value: 'Noto Sans Deseret',
		},
		{
			label: 'Noto Sans Imperial Aramaic',
			value: 'Noto Sans Imperial Aramaic',
		},
		{
			label: 'Rubik Burned',
			value: 'Rubik Burned',
		},
		{
			label: 'Flow Rounded',
			value: 'Flow Rounded',
		},
		{
			label: 'Noto Sans Cherokee',
			value: 'Noto Sans Cherokee',
		},
		{
			label: 'Noto Sans Tai Viet',
			value: 'Noto Sans Tai Viet',
		},
		{
			label: 'Noto Sans Sundanese',
			value: 'Noto Sans Sundanese',
		},
		{
			label: 'Ingrid Darling',
			value: 'Ingrid Darling',
		},
		{
			label: 'Yuji Hentaigana Akari',
			value: 'Yuji Hentaigana Akari',
		},
		{
			label: 'Mingzat',
			value: 'Mingzat',
		},
		{
			label: 'Noto Sans Tifinagh',
			value: 'Noto Sans Tifinagh',
		},
		{
			label: 'Noto Serif Toto',
			value: 'Noto Serif Toto',
		},
		{
			label: 'Noto Sans Tangsa',
			value: 'Noto Sans Tangsa',
		},
		{
			label: 'Blaka Ink',
			value: 'Blaka Ink',
		},
		{
			label: 'Noto Sans Egyptian Hieroglyphs',
			value: 'Noto Sans Egyptian Hieroglyphs',
		},
		{
			label: 'Noto Sans New Tai Lue',
			value: 'Noto Sans New Tai Lue',
		},
		{
			label: 'Noto Sans Kayah Li',
			value: 'Noto Sans Kayah Li',
		},
		{
			label: 'Noto Sans Cham',
			value: 'Noto Sans Cham',
		},
		{
			label: 'Rubik Maze',
			value: 'Rubik Maze',
		},
		{
			label: 'Noto Sans Bamum',
			value: 'Noto Sans Bamum',
		},
		{
			label: 'Noto Traditional Nushu',
			value: 'Noto Traditional Nushu',
		},
		{
			label: 'Noto Sans Old Persian',
			value: 'Noto Sans Old Persian',
		},
		{
			label: 'Noto Serif Gurmukhi',
			value: 'Noto Serif Gurmukhi',
		},
		{
			label: 'Noto Sans Avestan',
			value: 'Noto Sans Avestan',
		},
		{
			label: 'Noto Sans Tai Tham',
			value: 'Noto Sans Tai Tham',
		},
		{
			label: 'Noto Sans Ugaritic',
			value: 'Noto Sans Ugaritic',
		},
		{
			label: 'Noto Serif NP Hmong',
			value: 'Noto Serif NP Hmong',
		},
		{
			label: 'Noto Sans Cuneiform',
			value: 'Noto Sans Cuneiform',
		},
		{
			label: 'Noto Sans Balinese',
			value: 'Noto Sans Balinese',
		},
		{
			label: 'Noto Sans Marchen',
			value: 'Noto Sans Marchen',
		},
		{
			label: 'Noto Sans Yi',
			value: 'Noto Sans Yi',
		},
		{
			label: 'Yuji Hentaigana Akebono',
			value: 'Yuji Hentaigana Akebono',
		},
		{
			label: 'Noto Sans Sharada',
			value: 'Noto Sans Sharada',
		},
		{
			label: 'Noto Sans Takri',
			value: 'Noto Sans Takri',
		},
		{
			label: 'Noto Sans Brahmi',
			value: 'Noto Sans Brahmi',
		},
		{
			label: 'Noto Sans Glagolitic',
			value: 'Noto Sans Glagolitic',
		},
		{
			label: 'Noto Sans Ol Chiki',
			value: 'Noto Sans Ol Chiki',
		},
		{
			label: 'Noto Sans Limbu',
			value: 'Noto Sans Limbu',
		},
		{
			label: 'Noto Sans Tagbanwa',
			value: 'Noto Sans Tagbanwa',
		},
		{
			label: 'Noto Sans Inscriptional Pahlavi',
			value: 'Noto Sans Inscriptional Pahlavi',
		},
		{
			label: 'Noto Sans Hanunoo',
			value: 'Noto Sans Hanunoo',
		},
		{
			label: 'Noto Sans Pahawh Hmong',
			value: 'Noto Sans Pahawh Hmong',
		},
		{
			label: 'Noto Sans Medefaidrin',
			value: 'Noto Sans Medefaidrin',
		},
		{
			label: 'Noto Sans Saurashtra',
			value: 'Noto Sans Saurashtra',
		},
		{
			label: 'Noto Serif Grantha',
			value: 'Noto Serif Grantha',
		},
		{
			label: 'Noto Serif Balinese',
			value: 'Noto Serif Balinese',
		},
		{
			label: 'Noto Sans Old Turkic',
			value: 'Noto Sans Old Turkic',
		},
		{
			label: 'Noto Sans Lisu',
			value: 'Noto Sans Lisu',
		},
		{
			label: 'Noto Sans Buhid',
			value: 'Noto Sans Buhid',
		},
		{
			label: 'Noto Sans Osage',
			value: 'Noto Sans Osage',
		},
		{
			label: 'Noto Sans Bassa Vah',
			value: 'Noto Sans Bassa Vah',
		},
		{
			label: 'Padyakke Expanded One',
			value: 'Padyakke Expanded One',
		},
		{
			label: 'Noto Sans Psalter Pahlavi',
			value: 'Noto Sans Psalter Pahlavi',
		},
		{
			label: 'Noto Sans Vai',
			value: 'Noto Sans Vai',
		},
		{
			label: 'Noto Sans Mayan Numerals',
			value: 'Noto Sans Mayan Numerals',
		},
		{
			label: 'Noto Sans Tirhuta',
			value: 'Noto Sans Tirhuta',
		},
		{
			label: 'Noto Sans Chakma',
			value: 'Noto Sans Chakma',
		},
		{
			label: 'Noto Sans Mende Kikakui',
			value: 'Noto Sans Mende Kikakui',
		},
		{
			label: 'Noto Sans Khudawadi',
			value: 'Noto Sans Khudawadi',
		},
		{
			label: 'Noto Sans Tai Le',
			value: 'Noto Sans Tai Le',
		},
		{
			label: 'Noto Sans Newa',
			value: 'Noto Sans Newa',
		},
		{
			label: 'Noto Serif Oriya',
			value: 'Noto Serif Oriya',
		},
		{
			label: 'Noto Sans Buginese',
			value: 'Noto Sans Buginese',
		},
		{
			label: 'Noto Sans Bhaiksuki',
			value: 'Noto Sans Bhaiksuki',
		},
		{
			label: 'Noto Sans Palmyrene',
			value: 'Noto Sans Palmyrene',
		},
		{
			label: 'Noto Sans Masaram Gondi',
			value: 'Noto Sans Masaram Gondi',
		},
		{
			label: 'Noto Sans Modi',
			value: 'Noto Sans Modi',
		},
		{
			label: 'Noto Sans Lydian',
			value: 'Noto Sans Lydian',
		},
		{
			label: 'Noto Serif Yezidi',
			value: 'Noto Serif Yezidi',
		},
		{
			label: 'Noto Sans Warang Citi',
			value: 'Noto Sans Warang Citi',
		},
		{
			label: 'Noto Sans Hatran',
			value: 'Noto Sans Hatran',
		},
		{
			label: 'Noto Sans Rejang',
			value: 'Noto Sans Rejang',
		},
		{
			label: 'Noto Sans Shavian',
			value: 'Noto Sans Shavian',
		},
		{
			label: 'Noto Sans Zanabazar Square',
			value: 'Noto Sans Zanabazar Square',
		},
		{
			label: 'Noto Sans Phoenician',
			value: 'Noto Sans Phoenician',
		},
		{
			label: 'Noto Sans Siddham',
			value: 'Noto Sans Siddham',
		},
		{
			label: 'Noto Sans Lycian',
			value: 'Noto Sans Lycian',
		},
		{
			label: 'Noto Sans Inscriptional Parthian',
			value: 'Noto Sans Inscriptional Parthian',
		},
		{
			label: 'Noto Sans Grantha',
			value: 'Noto Sans Grantha',
		},
		{
			label: 'Noto Sans Wancho',
			value: 'Noto Sans Wancho',
		},
		{
			label: 'Noto Serif Dogra',
			value: 'Noto Serif Dogra',
		},
		{
			label: 'Noto Sans Batak',
			value: 'Noto Sans Batak',
		},
		{
			label: 'Noto Sans Old South Arabian',
			value: 'Noto Sans Old South Arabian',
		},
		{
			label: 'Noto Sans Linear A',
			value: 'Noto Sans Linear A',
		},
		{
			label: 'Noto Sans SignWriting',
			value: 'Noto Sans SignWriting',
		},
		{
			label: 'Noto Sans Old North Arabian',
			value: 'Noto Sans Old North Arabian',
		},
		{
			label: 'Noto Sans Osmanya',
			value: 'Noto Sans Osmanya',
		},
		{
			label: 'Noto Sans Syriac',
			value: 'Noto Sans Syriac',
		},
		{
			label: 'Noto Sans Runic',
			value: 'Noto Sans Runic',
		},
		{
			label: 'Noto Sans Caucasian Albanian',
			value: 'Noto Sans Caucasian Albanian',
		},
		{
			label: 'Noto Sans Khojki',
			value: 'Noto Sans Khojki',
		},
		{
			label: 'Noto Sans Kaithi',
			value: 'Noto Sans Kaithi',
		},
		{
			label: 'Noto Sans Tamil Supplement',
			value: 'Noto Sans Tamil Supplement',
		},
		{
			label: 'Noto Sans Gunjala Gondi',
			value: 'Noto Sans Gunjala Gondi',
		},
		{
			label: 'Noto Sans Ogham',
			value: 'Noto Sans Ogham',
		},
		{
			label: 'Noto Sans Mandaic',
			value: 'Noto Sans Mandaic',
		},
		{
			label: 'Noto Sans Hanifi Rohingya',
			value: 'Noto Sans Hanifi Rohingya',
		},
		{
			label: 'Noto Sans Old Sogdian',
			value: 'Noto Sans Old Sogdian',
		},
		{
			label: 'Noto Sans Elymaic',
			value: 'Noto Sans Elymaic',
		},
		{
			label: 'Noto Sans NKo',
			value: 'Noto Sans NKo',
		},
		{
			label: 'Noto Sans Duployan',
			value: 'Noto Sans Duployan',
		},
		{
			label: 'Noto Sans Kharoshthi',
			value: 'Noto Sans Kharoshthi',
		},
		{
			label: 'Noto Sans Nushu',
			value: 'Noto Sans Nushu',
		},
		{
			label: 'Noto Sans Old Permic',
			value: 'Noto Sans Old Permic',
		},
		{
			label: 'Noto Sans Linear B',
			value: 'Noto Sans Linear B',
		},
		{
			label: 'Noto Sans Elbasan',
			value: 'Noto Sans Elbasan',
		},
		{
			label: 'Noto Sans Soyombo',
			value: 'Noto Sans Soyombo',
		},
		{
			label: 'Noto Sans Pau Cin Hau',
			value: 'Noto Sans Pau Cin Hau',
		},
		{
			label: 'Noto Sans Phags Pa',
			value: 'Noto Sans Phags Pa',
		},
		{
			label: 'Noto Sans Nabataean',
			value: 'Noto Sans Nabataean',
		},
		{
			label: 'Noto Sans Manichaean',
			value: 'Noto Sans Manichaean',
		},
		{
			label: 'Noto Sans Meroitic',
			value: 'Noto Sans Meroitic',
		},
		{
			label: 'Noto Sans Sogdian',
			value: 'Noto Sans Sogdian',
		},
		{
			label: 'Noto Sans Mahajani',
			value: 'Noto Sans Mahajani',
		},
		{
			label: 'Wavefont',
			value: 'Wavefont',
		},
		{
			label: 'ADLaM Display',
			value: 'ADLaM Display',
		},
	],
};
