import React from 'react';
import { TabPanel } from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import PropTypes from 'prop-types';

/**
 * Import Css
 */
import './editor.scss';

const propTypes = {
	content: PropTypes.node.isRequired,
	style: PropTypes.node.isRequired,
};

const defaultProps = {
	content: '',
	style: '',
};

export default function ContentStyleTabs(props) {
	const { content, style } = props;

	const tabs = [
		{
			name: 'content',
			render: content,
			title: <>{__('Content', 'ablocks')}</>,
			className: 'ablocks-content-style-tab__item',
		},
		{
			name: 'style',
			render: style,
			title: <>{__('Style', 'ablocks')}</>,
			className: 'ablocks-content-style-tab__item',
		},
	];

	return (
		<React.Fragment>
			<TabPanel
				className="ablocks-content-style-tabs"
				activeClass="ablocks-content-style-tab__item--active"
				tabs={tabs}
			>
				{(tab) => tab.render}
			</TabPanel>
		</React.Fragment>
	);
}

ContentStyleTabs.propTypes = propTypes;
ContentStyleTabs.defaultProps = defaultProps;
