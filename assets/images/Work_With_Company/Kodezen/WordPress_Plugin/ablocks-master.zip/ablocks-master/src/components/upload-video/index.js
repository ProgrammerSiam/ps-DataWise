import { MediaUpload } from '@wordpress/block-editor';
import { __ } from '@wordpress/i18n';
import Button from '@Components/Button';
import { plugin_root_url as PluginURL } from '@Utils/helper';
import './styles.scss';

export default function VideoUploadField(props) {
	const {
		allowedTypes,
		attributeValue,
		attributeName,
		onSelectImageHandler,
		onRemoveImageHandler,
		deviceType = '',
	} = props;

	let imageUploaderAndPreview;
	const imageAttributeValue =
		attributeValue[attributeName + deviceType] ||
		attributeValue[attributeName];
	const replaceImage = (
		<>
			<MediaUpload
				allowedTypes={allowedTypes}
				value={null}
				onSelect={(mediaValue) => {
					onSelectImageHandler(mediaValue);
				}}
				render={({ open }) => (
					<div className="ablocks-background-video--upload__replace">
						<Button
							onClick={open}
							label={__('Replace Video', 'ablocks')}
							isShowPrimaryLabel
						/>
					</div>
				)}
			/>
			<Button
				onClick={() => onRemoveImageHandler()}
				icon={
					<span className="ablocks-icon ablocks-icon--delete"></span>
				}
			/>
		</>
	);

	if (imageAttributeValue) {
		imageUploaderAndPreview = (
			<div className="ablocks-video-wrapper">
				<video
					src={imageAttributeValue}
					className="ablocks-video"
				></video>
				{replaceImage}
			</div>
		);
	} else {
		imageUploaderAndPreview = (
			<MediaUpload
				allowedTypes={allowedTypes}
				value={attributeName + deviceType}
				onSelect={(mediaValue) => {
					onSelectImageHandler(mediaValue);
				}}
				render={({ open }) => (
					<div className="ablocks-placeholder-video-wrapper">
						<img
							className="ablocks-placeholder-image"
							src={
								PluginURL +
								'/assets/images/placeholder-image.svg'
							}
							alt=""
						/>
						<div className="ablocks-background-video--upload__replace">
							<Button
								onClick={open}
								label={__('Choose Video…', 'ablocks')}
								isShowPrimaryLabel
							/>
						</div>
					</div>
				)}
			/>
		);
	}

	return imageUploaderAndPreview;
}
