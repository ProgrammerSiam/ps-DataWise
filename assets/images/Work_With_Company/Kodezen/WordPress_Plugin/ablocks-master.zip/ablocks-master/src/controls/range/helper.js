export const getAttributeDefaultValue = (
	isResponsive = false,
	attributeObjectKey = 'value',
	defaultValue = {}
) => {
	if (isResponsive) {
		return {
			[attributeObjectKey]: '',
			[attributeObjectKey + 'Tablet']: '',
			[attributeObjectKey + 'Mobile']: '',
			[attributeObjectKey + 'Unit']: 'px',
			[attributeObjectKey + 'UnitTablet']: '',
			[attributeObjectKey + 'UnitMobile']: '',
			...defaultValue,
		};
	}
	return {
		[attributeObjectKey]: '',
		...defaultValue,
	};
};

export const getAttribute = (
	attributeName,
	isResponsive = false,
	defaultValue = {},
	attributeObjectKey = 'value'
) => {
	if (isResponsive) {
		return {
			[attributeName]: {
				type: 'object',
				default: getAttributeDefaultValue(
					isResponsive,
					attributeObjectKey,
					defaultValue
				),
			},
		};
	}
	return {
		[attributeName]: {
			type: 'object',
			default: getAttributeDefaultValue(
				isResponsive,
				attributeObjectKey,
				defaultValue
			),
		},
	};
};
