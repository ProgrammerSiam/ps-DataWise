import { getUnit } from '@Utils/helper';

export const typeOptions = [
	{ label: 'None', value: 'none' },
	{ label: 'Color', value: 'color' },
	{ label: 'Image', value: 'image' },
];

export const getAttributeDefaultValue = (isResponsive = false) => {
	if (isResponsive) {
		return {
			backgroundType: 'none',
			backgroundTypeH: 'none',

			// Background color - Normal
			backgroundColor: '',

			// Background color - Hover
			backgroundColorH: '',

			// Background image - Normal
			imgId: '',
			imgIdTablet: '',
			imgIdMobile: '',
			imgUrl: '',
			imgUrlTablet: '',
			imgUrlMobile: '',
			imgSize: '',
			imgSizeTablet: '',
			imgSizeMobile: '',
			imgPosition: '',
			imgPositionTablet: '',
			imgPositionMobile: '',
			imgXPositionUnit: 'px',
			imgXPositionTabletUnit: '',
			imgXPositionMobileUnit: '',
			imgXPosition: '',
			imgXPositionTablet: '',
			imgXPositionMobile: '',
			imgYPositionUnit: 'px',
			imgYPositionUnitTablet: '',
			imgYPositionUnitMobile: '',
			imgYPosition: '',
			imgYPositionTablet: '',
			imgYPositionMobile: '',
			imgAttachment: '',
			imgRepeat: '',
			imgRepeatTablet: '',
			imgRepeatMobile: '',
			imgDisplaySize: '',
			imgDisplaySizeTablet: '',
			imgDisplaySizeMobile: '',
			imgDisplaySizeWidth: '',
			imgDisplaySizeWidthTablet: '',
			imgDisplaySizeWidthMobile: '',
			imgDisplaySizeWidthUnit: 'px',
			imgDisplaySizeWidthUnitTablet: '',
			imgDisplaySizeWidthUnitMobile: '',

			// Background image - Hover
			imgIdH: '',
			imgIdTabletH: '',
			imgIdMobileH: '',
			imgUrlH: '',
			imgUrlHTablet: '',
			imgUrlHMobile: '',
			imgSizeH: '',
			imgSizeHTablet: '',
			imgSizeHMobile: '',
			imgPositionH: '',
			imgPositionHTablet: '',
			imgPositionHMobile: '',
			imgXPositionUnitH: 'px',
			imgXPositionUnitHTablet: '',
			imgXPositionUnitHMobile: '',
			imgXPositionH: '',
			imgXPositionHTablet: '',
			imgXPositionHMobile: '',
			imgYPositionUnitH: 'px',
			imgYPositionUnitHTablet: '',
			imgYPositionUnitHMobile: '',
			imgYPositionH: '',
			imgYPositionHTablet: '',
			imgYPositionHMobile: '',
			imgAttachmentH: '',
			imgRepeatH: '',
			imgRepeatHTablet: '',
			imgRepeatHMobile: '',
			imgDisplaySizeH: '',
			imgDisplaySizeHTablet: '',
			imgDisplaySizeHMobile: '',
			imgDisplaySizeWidthH: '',
			imgDisplaySizeWidthHTablet: '',
			imgDisplaySizeWidthHMobile: '',
			imgDisplaySizeWidthHUnit: 'px',
			imgDisplaySizeWidthHUnitTablet: '',
			imgDisplaySizeWidthHUnitMobile: '',

			// Background image transition
			transitionDuration: '',

			// Background video
			videoUrl: '',
			youtubeURL: '',
			vimeoURL: '',
			selfHostedURL: '',
			externalLink: false,
			videoSource: 'none',
			videoPlayOnce: '',
			videoStartTime: '',
			videoEndTime: '',
			playOnMobile: '',
			videoPrivacyMode: '',
			fallbackImageUrl: '',
		};
	}
	return {
		backgroundType: 'none',
		backgroundTypeH: 'none',

		// Background color - Normal
		backgroundColor: '',

		// Background color - Hover
		backgroundColorH: '',

		// Background image - Normal
		imgId: '',
		imgUrl: '',
		imgSize: '',
		imgPosition: '',
		imgAttachment: '',
		imgRepeat: '',
		imgDisplaySize: '',
		imgdisplaySizeWidth: '',
		imgDisplaySizeWidthUnit: 'px',
		imgXPositionUnit: 'px',
		imgXPosition: '',
		imgYPositionUnit: 'px',
		imgYPosition: '',

		// Background image - Hover
		imgIdH: '',
		imgUrlH: '',
		imgSizeH: '',
		imgPositionH: '',
		imgXPositionUnitH: 'px',
		imgXPositionH: '',
		imgYPositionUnitH: 'px',
		imgYPositionH: '',
		imgAttachmentH: '',
		imgRepeatH: '',
		imgDisplaySizeH: '',
		imgDisplaySizeWidthH: '',
		imgDisplaySizeWidthHUnit: 'px',

		// Background image transition
		transitionDuration: '',

		// Background video
		videoUrl: '',
		youtubeURL: '',
		vimeoURL: '',
		selfHostedURL: '',
		externalLink: false,
		videoSource: 'none',
		videoPlayOnce: '',
		videoStartTime: '',
		videoEndTime: '',
		playOnMobile: '',
		videoPrivacyMode: '',
		fallbackImageUrl: '',
	};
};

export const getAttribute = (attributeName, isResponsive = false) => {
	if (isResponsive) {
		return {
			[attributeName]: {
				type: 'object',
				default: getAttributeDefaultValue(isResponsive),
			},
		};
	}
	return {
		[attributeName]: {
			type: 'object',
			default: getAttributeDefaultValue(isResponsive),
		},
	};
};

export const getCSS = (attributeValue, property = '', device = '') => {
	const value = {
		...getAttributeDefaultValue(device ? true : false),
		...attributeValue,
	};

	const unitXPositionUnit = getUnit(
		{
			unit: value.imgXPositionUnit,
			unitTablet: value.imgXPositionUnitTablet,
			unitMobile: value.imgXPositionUnitMobile,
		},
		device
	);
	const unitYPositionUnit = getUnit(
		{
			unit: value.imgYPositionUnit,
			unitTablet: value.imgYPositionUnitTablet,
			unitMobile: value.imgYPositionUnitMobile,
		},
		device
	);
	const imgDisplaySizeWidthUnit = getUnit(
		{
			unit: value.imgDisplaySizeWidthUnit,
			unitTablet: value.imgDisplaySizeWidthUnitTablet,
			unitMobile: value.imgDisplaySizeWidthUnitMobile,
		},
		device
	);

	const css = {};

	if (value.backgroundType === 'image') {
		if (value.imgUrl !== '' && value.imgUrl !== undefined) {
			if (!value['imgUrl' + device]) {
				// background image
				css[`${property}-image`] = `url("${value.imgUrl}")`;
			} else {
				// background image
				css[`${property}-image`] = `url("${value['imgUrl' + device]}")`;
			}

			// background-position css
			if (value['imgPosition' + device] !== '') {
				if (value['imgPosition' + device] === 'custom') {
					css[`${property}-position`] = `${
						value['imgXPosition' + device]
							? value['imgXPosition' + device]
							: '0'
					}${unitXPositionUnit} ${
						value['imgYPosition' + device]
							? value['imgYPosition' + device]
							: '0'
					}${unitYPositionUnit}`;
				} else {
					css[`${property}-position`] = value['imgPosition' + device];
				}
			}
			// background-attachments css
			if (value['imgAttachment' + device] !== '') {
				css[`${property}-attachment`] = value['imgAttachment' + device];
			}
			// background-repeat css
			if (value['imgRepeat' + device] !== '') {
				css[`${property}-repeat`] = value['imgRepeat' + device];
			}
			// background-size css
			if (value['imgDisplaySize' + device] !== '') {
				if (value['imgDisplaySize' + device] === 'custom') {
					css[`${property}-size`] = `${
						value['imgDisplaySizeWidth' + device]
					}${imgDisplaySizeWidthUnit} auto`;
				} else {
					css[`${property}-size`] = value['imgDisplaySize' + device];
				}
			}
		}
	} else if (value.backgroundType === 'video') {
		// fallbackImageUrl
		if (
			value.fallbackImageUrl !== '' &&
			value.fallbackImageUrl !== undefined
		) {
			css[`${property}-image`] = `url("${value.fallbackImageUrl}")`;
			css[`${property}-size`] = 'cover';
		}
	} else if (value.backgroundType === 'color') {
		if (value.backgroundColor) {
			// background color
			css[`${property}`] = value.backgroundColor;
		}
	}

	if (
		value.transitionDuration !== '' &&
		value.transitionDuration !== undefined
	) {
		css.transition = `${property} ${value.transitionDuration}s ease`;
	}

	return css;
};

export const getHoverCSS = (attributeValue, property = '', device = '') => {
	const value = {
		...getAttributeDefaultValue(device ? true : false),
		...attributeValue,
	};

	const unitXPositionUnitH = getUnit(
		{
			unit: value.imgXPositionUnitH,
			unitTablet: value.imgXPositionUnitHTablet,
			unitMobile: value.imgXPositionUnitHMobile,
		},
		device
	);
	const unitYPositionUnitH = getUnit(
		{
			unit: value.imgYPositionUnitH,
			unitTablet: value.imgYPositionUnitHTablet,
			unitMobile: value.imgYPositionUnitHMobile,
		},
		device
	);
	const imgDisplaySizeWidthHUnit = getUnit(
		{
			unit: value.imgDisplaySizeWidthHUnit,
			unitTablet: value.imgDisplaySizeWidthHUnitTablet,
			unitMobile: value.imgDisplaySizeWidthHMobile,
		},
		device
	);

	const css = {};

	if (value.backgroundType === 'image' && value.backgroundTypeH === 'image') {
		if (
			value['imgUrlH' + device] !== '' &&
			value['imgUrlH' + device] !== undefined
		) {
			css[`${property}-image`] = `url("${value['imgUrlH' + device]}")`;

			// background-position css
			if (value['imgPositionH' + device] !== '') {
				if (value['imgPositionH' + device] === 'custom') {
					css[`${property}-position`] = `${
						value['imgXPositionH' + device]
							? value['imgXPositionH' + device]
							: '0'
					}${unitXPositionUnitH} ${
						value['imgYPositionH' + device]
							? value['imgYPositionH' + device]
							: '0'
					}${unitYPositionUnitH}`;
				} else {
					css[`${property}-position`] =
						value['imgPositionH' + device];
				}
			}
			// background-attachments css
			if (value['imgAttachmentH' + device] !== '') {
				css[`${property}-attachment`] =
					value['imgAttachmentH' + device];
			}
			// background-repeat css
			if (value['imgRepeatH' + device] !== '') {
				css[`${property}-repeat`] = value['imgRepeatH' + device];
			}
			// background-size css
			if (value['imgDisplaySizeH' + device] !== '') {
				if (value['imgDisplaySizeH' + device] === 'custom') {
					css[`${property}-size`] = `${
						value['imgDisplaySizeWidthH' + device]
					}${imgDisplaySizeWidthHUnit} auto`;
				} else {
					css[`${property}-size`] = value['imgDisplaySizeH' + device];
				}
			}
		}
	} else if (value.backgroundTypeH === 'video') {
		// use hover background video
	} else if (value.backgroundTypeH === 'color') {
		if (value.backgroundColorH) {
			// Background color - Hover
			css[`${property}`] = value.backgroundColorH;
		}
	}

	return css;
};
