import { getCSS as getAlignmentCSS } from '@Controls/alignment/helper';
import { getCSS as getTypographyCSS } from '@Controls/typography/helper';
import { getCSS as getTextShadowCSS } from '@Controls/textShadow/helper';
import { getCSS as getTextStrokeCSS } from '@Controls/textStroke/helper';

export const getWrapperCSS = (attributes, device = '') => {
	return {
		...getAlignmentCSS(attributes?.alignment, 'text-align', device),
	};
};
export const getHeadingTextCSS = (attributes, device = '') => {
	return {
		...getTypographyCSS(attributes?.typography, device),
		...getTextStrokeCSS(attributes?.textStroke, device),
		...getTextShadowCSS(attributes?.textShadow),
	};
};
