import ABlocksColorControl from '@Controls/color-gradient-control';
import { __ } from '@wordpress/i18n';

export default function ABlocksBackgroundColorPicker(props) {
	const {
		hover,
		attributeValue,
		changeHandler,
		attributeName,
		setAttributes,
	} = props;
	let backgroundColorAttributeObjectKey = 'backgroundColor';

	if (hover) {
		backgroundColorAttributeObjectKey = 'backgroundColorH';
	}
	return (
		<ABlocksColorControl
			isGradient
			label={__('Background color', 'ablocks')}
			attributeName={backgroundColorAttributeObjectKey}
			attributeValue={attributeValue[backgroundColorAttributeObjectKey]}
			onChangeHandler={(attributeObjectKey, controlValue) => {
				changeHandler(controlValue, attributeObjectKey);
			}}
			resetHandler={() => {
				const newAttributeValue = { ...attributeValue };
				delete newAttributeValue[backgroundColorAttributeObjectKey];
				setAttributes({ [attributeName]: newAttributeValue });
			}}
		/>
	);
}
