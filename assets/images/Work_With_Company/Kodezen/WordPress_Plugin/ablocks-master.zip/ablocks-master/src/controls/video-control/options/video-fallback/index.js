import GetDeviceType from '@Utils/get-device-type';
import MediaUploadField from '@Components/media-upload';
import { __ } from '@wordpress/i18n';
import '../../options/styles.scss';

export default function ABlocksBackgroundVideoFallback(props) {
	const {
		attributeValue,
		onSelectFallbackImageHandler,
		onRemoveFallbackImageHandler,
	} = props;
	const deviceType = GetDeviceType();

	return (
		<div className="ablocks-control--background__video--fallback">
			<p>{__('Background fallback', 'ablocks')}</p>
			<MediaUploadField
				allowedTypes={['image']}
				attributeValue={attributeValue}
				deviceType={deviceType}
				onSelectImageHandler={onSelectFallbackImageHandler}
				onRemoveImageHandler={onRemoveFallbackImageHandler}
				attributeName="fallbackImageUrl"
			/>
			<span className="ablocks-control--background__video--fallback__description">
				{__(
					'This cover image will replace the background video in case that the video could not be loaded',
					'ablocks'
				)}
			</span>
		</div>
	);
}
