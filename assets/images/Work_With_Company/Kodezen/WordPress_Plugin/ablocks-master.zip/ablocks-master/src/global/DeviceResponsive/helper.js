export const getAttribute = () => {
	return {
		_hide_on_desktop: {
			type: 'bool',
			default: false,
		},
		_hide_on_tablet: {
			type: 'bool',
			default: false,
		},
		_hide_on_mobile: {
			type: 'bool',
			default: false,
		},
	};
};

export const getCSS = (attributeValue, device = '') => {
	const CSS = {
		display: 'inherit',
		background:
			'repeating-linear-gradient(125deg, rgba(0, 0, 0, 0.05), rgba(0, 0, 0, 0.05) 1px, transparent 2px, transparent 9px)',
		border: '1px solid rgba(0, 0, 0, 0.02)',
	};

	if (!device && attributeValue._hide_on_desktop) {
		return CSS;
	}

	if ('Tablet' === device && attributeValue._hide_on_tablet) {
		return CSS;
	}

	if ('Mobile' === device && attributeValue._hide_on_mobile) {
		return CSS;
	}

	return {};
};

export const getInnerElementCSS = (attributeValue, device = '') => {
	const CSS = {
		filter: 'opacity(0.4) saturate(0)',
	};

	if (!device && attributeValue._hide_on_desktop) {
		return CSS;
	}

	if ('Tablet' === device && attributeValue._hide_on_tablet) {
		return CSS;
	}

	if ('Mobile' === device && attributeValue._hide_on_mobile) {
		return CSS;
	}

	return {};
};
