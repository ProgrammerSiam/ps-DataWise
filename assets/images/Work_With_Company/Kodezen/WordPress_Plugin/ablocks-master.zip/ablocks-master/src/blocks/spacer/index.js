import { registerBlockType } from '@wordpress/blocks';
import attributes from './attributes';
import Edit from './edit';
import Save from './save';
import metadata from './block.json';

registerBlockType(metadata.name, {
	attributes,
	icon: (
		<svg
			width="24"
			height="25"
			viewBox="0 0 24 25"
			fill="none"
			xmlns="http://www.w3.org/2000/svg"
		>
			<path
				d="M9 9.56091L9 15.5609L15 15.5609L15 9.56091L9 9.56091ZM4 4.56091L4 6.06091L20 6.06091L20 4.56091L4 4.56091ZM20 19.0609L4 19.0609L4 20.5609L20 20.5609L20 19.0609Z"
				fill="#E930F0"
			/>
		</svg>
	),
	edit: Edit,
	save: Save,
});
