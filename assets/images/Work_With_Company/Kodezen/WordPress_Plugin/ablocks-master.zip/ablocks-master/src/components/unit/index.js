import React, { useState, useEffect, useRef, forwardRef } from 'react';
import PropTypes from 'prop-types';
import Button from '@Components/Button';
import { objectUniqueCheck } from '@Utils/helper';
import GetDeviceType from '@Utils/get-device-type';
import './editor.scss';

const propTypes = {
	options: PropTypes.array,
	attributeObjectKey: PropTypes.string,
	defaultValue: PropTypes.string,
	attributeName: PropTypes.string,
	onChangeHandler: PropTypes.func,
	isResponsive: PropTypes.bool,
	attributeDefaultValue: PropTypes.object,
	setAttributes: PropTypes.func,
	getAttributeDefaultValue: PropTypes.func,
	attributeValue: PropTypes.any,
};

const defaultProps = {
	attributeObjectKey: '',
	defaultValue: '',
	isResponsive: true,
	options: [
		{ value: 'px', label: 'px' },
		{ value: '%', label: '%' },
		{ value: 'rem', label: 'rem' },
		{ value: 'em', label: 'em' },
	],
};

const ABlocksUnitSelect = forwardRef(
	(
		{
			options,
			attributeValue,
			attributeName,
			onChangeHandler,
			attributeObjectKey,
			getAttributeDefaultValue,
			setAttributes,
			isResponsive,
		},
		ref
	) => {
		const deviceType = GetDeviceType();

		const [isDropdownOpen, setDropdownOpen] = useState(false);
		const menuItemRef = useRef(null);
		// const relativeTo = useRef(null);

		const toggleDropdown = () => {
			setDropdownOpen(!isDropdownOpen);
		};

		const handleClick = (e) => {
			if (
				menuItemRef?.current &&
				!menuItemRef?.current?.contains(e.target)
			) {
				setDropdownOpen(false);
			}
		};

		useEffect(() => {
			document.addEventListener('mousedown', handleClick);
			return () => document.removeEventListener('mousedown', handleClick);
		}, []);

		const changeHandler = (controlValue, deviceMode) => {
			if (onChangeHandler) {
				onChangeHandler(
					controlValue,
					isResponsive
						? attributeObjectKey + deviceMode
						: attributeObjectKey
				);
			} else {
				defaultChangeHandler(controlValue, deviceMode);
			}
		};

		const defaultChangeHandler = (controlValue, deviceMode) => {
			if (isResponsive) {
				return setAttributes({
					[attributeName]: objectUniqueCheck(
						getAttributeDefaultValue(isResponsive),
						{
							...attributeValue,
							[attributeObjectKey + deviceMode]: controlValue,
						}
					),
				});
			}
			return setAttributes({ [attributeName]: controlValue });
		};

		const renderOptions = () => {
			return (
				<div
					className={`ablocks-unit-select__dropdown-items ${
						isDropdownOpen &&
						'ablocks-unit-select__dropdown--is-open'
					}`}
					ref={menuItemRef}
				>
					{options.map((option, index) => {
						return (
							<Button
								key={index}
								onClick={() => {
									changeHandler(option.value, deviceType);
									toggleDropdown();
								}}
								label={option.label}
							/>
						);
					})}
				</div>
			);
		};

		const getLabel = () => {
			const defaultUnit = options[0]?.label || 'px';
			if (isResponsive) {
				return attributeValue[attributeObjectKey + deviceType]
					? attributeValue[attributeObjectKey + deviceType]
					: defaultUnit;
			}
			return attributeValue ?? defaultUnit;
		};

		return (
			<div className="ablocks-unit-select">
				<Button
					onClick={toggleDropdown}
					ref={ref}
					label={getLabel()}
					icon={
						<span className="ablocks-icon ablocks-icon--angle-down"></span>
					}
					iconPosition="right"
				/>
				{renderOptions()}
			</div>
		);
	}
);

ABlocksUnitSelect.propTypes = propTypes;
ABlocksUnitSelect.defaultProps = defaultProps;
export default ABlocksUnitSelect;
