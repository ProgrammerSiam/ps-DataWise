import { registerBlockType } from '@wordpress/blocks';
import attributes from './attributes';
import Edit from './edit';
import Save from './save';
import metadata from './block.json';

registerBlockType(metadata.name, {
	attributes,
	icon: (
		<svg
			width="24"
			height="25"
			viewBox="0 0 24 25"
			fill="none"
			xmlns="http://www.w3.org/2000/svg"
		>
			<path
				d="M17.6 7.56091C17 8.46091 16.1 9.26091 15 9.56091V10.5609H17V17.5609H19V7.56091H17.6ZM11 11.5609H7V7.56091H5V17.5609H7V13.5609H11V17.5609H13V7.56091H11V11.5609Z"
				fill="#E930F0"
			/>
		</svg>
	),
	edit: Edit,
	save: Save,
});
