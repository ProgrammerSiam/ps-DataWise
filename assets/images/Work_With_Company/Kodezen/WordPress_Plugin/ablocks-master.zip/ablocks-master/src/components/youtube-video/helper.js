export const generateYouTubeEmbedURL = (
	videoID,
	privacyMode,
	loop,
	mute,
	autoplay,
	playerControl,
	getStartAndEndTime
) => {
	const baseYouTubeURL = `https://${
		privacyMode ? 'www.youtube-nocookie.com' : 'www.youtube.com'
	}/embed/`;
	const defaultVideoID = '9hg-KpQoL5M';
	const commonLink = `?amp;controls=${
		playerControl ? '1' : '0'
	}&rel=0&playsinline=1&mute=${mute ? '1' : '0'}&autoplay=${
		autoplay ? '1' : '0'
	}&loop=${loop ? '1' : '0'}${getStartAndEndTime || ''}`;

	const embedURL = videoID
		? `${baseYouTubeURL + videoID + commonLink}`
		: `${baseYouTubeURL + defaultVideoID + commonLink}`;

	return embedURL;
};

export function getYouTubeVideoId(url = '') {
	const match = url?.match(
		/(?:youtu\.be\/|youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/
	);
	return match ? match[1] : null;
}

export const handleYTStartAndEndTime = (videoStartTime, videoEndTime) => {
	const formattedStartTime = videoStartTime || 0;
	const formattedEndTime = videoEndTime || '';

	const isVideoTimeSet =
		formattedStartTime || formattedEndTime
			? `&amp;start=${formattedStartTime}&end=${formattedEndTime}`
			: '';

	return isVideoTimeSet;
};

// https://www.youtube.com/watch?v=NSAOrGb9orM
// https://youtu.be/NSAOrGb9orM?si=U-N-6AMDecsu9tIH
// https://www.youtube.com/embed/NSAOrGb9orM?si=U-N-6AMDecsu9tIH
