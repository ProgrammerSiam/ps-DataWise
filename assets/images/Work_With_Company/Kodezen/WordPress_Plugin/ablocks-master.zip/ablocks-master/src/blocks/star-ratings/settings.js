import React from 'react';
import { InspectorControls } from '@wordpress/block-editor';
import { __ } from '@wordpress/i18n';
import InspectorTabs from '@Components/inspector-tabs';
import ABlocksAlignmentControl from '@Controls/alignment';
import ABlocksSelectControl from '@Controls/select';
import Separator from '@Components/separator';
import ABlocksColorControl from '@Controls/color-gradient-control';
import ContentStyleTabs from '@Components/content-style-tabs';
import ABlocksPanelBody from '@Components/panel-body';
import ABlocksRangeControl from '@Controls/range';
import ABlocksIconUploader from '@Controls/icon-upload';
import { ratingScaleOptions } from './helper';
import ABlocksToggleControl from '@Controls/toggleButton';
import ABlocksTypography from '@Controls/typography';
const propTypes = {};

const defaultProps = {};

export default function Settings(props) {
	const { attributes, setAttributes } = props;
	const {
		scale,
		ratingColor,
		ratingUnmarkedColor,
		alignment,
		showRatingNumber,
		spacing,
		size,
		ratingNumberColor,
		ratingNumberTypography,
	} = attributes;
	return (
		<React.Fragment>
			<InspectorControls>
				<InspectorTabs
					attributes={attributes}
					setAttributes={setAttributes}
				>
					<ABlocksPanelBody
						title={__('Start Rating', 'ablocks')}
						initialOpen={true}
					>
						<ContentStyleTabs
							content={
								<>
									<ABlocksSelectControl
										label={__('Scale', 'ablocks')}
										options={ratingScaleOptions}
										attributeName="scale"
										attributeValue={scale}
										onChangeHandler={(controlValue) => {
											setAttributes({
												scale: controlValue,
												rating:
													attributes?.rating >
													controlValue
														? controlValue
														: attributes?.rating,
											});
										}}
									/>
									<ABlocksRangeControl
										label={__('Rating', 'ablocks')}
										attributeName="rating"
										attributeObjectKey="rating"
										attributeValue={attributes}
										setAttributes={setAttributes}
										isResponsive={false}
										isInline={false}
										step={0.1}
										min={1}
										max={scale ? Number(scale) : 5}
									/>
									<ABlocksIconUploader
										label={__('Icon', 'ablocks')}
										attributes={attributes}
										setAttributes={setAttributes}
									/>
									<ABlocksAlignmentControl
										label={__('Alignment', 'ablocks')}
										attributeName="alignment"
										attributeValue={alignment}
										setAttributes={setAttributes}
										isInline={false}
										options={[
											{
												label: 'left',
												value: 'left',
												icon: 'left',
											},
											{
												label: 'center',
												value: 'center',
												icon: 'center',
											},
											{
												label: 'right',
												value: 'right',
												icon: 'right',
											},
										]}
									/>
									<ABlocksToggleControl
										label={__(
											'Show Rating number',
											'ablocks'
										)}
										attributeName="showRatingNumber"
										attributeValue={showRatingNumber}
										setAttributes={setAttributes}
										isResponsive={false}
									/>
								</>
							}
							style={
								<>
									<ABlocksRangeControl
										label={__('Size', 'ablocks')}
										attributeName="size"
										attributeValue={size}
										setAttributes={setAttributes}
										isResponsive={true}
										step={1}
										min={1}
										max={30}
										isInline={false}
									/>

									<ABlocksRangeControl
										label={__('Spacing', 'ablocks')}
										attributeName="spacing"
										attributeValue={spacing}
										setAttributes={setAttributes}
										isResponsive={true}
										step={1}
										min={1}
										max={20}
										isInline={false}
									/>
									<Separator />
									<ABlocksColorControl
										label={__('Color', 'ablocks')}
										attributeName="ratingColor"
										attributeValue={ratingColor}
										setAttributes={setAttributes}
									/>
									<ABlocksColorControl
										label={__('Unmarked Color', 'ablocks')}
										attributeName="ratingUnmarkedColor"
										attributeValue={ratingUnmarkedColor}
										setAttributes={setAttributes}
									/>
								</>
							}
						/>
					</ABlocksPanelBody>
					{showRatingNumber && (
						<ABlocksPanelBody
							title={__('Rating Number ', 'ablocks')}
							initialOpen={true}
						>
							<ContentStyleTabs
								content={
									<>
										<ABlocksAlignmentControl
											label={__('Position', 'ablocks')}
											isResponsive={false}
											attributeName="ratingNumberPosition"
											attributeObjectKey="ratingNumberPosition"
											attributeValue={attributes}
											setAttributes={setAttributes}
											isInline={false}
											options={[
												{
													label: 'left',
													value: 'left',
													icon: 'left',
												},
												{
													label: 'right',
													value: 'right',
													icon: 'right',
												},
											]}
										/>
										<ABlocksRangeControl
											label={__('Gap', 'ablocks')}
											attributeName="ratingNumberGap"
											attributeObjectKey="ratingNumberGap"
											attributeValue={attributes}
											setAttributes={setAttributes}
											isResponsive={false}
											step={1}
											min={1}
											max={50}
											isInline={false}
										/>
									</>
								}
								style={
									<>
										<ABlocksColorControl
											label={__('Color', 'ablocks')}
											attributeName="ratingNumberColor"
											attributeValue={ratingNumberColor}
											setAttributes={setAttributes}
										/>
										<ABlocksTypography
											label={__('Typography', 'ablocks')}
											attributeName="ratingNumberTypography"
											attributeValue={
												ratingNumberTypography
											}
											setAttributes={setAttributes}
											isResponsive={true}
										/>
									</>
								}
							/>
						</ABlocksPanelBody>
					)}
				</InspectorTabs>
			</InspectorControls>
		</React.Fragment>
	);
}

Settings.propTypes = propTypes;
Settings.defaultProps = defaultProps;
