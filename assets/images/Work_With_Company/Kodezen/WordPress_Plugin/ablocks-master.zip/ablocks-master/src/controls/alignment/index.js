import React from 'react';
import PropTypes from 'prop-types';
import GetDeviceType from '@Utils/get-device-type';
import ABlocksAlignmentItems from './items';
import ControlLabel from '@Components/control-label';
import {
	alignmentOptions,
	getAttributeDefaultValue,
} from '@Controls/alignment/helper';
import { objectUniqueCheck } from '@Utils/helper';
import classnames from 'classnames';
import './styles.scss';
const propTypes = {
	isResponsive: PropTypes.bool,
	label: PropTypes.string,
	attributeName: PropTypes.string,
	attributeValue: PropTypes.any,
	setAttributes: PropTypes.func,
	onChangeHandler: PropTypes.func,
	options: PropTypes.array,
	attributeObjectKey: PropTypes.string,
	isInline: PropTypes.bool,
};

const defaultProps = {
	label: '',
	isResponsive: true,
	options: alignmentOptions,
	attributeObjectKey: 'value',
	isInline: true,
};

let deviceType = '';
export default function ABlocksAlignmentControl(props) {
	const {
		isResponsive,
		attributeName,
		attributeValue,
		onChangeHandler,
		setAttributes,
		label,
		attributeObjectKey,
		options,
		isInline,
	} = props;
	deviceType = isResponsive ? GetDeviceType() : '';

	const changeHandler = (controlValue, deviceMode) => {
		if (onChangeHandler) {
			onChangeHandler(
				controlValue,
				isResponsive
					? attributeObjectKey + deviceMode
					: attributeObjectKey
			);
		} else {
			defaultChangeHandler(controlValue, deviceMode);
		}
	};
	const defaultChangeHandler = (controlValue, deviceMode) => {
		if (isResponsive) {
			return setAttributes({
				[attributeName]: objectUniqueCheck(
					getAttributeDefaultValue(isResponsive),
					{
						...attributeValue,
						[attributeObjectKey + deviceMode]: controlValue,
					}
				),
			});
		}
		return setAttributes({ [attributeName]: controlValue });
	};

	return (
		<React.Fragment>
			<div
				className={classnames(
					`ablocks-control ablocks-control--alignment`,
					{ 'ablocks-control--inline': isInline }
				)}
			>
				{label && (
					<ControlLabel label={label} isResponsive={isResponsive} />
				)}
				<ABlocksAlignmentItems
					attributeName={attributeName}
					deviceType={deviceType}
					attributeValue={
						attributeValue[attributeObjectKey + deviceType]
					}
					setAttributes={setAttributes}
					changeHandler={changeHandler}
					options={options}
					isResponsive={isResponsive}
				/>
			</div>
		</React.Fragment>
	);
}

ABlocksAlignmentControl.propTypes = propTypes;
ABlocksAlignmentControl.defaultProps = defaultProps;
