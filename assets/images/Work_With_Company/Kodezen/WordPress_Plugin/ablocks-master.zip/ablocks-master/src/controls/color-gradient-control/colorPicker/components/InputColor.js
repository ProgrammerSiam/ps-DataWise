import { TextControl } from '@wordpress/components';
import React, { useEffect, useState } from 'react';

import {
	getColorObjectDataBasedOnType,
	convertColordataToHsvaBasedOnType,
	isValidHex,
	isValidShortHex,
} from '../utils/helperFunctions';
import ABlocksUnitSelect from '@Components/unit';
import './InputColor.scss';

const colorTypeOptions = [
	{ label: 'HEX', value: 'hex' },
	{ label: 'RGB', value: 'rgb' },
	{ label: 'HSL', value: 'hsl' },
];

let ablocksHelperOnChangeTimeoutId = false;
let alertGiven = false;

export const InputColor = ({
	hsva,
	onChange,
	setColorType,
	colorType,
	alpha,
	handleAphaChange,
}) => {
	const [colorInputData, setColorInputData] = useState(
		getColorObjectDataBasedOnType(hsva, colorType)
	);

	function onColorTypeChange(option) {
		const optionValue = option.value;
		setColorInputData(getColorObjectDataBasedOnType(hsva, optionValue));
		setColorType(optionValue);
		onChange(hsva, optionValue);
	}

	const onInputChange = (name, val, max = 255) => {
		alertGiven = false;
		let value = val.trim();
		let newColorInputData = {};
		const isHex = name === 'hex';

		if (isHex) {
			value = value.startsWith('#') ? value : `#${value}`;
		} else if ('rgbhsl'.includes(name)) {
			value = parseInt(value);
			if (value > max || value < 0) {
				return false;
			}
		}
		newColorInputData = {
			...colorInputData,
			[name]: value,
		};
		setColorInputData(newColorInputData);

		clearTimeout(ablocksHelperOnChangeTimeoutId);
		const timeOutInMs = isHex && isValidShortHex(value) ? 600 : 300;
		ablocksHelperOnChangeTimeoutId = setTimeout(() => {
			if (isHex && !isValidHex(value)) {
				return false;
			}
			const newHsva = convertColordataToHsvaBasedOnType(
				newColorInputData,
				colorType
			);
			onChange(newHsva, colorType);
		}, timeOutInMs);
	};

	const handleBlur = () => {
		if (alertGiven) {
			return false;
		}

		let isColorValid = false;
		if (colorType === 'hex') {
			isColorValid = isValidHex(colorInputData?.hex);
		} else if (colorType === 'rgb') {
			const { r, g, b, a } = colorInputData;
			isColorValid =
				[r, g, b].every((item) => item >= 0 && item <= 255) &&
				typeof a === 'number';
		} else if (colorType === 'hsl') {
			const { h, s, l, a } = colorInputData;
			isColorValid =
				h >= 0 &&
				h <= 360 &&
				[s, l].every((item) => item >= 0 && item <= 100) &&
				typeof a === 'number';
		}

		if (!isColorValid) {
			alertGiven = true;
			// eslint-disable-next-line no-alert
			return window.alert(
				'Input color is not valid. Please give a valid color value.'
			);
		}
	};

	useEffect(() => {
		clearTimeout(ablocksHelperOnChangeTimeoutId);
		ablocksHelperOnChangeTimeoutId = setTimeout(() => {
			setColorInputData(
				getColorObjectDataBasedOnType(hsva, colorType || 'hex')
			);
		}, 300);
		return () => {
			clearTimeout(ablocksHelperOnChangeTimeoutId);
		};
	}, [hsva]); // eslint-disable-line react-hooks/exhaustive-deps

	const colorTypeSelectedOption = colorTypeOptions.find(
		(item) => item.value === colorType
	);

	let commonProps = {};
	if (colorType === 'hex') {
		commonProps = {
			onBlur: handleBlur,
			className: 'ablocks-color-input--hex-field',
			value: colorInputData?.hex,
			onChange: (value) => onInputChange('hex', value),
		};
	} else if (colorType === 'rgb') {
		commonProps = {
			onBlur: handleBlur,
			className: 'ablocks-color-input--rgb-field',
			type: 'number',
			min: 0,
			max: 255,
		};
	} else if (colorType === 'hsl') {
		commonProps = {
			onBlur: handleBlur,
			className: 'ablocks-color-input--rgb-field',
			type: 'number',
			min: 0,
		};
	}

	return (
		<div className="ablocks-color-input">
			<div
				className={`ablocks-color-input--color-string ablocks-color-input-wrapper--colortype-${
					colorType || 'hex'
				}`}
			>
				<div className="ablocks-color-input--color-value ablocks-color-input--color-value-fields">
					{colorType === 'hex' && <TextControl {...commonProps} />}
					{colorType === 'rgb' && (
						<>
							<TextControl
								{...commonProps}
								value={colorInputData?.r}
								onChange={(value) => onInputChange('r', value)}
							/>
							<TextControl
								{...commonProps}
								value={colorInputData?.g}
								onChange={(value) => onInputChange('g', value)}
							/>
							<TextControl
								{...commonProps}
								value={colorInputData?.b}
								onChange={(value) => onInputChange('b', value)}
							/>
						</>
					)}
					{colorType === 'hsl' && (
						<>
							<TextControl
								{...commonProps}
								max={360}
								value={colorInputData?.h}
								onChange={(value) =>
									onInputChange('h', value, 360)
								}
							/>
							<TextControl
								{...commonProps}
								max={100}
								value={colorInputData?.s}
								onChange={(value) =>
									onInputChange('s', value, 100)
								}
							/>
							<TextControl
								{...commonProps}
								max={100}
								value={colorInputData?.l}
								onChange={(value) =>
									onInputChange('l', value, 100)
								}
							/>
						</>
					)}
				</div>
				<div className="ablocks-color-input--color-value ablocks-color-input--alpha-percentage">
					<TextControl
						className="ablocks-color-input--alpha-field"
						type="number"
						value={alpha}
						onChange={handleAphaChange}
					/>
					<span className="ablocks-color-input--percentage-icon">
						%
					</span>
				</div>
			</div>

			<ABlocksUnitSelect
				options={colorTypeOptions}
				onChangeHandler={(option) => {
					onColorTypeChange({ value: option });
				}}
				isResponsive={false}
				attributeValue={colorTypeSelectedOption?.label}
			/>
		</div>
	);
};
