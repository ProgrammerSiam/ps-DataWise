import React from 'react';
import { onSelectImage } from './utils';
import { caption } from '@wordpress/icons';
import getDeviceType from '@Utils/get-device-type';
import { ToolbarButton } from '@wordpress/components';
import { useSelect, useDispatch } from '@wordpress/data';
import { store as coreStore } from '@wordpress/core-data';
import {
	BlockControls,
	AlignmentControl,
	MediaReplaceFlow,
	// eslint-disable-next-line
	__experimentalImageURLInputUI as ImageURLInputUI,
} from '@wordpress/block-editor';

export default function Toolbar(props) {
	const { attributes, setAttributes, isSelected, block_id } = props;
	const {
		imgId,
		imgIdTablet,
		imgIdMobile,
		textAlign,
		imgCaption,
		imgUrl,
		imgLink: { linkDestination, href, linkTarget, rel, linkClass },
	} = attributes;
	const deviceType = getDeviceType();
	let responsiveImageId;
	if (deviceType === 'Tablet') {
		responsiveImageId = imgIdTablet;
	} else if (deviceType === 'Mobile') {
		responsiveImageId = imgIdMobile;
	} else {
		responsiveImageId = imgId;
	}
	const { createNotice } = useDispatch('core/notices');
	const { image } = useSelect(
		(select) => {
			const { getMedia } = select(coreStore);
			return {
				image:
					responsiveImageId && isSelected
						? getMedia(responsiveImageId)
						: null,
			};
		},
		[imgId, imgIdTablet, imgIdMobile, isSelected]
	);

	const handleAddCaption = () => {
		setAttributes({ imgCaption: !imgCaption });
	};

	function onSetHref(params) {
		setAttributes({
			imgLink: { ...attributes?.imgLink, ...params },
		});
	}

	function onSelectURL(params) {
		setAttributes({
			['imgId' + deviceType]: block_id?.split('-')[0],
			['imgUrl' + deviceType]: params,
		});
	}

	function onUploadError(message) {
		createNotice('error', message, {
			type: 'snackbar',
		});
	}

	return (
		<>
			<BlockControls group="block">
				{/* Alignment control  */}
				<AlignmentControl
					value={textAlign}
					onChange={(nextAlign) => {
						setAttributes({
							alignment: {
								['value' + deviceType]: nextAlign,
							},
						});
					}}
				/>
				{imgId && (
					<>
						{/* Link control  */}
						<ImageURLInputUI
							url={href || ''}
							onChangeUrl={onSetHref}
							linkDestination={linkDestination}
							mediaUrl={(image && image.source_url) || imgUrl}
							mediaLink={image && image.link}
							linkTarget={linkTarget}
							linkClass={linkClass}
							rel={rel}
						/>

						{/* Caption control  */}
						<ToolbarButton
							icon={caption}
							label="Add caption"
							isPressed={imgCaption}
							onClick={handleAddCaption}
						/>
					</>
				)}
			</BlockControls>

			{imgId && (
				<BlockControls group="other">
					<MediaReplaceFlow
						mediaId={['imgId' + deviceType]}
						mediaURL={imgUrl}
						allowedTypes={['image']}
						accept="image/*"
						onSelect={(mediaValue) =>
							onSelectImage(
								mediaValue,
								attributes,
								setAttributes,
								deviceType
							)
						}
						onSelectURL={onSelectURL}
						onError={onUploadError}
					/>
				</BlockControls>
			)}
		</>
	);
}
