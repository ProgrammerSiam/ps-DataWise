import globalAttributes from '@Global/AdvancedSettings/attributes';
import { getAttribute as alignmentAttributes } from '@Controls/alignment/helper';
import { getAttribute as dimensionsAttributes } from '@Controls/dimensions/helper';
import { getAttribute as iconPickerAttributes } from '@Controls/icon-upload/helper';

const attributes = {
	block_id: {
		type: 'string',
	},
	primaryColor: {
		type: 'string',
		default: '#69727d',
	},
	backgroundColor: {
		type: 'string',
	},
	iconType: {
		type: 'string',
		default: 'default',
	},
	iconShape: {
		type: 'string',
		default: 'circle',
	},
	iconSize: {
		type: 'number',
	},
	rotate: {
		type: 'number',
	},
	...iconPickerAttributes(),
	...dimensionsAttributes('padding', false),
	...dimensionsAttributes('borderRadius', false),
	...dimensionsAttributes('borderWidth', false),
	...alignmentAttributes('alignment', true, {
		value: 'left',
	}),
	...globalAttributes,
};
export default attributes;
