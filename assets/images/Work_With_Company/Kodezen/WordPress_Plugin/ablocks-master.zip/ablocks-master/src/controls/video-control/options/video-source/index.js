import GetDeviceType from '@Utils/get-device-type';
import ABlocksTextControl from '@Controls/text';
import ABlocksToggleControl from '@Controls/toggleButton';
import VideoUploadField from '@Components/upload-video';
import { __ } from '@wordpress/i18n';
import { videoSourceOption } from '../../helper';
import ABlocksSelectControl from '@Controls/select';
import '../../options/styles.scss';

export default function ABlockVideoSource(props) {
	const {
		attributeValue,
		setAttributes,
		attributeName,
		changeHandler,
		onSelectVideoHandler,
		onRemoveVideoHandler,
	} = props;

	const deviceType = GetDeviceType();

	return (
		<div className="ablocks-control--background__video">
			<ABlocksSelectControl
				label={__('Source', 'ablocks')}
				options={videoSourceOption}
				isResponsive={false}
				attributeValue={attributeValue}
				attributeObjectKey="videoSource"
				attributeName={attributeName}
				setAttributes={setAttributes}
			/>
			{attributeValue?.videoSource === 'youtube' && (
				<ABlocksTextControl
					label={__('Link', 'ablocks')}
					placeholder=""
					attributeValue={attributeValue?.youtubeURL}
					attributeName={attributeName}
					setAttributes={setAttributes}
					onChangeHandler={(controlValue) =>
						changeHandler(controlValue, 'youtubeURL')
					}
				/>
			)}

			{attributeValue?.videoSource === 'vimeo' && (
				<ABlocksTextControl
					label={__('Link', 'ablocks')}
					placeholder=""
					attributeValue={attributeValue?.vimeoURL}
					attributeName={attributeName}
					setAttributes={setAttributes}
					onChangeHandler={(controlValue) =>
						changeHandler(controlValue, 'vimeoURL')
					}
				/>
			)}

			{attributeValue?.videoSource === 'selfHosted' && (
				<>
					<div className="ablocks-control--background__video--external--link">
						<p>{__('External link', 'ablocks')}</p>
						<ABlocksToggleControl
							isResponsive={true}
							attributeValue={attributeValue?.externalLink}
							setAttributes={setAttributes}
							onChangeHandler={(value) =>
								changeHandler(value, 'externalLink')
							}
						/>
					</div>
					{attributeValue?.externalLink ? (
						<div>
							<ABlocksTextControl
								label={__('Link', 'ablocks')}
								placeholder=""
								attributeValue={attributeValue?.selfHostedURL}
								attributeName={attributeName}
								setAttributes={setAttributes}
								onChangeHandler={(controlValue) =>
									changeHandler(controlValue, 'selfHostedURL')
								}
							/>
						</div>
					) : (
						<div>
							<p>{__('Video', 'ablocks')}</p>
							<VideoUploadField
								allowedTypes={['video']}
								attributeValue={attributeValue}
								deviceType={deviceType}
								onSelectImageHandler={onSelectVideoHandler}
								onRemoveImageHandler={onRemoveVideoHandler}
								attributeName={'videoUrl'}
							/>
						</div>
					)}
				</>
			)}
		</div>
	);
}
