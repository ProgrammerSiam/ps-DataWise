import RenderIcon from '@Controls/icon-upload/render-icon';

import React from 'react';
import RenderContainer from '../../components/block-container/render';
import metadata from './block.json';
import './style.css';
const propTypes = {};

const defaultProps = {};

export default function Render(props) {
	const { attributes } = props;
	const {
		block_id,
		scale,
		rating,
		showRatingNumber,
		ratingColor,
		ratingUnmarkedColor,
	} = attributes;
	return (
		<RenderContainer
			blockId={block_id}
			name={metadata.name}
			attributes={attributes}
		>
			<div className="ablocks-star-ratings-icons">
				{Array.from({ length: scale ? Number(scale) : 5 }).map(
					(_, index) => {
						const starValue = index + 1;
						const starClass = 'ablocks-rating';
						let fillPercentage = 0;
						if (starValue <= Math.floor(rating)) {
							// Full star
							fillPercentage = 100;
						} else if (starValue === Math.floor(rating) + 1) {
							// Partially filled star
							fillPercentage = (rating % 1) * 100;
						}
						return (
							<div
								key={index}
								className={starClass}
								style={{
									'--marked-color': ratingColor,
									'--unmarked-color': ratingUnmarkedColor,
								}}
							>
								<div
									className="ablocks-rating__fill"
									style={{ width: `${fillPercentage}%` }}
								>
									<RenderIcon attributes={attributes} />
								</div>
								<div className="ablocks-rating__unfill">
									<RenderIcon attributes={attributes} />
								</div>
							</div>
						);
					}
				)}
			</div>

			{showRatingNumber && (
				<span className="ablocks-star-rating-number">
					({rating}/{scale})
				</span>
			)}
		</RenderContainer>
	);
}

Render.propTypes = propTypes;
Render.defaultProps = defaultProps;
