import { registerBlockType } from '@wordpress/blocks';
import attributes from './attributes';
import Edit from './edit';
import Save from './save';
import metadata from './block.json';

registerBlockType(metadata.name, {
	attributes,
	icon: (
		<svg
			width="24"
			height="25"
			viewBox="0 0 24 25"
			fill="none"
			xmlns="http://www.w3.org/2000/svg"
		>
			<path
				d="M18.7 3.56091H5.3C4 3.56091 3 4.56091 3 5.86091V19.2609C3 20.5609 4 21.5609 5.3 21.5609H18.7C20 21.5609 21 20.5609 21 19.2609V5.86091C21 4.56091 20 3.56091 18.7 3.56091ZM19.5 19.2609C19.5 19.6609 19.1 20.0609 18.7 20.0609H5.3C4.9 20.0609 4.5 19.6609 4.5 19.2609V5.86091C4.5 5.46091 4.9 5.06091 5.3 5.06091H18.7C19.1 5.06091 19.5 5.46091 19.5 5.86091V19.2609ZM10 15.5609L15 12.5609L10 9.56091V15.5609Z"
				fill="#E930F0"
			/>
		</svg>
	),
	edit: Edit,
	save: Save,
});
