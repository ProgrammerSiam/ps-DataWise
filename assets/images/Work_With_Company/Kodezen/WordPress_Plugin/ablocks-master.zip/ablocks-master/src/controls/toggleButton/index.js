import React from 'react';
import { ToggleControl } from '@wordpress/components';
import PropTypes from 'prop-types';
import GetDeviceType from '@Utils/get-device-type';
import ControlLabel from '@Components/control-label';
import './editor.scss';

const propTypes = {
	isResponsive: PropTypes.bool,
	label: PropTypes.string,
	attributeName: PropTypes.string,
	setAttributes: PropTypes.func,
	attributeValue: PropTypes.any,
	attributeObjectKey: PropTypes.string,
};

const defaultProps = {
	label: '',
	isResponsive: true,
	attributeObjectKey: '',
};

export default function ABlocksToggleControl(props) {
	const {
		isResponsive,
		label,
		attributeName,
		attributeValue,
		setAttributes,
		onChangeHandler,
		attributeObjectKey,
	} = props;
	const deviceType = GetDeviceType();

	const changeHandler = (controlValue, deviceMode) => {
		if (onChangeHandler) {
			onChangeHandler(
				controlValue,
				isResponsive
					? attributeObjectKey + deviceMode
					: attributeObjectKey
			);
		} else {
			defaultChangeHandler(controlValue, deviceMode);
		}
	};

	const defaultChangeHandler = (controlValue, deviceMode) => {
		if (isResponsive) {
			return setAttributes({
				[attributeName]: {
					...attributeValue,
					[attributeObjectKey + deviceMode]: controlValue,
				},
			});
		} else if (attributeObjectKey !== '') {
			return setAttributes({
				[attributeName]: {
					...attributeValue,
					[attributeObjectKey]: controlValue,
				},
			});
		}
		return setAttributes({
			[attributeName]: controlValue,
		});
	};

	return (
		<React.Fragment>
			<div className="ablocks-toggle-control">
				{label && (
					<ControlLabel label={label} isResponsive={isResponsive} />
				)}
				<ToggleControl
					className="ablocks-components-toggle-control"
					checked={
						attributeObjectKey
							? attributeValue[attributeObjectKey]
							: attributeValue
					}
					onChange={(isEnabled) =>
						changeHandler(isEnabled, deviceType)
					}
				/>
			</div>
		</React.Fragment>
	);
}

ABlocksToggleControl.propTypes = propTypes;
ABlocksToggleControl.defaultProps = defaultProps;
