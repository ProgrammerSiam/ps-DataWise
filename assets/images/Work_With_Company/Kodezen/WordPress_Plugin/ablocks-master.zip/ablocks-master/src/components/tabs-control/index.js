import React from 'react';
import { TabPanel } from '@wordpress/components';

/**
 * Import Css
 */
import './editor.scss';

const ABlocksTabsControl = (props) => {
	const { tabs = [], initialTabName = '' } = props;

	const modTabs = tabs.map((item) => ({
		...(item || {}),
		className: `${item?.className || ''} ablocks-tabs-control__tabs-item`,
	}));

	return (
		<React.Fragment>
			<TabPanel
				className="ablocks-tabs-control"
				activeClass="ablocks-tabs-control__tabs-item--active"
				tabs={modTabs}
				initialTabName={initialTabName}
			>
				{(tab) => tab.render}
			</TabPanel>
		</React.Fragment>
	);
};

export default ABlocksTabsControl;
