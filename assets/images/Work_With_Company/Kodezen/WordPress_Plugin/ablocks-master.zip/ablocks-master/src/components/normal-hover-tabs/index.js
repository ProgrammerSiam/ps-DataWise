import React from 'react';
import { TabPanel } from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import PropTypes from 'prop-types';
import './editor.scss';

const propTypes = {
	normal: PropTypes.node.isRequired,
	hover: PropTypes.node.isRequired,
};

const defaultProps = {
	normal: '',
	hover: '',
};

export default function NormalHoverTabs(props) {
	const { normal, hover } = props;

	const tabs = [
		{
			name: 'normal',
			render: normal,
			title: (
				<>
					<span className="ablocks-text">
						{__('Normal', 'ablocks')}
					</span>
				</>
			),
			className: 'ablocks-normal-hover-tab__item',
		},
		{
			name: 'hover',
			render: hover,
			title: (
				<>
					<span className="ablocks-text">
						{__('Hover', 'ablocks')}
					</span>
				</>
			),
			className: 'ablocks-normal-hover-tab__item',
		},
	];

	return (
		<React.Fragment>
			<TabPanel
				className="ablocks-normal-hover-tabs"
				activeClass="ablocks-normal-hover-tab__item--active"
				tabs={tabs}
			>
				{(tab) => tab.render}
			</TabPanel>
		</React.Fragment>
	);
}

NormalHoverTabs.propTypes = propTypes;
NormalHoverTabs.defaultProps = defaultProps;
