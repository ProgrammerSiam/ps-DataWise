import React from 'react';
import './styles.scss';
import { TextControl } from '@wordpress/components';
import { objectUniqueCheck } from '@Utils/helper';

const ABlocksInputField = (props) => {
	const {
		label,
		attributeName,
		setAttributes,
		attributeValue,
		onChangeHandler,
		getAttributeDefaultValue,
		name,
		value,
		deviceMode,
	} = props;

	const changeHandler = (controlValue) => {
		if (onChangeHandler) {
			onChangeHandler(controlValue, name, deviceMode);
		} else {
			defaultChangeHandler(controlValue);
		}
	};

	const defaultChangeHandler = (controlValue) => {
		return setAttributes({
			[attributeName]: objectUniqueCheck(getAttributeDefaultValue(''), {
				...attributeValue,
				[name]: controlValue,
			}),
		});
	};

	return (
		<div className="ablocks-input-field-control">
			<div className="">{label}</div>
			<TextControl
				type="text"
				value={value}
				onChange={(controlValue) => changeHandler(controlValue)}
			/>
		</div>
	);
};

export default ABlocksInputField;
