import React from 'react';
import PropTypes from 'prop-types';
import {
	generateYouTubeEmbedURL,
	getYouTubeVideoId,
	handleYTStartAndEndTime,
} from './helper';

const propTypes = {
	youtubeURL: PropTypes.string,
	videoStartTime: PropTypes.string,
	videoEndTime: PropTypes.string,
	loop: PropTypes.bool,
	mute: PropTypes.bool,
	autoplay: PropTypes.bool,
	playerControl: PropTypes.bool,
	privacyMode: PropTypes.bool,
};

const defaultProps = {
	youtubeURL: '',
	videoStartTime: '',
	videoEndTime: '',
	loop: false,
	mute: false,
	autoplay: false,
	playerControl: false,
	privacyMode: false,
};

const YoutubeIframe = (props) => {
	const {
		youtubeURL,
		videoStartTime,
		videoEndTime,
		loop,
		mute,
		autoplay,
		playerControl,
		privacyMode,
	} = props;
	const videoID = getYouTubeVideoId(youtubeURL);
	const getStartAndEndTime = handleYTStartAndEndTime(
		videoStartTime,
		videoEndTime
	);
	const videoSource = generateYouTubeEmbedURL(
		videoID,
		privacyMode,
		loop,
		mute,
		autoplay,
		playerControl,
		getStartAndEndTime
	);

	return (
		<iframe
			width={'100%'}
			height={'100%'}
			src={videoSource}
			frameBorder="0"
			className="ablocks-video-player"
			title="YouTube video player"
			allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
			allowfullscreen
		></iframe>
	);
};

export default YoutubeIframe;

YoutubeIframe.propTypes = propTypes;
YoutubeIframe.defaultProps = defaultProps;
