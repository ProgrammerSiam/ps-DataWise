export const arraysEqual = (a, b) => {
	//
	if (a instanceof Array && b instanceof Array) {
		if (a.length !== b.length) {
			return false;
		}
		for (let i = 0; i < a.length; i++) {
			if (!arraysEqual(a[i], b[i])) {
				return false;
			}
		}
		return true;
	}
	return a === b;
};

export const shallowEqual = (object1, object2) => {
	const keys1 = Object.keys(object1);
	const keys2 = Object.keys(object2);

	if (keys1.length !== keys2.length) {
		return false;
	}

	for (const key of keys1) {
		if (object1[key] !== object2[key]) {
			return false;
		}
	}

	return true;
};

export const getGradientType = (value = '') => {
	let gradientType = value.trim().match(/^\w+-gradient/gi);
	gradientType = gradientType?.length > 0 ? gradientType[0] : false;
	gradientType =
		typeof gradientType === 'string' && gradientType.toLowerCase();
	return gradientType;
};

export const objectToStringRgba = ({ r, g, b, a }) =>
	`rgba(${r},${g},${b},${a})`;
