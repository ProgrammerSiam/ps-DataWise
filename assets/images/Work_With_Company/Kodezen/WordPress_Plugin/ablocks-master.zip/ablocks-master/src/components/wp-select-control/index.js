import React from 'react';
import PropTypes from 'prop-types';
import ControlLabel from '@Components/control-label';
import { SelectControl } from '@wordpress/components';
import './styles.scss';

const propTypes = {
	isResponsive: PropTypes.bool,
	label: PropTypes.string,
	attributeName: PropTypes.string,
	attributeValue: PropTypes.any,
	onChangeHandler: PropTypes.func,
};

const defaultProps = {
	label: '',
	isResponsive: true,
	deviceMode: '',
	options: [],
};

export default function ABlocksWPSelectControl(props) {
	const {
		options,
		isResponsive,
		attributeName,
		attributeValue,
		onChangeHandler,
		label,
		deviceType,
	} = props;

	return (
		<React.Fragment>
			{label && (
				<div className="ablocks-select-control">
					<ControlLabel label={label} isResponsive={isResponsive} />
					<SelectControl
						options={options}
						value={attributeValue}
						onChange={(controlValue) =>
							onChangeHandler(
								controlValue,
								attributeName,
								deviceType
							)
						}
					/>
				</div>
			)}
		</React.Fragment>
	);
}

ABlocksWPSelectControl.propTypes = propTypes;
ABlocksWPSelectControl.defaultProps = defaultProps;
