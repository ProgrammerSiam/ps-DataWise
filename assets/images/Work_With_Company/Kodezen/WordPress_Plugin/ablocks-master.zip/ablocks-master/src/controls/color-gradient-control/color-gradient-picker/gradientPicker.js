import React, { useEffect, useState, useCallback } from 'react';
import { __ } from '@wordpress/i18n';
import AblocksPopover from '@Components/popover';
import AnglePicker from '../angle-picker';
import CustomToggler from './customToggler';
import { ColorPicker } from '../colorPicker';
import Markers from './markers';
import { getGradientType } from './helper';
import { noop } from '../commonFunctions';
import { parseGradient, getGradient } from './utils';

import { getTypeAndHsvaObjectFromColorString } from '../colorPicker/utils/helperFunctions';

const radialStartPositionOptions = [
	{ label: 'Top Left', value: 'top-left' },
	{ label: 'Top', value: 'top' },
	{ label: 'Top Right', value: 'top-right' },
	{ label: 'Left', value: 'left' },
	{ label: 'Center', value: 'center' },
	{ label: 'Right', value: 'right' },
	{ label: 'Bottom Left', value: 'bottom-left' },
	{ label: 'Bottom', value: 'bottom' },
	{ label: 'Bottom Right', value: 'bottom-right' },
];

let hanldeRadialStartingPositionChange = noop;
let onAngleChange = noop;
let ablocksHelperOnChangeTimeoutId;

const GradientPicker = ({ value, onChange, type }) => {
	const [isVisible, setIsVisible] = useState(false);
	const parsedColors = useCallback(() => {
		if (getGradientType(value) === type) {
			return parseGradient(value);
		}
		if (type === 'linear-gradient') {
			return parseGradient(
				'linear-gradient(90deg, #BE21FF 0%, #736EC8CC 50%, #29A6FE 100%)'
			);
		}
		if (type === 'radial-gradient') {
			return parseGradient(
				'radial-gradient(circle at center, #BE21FF 0%, #736EC8CC 50%, #29A6FE 100%)'
			);
		}
	}, [value, type]);

	const initColor = parsedColors();
	const { stops } = initColor;
	const lastStopIndex = stops.length - 1;
	const lastStopColorString = stops[lastStopIndex][0];
	const { hsva } = getTypeAndHsvaObjectFromColorString(lastStopColorString);
	const lastStopLoc = stops[lastStopIndex][1];
	const [activeColor, setActiveColor] = useState({
		colorString: lastStopColorString,
		alpha: hsva.a * 100,
		loc: lastStopLoc,
		index: lastStopIndex,
	});
	const [color, setColor] = useState(initColor);
	const [radialStartPosition, setRadialStartPosition] = useState('center');

	let linearAnglePicker = <></>;
	let radialComponents = <></>;

	useEffect(() => {
		if (color.gradient !== initColor.gradient) {
			onChange(color.gradient);
		}
	}, [color.gradient]); // eslint-disable-line react-hooks/exhaustive-deps

	useEffect(() => {
		const parsedColor = parsedColors();
		const { type: gradientType, modifier } = parsedColor;
		if (gradientType === 'radial' && typeof modifier === 'string') {
			const startPositionValue = modifier
				.toLowerCase()
				.split(' at ')[1]
				?.trim()
				.replace(' ', '-');
			const startPositionReverseValue = startPositionValue
				.split('-')
				.reverse()
				.join('-');
			const parsedRadialStartPosition = radialStartPositionOptions.find(
				(item) =>
					item.value === startPositionValue ||
					item.value === startPositionReverseValue
			);
			setRadialStartPosition(parsedRadialStartPosition.value);
		}
		setColor(parsedColor);
	}, [type]); //eslint-disable-line react-hooks/exhaustive-deps

	const onActiveStopColorChange = (colorString) => {
		clearTimeout(ablocksHelperOnChangeTimeoutId);
		const { hsva: colorHsva } =
			getTypeAndHsvaObjectFromColorString(colorString);
		const activeIndex = activeColor.index;
		const newStops = color.stops.map((item, index) => {
			if (index === activeIndex) {
				return [colorString, item[1], index];
			}
			return item;
		});
		const gradient = getGradient(color.type, newStops, color.modifier);
		setColor((prev) => {
			return {
				...prev,
				gradient,
				stops: newStops,
			};
		});
		ablocksHelperOnChangeTimeoutId = setTimeout(() => {
			onChange(gradient);
			setActiveColor((prev) => {
				return {
					...prev,
					colorString,
					alpha: colorHsva.a * 100,
					key: (prev?.key || 1) + 1,
				};
			});
		}, 300);
	};

	if (type === 'linear-gradient') {
		onAngleChange = (angle) => {
			clearTimeout(ablocksHelperOnChangeTimeoutId);
			const gradient = getGradient(color.type, color.stops, angle);
			setColor((prev) => {
				return {
					...prev,
					gradient,
					modifier: angle,
				};
			});
			ablocksHelperOnChangeTimeoutId = setTimeout(() => {
				onChange(gradient);
			}, 300);
		};
		linearAnglePicker = (
			<AnglePicker value={color} onChange={onAngleChange} />
		);
	}

	if (type === 'radial-gradient') {
		hanldeRadialStartingPositionChange = (position) => {
			setRadialStartPosition(position);
			const stringRadialStartPosition = position.replace('-', ' ');
			const modifier = `circle at ${stringRadialStartPosition} `;
			const gradient = getGradient(color.type, color.stops, modifier);
			setColor((prev) => {
				return {
					...prev,
					gradient,
					modifier,
				};
			});
			onChange(gradient);
		};

		radialComponents = (
			<>
				<div
					className="ablocks-control-radial-gradient-preview-wrapper"
					style={{ background: color.gradient }}
				>
					<ul>
						{radialStartPositionOptions.map((item, index) => (
							<li // eslint-disable-line jsx-a11y/no-noninteractive-element-interactions
								key={index}
								onClick={() =>
									hanldeRadialStartingPositionChange(
										item.value
									)
								}
								onKeyDown={() => {}}
							>
								<span
									className={`ablocks-radial-gradient-position-dot ${
										item.value === radialStartPosition
											? 'active'
											: ''
									}`}
								></span>
							</li>
						))}
					</ul>
				</div>
			</>
		);
	}

	const togglePopoverVisibility = () => {
		setIsVisible(!isVisible);
	};

	return (
		<>
			{linearAnglePicker}
			{radialComponents}
			<Markers
				color={color}
				setColor={setColor}
				activeColor={activeColor}
				setActiveColor={setActiveColor}
			/>

			<AblocksPopover
				className="ablocks-control--gradient-active-color-popover-root"
				label={__('Active Color', 'ablocks')}
				isShowPrimaryLabel={true}
				height={370}
				width={320}
				isVisible={isVisible}
				toggleVisible={togglePopoverVisibility}
				CustomToggler={(props) => (
					<CustomToggler
						{...props}
						activeColor={activeColor}
						togglePopoverVisibility={togglePopoverVisibility}
						onColorChange={onActiveStopColorChange}
					/>
				)}
			>
				<div className="ablocks-control--inside-popover-color-picker">
					<ColorPicker
						value={activeColor.colorString}
						key={activeColor?.key || 1}
						onChange={onActiveStopColorChange}
					/>
				</div>
			</AblocksPopover>
		</>
	);
};

export default GradientPicker;
