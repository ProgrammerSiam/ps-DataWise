import globalAttributes from '@Global/AdvancedSettings/attributes';
import { getAttribute as getRangeAttributes } from '@Controls/range/helper';

export const spacerHeight = getRangeAttributes('spacerHeight', true, {
	value: 50,
	valueUnit: 'px',
});

const attributes = {
	block_id: {
		type: 'string',
	},
	...spacerHeight,
	...globalAttributes,
};
export default attributes;
