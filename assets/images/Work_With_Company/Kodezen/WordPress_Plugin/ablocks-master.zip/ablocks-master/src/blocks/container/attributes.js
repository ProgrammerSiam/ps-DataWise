import globalAttributes from '@Global/AdvancedSettings/attributes';

const attributes = {
	block_id: {
		type: 'string',
	},
	className: {
		type: 'string',
	},
	isRootContainer: {
		type: 'boolean',
	},
	variationSelected: {
		type: 'boolean',
		default: true,
	},
	containerWidthType: {
		type: 'string',
		default: 'alignfull',
	},
	innerWidthType: {
		type: 'string',
		default: 'alignwide',
	},
	contentBoxWidth: {
		type: 'object',
		default: {
			value: 1280,
			valueUnit: 'px',
		},
	},
	containerCustomWidth: {
		type: 'object',
		default: {
			value: 100,
			valueUnit: '%',
		},
	},
	minimumHeight: {
		type: 'object',
	},
	overflow: {
		type: 'string',
		default: 'visible',
	},
	// flex direction start
	direction: {
		type: 'string',
	},
	directionTablet: {
		type: 'string',
	},
	directionMobile: {
		type: 'string',
	},
	// flex direction end
	// flex 'justify content' start
	justify: {
		type: 'string',
	},
	justifyTablet: {
		type: 'string',
	},
	justifyMobile: {
		type: 'string',
	},
	// flex 'justify content' end
	// flex 'align items" start
	align: {
		type: 'string',
	},
	alignTablet: {
		type: 'string',
	},
	alignMobile: {
		type: 'string',
	},
	// flex 'align items" end
	// flex 'gap" start
	gap: {
		type: 'object',
	},
	// flex 'gap" end
	// flex 'wrap" start
	wrap: {
		type: 'string',
	},
	wrapTablet: {
		type: 'string',
	},
	wrapMobile: {
		type: 'string',
	},
	// flex 'wrap" end
	...globalAttributes,
};
export default attributes;
