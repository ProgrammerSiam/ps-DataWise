import globalAttributes from '@Global/AdvancedSettings/attributes';
import { getAttribute as typographyAttributes } from '@Controls/typography/helper';
import { getAttribute as getBackgroundAttribute } from '@Controls/background/helper';
import { getAttribute as getBorderAttributes } from '@Controls/border/helper';
import { getAttribute as getDimensionsAttributes } from '@Controls/dimensions/helper';

const attributes = {
	block_id: {
		type: 'string',
	},
	course_count: {
		type: 'number',
		default: 3,
	},
	course_columns: {
		type: 'number',
		default: 3,
	},
	show_pagination: {
		type: 'boolean',
	},
	difficulty_levels: {
		type: 'array',
	},
	price_types: {
		type: 'array',
	},
	order_by: {
		type: 'string',
	},
	course_order: {
		type: 'string',
	},
	course_ids: {
		type: 'array',
	},
	course_categories: {
		type: 'array',
	},
	course_tags: {
		type: 'array',
	},
	course_exclude_ids: {
		type: 'array',
	},
	course_exclude_categories: {
		type: 'array',
	},
	course_exclude_tags: {
		type: 'array',
	},
	category_color: {
		type: 'string',
	},
	category_hover_color: {
		type: 'string',
	},
	title_color: {
		type: 'string',
	},
	title_hover_color: {
		type: 'string',
	},
	author_color: {
		type: 'string',
	},
	author_hover_color: {
		type: 'string',
	},
	rating_color: {
		type: 'string',
	},
	rating_hover_color: {
		type: 'string',
	},
	price_color: {
		type: 'string',
	},
	price_hover_color: {
		type: 'string',
	},
	wish_icon_color: {
		type: 'string',
	},
	wish_icon_hover_color: {
		type: 'string',
	},
	...typographyAttributes('cat_typography', true),
	...typographyAttributes('title_typography', true),
	...typographyAttributes('author_typography', true),
	...typographyAttributes('rating_typography', true),
	...typographyAttributes('price_typography', true),
	...getBackgroundAttribute('card_background', true),
	...getBorderAttributes('card_border', true),
	...getDimensionsAttributes('card_margin', true),
	...getDimensionsAttributes('card_hover_margin', true),
	...getDimensionsAttributes('card_padding', true),
	...getDimensionsAttributes('card_hover_padding', true),
	...getBackgroundAttribute('wish_icon_background', true),
	...globalAttributes,
};
export default attributes;
