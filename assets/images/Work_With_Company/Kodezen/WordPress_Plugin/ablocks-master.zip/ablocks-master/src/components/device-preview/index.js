import React, { useState, useEffect, useRef, forwardRef } from 'react';
import { ButtonGroup } from '@wordpress/components';
import Button from '@Components/Button';
import { dispatch } from '@wordpress/data';
import GetDeviceType from '@Utils/get-device-type';
import Tooltip from '@Components/tooltip';
import './editor.scss';

const propTypes = {};

const defaultProps = {};

const deviceOptions = [
	{ name: 'Desktop', icon: 'desktop' },
	{ name: 'Tablet', icon: 'tablet' },
	{ name: 'Mobile', icon: 'mobile' },
];

const ABlocksDevicePreview = forwardRef((props, ref) => {
	const deviceType = GetDeviceType();
	const [isDropdownOpen, setDropdownOpen] = useState(false);
	const menuItemRef = useRef(null);

	const toggleDropdown = () => {
		setDropdownOpen(!isDropdownOpen);
	};

	const handleClick = (e) => {
		if (menuItemRef?.current && !menuItemRef?.current?.contains(e.target)) {
			setDropdownOpen(false);
		}
	};

	useEffect(() => {
		document.addEventListener('mousedown', handleClick);
		return () => document.removeEventListener('mousedown', handleClick);
	}, []);

	const onClickHandler = (device) => {
		dispatch('core/edit-post').__experimentalSetPreviewDeviceType(device);
		toggleDropdown();
	};

	const renderDeviceOptions = () => {
		return (
			<div
				className={`ablocks-responsive-navigation__dropdown-items ${
					isDropdownOpen &&
					'ablocks-responsive-navigation__dropdown--is-open'
				}`}
				ref={menuItemRef}
			>
				{deviceOptions.map((device) => (
					<Button
						key={device.name}
						onClick={() => onClickHandler(device.name)}
						icon={
							<Tooltip tooltipText={device.icon} position="right">
								<span
									className={`ablocks-icon ablocks-icon--${device.icon}`}
								></span>
							</Tooltip>
						}
					/>
				))}
			</div>
		);
	};

	return (
		<React.Fragment>
			<ButtonGroup className="ablocks-responsive-navigation">
				<Button
					onClick={toggleDropdown}
					ref={ref}
					icon={
						deviceOptions.find(
							(device) => device.name === deviceType
						)?.icon ? (
							<span
								className={`ablocks-icon ablocks-icon--${
									deviceOptions.find(
										(device) => device.name === deviceType
									).icon
								}`}
							></span>
						) : (
							<span
								className={`ablocks-icon ablocks-icon--desktop`}
							></span>
						)
					}
				/>
				{renderDeviceOptions()}
			</ButtonGroup>
		</React.Fragment>
	);
});

ABlocksDevicePreview.propTypes = propTypes;
ABlocksDevicePreview.defaultProps = defaultProps;

export default ABlocksDevicePreview;
