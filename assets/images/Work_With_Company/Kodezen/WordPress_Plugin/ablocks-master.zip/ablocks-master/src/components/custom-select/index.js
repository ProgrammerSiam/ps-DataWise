import { useState, useRef, useEffect } from 'react';
import ControlLabel from '@Components/control-label';
import PropTypes from 'prop-types';
import './editor.scss';

const propTypes = {
	label: PropTypes.string,
	isSearch: PropTypes.bool,
	options: PropTypes.array,
	isResponsive: PropTypes.bool,
	changeHandler: PropTypes.func,
	attributeValue: PropTypes.string,
	attributeObjectKey: PropTypes.string,
};

const defaultProps = {
	label: '',
	options: [],
	deviceMode: '',
	isSearch: false,
	attributeValue: '',
	isResponsive: false,
	attributeObjectKey: '',
};

const ABlocksCustomSelect = (props) => {
	const {
		label,
		isSearch,
		attributeValue,
		changeHandler,
		attributeObjectKey,
		isResponsive,
		options,
	} = props;
	const [isToggle, setIsToggle] = useState(false);
	const [searchOptions, setSearchOptions] = useState('');
	const inputRef = useRef(null);
	const optionsRef = useRef(null);
	const attributeValueAndIsSearchOptions =
		attributeValue && !searchOptions?.length > 0;

	useEffect(() => {
		const handleClick = (e) => {
			if (inputRef?.current && !inputRef?.current?.contains(e.target)) {
				setIsToggle(false);
			}
		};

		document.addEventListener('mousedown', handleClick);

		if (optionsRef.current) {
			const optionsHeight = optionsRef.current.offsetHeight;
			const inputRect = inputRef.current.getBoundingClientRect();
			const spaceBelow = window.innerHeight - inputRect.bottom;
			const spaceAbove = inputRect.top;

			if (spaceBelow < optionsHeight && spaceAbove > spaceBelow) {
				optionsRef.current.style.top = `-${optionsHeight}px`;
			} else {
				optionsRef.current.style.top = '100%';
			}
		}

		return () => {
			document.removeEventListener('mousedown', handleClick);
		};
	}, [isToggle, searchOptions, options]);

	return (
		<div className="ablocks-control ablocks-custom-select">
			<ControlLabel label={label} isResponsive={isResponsive} />
			<div className="ablocks-custom-select--container" ref={inputRef}>
				{/* input box content */}
				<div
					className="ablocks-custom-select--inner-content"
					onKeyDown={() => {}}
					onClick={() => setIsToggle(!isToggle)}
					role="presentation"
				>
					{/* Input and value content area  */}
					<div className="ablocks-custom-select--box">
						{attributeValueAndIsSearchOptions && (
							<div className="ablocks-custom-select--single-value">
								{options.find(
									(option) => option.value === attributeValue
								)?.label || options[0]?.label}
							</div>
						)}
						{!attributeValueAndIsSearchOptions && (
							<div className="ablocks-custom-select--single-value">
								Select...
							</div>
						)}
						{isSearch && (
							<div className="ablocks-custom-select--input-container">
								<input
									className="ablocks-custom-select--search-option"
									type="text"
									value={searchOptions}
									onChange={(e) => {
										setSearchOptions(e.target.value);
									}}
								/>
							</div>
						)}
					</div>
					<div className="ablocks-custom-select--indicator">
						<span className="ablocks-icon ablocks-icon--angle-down"></span>
					</div>
				</div>
				{/* dropdown options  */}
				<div
					className={`ablocks-custom-select--options${
						isToggle
							? ' ablocks-custom-select--options--toggle'
							: ''
					}`}
					onClick={() => setIsToggle(!isToggle)}
					onKeyDown={() => {}}
					ref={optionsRef}
					role="presentation"
				>
					{options
						.filter((option) =>
							option.label
								.toLowerCase()
								.includes(searchOptions.toLowerCase())
						)
						?.map((option, index) => {
							const handleOptionClick = () => {
								setSearchOptions('');
								changeHandler(option.value, attributeObjectKey);
							};
							return (
								<span
									key={index}
									className={`ablocks-custom-select--option${
										attributeValue === option.value &&
										options.findIndex(
											(o) => o.value === option.value
										) === index
											? ' ablocks-custom-select--option--active'
											: ''
									}`}
									onClick={handleOptionClick}
									onKeyDown={() => {}}
									role="presentation"
								>
									{option?.label}
								</span>
							);
						})}
				</div>
			</div>
		</div>
	);
};

ABlocksCustomSelect.propTypes = propTypes;
ABlocksCustomSelect.defaultProps = defaultProps;
export default ABlocksCustomSelect;
