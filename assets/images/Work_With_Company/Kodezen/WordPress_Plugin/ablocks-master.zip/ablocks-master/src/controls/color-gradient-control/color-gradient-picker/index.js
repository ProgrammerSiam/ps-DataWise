import React, { useState, useEffect } from 'react';

import ABlocksTabsControl from '@Components/tabs-control';
import { ColorPicker } from '../colorPicker';
import { getGradientType } from './helper';
import { setTabsForColorGradientTabpanel } from './tabsHelper';

import './editor.scss';

let ablocksHelperOnChangeTimeoutId;
export const ColorGradientMain = ({
	value,
	allowGradient,
	onChange,
	setActiveTab,
}) => {
	const [tabs, setTabs] = useState([]);

	useEffect(() => {
		if (allowGradient) {
			setTabsForColorGradientTabpanel({
				setActiveTab,
				solidPicker,
				value,
				onChange,
				setTabs,
			});
		}
	}, [allowGradient]); // eslint-disable-line react-hooks/exhaustive-deps

	useEffect(() => {
		clearTimeout(ablocksHelperOnChangeTimeoutId);
		ablocksHelperOnChangeTimeoutId = setTimeout(() => {
			if (allowGradient) {
				setTabsForColorGradientTabpanel({
					setActiveTab,
					solidPicker,
					value,
					onChange,
					setTabs,
				});
			}
		}, 700);
		return () => {
			clearTimeout(ablocksHelperOnChangeTimeoutId);
		};
	}, [value, allowGradient]); // eslint-disable-line react-hooks/exhaustive-deps

	const solidPicker = <ColorPicker value={value} onChange={onChange} />;

	return (
		<>
			{allowGradient ? (
				<ABlocksTabsControl
					initialTabName={getGradientType(value) || 'solid'}
					tabs={tabs}
				/>
			) : (
				solidPicker
			)}
		</>
	);
};
