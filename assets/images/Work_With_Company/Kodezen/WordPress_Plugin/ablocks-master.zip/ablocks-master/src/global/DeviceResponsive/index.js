import React from 'react';
import ABlocksToggleControl from '@Controls/toggleButton';

const propTypes = {};

const defaultProps = {};

export default function DeviceResponsive({ attributes, setAttributes }) {
	return (
		<React.Fragment>
			<ABlocksToggleControl
				isResponsive={false}
				label="Hide On Desktop"
				attributeValue={attributes?._hide_on_desktop}
				setAttributes={setAttributes}
				attributeName="_hide_on_desktop"
			/>
			<ABlocksToggleControl
				isResponsive={false}
				label="Hide On Tablet"
				attributeValue={attributes?._hide_on_tablet}
				setAttributes={setAttributes}
				attributeName="_hide_on_tablet"
			/>
			<ABlocksToggleControl
				isResponsive={false}
				label="Hide On Mobile"
				attributeValue={attributes?._hide_on_mobile}
				setAttributes={setAttributes}
				attributeName="_hide_on_mobile"
			/>
		</React.Fragment>
	);
}

DeviceResponsive.propTypes = propTypes;
DeviceResponsive.defaultProps = defaultProps;
