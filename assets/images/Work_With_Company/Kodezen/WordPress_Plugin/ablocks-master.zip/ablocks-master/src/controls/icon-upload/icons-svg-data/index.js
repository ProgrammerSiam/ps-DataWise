export { default as regularIcons } from './regular.json';
export { default as brandsIcons } from './brands.json';
export { default as solidIcons } from './solid.json';
