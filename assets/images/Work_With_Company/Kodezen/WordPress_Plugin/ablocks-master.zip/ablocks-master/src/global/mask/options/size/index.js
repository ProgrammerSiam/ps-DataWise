import React from 'react';
import ABlocksSelectControl from '@Controls/select';
import { __ } from '@wordpress/i18n';
import ABlocksRangeControl from '@Controls/range';

const Sizes = [
	{ value: 'contain', label: __('Fit', 'ablocks') },
	{ value: 'cover', label: __('Fill', 'ablocks') },
	{ value: 'custom', label: __('Custom', 'ablocks') },
];

const ABlocksMaskSize = (props) => {
	const {
		deviceType,
		attributeValue,
		changeHandler,
		attributeName,
		setAttributes,
	} = props;

	let maxDefaultValue = 500;

	if (attributeValue['scaleUnit' + deviceType] === 'px') {
		maxDefaultValue = 500;
	}
	if (attributeValue['scaleUnit' + deviceType] === '%') {
		maxDefaultValue = 200;
	}
	if (
		attributeValue['scaleUnit' + deviceType] === 'em' ||
		attributeValue['scaleUnit' + deviceType] === 'vw'
	) {
		maxDefaultValue = 100;
	}
	if (attributeValue['scaleUnit' + deviceType] === 'rem') {
		maxDefaultValue = 10;
	}

	return (
		<>
			<ABlocksSelectControl
				options={Sizes}
				isResponsive={true}
				attributeValue={attributeValue}
				label={__('Size', 'ablocks')}
				attributeName={attributeName}
				attributeObjectKey="maskSize"
				setAttributes={setAttributes}
			/>

			{attributeValue['maskSize' + deviceType] === 'custom' && (
				<div className="ablocks-mask-control__size">
					<ABlocksRangeControl
						{...props}
						label={__('Scale', 'ablocks')}
						min={0}
						max={maxDefaultValue}
						hasUnit={true}
						isInline={false}
						onChangeHandler={changeHandler}
						attributeObjectKey="scale"
					/>
				</div>
			)}
		</>
	);
};

export default ABlocksMaskSize;
