import { __ } from '@wordpress/i18n';
import { googleFontsAll } from './googleFonts';

const { fontVariants } = googleFontsAll;

const loadedFonts = {};
export const createLinkElement = ({
	href,
	id = false,
	rel = 'stylesheet',
	extraAttribute = {},
	document = document,
}) => {
	const link = document.createElement('link');
	link.href = href;
	if (id) {
		link.id = id;
	}
	if (rel) {
		link.rel = rel;
	}
	const { attributeName, attributeValue = '' } = extraAttribute;
	if (attributeName) {
		link.setAttribute(attributeName, attributeValue);
	}
	return link;
};

export const loadGoogleFontsPreconnectLinks = (document) => {
	const googleFontsApisLink = createLinkElement({
		href: 'https://fonts.googleapis.com',
		rel: 'preconnect',
		document,
	});
	const googleGstaticLink = createLinkElement({
		href: 'https://fonts.gstatic.com',
		rel: 'preconnect',
		extraAttribute: {
			attributeName: 'crossorigin',
		},
		document,
	});
	document.head.appendChild(googleFontsApisLink);
	document.head.appendChild(googleGstaticLink);
};

export const loadGoogleFontsLinks = (document) => {
	let googleFontUrl = `https://fonts.googleapis.com/css2?`;
	for (const item in loadedFonts) {
		googleFontUrl += `family=${item.replace(/\s+/g, '+')}`;
		loadedFonts[item] = loadedFonts[item].filter((weight) =>
			fontVariants[item]?.variants?.includes(weight)
		);
		if (loadedFonts[item].length > 0) {
			googleFontUrl += ':wght@';
			loadedFonts[item].sort().forEach((weight, index, array) => {
				googleFontUrl += `${weight};`;
				if (index === array.length - 1) {
					googleFontUrl = googleFontUrl.replace(/;$/i, '');
				}
			});
		}
		googleFontUrl += '&';
	}
	googleFontUrl += `display=swap`;

	const existingFontsLinkTag = document.getElementById(
		'ablocks-google-fonts-loader'
	);

	const googleFontsLoaderLink = createLinkElement({
		href: googleFontUrl,
		id: 'ablocks-google-fonts-loader',
		document,
	});

	document.head.appendChild(googleFontsLoaderLink);
	if (
		existingFontsLinkTag &&
		// the chek below ('> 2') was done to prevent the flicker effect when adding multiple font-families to multiple blocks
		loadedFonts.length > 2
	) {
		document.head.removeChild(existingFontsLinkTag);
	}
};

export const loadGoogleFontsInEditor = (allFonts, editorContainerEl) => {
	if (!editorContainerEl) {
		return false;
	}

	let isFontsAlreadyLoaded = true;
	for (const fontFamily in allFonts) {
		if (allFonts[fontFamily].length === 0) {
			if (!loadedFonts[fontFamily]) {
				isFontsAlreadyLoaded = false;
				loadedFonts[fontFamily] = [];
			}
			continue;
		}

		for (const weight of allFonts[fontFamily]) {
			const weightsInLoadedFonts = loadedFonts[fontFamily];
			if (weightsInLoadedFonts?.includes(weight)) {
				continue;
			}
			isFontsAlreadyLoaded = false;
			loadedFonts[fontFamily] = weightsInLoadedFonts
				? weightsInLoadedFonts.concat(weight)
				: [weight];
		}
	}
	if (isFontsAlreadyLoaded) {
		return false;
	}

	const html = editorContainerEl.closest('html');
	const document = html.parentNode;
	if (Object.keys(loadedFonts).length === 1) {
		loadGoogleFontsPreconnectLinks(document);
	}
	loadGoogleFontsLinks(document);
};

export const getAttributeDefaultValue = (isResponsive = false) => {
	if (isResponsive) {
		return {
			fontFamily: '',
			weight: '400',
			transform: '',
			style: '',
			decoration: '',
			fontSize: '',
			fontSizeTablet: '',
			fontSizeMobile: '',
			fontSizeUnit: 'px',
			fontSizeUnitTablet: 'px',
			fontSizeUnitMobile: 'px',
			lineHeight: '',
			lineHeightTablet: '',
			lineHeightMobile: '',
			lineHeightUnit: 'px',
			lineHeightUnitTablet: 'px',
			lineHeightUnitMobile: 'px',
			letterSpacing: '',
			letterSpacingTablet: '',
			letterSpacingMobile: '',
			letterSpacingUnit: 'px',
			letterSpacingUnitTablet: 'px',
			letterSpacingUnitMobile: 'px',
			wordSpacing: '',
			wordSpacingTablet: '',
			wordSpacingMobile: '',
			wordSpacingUnit: 'px',
			wordSpacingUnitTablet: 'px',
			wordSpacingUnitMobile: 'px',
		};
	}
	return {
		fontFamily: '',
		weight: '400',
		transform: '',
		style: '',
		decoration: '',
		fontSize: '',
		fontSizeUnit: 'px',
		lineHeight: '',
		lineHeightUnit: 'px',
		letterSpacing: '',
		letterSpacingUnit: 'px',
		wordSpacing: '',
		wordSpacingUnit: 'px',
	};
};

export const getAttribute = (attributeName, isResponsive = false) => {
	if (isResponsive) {
		return {
			[attributeName]: {
				type: 'object',
				default: getAttributeDefaultValue(isResponsive),
			},
		};
	}
	return {
		[attributeName]: {
			type: 'object',
			default: getAttributeDefaultValue(isResponsive),
		},
	};
};

export const getCSS = (attributeValue, device = '') => {
	const value = {
		...getAttributeDefaultValue(device ? true : false),
		...attributeValue,
	};
	const css = {};

	if (value.fontFamily !== '') {
		css['font-family'] = value.fontFamily;
	}
	if (value.weight !== '') {
		css['font-weight'] = value.weight;
	}
	if (value.transform !== '') {
		css['text-transform'] = value.transform;
	}
	if (value.weight !== '') {
		css['font-weight'] = value.weight;
	}
	if (value.style !== '') {
		css['font-style'] = value.style;
	}
	if (value.decoration !== '') {
		css['text-decoration'] = value.decoration;
	}
	if (value['fontSize' + device] !== '') {
		css['font-size'] = `${value['fontSize' + device]}${
			value[`fontSizeUnit` + device]
		}`;
	}
	if (
		value['lineHeight' + device] !== '' &&
		value['lineHeightUnit' + device] !== ''
	) {
		css['line-height'] = `${value['lineHeight' + device]}${
			value[`lineHeightUnit` + device]
		}`;
	}
	if (
		value['letterSpacing' + device] !== '' &&
		value['letterSpacingUnit' + device] !== ''
	) {
		css['letter-spacing'] = `${value['letterSpacing' + device]}${
			value[`letterSpacingUnit` + device]
		}`;
	}
	if (
		value['wordSpacing' + device] !== '' &&
		value['wordSpacingUnit' + device] !== ''
	) {
		css['word-spacing'] = `${value['wordSpacing' + device]}${
			value[`wordSpacingUnit` + device]
		}`;
	}

	return css;
};

export const fontWeight = [
	{
		label: __('100 (Thin)', 'ablocks'),
		value: '100',
	},
	{
		label: __('200 (Extra Light)', 'ablocks'),
		value: '200',
	},
	{
		label: __('300 (Light)', 'ablocks'),
		value: '300',
	},
	{
		label: __('400 (Normal)', 'ablocks'),
		value: '400',
	},
	{
		label: __('500 (Medium)', 'ablocks'),
		value: '500',
	},
	{
		label: __('600 (Semi Bold)', 'ablocks'),
		value: '600',
	},
	{
		label: __('700 (Bold)', 'ablocks'),
		value: '700',
	},
	{
		label: __('800 (Extra Bold)', 'ablocks'),
		value: '800',
	},
	{
		label: __('900 (Black)', 'ablocks'),
		value: '900',
	},
];
export const transform = [
	{
		label: __('Default', 'ablocks'),
		value: '',
	},
	{
		label: __('Uppercase', 'ablocks'),
		value: 'uppercase',
	},
	{
		label: __('Lowercase', 'ablocks'),
		value: 'lowercase',
	},
	{
		label: __('Capitalize', 'ablocks'),
		value: 'capitalize',
	},
	{
		label: __('Normal', 'ablocks'),
		value: 'none',
	},
];
export const style = [
	{
		label: __('Default', 'ablocks'),
		value: '',
	},
	{
		label: __('Normal', 'ablocks'),
		value: 'normal',
	},
	{
		label: __('Italic', 'ablocks'),
		value: 'italic',
	},
	{
		label: __('Oblique', 'ablocks'),
		value: 'oblique',
	},
];
export const decoration = [
	{
		label: __('Default', 'ablocks'),
		value: '',
	},
	{
		label: __('Underline', 'ablocks'),
		value: 'underline',
	},
	{
		label: __('Overline', 'ablocks'),
		value: 'overline',
	},
	{
		label: __('Line Through', 'ablocks'),
		value: 'line-through',
	},
	{
		label: __('None', 'ablocks'),
		value: 'none',
	},
];
