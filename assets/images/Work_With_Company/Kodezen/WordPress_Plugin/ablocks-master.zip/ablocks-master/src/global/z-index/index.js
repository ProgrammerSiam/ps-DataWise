import React from 'react';
import PropTypes from 'prop-types';
import ABlocksNumberControl from '@Controls/number';
import GetDeviceType from '@Utils/get-device-type';
import { getAttributeDefaultValue } from './helper';
import { objectUniqueCheck } from '@Utils/helper';
import ControlLabel from '@Components/control-label';
import './styles.scss';
const propTypes = {
	isResponsive: PropTypes.bool,
	label: PropTypes.string,
	attributeName: PropTypes.string,
	attributeValue: PropTypes.any,
	onChangeHandler: PropTypes.func,
};
const defaultProps = {
	label: '',
	isResponsive: true,
};

const ABlocksZIndexControl = (props) => {
	const {
		label,
		isResponsive,
		attributeName,
		attributeValue,
		setAttributes,
		onChangeHandler,
	} = props;
	const deviceType = GetDeviceType();
	const changeHandler = (controlValue, deviceMode) => {
		if (onChangeHandler) {
			onChangeHandler(
				controlValue,
				deviceMode,
				getAttributeDefaultValue(isResponsive)
			);
		} else {
			defaultChangeHandler(controlValue, deviceMode);
		}
	};
	const defaultChangeHandler = (controlValue, deviceMode) => {
		if (isResponsive) {
			return setAttributes({
				[attributeName]: objectUniqueCheck(
					getAttributeDefaultValue(isResponsive),
					{
						...attributeValue,
						['zIndex' + deviceMode]: controlValue,
					}
				),
			});
		}

		return setAttributes({ [attributeName]: controlValue });
	};

	return (
		<React.Fragment>
			<div className="ablocks-control ablocks-control--zindex ablocks-control--inline">
				<div className="ablocks-control__head">
					{label && (
						<ControlLabel
							label={label}
							isResponsive={isResponsive}
						/>
					)}
				</div>
				<div className="ablocks-control__fields">
					<ABlocksNumberControl
						attributeValue={attributeValue['zIndex' + deviceType]}
						onChangeHandler={(controlValue) =>
							changeHandler(controlValue, deviceType)
						}
					/>
				</div>
			</div>
		</React.Fragment>
	);
};
ABlocksZIndexControl.propTypes = propTypes;
ABlocksZIndexControl.defaultProps = defaultProps;
export default ABlocksZIndexControl;
