import { __ } from '@wordpress/i18n';
import { getUnit } from '@Utils/helper';

export const widthTypeOptions = [
	{ value: 'default', label: __('Default', 'ablocks') },
	{ value: 'full', label: __('Full Width (100%)', 'ablocks') },
	{ value: 'auto', label: __('Inline (auto)', 'ablocks') },
	{ value: 'custom', label: __('Custom', 'ablocks') },
];

export const getAttributeDefaultValue = (isResponsive = false) => {
	if (isResponsive) {
		return {
			widthType: 'default',
			widthTypeTablet: '',
			widthTypeMobile: '',
			customWidth: '',
			customWidthTablet: '',
			customWidthMobile: '',
			customWidthUnit: 'px',
			customWidthUnitTablet: '',
			customWidthUnitMobile: '',
		};
	}
	return {
		widthType: 'default',
		customWidth: '',
		customWidthUnit: 'px',
	};
};

export const getAttribute = (attributeName, isResponsive = false) => {
	if (isResponsive) {
		return {
			[attributeName]: {
				type: 'object',
				default: getAttributeDefaultValue(isResponsive),
			},
		};
	}
	return {
		[attributeName]: {
			type: 'object',
			default: getAttributeDefaultValue(isResponsive),
		},
	};
};

export const getCSS = (attributeValue, property = '', device = '') => {
	const value = {
		...getAttributeDefaultValue(device ? true : false),
		...attributeValue,
	};

	if (
		value['widthType' + device] !== '' &&
		value['widthType' + device] !== 'default'
	) {
		const css = {};

		if (value['widthType' + device] === 'full') {
			css[`${property}`] = '100%';
		} else if (value['widthType' + device] === 'auto') {
			css[`${property}`] = 'auto';
		} else if (value['widthType' + device] === 'custom') {
			css[`${property}`] =
				value['customWidth' + device] +
				getUnit(
					{
						unit: value.customWidthUnit,
						unitTablet: value.customWidthUnitTablet,
						unitMobile: value.customWidthUnitMobile,
					},
					device
				);
		}
		return css;
	}
};
