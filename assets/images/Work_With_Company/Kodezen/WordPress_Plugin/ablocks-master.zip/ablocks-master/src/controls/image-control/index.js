import React from 'react';
import PropTypes from 'prop-types';
import MediaUploadField from '@Components/media-upload/index';
import ControlLabel from '@Components/control-label/index';
import ABlocksRangeControl from '@Controls/range';
import { __ } from '@wordpress/i18n';
import ABlocksSelectControl from '@Controls/select';
import {
	imageSizeOptions,
	imagePositions,
	imageAttachment,
	imageRepeatOptions,
	displaySizeOptions,
} from './helper';
import GetDeviceType from '@Utils/get-device-type';

const propTypes = {
	attributeValue: PropTypes.object,
	changeHandler: PropTypes.func,
	isResponsive: PropTypes.bool,
	hover: PropTypes.bool,
	onChangeHandler: PropTypes.func,
	onSelectImageHandler: PropTypes.func,
	onRemoveImageHandler: PropTypes.func,
};

export default function ABlocksImageControl(props) {
	const {
		attributeValue,
		isResponsive,
		hover,
		attributeName,
		changeHandler,
		onSelectImageHandler,
		onRemoveImageHandler,
		setAttributes,
	} = props;
	const deviceType = GetDeviceType();

	const commonProps = {
		...props,
	};

	return (
		<React.Fragment>
			<ControlLabel
				label={__('Image', 'ablocks')}
				isResponsive={isResponsive}
			/>
			<MediaUploadField
				allowedTypes={['image']}
				attributeValue={attributeValue}
				deviceType={deviceType}
				onSelectImageHandler={onSelectImageHandler}
				onRemoveImageHandler={onRemoveImageHandler}
				attributeName={hover ? 'imgUrlH' : 'imgUrl'}
			/>
			{attributeValue[hover ? 'imgUrlH' : 'imgUrl'] && (
				<div>
					<ABlocksSelectControl
						label={__('Image Size', 'ablocks')}
						options={imageSizeOptions}
						isSearch={true}
						isResponsive={isResponsive}
						attributeValue={attributeValue}
						attributeObjectKey={hover ? 'imgSizeH' : 'imgSize'}
						attributeName={attributeName}
						setAttributes={setAttributes}
					/>

					<ABlocksSelectControl
						label={__('Position', 'ablocks')}
						options={imagePositions}
						isResponsive={isResponsive}
						attributeValue={attributeValue}
						attributeObjectKey={
							hover ? 'imgPositionH' : 'imgPosition'
						}
						attributeName={attributeName}
						setAttributes={setAttributes}
					/>

					{attributeValue[
						hover
							? 'imgPositionH' + deviceType
							: 'imgPosition' + deviceType
					] === 'custom' && (
						<>
							<ABlocksRangeControl
								{...commonProps}
								label="X position"
								min={-500}
								max={500}
								step={1}
								hasUnit={true}
								isInline={false}
								onChangeHandler={changeHandler}
								attributeObjectKey={
									hover ? 'imgXPositionH' : 'imgXPosition'
								}
							/>

							<ABlocksRangeControl
								{...commonProps}
								label="Y position"
								min={-500}
								max={500}
								step={1}
								hasUnit={true}
								isInline={false}
								onChangeHandler={changeHandler}
								attributeObjectKey={
									hover ? 'imgYPositionH' : 'imgYPosition'
								}
							/>
						</>
					)}

					<ABlocksSelectControl
						label={__('Attachment', 'ablocks')}
						options={imageAttachment}
						isResponsive={false}
						attributeValue={attributeValue}
						attributeObjectKey={
							hover ? 'imgAttachmentH' : 'imgAttachment'
						}
						attributeName={attributeName}
						setAttributes={setAttributes}
					/>

					<ABlocksSelectControl
						label={__('Repeat', 'ablocks')}
						options={imageRepeatOptions}
						isResponsive={isResponsive}
						attributeValue={attributeValue}
						attributeObjectKey={hover ? 'imgRepeatH' : 'imgRepeat'}
						attributeName={attributeName}
						setAttributes={setAttributes}
					/>

					<ABlocksSelectControl
						label={__('Display size', 'ablocks')}
						options={displaySizeOptions}
						isResponsive={isResponsive}
						attributeValue={attributeValue}
						attributeObjectKey={
							hover ? 'imgDisplaySizeH' : 'imgDisplaySize'
						}
						attributeName={attributeName}
						setAttributes={setAttributes}
					/>

					{attributeValue[
						hover
							? 'imgDisplaySizeH' + deviceType
							: 'imgDisplaySize' + deviceType
					] === 'custom' && (
						<ABlocksRangeControl
							{...commonProps}
							label="Width"
							min={0}
							max={10}
							hasUnit={true}
							isInline={false}
							onChangeHandler={changeHandler}
							attributeObjectKey={
								hover
									? 'imgDisplaySizeWidthH'
									: 'imgDisplaySizeWidth'
							}
						/>
					)}
				</div>
			)}
		</React.Fragment>
	);
}

ABlocksImageControl.propTypes = propTypes;
