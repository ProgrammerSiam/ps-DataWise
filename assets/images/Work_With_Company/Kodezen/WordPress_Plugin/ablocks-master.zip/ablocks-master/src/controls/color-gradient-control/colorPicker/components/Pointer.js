import React from 'react';
import { formatClassName } from '../utils/format';

export const Pointer = ({ className, color, left, top = 0.5 }) => {
	const nodeClassName = formatClassName([
		'ablocks-control--color-pickerpointer',
		className,
	]);

	const style = {
		top: `${top * 100}%`,
		left: `${left * 100}%`,
	};

	return (
		<div className={nodeClassName} style={style}>
			<div
				className="ablocks-control--color-pickerpointer-fill"
				style={{ backgroundColor: color }}
			/>
		</div>
	);
};
