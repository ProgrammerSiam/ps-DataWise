import React from 'react';
import PropTypes from 'prop-types';
import { __ } from '@wordpress/i18n';
import ABlocksDimensions from '../dimensions';
import ABlocksNormalHoverTabs from '@Components/normal-hover-tabs';
import { getAttributeDefaultValue, borderStyleOpions } from './helper';
import { objectUniqueCheck } from '@Utils/helper';
import ABlocksColorControl from '@Controls/color-gradient-control';
import ABlocksSelectControl from '@Controls/select';
import './styles.scss';

const propTypes = {
	isResponsive: PropTypes.bool,
	attributeName: PropTypes.string,
	attributeValue: PropTypes.any,
	onChangeHandler: PropTypes.func,
	radiusAttributeName: PropTypes.string,
	radiusAttributeValue: PropTypes.any,
	widthAttributeName: PropTypes.string,
	widthAttributeValue: PropTypes.any,
};

const defaultProps = {
	isResponsive: true,
};

export default function ABlocksBorderControl(props) {
	const { isResponsive, attributeName, attributeValue, setAttributes } =
		props;

	const changeHandler = (paramControlValue, paramAttributeObjectKey) => {
		return setAttributes({
			[attributeName]: objectUniqueCheck(
				getAttributeDefaultValue(isResponsive),
				{
					...attributeValue,
					[paramAttributeObjectKey]: paramControlValue,
				}
			),
		});
	};

	const showControl = attributeValue.borderStyle;
	const showControlH = attributeValue.borderStyleH;

	return (
		<React.Fragment>
			<div className="ablocks-border-control">
				<ABlocksNormalHoverTabs
					normal={
						<>
							<ABlocksSelectControl
								label={__('Border Style', 'ablocks')}
								options={borderStyleOpions}
								isResponsive={false}
								attributeObjectKey="borderStyle"
								attributeValue={attributeValue}
								attributeName={attributeName}
								setAttributes={setAttributes}
							/>

							{showControl !== 'none' &&
								showControl !== 'default' &&
								showControl && (
									<>
										<div className="ablocks-border-control__options">
											<ABlocksDimensions
												label={__('Width', 'ablocks')}
												attributeName={attributeName}
												attributeValue={attributeValue}
												setAttributes={setAttributes}
												isResponsive={true}
												attributeObjectKeySuffix="Width"
												onChangeHandler={changeHandler}
											/>
										</div>
										<ABlocksColorControl
											label={__(
												'Border color',
												'ablocks'
											)}
											attributeName="borderColor"
											attributeValue={
												attributeValue.borderColor
											}
											onChangeHandler={(
												attributeObjectKey,
												controlValue
											) =>
												changeHandler(
													controlValue,
													attributeObjectKey
												)
											}
										/>
									</>
								)}
							<ABlocksDimensions
								label={__('Border Radius', 'ablocks')}
								attributeName={attributeName}
								attributeValue={attributeValue}
								setAttributes={setAttributes}
								isResponsive={true}
								attributeObjectKeySuffix="Radius"
								onChangeHandler={changeHandler}
							/>
						</>
					}
					hover={
						<>
							<ABlocksSelectControl
								label={__('Border Style', 'ablocks')}
								options={borderStyleOpions}
								isResponsive={false}
								attributeObjectKey="borderStyleH"
								attributeValue={attributeValue}
								setAttributes={setAttributes}
								attributeName={attributeName}
							/>
							{showControlH !== 'none' &&
								showControlH !== 'default' &&
								showControlH && (
									<>
										<div className="ablocks-border-control__options">
											<ABlocksDimensions
												label={__('Width', 'ablocks')}
												attributeName={attributeName}
												attributeValue={attributeValue}
												setAttributes={setAttributes}
												isResponsive={true}
												attributeObjectKeySuffix="WidthH"
												onChangeHandler={changeHandler}
											/>
										</div>
										<ABlocksColorControl
											label={__(
												'Border color',
												'ablocks'
											)}
											attributeName="borderColorH"
											attributeValue={
												attributeValue.borderColorH
											}
											onChangeHandler={(
												attributeObjectKey,
												controlValue
											) =>
												changeHandler(
													controlValue,
													attributeObjectKey
												)
											}
										/>
									</>
								)}
							<ABlocksDimensions
								label={__('Border Radius', 'ablocks')}
								attributeName={attributeName}
								attributeValue={attributeValue}
								setAttributes={setAttributes}
								isResponsive={true}
								attributeObjectKeySuffix="RadiusH"
								onChangeHandler={changeHandler}
							/>
						</>
					}
				/>
			</div>
		</React.Fragment>
	);
}

ABlocksBorderControl.propTypes = propTypes;
ABlocksBorderControl.defaultProps = defaultProps;
