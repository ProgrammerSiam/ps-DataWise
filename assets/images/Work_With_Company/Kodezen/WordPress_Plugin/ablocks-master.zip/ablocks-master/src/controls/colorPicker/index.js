import React, { useState } from 'react';
import {
	ButtonGroup,
	Button,
	ColorPicker,
	GradientPicker,
} from '@wordpress/components';
import PropTypes from 'prop-types';
import './editor.scss';

const propTypes = {
	isResponsive: PropTypes.bool,
	label: PropTypes.string,
	attributeName: PropTypes.string,
	attributeValue: PropTypes.any,
	onChangeHandler: PropTypes.func,
};

const defaultProps = {
	label: '',
	isResponsive: true,
};

export default function ABlocksColorPickerControl(props) {
	const { attributeName, attributeValue, setAttributes, label } = props;

	const [backgroundType, setBackgroundType] = useState('classic');

	const handleBackgroundTypeChange = (type) => {
		setBackgroundType(type);
	};

	const changeHandler = (controlValue) => {
		setAttributes({
			[attributeName]: {
				...attributeValue,
				[backgroundType]: controlValue,
			},
		});
	};

	return (
		<React.Fragment>
			<div className="ablocks-colorPicker-control">
				<div className="ablocks-colorPicker-control__control">
					<p>{label}</p>
					<ButtonGroup>
						<Button
							onClick={() =>
								handleBackgroundTypeChange('classic')
							}
							className="--button"
						>
							<span className="dashicons dashicons-admin-customizer"></span>
						</Button>
						<Button
							onClick={() =>
								handleBackgroundTypeChange('gradient')
							}
							className="--button"
						>
							<span className="dashicons dashicons-color-picker"></span>
						</Button>
					</ButtonGroup>
				</div>
				<div>
					{backgroundType === 'classic' && (
						<ColorPicker onChange={changeHandler} />
					)}

					{backgroundType === 'gradient' && (
						<GradientPicker onChange={changeHandler} />
					)}
				</div>
			</div>
		</React.Fragment>
	);
}

ABlocksColorPickerControl.propTypes = propTypes;
ABlocksColorPickerControl.defaultProps = defaultProps;
