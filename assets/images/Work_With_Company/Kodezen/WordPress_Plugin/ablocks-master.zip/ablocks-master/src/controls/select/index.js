import { getAttributeDefaultValue } from './helper';
import { useState, useRef, useEffect } from 'react';
import ControlLabel from '@Components/control-label';
import GetDeviceType from '@Utils/get-device-type';
import { objectUniqueCheck } from '@Utils/helper';
import PropTypes from 'prop-types';
import './styles.scss';

const propTypes = {
	label: PropTypes.string,
	isSearch: PropTypes.bool,
	options: PropTypes.array,
	isResponsive: PropTypes.bool,
	onChangeHandler: PropTypes.func,
	attributeValue: PropTypes.oneOfType([
		PropTypes.string,
		PropTypes.object,
		PropTypes.array,
	]),
	attributeObjectKey: PropTypes.string,
	isInline: PropTypes.bool,
	isMulti: PropTypes.bool,
};

const defaultProps = {
	label: '',
	options: [],
	isSearch: false,
	attributeValue: '',
	isResponsive: false,
	attributeObjectKey: '',
	isInline: true,
	isMulti: false,
};

const ABlocksSelectControl = (props) => {
	const {
		label,
		isSearch,
		attributeValue,
		onChangeHandler,
		attributeName,
		setAttributes,
		attributeObjectKey,
		isResponsive,
		options,
		isMulti,
	} = props;
	const inputRef = useRef(null);
	const optionsRef = useRef(null);
	const deviceType = GetDeviceType();
	// const checkedAttributeValue = attributeObjectKey
	// 	? attributeValue[
	// 			isResponsive
	// 				? attributeObjectKey + deviceType
	// 				: attributeObjectKey
	// 	  ]
	// 	: isResponsive
	// 	? attributeValue + deviceType
	// 	: attributeValue;

	let checkedAttributeValue;

	if (attributeObjectKey) {
		if (isResponsive) {
			checkedAttributeValue =
				attributeValue[attributeObjectKey + deviceType];
		} else {
			checkedAttributeValue = attributeValue[attributeObjectKey];
		}
	} else {
		checkedAttributeValue = isResponsive
			? attributeValue + deviceType
			: attributeValue;
	}
	const [isToggle, setIsToggle] = useState(false);
	const [searchOptions, setSearchOptions] = useState('');
	const [multiSelectValue, setMultiSelectValue] = useState(
		checkedAttributeValue
	);
	const changeHandler = (controlValue, deviceMode) => {
		if (onChangeHandler) {
			onChangeHandler(
				controlValue,
				isResponsive
					? attributeObjectKey + deviceMode
					: attributeObjectKey
			);
		} else {
			defaultChangeHandler(controlValue, deviceMode);
		}
	};

	const defaultChangeHandler = (controlValue, deviceMode) => {
		if (attributeObjectKey) {
			const key = isResponsive
				? attributeObjectKey + deviceMode
				: attributeObjectKey;
			return setAttributes({
				[attributeName]: objectUniqueCheck(
					getAttributeDefaultValue(isResponsive, attributeObjectKey),
					{
						...attributeValue,
						[key]: controlValue,
					}
				),
			});
		}
		return setAttributes({ [attributeName]: controlValue });
	};

	const handleSelectValue = (e, option) => {
		if (isMulti) {
			const updatedData = [...multiSelectValue];
			updatedData.push(option?.value);

			// call change handler for set attributes value
			changeHandler(updatedData, deviceType);
			// Added a new value in multi select
			setMultiSelectValue(updatedData);
		} else {
			setSearchOptions('');
			changeHandler(option.value, deviceType);
		}
	};

	const handleRemoveMultiSelectValue = (e, option, elementIndex) => {
		// This will prevent the event from bubbling up to parent elements
		e.stopPropagation();

		const updatedData = [...multiSelectValue];
		updatedData.splice(elementIndex, 1);

		// call change handler for set attributes value
		changeHandler(updatedData, deviceType);

		// removed and updated a value from multi select
		setMultiSelectValue(updatedData);
	};

	useEffect(() => {
		if (
			Array.isArray(checkedAttributeValue) &&
			Array.isArray(multiSelectValue)
		) {
			const chkLength = checkedAttributeValue?.length;
			const mltLength = multiSelectValue?.length;
			if (
				chkLength !== mltLength ||
				!checkedAttributeValue.every(
					(value, index) => value === multiSelectValue[index]
				)
			) {
				setMultiSelectValue(checkedAttributeValue);
			}
		} else if (checkedAttributeValue !== multiSelectValue) {
			setMultiSelectValue(checkedAttributeValue);
		}
	}, [checkedAttributeValue, multiSelectValue]);

	useEffect(() => {
		const handleClick = (e) => {
			if (inputRef?.current && !inputRef?.current?.contains(e.target)) {
				setIsToggle(false);
			}
		};

		document.addEventListener('mousedown', handleClick);

		if (optionsRef.current) {
			const optionsHeight = optionsRef.current.offsetHeight;
			const inputRect = inputRef.current.getBoundingClientRect();
			const spaceBelow = window.innerHeight - inputRect.bottom;
			const spaceAbove = inputRect.top;

			if (spaceBelow < optionsHeight && spaceAbove > spaceBelow) {
				optionsRef.current.style.top = `-${optionsHeight}px`;
			} else {
				optionsRef.current.style.top = '100%';
			}
		}

		return () => {
			document.removeEventListener('mousedown', handleClick);
		};
	}, [isToggle, searchOptions, options]);

	return (
		<div className="ablocks-control ablocks-custom-select">
			<ControlLabel label={label} isResponsive={isResponsive} />
			<div className="ablocks-custom-select--container" ref={inputRef}>
				{/* input box content  */}
				<div
					role="presentation"
					className="ablocks-custom-select--inner-content"
					onClick={() => setIsToggle(!isToggle)}
					onKeyDown={() => {}}
				>
					{/* Input and value content area  */}
					<div className="ablocks-custom-select--box">
						{isMulti ? (
							<div className="ablocks-custom-select--multi-value">
								{multiSelectValue?.length > 0
									? options
											.filter((option) =>
												multiSelectValue.includes(
													option.value
												)
											)
											?.map((option, index) => (
												<div
													className="ablocks-multi-select--option"
													key={index}
												>
													<span className="ablocks-multi-select--option-label">
														{option?.label}
													</span>
													<span
														role="presentation"
														className="ablocks-multi-select--option-close"
														onClick={(e) =>
															handleRemoveMultiSelectValue(
																e,
																option,
																index
															)
														}
														onKeyDown={() => {}}
													>
														<span className="ablocks-icon ablocks-icon--close"></span>
													</span>
												</div>
											))
									: 'select...'}
							</div>
						) : (
							<div className="ablocks-custom-select--single-value">
								{isSearch && searchOptions?.length > 0
									? ''
									: options?.find(
											(option) =>
												option.value ===
												checkedAttributeValue
									  )?.label ||
									  options[0]?.label ||
									  'select...'}
							</div>
						)}

						{isSearch && (
							<div className="ablocks-custom-select--input-container">
								<input
									className="ablocks-custom-select--search-option"
									type="text"
									value={searchOptions}
									onChange={(e) => {
										setSearchOptions(e.target.value);
									}}
								/>
							</div>
						)}
					</div>
					{/* Right side arrow SVG icon  */}
					<div className="ablocks-custom-select--indicator">
						<span className="ablocks-icon ablocks-icon--angle-down"></span>
					</div>
				</div>
				{/* dropdown options  */}
				<div
					role="presentation"
					className={`ablocks-custom-select--options${
						isToggle
							? ' ablocks-custom-select--options--toggle'
							: ''
					}`}
					onClick={() => {
						setIsToggle(!isToggle);
					}}
					onKeyDown={() => {}}
					ref={optionsRef}
				>
					{isMulti ? (
						options
							?.filter((option) => {
								return !multiSelectValue.includes(option.value);
							})
							.map((option, index) => (
								<span
									role="presentation"
									key={index}
									className={`ablocks-custom-select--option`}
									onClick={(e) =>
										handleSelectValue(e, option, index)
									}
									onKeyDown={() => {}}
								>
									{option?.label}
								</span>
							))
					) : (
						<>
							{options
								.filter((option) =>
									option.label
										.toLowerCase()
										.includes(searchOptions.toLowerCase())
								)
								?.map((option, index) => (
									<span
										role="presentation"
										key={index}
										className={`ablocks-custom-select--option${
											checkedAttributeValue ===
												option.value &&
											options.findIndex(
												(o) => o.value === option.value
											) === index
												? ' ablocks-custom-select--option--active'
												: ''
										}`}
										onClick={(e) =>
											handleSelectValue(e, option, index)
										}
										onKeyDown={() => {}}
									>
										{option?.label}
									</span>
								))}
						</>
					)}
				</div>
			</div>
		</div>
	);
};
ABlocksSelectControl.propTypes = propTypes;
ABlocksSelectControl.defaultProps = defaultProps;
export default ABlocksSelectControl;
