import React from 'react';
import ABlocksSelectControl from '@Controls/select';
import ABlocksRangeControl from '@Controls/range';
import { __ } from '@wordpress/i18n';

const Positions = [
	{ value: 'center center', label: __('Center Center', 'ablocks') },
	{ value: 'center left', label: __('Center Left', 'ablocks') },
	{ value: 'center right', label: __('Center Right', 'ablocks') },
	{ value: 'top center', label: __('Top Center', 'ablocks') },
	{ value: 'top left', label: __('Top Left', 'ablocks') },
	{ value: 'top right', label: __('Top Right', 'ablocks') },
	{ value: 'bottom center', label: __('Bottom Center', 'ablocks') },
	{ value: 'bottom left', label: __('Bottom Left', 'ablocks') },
	{ value: 'bottom right', label: __('Bottom Right', 'ablocks') },
	{ value: 'custom', label: __('Custom', 'ablocks') },
];

const ABlocksMaskPosition = (props) => {
	const {
		deviceType,
		attributeValue,
		changeHandler,
		attributeName,
		setAttributes,
	} = props;

	let maxXDefaultValue;
	let minXDefaultValue;
	let maxYDefaultValue;
	let minYDefaultValue;

	// x-max
	if (attributeValue['xPositionUnit' + deviceType] === 'px') {
		maxXDefaultValue = 500;
	}
	if (
		attributeValue['xPositionUnit' + deviceType] === 'em' ||
		attributeValue['scaleUnit' + deviceType] === 'vw' ||
		attributeValue['xPositionUnit' + deviceType] === '%'
	) {
		maxXDefaultValue = 100;
	}
	if (attributeValue['xPositionUnit' + deviceType] === 'rem') {
		maxXDefaultValue = 10;
	}

	// x-min
	if (attributeValue['xPositionUnit' + deviceType] === 'px') {
		minXDefaultValue = -500;
	}
	if (
		attributeValue['xPositionUnit' + deviceType] === 'em' ||
		attributeValue['scaleUnit' + deviceType] === 'vw' ||
		attributeValue['xPositionUnit' + deviceType] === '%'
	) {
		minXDefaultValue = -100;
	}
	if (attributeValue['xPositionUnit' + deviceType] === 'rem') {
		minXDefaultValue = 0;
	}

	// y-max
	if (attributeValue['yPositionUnit' + deviceType] === 'px') {
		maxYDefaultValue = 500;
	}
	if (
		attributeValue['yPositionUnit' + deviceType] === 'em' ||
		attributeValue['scaleUnit' + deviceType] === 'vw' ||
		attributeValue['yPositionUnit' + deviceType] === '%'
	) {
		maxYDefaultValue = 100;
	}
	if (attributeValue['yPositionUnit' + deviceType] === 'rem') {
		maxYDefaultValue = 10;
	}

	// y-min
	if (attributeValue['yPositionUnit' + deviceType] === 'px') {
		minYDefaultValue = -500;
	}
	if (
		attributeValue['yPositionUnit' + deviceType] === 'em' ||
		attributeValue['scaleUnit' + deviceType] === 'vw' ||
		attributeValue['yPositionUnit' + deviceType] === '%'
	) {
		minYDefaultValue = -100;
	}
	if (attributeValue['yPositionUnit' + deviceType] === 'rem') {
		minYDefaultValue = -10;
	}

	return (
		<>
			<ABlocksSelectControl
				label={__('Position', 'ablocks')}
				options={Positions}
				isResponsive={true}
				attributeValue={attributeValue}
				attributeObjectKey="maskPosition"
				attributeName={attributeName}
				setAttributes={setAttributes}
			/>

			{attributeValue['maskPosition' + deviceType] === 'custom' && (
				<>
					<div className="ablocks-mask-control__position">
						<ABlocksRangeControl
							{...props}
							label={__('X Position', 'ablocks')}
							min={minXDefaultValue}
							max={maxXDefaultValue}
							hasUnit={true}
							isInline={false}
							onChangeHandler={changeHandler}
							attributeObjectKey="xPosition"
						/>
					</div>
					<div className="ablocks-mask-control__position">
						<ABlocksRangeControl
							{...props}
							label={__('Y Position', 'ablocks')}
							min={minYDefaultValue}
							max={maxYDefaultValue}
							hasUnit={true}
							isInline={false}
							onChangeHandler={changeHandler}
							attributeObjectKey="yPosition"
						/>
					</div>
				</>
			)}
		</>
	);
};

export default ABlocksMaskPosition;
