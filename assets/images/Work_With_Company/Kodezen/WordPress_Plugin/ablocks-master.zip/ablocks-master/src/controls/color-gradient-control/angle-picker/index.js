import React, { useRef } from 'react';

import { RangeControl } from '@wordpress/components';

import { ANGLE_PICKER_PROP_TYPES } from './constant';
import useDragging from './useDragging';
import { centerOffset, clampAngle, snapAngle, pointDegrees } from './function';
import './editor.scss';

const AngleControl = ({ angle, setAngle, size = 80, snap = 5, gradient }) => {
	const pickerRef = useRef();
	const anglePcikerCircleStyles = {
		height: size,
		width: size,
	};
	const angleWrapperStyles = {
		background: gradient,
	};
	const indicatorWrapperStyles = {
		transform: `rotate(${angle}deg)`,
		height: size,
	};

	const onAngleChange = ({ clientX, clientY }, useSnap = false) => {
		const center = centerOffset(pickerRef.current);
		const degrees = pointDegrees(clientX, clientY, center);

		const clamped = clampAngle(degrees);
		const newAngle = useSnap ? snapAngle(clamped, snap) : clamped;

		setAngle(newAngle);
		return newAngle;
	};

	const [drag] = useDragging({
		onDragStart: (e) => onAngleChange(e, true),
		onDrag: onAngleChange,
		onDragEnd: (angleValue) => {
			if (!angleValue) {
				return;
			}
			const snappedAngle = snapAngle(angleValue, snap);
			setAngle(snappedAngle);
		},
	});

	return (
		<div className="ablocks-control-angle-control-wrapper">
			<div
				className="ablocks-control-angle-picker-wrapper"
				style={angleWrapperStyles}
			>
				<div
					className="ablocks-control-angle-picker"
					ref={pickerRef}
					onMouseDown={drag}
					onTouchStart={drag}
					style={anglePcikerCircleStyles}
					role="presentation"
				>
					<span
						className="ablocks-control-angle-picker-indicator-wrapper"
						style={indicatorWrapperStyles}
					>
						<span className="ablocks-control-angle-picker-indicator">
							<i />
						</span>
					</span>
				</div>
			</div>
			<RangeControl
				className="ablocks-gradient-reversed-range-control"
				label="Angle"
				value={angle}
				onChange={setAngle}
				min={0}
				max={360}
				step={1}
			/>
		</div>
	);
};

const AnglePicker = ({ value, onChange }) => {
	return (
		<AngleControl
			gradient={value?.gradient}
			angle={value?.modifier || 90}
			setAngle={onChange}
			size={90}
		/>
	);
};
AngleControl.propTypes = ANGLE_PICKER_PROP_TYPES;

export default AnglePicker;
