import React from 'react';
import RenderContainer from '@Components/block-container/render';
import RenderIcon from '@Controls/icon-upload/render-icon';
import metadata from './block.json';
import './style.css';

const propTypes = {};

const defaultProps = {};

export default function Render(props) {
	const { attributes } = props;
	const { block_id } = attributes;
	return (
		<React.Fragment>
			<RenderContainer
				blockId={block_id}
				name={metadata.name}
				attributes={attributes}
				typography={[]}
			>
				<div className="ablocks-icon-wrap">
					<RenderIcon attributes={attributes} />
				</div>
			</RenderContainer>
		</React.Fragment>
	);
}

Render.propTypes = propTypes;
Render.defaultProps = defaultProps;
