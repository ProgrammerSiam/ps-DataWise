import React from 'react';
import RenderContainer from '@Components/block-container/render';
import { getBlockTypes } from '@wordpress/blocks';
import { InnerBlocks } from '@wordpress/block-editor';
import { select } from '@wordpress/data';
import metadata from './block.json';

const propTypes = {};

const defaultProps = {};

export default function Render(props) {
	const { attributes, clientId } = props;
	const { block_id } = attributes;
	const hasChildBlocks =
		select('core/block-editor').getBlockOrder(clientId).length > 0;
	const innerBlocksProps = {
		renderAppender: hasChildBlocks
			? undefined
			: InnerBlocks.ButtonBlockAppender,
		allowedBlocks: getBlockTypes()
			.filter((item) => !item.parent)
			.map((block) => block.name),
	};

	return (
		<React.Fragment>
			<RenderContainer
				blockId={block_id}
				name={metadata.name}
				attributes={attributes}
				typography={[]}
			>
				<div className="ablocks-container-block-wrapper">
					<InnerBlocks {...innerBlocksProps} />
				</div>
			</RenderContainer>
		</React.Fragment>
	);
}

Render.propTypes = propTypes;
Render.defaultProps = defaultProps;
