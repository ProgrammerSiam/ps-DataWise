import React from 'react';
import PropTypes from 'prop-types';
import { __ } from '@wordpress/i18n';
import GetDeviceType from '@Utils/get-device-type';
import { objectUniqueCheck } from '@Utils/helper';
import ABlocksAlignmentControl from '@Controls/alignment';
import ABlocksRangeControl from '@Controls/range';
import ABlocksSelectControl from '@Controls/select';
import {
	getAttributeDefaultValue,
	verticalOrientation,
	horizontalOrientation,
} from './helper';
import './styles.scss';

const propTypes = {
	isResponsive: PropTypes.bool,
	label: PropTypes.string,
	attributeName: PropTypes.string,
	attributeValue: PropTypes.any,
	setAttributes: PropTypes.func,
};
const defaultProps = {
	label: '',
	isResponsive: true,
};

const ABlocksPositionControl = (props) => {
	const {
		label,
		isResponsive,
		attributeName,
		attributeValue,
		setAttributes,
	} = props;
	const deviceType = GetDeviceType();

	const changeHandler = (controlValue, attributeObjectKey = '') => {
		return setAttributes({
			[attributeName]: objectUniqueCheck(
				getAttributeDefaultValue(isResponsive),
				{
					...attributeValue,
					[attributeObjectKey]: controlValue,
				}
			),
		});
	};

	const positionsTypeOptions = [
		{ value: 'relative', label: 'Default' },
		{ value: 'absolute', label: 'Absolute' },
		{ value: 'fixed', label: 'Fixed' },
	];

	const showControl =
		attributeValue.positionType === 'absolute' ||
		attributeValue.positionType === 'fixed';

	let rangeMaxValue;
	if (
		attributeValue['unit' + deviceType] === 'px' ||
		attributeValue['unit' + deviceType] === undefined
	) {
		rangeMaxValue = 1000;
	}
	if (
		attributeValue['unit' + deviceType] === '%' ||
		attributeValue['unit' + deviceType] === 'vw' ||
		attributeValue['unit' + deviceType] === 'vh'
	) {
		rangeMaxValue = 200;
	}
	if (
		attributeValue['unit' + deviceType] === 'rem' ||
		attributeValue['unit' + deviceType] === 'em'
	) {
		rangeMaxValue = 10;
	}

	let rangeMinValue;
	if (
		attributeValue['unit' + deviceType] === 'px' ||
		attributeValue['unit' + deviceType] === undefined
	) {
		rangeMinValue = -1000;
	}
	if (
		attributeValue['unit' + deviceType] === '%' ||
		attributeValue['unit' + deviceType] === 'vw' ||
		attributeValue['unit' + deviceType] === 'vh'
	) {
		rangeMinValue = -200;
	}
	if (
		attributeValue['unit' + deviceType] === 'rem' ||
		attributeValue['unit' + deviceType] === 'em'
	) {
		rangeMinValue = 0;
	}

	return (
		<React.Fragment>
			<div className="ablocks-position-control">
				<ABlocksSelectControl
					options={positionsTypeOptions}
					label={label}
					attributeValue={attributeValue}
					attributeObjectKey="positionType"
					attributeName={attributeName}
					setAttributes={setAttributes}
				/>
				{showControl && (
					<>
						<ABlocksAlignmentControl
							label={__('Horizontal Orientation', 'ablocks')}
							attributeObjectKey="hOrientation"
							options={horizontalOrientation}
							attributeValue={attributeValue}
							isInline={false}
							onChangeHandler={changeHandler}
						/>

						{/* Horizontal offSet */}
						<div className="ablocks-position-control__offset">
							<ABlocksRangeControl
								{...props}
								hasUnit={true}
								isInline={false}
								min={rangeMinValue}
								max={rangeMaxValue}
								onChangeHandler={changeHandler}
								label={__('Offset', 'ablocks')}
								attributeObjectKey="hOffset"
							/>
						</div>

						<ABlocksAlignmentControl
							label={__('Vertical Orientation', 'ablocks')}
							attributeObjectKey="vOrientation"
							options={verticalOrientation}
							attributeValue={attributeValue}
							isInline={false}
							onChangeHandler={changeHandler}
						/>
						{/* Vertical offSet */}
						<div className="ablocks-position-control__offset">
							<ABlocksRangeControl
								{...props}
								hasUnit={true}
								isInline={false}
								min={rangeMinValue}
								max={rangeMaxValue}
								onChangeHandler={changeHandler}
								label={__('Offset', 'ablocks')}
								attributeObjectKey="vOffset"
							/>
						</div>
					</>
				)}
			</div>
		</React.Fragment>
	);
};
ABlocksPositionControl.propTypes = propTypes;
ABlocksPositionControl.defaultProps = defaultProps;
export default ABlocksPositionControl;
