import React, { useState } from 'react';
import { __ } from '@wordpress/i18n';
import PropTypes from 'prop-types';
import Button from '@Components/Button';
import { Modal } from '@wordpress/components';
import RenderIconLists from './options/RenderIcons';
import ControlLabel from '@Components/control-label';
import { plugin_root_url as PluginURL } from '@Utils/helper';

import { regularIcons, brandsIcons, solidIcons } from './icons-svg-data';

import './styles.scss';

const propTypes = {
	label: PropTypes.string,
	attributePrefix: PropTypes.string,
	setAttributes: PropTypes.func,
	onChangeHandler: PropTypes.func,
	attributes: PropTypes.object,
};

const defaultProps = {
	attributePrefix: 'icon',
};

export default function ABlocksIconUploader({
	label,
	attributePrefix,
	attributes,
	setAttributes,
	onChangeHandler,
}) {
	const [openIconLibrary, setOpenIconLibrary] = useState(false);
	const [searchIcons, setSearchIcons] = useState('');
	const [modalIconType, setModalIconType] = useState('all');

	const iconClass = attributes[attributePrefix + 'Class'];

	const changeHandler = (className) => {
		if (onChangeHandler) {
			onChangeHandler(className);
		} else {
			defaultChangeHandler(className);
		}
		setOpenIconLibrary(false);
	};

	const defaultChangeHandler = (className) => {
		const iconsList = {};
		const iconType = className.substring(2, 3);

		switch (iconType) {
			case 'r':
				iconsList.data = regularIcons.icons;
				break;

			case 's':
				iconsList.data = solidIcons.icons;
				break;

			case 'b':
				iconsList.data = brandsIcons.icons;
				break;
		}

		const iconKey = className.substring(7);
		const iconData = iconsList.data[iconKey];
		const iconSvgViewBox = `0 0 ${iconData[0]} ${iconData[1]}`;
		const iconSvgPath = iconData[4];

		setAttributes({
			[attributePrefix + 'SvgPath']: iconSvgPath,
			[attributePrefix + 'SvgViewBox']: iconSvgViewBox,
			[attributePrefix + 'Class']: className,
		});
	};

	return (
		<div>
			{/* Icon picker label*/}
			<ControlLabel label={label} isResponsive={false}></ControlLabel>
			{/* Icon uploder */}
			<div className="ablocks-placeholder-icon-wrapper">
				<img
					className="ablocks-placeholder-image"
					src={PluginURL + '/assets/images/placeholder-image.svg'}
					alt=""
				/>
				{iconClass && (
					<div className="iconWrapper">
						{/* Renderin icon in the icon uploder  */}
						<i className={iconClass}></i>
					</div>
				)}
				<button
					onClick={() => {
						setOpenIconLibrary(true);
					}}
					className={`ablocks-icon-btn ${
						iconClass
							? 'ablocks-replace-icon'
							: 'ablocks-upload-icon'
					}`}
				>
					{iconClass
						? __('Replace icon…', 'ablocks')
						: __('Choose icon…', 'ablocks')}
				</button>

				<button
					className="ablocks-delete-icon"
					onClick={() =>
						setAttributes({ [attributePrefix + 'Class']: '' })
					}
				>
					<span className="ablocks-icon ablocks-icon--delete"></span>
				</button>
			</div>

			{/* Icon library modal  */}
			{openIconLibrary && (
				<Modal
					onRequestClose={() => {
						setOpenIconLibrary(false);
					}}
				>
					<div className="ablocks-icon-library">
						{/* <div className="ablocks-icon-library--sidebar">
							<h2 className="ablocks-icon-library--sidebar--text">
								{__('ICONS LIBRARY', 'ablocks')}
							</h2>
							<div className="ablocks-icon-library--sidebar--content">
								<ContentStyleTabs />
								<div className="ablocks-icon-library--sidebar--content--icon-manager">
									{iconManagerOptions?.map(
										(option, index) => (
											<span
												key={index}
												className="option"
											>
												{option?.label}
											</span>
										)
									)}
								</div>
							</div>
						</div> */}
						<div className="ablocks-icon-library--wrapper">
							<div className="ablocks-icon-library--header">
								<input
									type="text"
									className="ablocks-icon-library--icons-search"
									placeholder={__('search icons…', 'ablocks')}
									value={searchIcons}
									onChange={(e) =>
										setSearchIcons(e.target.value)
									}
								/>
								<div className="ablocks-icon-library--header--btn-wrapper">
									<Button
										icon={
											<span className="ablocks-icon ablocks-icon--close"></span>
										}
										onClick={() => {
											setOpenIconLibrary(false);
										}}
									></Button>
								</div>
							</div>
							<div className="ablocks-icon-library--content-area">
								<div className="ablocks-icon-library--icons-type">
									<span
										role="presentation"
										className={`${
											modalIconType === 'all'
												? 'active'
												: ''
										}`}
										onClick={() => setModalIconType('all')}
										onKeyDown={() => {}}
									>
										{__('All', 'ablocks')}
									</span>
									<span
										role="presentation"
										className={`${
											modalIconType === 'solid'
												? 'active'
												: ''
										}`}
										onClick={() =>
											setModalIconType('solid')
										}
										onKeyDown={() => {}}
									>
										{__('Solid', 'ablocks')}
									</span>
									<span
										role="presentation"
										className={`${
											modalIconType === 'brands'
												? 'active'
												: ''
										}`}
										onClick={() =>
											setModalIconType('brands')
										}
										onKeyDown={() => {}}
									>
										{__('Brands', 'ablocks')}
									</span>
								</div>
								<div className="ablocks-icon-library--icons">
									<h2 className="ablocks-icon-library--icons--total-icon">
										{__('All Icons', 'ablocks')}
									</h2>
								</div>
								{/* Rendering all of icons  */}
								<RenderIconLists
									changeHandler={changeHandler}
									searchIconQuery={searchIcons}
									modalIconType={modalIconType}
								/>
							</div>
						</div>
					</div>
				</Modal>
			)}
		</div>
	);
}

ABlocksIconUploader.propTypes = propTypes;
ABlocksIconUploader.defaultProps = defaultProps;
