export const getAttributeDefaultValue = (isResponsive = false) => {
	if (isResponsive) {
		return {
			zIndex: '',
			zIndexTablet: '',
			zIndexMobile: '',
		};
	}
	return {
		zIndex: '',
	};
};

export const getAttribute = (attributeName, isResponsive = false) => {
	if (isResponsive) {
		return {
			[attributeName]: {
				type: 'object',
				default: getAttributeDefaultValue(isResponsive),
			},
		};
	}
	return {
		[attributeName]: {
			type: 'object',
			default: getAttributeDefaultValue(isResponsive),
		},
	};
};

export const getCSS = (attributeValue, property = '', device = '') => {
	const value = {
		...getAttributeDefaultValue(device ? true : false),
		...attributeValue,
	};
	const css = {};
	if (value['zIndex' + device]) {
		css[`${property}`] = value['zIndex' + device];
	}
	return css;
};
