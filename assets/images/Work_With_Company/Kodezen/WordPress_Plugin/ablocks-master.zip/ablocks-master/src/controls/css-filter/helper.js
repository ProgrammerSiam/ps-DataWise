export const getAttributeDefaultValue = () => {
	return {
		// CSS filter attributes
		blur: '',
		brightness: '',
		contrast: '',
		saturate: '',
		hue: '',
		// CSS filter hover attributes
		blurH: '',
		brightnessH: '',
		contrastH: '',
		saturateH: '',
		hueH: '',
	};
};

export const getAttribute = (attributeName) => {
	return {
		[attributeName]: {
			type: 'object',
			default: getAttributeDefaultValue(),
		},
	};
};

export const getCSS = (attributeValue, device = '') => {
	const value = {
		...getAttributeDefaultValue(device ? true : false),
		...attributeValue,
	};

	const css = {};

	if (
		value?.blur !== '' ||
		value?.brightness !== '' ||
		value?.contrast !== '' ||
		value?.saturate !== '' ||
		value?.hue !== ''
	) {
		const filterValues = {
			brightness: `brightness(${value?.brightness || 100}%)`,
			contrast: `contrast(${value?.contrast || 100}%)`,
			saturate: `saturate(${value?.saturate || 100}%)`,
			blur: `blur(${value?.blur || 0}px)`,
			hue: `hue-rotate(${value?.hue || 0}deg)`,
		};

		// Filter css
		css.filter = Object.values(filterValues).join(' ');
	}

	return css;
};
