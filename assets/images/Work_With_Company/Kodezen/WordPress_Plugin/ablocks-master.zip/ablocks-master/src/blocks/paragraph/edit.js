import React, { useEffect } from 'react';
import Settings from './settings';
import Render from './render';
import CSSGenerator from '@Utils/css-generator';
import {
	getWrapperCSS,
	getParagraphTextCSS,
	getParagraphDropTextCSS,
} from './styling';

export default function Edit(props) {
	const { isSelected, attributes, setAttributes, clientId } = props;

	useEffect(() => {
		setAttributes({ block_id: clientId });
	}, [clientId, setAttributes]);

	// Generate CSS
	const cssGenerator = new CSSGenerator(attributes);

	cssGenerator.addClassStyles(
		'{{WRAPPER}}',
		getWrapperCSS(attributes),
		getWrapperCSS(attributes, 'Tablet'),
		getWrapperCSS(attributes, 'Mobile')
	);

	const desktopParagraphTextStyles = getParagraphTextCSS(attributes);

	if (attributes?.textColor) {
		desktopParagraphTextStyles.color = attributes.textColor;
	}
	cssGenerator.addClassStyles(
		'{{WRAPPER}} .ablocks-paragraph-text',
		desktopParagraphTextStyles,
		getParagraphTextCSS(attributes, 'Tablet'),
		getParagraphTextCSS(attributes, 'Mobile')
	);
	cssGenerator.addClassStyles(
		'{{WRAPPER}} .ablocks-paragraph-text-drop-caps::first-letter',
		getParagraphDropTextCSS(attributes),
		getParagraphDropTextCSS(attributes, 'Tablet'),
		getParagraphDropTextCSS(attributes, 'Mobile')
	);

	const generatedCSS = cssGenerator.generateCSS();
	return (
		<>
			<style>{generatedCSS}</style>
			{isSelected && <Settings {...props} />}
			<Render {...props} />
		</>
	);
}
