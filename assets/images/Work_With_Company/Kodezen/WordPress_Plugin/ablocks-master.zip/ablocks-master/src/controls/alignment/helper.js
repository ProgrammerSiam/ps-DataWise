export const alignmentOptions = [
	{
		label: 'left',
		value: 'left',
		icon: 'left',
	},
	{
		label: 'center',
		value: 'center',
		icon: 'center',
	},
	{
		label: 'right',
		value: 'right',
		icon: 'right',
	},
	{
		label: 'justify',
		value: 'justify',
		icon: 'justify',
	},
];

export const getAttributeDefaultValue = (
	isResponsive = false,
	defaultValue
) => {
	if (isResponsive) {
		return {
			value: 'default',
			valueTablet: '',
			valueMobile: '',
			...defaultValue,
		};
	}
	return {
		value: 'default',
		...defaultValue,
	};
};

export const getAttribute = (
	attributeName,
	isResponsive = false,
	defaultValue = {}
) => {
	if (isResponsive) {
		return {
			[attributeName]: {
				type: 'object',
				default: getAttributeDefaultValue(isResponsive, defaultValue),
			},
		};
	}
	return {
		[attributeName]: {
			type: 'object',
			default: getAttributeDefaultValue(isResponsive, defaultValue),
		},
	};
};

export const getCSS = (attributeValue, property = '', device = '') => {
	const value = {
		...getAttributeDefaultValue(device ? true : false),
		...attributeValue,
	};
	const css = {};

	if (value['value' + device] !== '') {
		css[`${property}`] = value['value' + device];
	}

	return css;
};
