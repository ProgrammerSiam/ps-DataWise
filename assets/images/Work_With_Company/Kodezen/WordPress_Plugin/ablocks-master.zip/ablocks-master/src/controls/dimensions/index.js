import React from 'react';
import PropTypes from 'prop-types';
import ControlLabel from '@Components/control-label';
import ABlocksUnitSelect from '@Components/unit';
import GetDeviceType from '@Utils/get-device-type';
import ABlocksDimensionFields from './Fields';
import { getAttributeDefaultValue } from './helper';
import { objectUniqueCheck } from '@Utils/helper';

const propTypes = {
	isResponsive: PropTypes.bool,
	label: PropTypes.string,
	attributeName: PropTypes.string,
	attributeValue: PropTypes.any,
	setAttributes: PropTypes.func,
	onChangeHandler: PropTypes.func,
	attributeObjectKeySuffix: PropTypes.string,
};

const defaultProps = {
	label: '',
	isResponsive: true,
	attributeObjectKeySuffix: '',
};

export default function ABlocksDimensions(props) {
	const {
		isResponsive,
		attributeName,
		attributeValue,
		onChangeHandler,
		setAttributes,
		label,
		attributeObjectKeySuffix,
	} = props;
	const deviceType = GetDeviceType();
	const changeHandler = (controlValue, name) => {
		if (onChangeHandler) {
			onChangeHandler(
				controlValue,
				isResponsive ? name + deviceType : name
			);
		} else {
			defaultChangeHandler(controlValue, name);
		}
	};

	const defaultChangeHandler = (controlValue, name) => {
		setAttributes({
			[attributeName]: objectUniqueCheck(
				getAttributeDefaultValue(isResponsive),
				{
					...attributeValue,
					[name + (isResponsive ? deviceType : '')]: controlValue,
				}
			),
		});
	};

	const commonProps = {
		attributeValue,
		deviceType,
		isResponsive,
		changeHandler,
	};

	return (
		<React.Fragment>
			<div className="ablocks-control ablocks-control--dimensions">
				<div className="ablocks-control__head">
					{label && (
						<ControlLabel
							label={label}
							isResponsive={isResponsive}
						/>
					)}
					<ABlocksUnitSelect
						attributeName={attributeName}
						attributeObjectKey={'unit' + attributeObjectKeySuffix}
						attributeValue={attributeValue}
						setAttributes={setAttributes}
						getAttributeDefaultValue={getAttributeDefaultValue}
					/>
				</div>
				<ABlocksDimensionFields
					{...commonProps}
					attributeName={attributeName}
					setAttributes={setAttributes}
					isDefaultLinked={
						attributeValue?.[
							'isLinked' + attributeObjectKeySuffix + deviceType
						]
					}
					attributeObjectKeySuffix={attributeObjectKeySuffix}
				/>
			</div>
		</React.Fragment>
	);
}

ABlocksDimensions.propTypes = propTypes;
ABlocksDimensions.defaultProps = defaultProps;
