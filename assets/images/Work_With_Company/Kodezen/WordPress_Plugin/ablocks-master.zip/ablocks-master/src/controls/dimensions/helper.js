import { getUnit } from '@Utils/helper';

export const getAttributeDefaultValue = (isResponsive = false) => {
	if (isResponsive) {
		return {
			isLinked: true,
			isLinkedTablet: true,
			isLinkedMobile: true,
			common: '',
			commonTablet: '',
			commonMobile: '',
			top: '',
			right: '',
			bottom: '',
			left: '',
			topTablet: '',
			rightTablet: '',
			bottomTablet: '',
			leftTablet: '',
			topMobile: '',
			rightMobile: '',
			bottomMobile: '',
			leftMobile: '',
			unit: 'px',
			unitTablet: '',
			unitMobile: '',
		};
	}
	return {
		isLinked: true,
		common: '',
		top: '',
		right: '',
		bottom: '',
		left: '',
		unit: 'px',
	};
};

export const getAttribute = (attributeName, isResponsive = false) => {
	if (isResponsive) {
		return {
			[attributeName]: {
				type: 'object',
				default: getAttributeDefaultValue(isResponsive),
			},
		};
	}
	return {
		[attributeName]: {
			type: 'object',
			default: getAttributeDefaultValue(isResponsive),
		},
	};
};

export const getCSS = (attributeValue, property = '', device = '') => {
	const value = {
		...getAttributeDefaultValue(device ? true : false),
		...attributeValue,
	};

	const css = {};
	const unit = getUnit(
		{
			unit: value.unit,
			unitTablet: value.unitTablet,
			unitMobile: value.unitMobile,
		},
		device
	);

	if (value['isLinked' + device]) {
		if (value['common' + device] !== '') {
			css[property] = value['common' + device] + unit;
		}
	} else {
		if (value['top' + device] !== '') {
			css[`${property}-top`] = value['top' + device] + unit;
		}
		if (value['right' + device] !== '') {
			css[`${property}-right`] = value['right' + device] + unit;
		}
		if (value['bottom' + device] !== '') {
			css[`${property}-bottom`] = value['bottom' + device] + unit;
		}
		if (value['left' + device] !== '') {
			css[`${property}-left`] = value['left' + device] + unit;
		}
	}

	return css;
};
