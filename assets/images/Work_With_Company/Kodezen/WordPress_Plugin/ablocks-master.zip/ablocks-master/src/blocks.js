/**
 * Includes all blocks root files
 */

import './styles.scss';

import './blocks/academy-courses/index';
import './blocks/container/index';
import './blocks/heading/index';
import './blocks/button/index';
import './blocks/icon/index';
import './blocks/image/index';
import './blocks/star-ratings/index';
import './blocks/divider/index';
import './blocks/paragraph/index';
import './blocks/spacer/index';
import './blocks/video/index';
