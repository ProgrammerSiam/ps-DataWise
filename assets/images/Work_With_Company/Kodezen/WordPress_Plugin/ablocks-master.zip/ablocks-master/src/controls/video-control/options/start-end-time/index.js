import ABlocksTextControl from '@Controls/text';
import { __ } from '@wordpress/i18n';
import '../../options/styles.scss';

export default function ABlocksVideoStartAndEndTime(props) {
	const { attributeName, attributeValue, setAttributes, changeHandler } =
		props;
	return (
		<div className="ablocks-control--background__video--upload">
			<ABlocksTextControl
				label={__('Start', 'ablocks')}
				placeholder=""
				attributeValue={attributeValue?.videoStartTime}
				attributeName={attributeName}
				setAttributes={setAttributes}
				onChangeHandler={(controlValue) =>
					changeHandler(controlValue, 'videoStartTime')
				}
			/>
			<span className="ablocks-control--background__video--upload__description">
				{__('Specify a start time (in seconds)', 'ablocks')}
			</span>
			{attributeValue?.videoSource !== 'vimeo' && (
				<>
					<ABlocksTextControl
						label={__('End', 'ablocks')}
						placeholder=""
						attributeValue={attributeValue?.videoEndTime}
						attributeName={attributeName}
						setAttributes={setAttributes}
						onChangeHandler={(controlValue) =>
							changeHandler(controlValue, 'videoEndTime')
						}
					/>
					<span className="ablocks-control--background__video--upload__description">
						{__('Specify a end time (in seconds)', 'ablocks')}
					</span>
				</>
			)}
		</div>
	);
}
