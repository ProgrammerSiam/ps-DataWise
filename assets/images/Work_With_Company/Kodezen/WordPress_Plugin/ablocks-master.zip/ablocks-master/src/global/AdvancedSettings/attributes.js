import { getAttribute as getDimensionAttribute } from '@Controls/dimensions/helper';
import { getAttribute as getWidthAttribute } from '@Global/width/helper';
import { getAttribute as getPositionsAttribute } from '@Global/positions/helper';
import { getAttribute as getZIndexAttribute } from '@Global/z-index/helper';
import { getAttribute as getTransformAttribute } from '@Global/transform/helper';
import { getAttribute as getMaskAttribute } from '@Global/mask/helper';
import { getAttribute as getAnimationAttribute } from '@Controls/animation/helper';
import { getAttribute as getBackgroundAttribute } from '@Controls/background/helper';
import { getAttribute as getDeviceResponsiveAttribute } from '@Global/DeviceResponsive/helper';
import { getAttribute as getBorderAttribute } from '@Controls/border/helper';

const attributes = {
	...getDimensionAttribute('_margin', true),
	...getDimensionAttribute('_padding', true),
	...getWidthAttribute('_width', true),
	...getBorderAttribute('_border', true),
	...getPositionsAttribute('_position', true),
	...getBackgroundAttribute('_background', true),
	...getZIndexAttribute('_zIndex', true),
	...getTransformAttribute('_transform', true),
	...getMaskAttribute('_mask', true),
	...getAnimationAttribute('_animation', true),
	...getDeviceResponsiveAttribute(),
};
export default attributes;
