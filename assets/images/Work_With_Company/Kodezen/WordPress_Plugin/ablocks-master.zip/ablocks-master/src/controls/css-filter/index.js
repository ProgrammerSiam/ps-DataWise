import React, { useState, useRef } from 'react';
import { __ } from '@wordpress/i18n';
import AblocksPopover from '@Components/popover';
import ABlocksRangeControl from '@Controls/range';
import { objectUniqueCheck } from '@Utils/helper';
import { getAttributeDefaultValue } from './helper';
import Button from '@Components/Button';
import ControlLabel from '@Components/control-label';

export default function AblocksCSSFilter(props) {
	const {
		hover,
		attributeName,
		setAttributes,
		attributeValue,
		isResponsive,
		label,
	} = props;

	const [isVisible, setIsVisible] = useState(false);
	const anchorRef = useRef(null);

	let attributeObjectKeyForBlur = 'blur';
	let attributeObjectKeyForBrightness = 'brightness';
	let attributeObjectKeyForContrast = 'contrast';
	let attributeObjectKeyForSaturate = 'saturate';
	let attributeObjectKeyForHue = 'hue';

	if (hover) {
		attributeObjectKeyForBlur = 'blurH';
		attributeObjectKeyForBrightness = 'brightnessH';
		attributeObjectKeyForContrast = 'contrastH';
		attributeObjectKeyForSaturate = 'saturateH';
		attributeObjectKeyForHue = 'hueH';
	}

	const handleResetCSSFilter = () => {
		setAttributes({
			[attributeName]: objectUniqueCheck(getAttributeDefaultValue, {
				...attributeValue,
				...{
					[attributeObjectKeyForBlur]: '',
					[attributeObjectKeyForBrightness]: '',
					[attributeObjectKeyForContrast]: '',
					[attributeObjectKeyForSaturate]: '',
					[attributeObjectKeyForHue]: '',
				},
			}),
		});
	};

	const onChangeHandler = (controlValue, attributeObjectKey) => {
		if (isResponsive) {
			return setAttributes({
				[attributeName]: objectUniqueCheck(getAttributeDefaultValue(), {
					...attributeValue,
					[attributeObjectKey]: controlValue,
				}),
			});
		}
		return setAttributes({ [attributeName]: controlValue });
	};
	const togglePopoverVisibility = () => {
		setIsVisible(!isVisible);
	};

	return (
		<div className="ablocks-control ablocks-control-color-gradient-root-wrapper">
			{label && (
				<div className="ablocks-control-label">
					<ControlLabel label={label} isResponsive={false} />
				</div>
			)}
			<div className="ablocks-control-color-gradient">
				<div className="ablocks-component-popover">
					<div className="ablocks-component-popover__field">
						<div
							className="ablocks-component-popover-toggler-wrapper"
							ref={anchorRef}
						>
							<Button
								ref={anchorRef}
								onClick={togglePopoverVisibility}
								icon={
									<span className="ablocks-icon ablocks-icon--edit"></span>
								}
								preset="transparent"
								className={
									isVisible
										? 'ablocks-component-popover__field--active'
										: ''
								}
							/>
						</div>
					</div>
					{isVisible && (
						<AblocksPopover
							isShowPrimaryLabel={false}
							label={'CSS Filters'}
							isReset={true}
							handleReset={handleResetCSSFilter}
							isVisible={isVisible}
							toggleVisible={setIsVisible}
							anchorRef={anchorRef}
						>
							<React.Fragment>
								<ABlocksRangeControl
									{...props}
									min={0}
									max={5}
									step={0.01}
									hasUnit={false}
									isInline={false}
									label={__('Blur', 'ablocks')}
									onChangeHandler={onChangeHandler}
									attributeObjectKey={
										attributeObjectKeyForBlur
									}
								/>
								<ABlocksRangeControl
									{...props}
									min={0}
									max={200}
									step={1}
									hasUnit={false}
									isInline={false}
									onChangeHandler={onChangeHandler}
									label={__('Brightness', 'ablocks')}
									attributeObjectKey={
										attributeObjectKeyForBrightness
									}
								/>

								<ABlocksRangeControl
									{...props}
									min={0}
									max={200}
									step={1}
									hasUnit={false}
									isInline={false}
									label={__('Contrast', 'ablocks')}
									onChangeHandler={onChangeHandler}
									attributeObjectKey={
										attributeObjectKeyForContrast
									}
								/>

								<ABlocksRangeControl
									{...props}
									min={0}
									max={200}
									step={1}
									hasUnit={false}
									isInline={false}
									label={__('Saturate', 'ablocks')}
									onChangeHandler={onChangeHandler}
									attributeObjectKey={
										attributeObjectKeyForSaturate
									}
								/>

								<ABlocksRangeControl
									{...props}
									min={0}
									max={360}
									step={1}
									hasUnit={false}
									isInline={false}
									label={__('Hue', 'ablocks')}
									onChangeHandler={onChangeHandler}
									attributeObjectKey={
										attributeObjectKeyForHue
									}
								/>
							</React.Fragment>
						</AblocksPopover>
					)}
				</div>
			</div>
		</div>
	);
}
