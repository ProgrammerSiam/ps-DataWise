import React from 'react';
import { __ } from '@wordpress/i18n';
import RenderContainer from '@Components/block-container/render';
import { RichText } from '@wordpress/block-editor';
import metadata from './block.json';

const propTypes = {};

const defaultProps = {};

export default function Render(props) {
	const { attributes, setAttributes } = props;
	const { block_id, headingTag } = attributes;
	return (
		<React.Fragment>
			<RenderContainer
				blockId={block_id}
				name={metadata.name}
				attributes={attributes}
				typography={[
					{
						fontFamily: attributes.typography?.fontFamily,
						weight: attributes.typography?.weight,
					},
				]}
			>
				<RichText
					tagName={headingTag}
					value={attributes.heading}
					className="ablocks-heading-text"
					onChange={(heading) => setAttributes({ heading })}
					placeholder={__('Enter your title…', 'ablocks')}
				/>
			</RenderContainer>
		</React.Fragment>
	);
}

Render.propTypes = propTypes;
Render.defaultProps = defaultProps;
