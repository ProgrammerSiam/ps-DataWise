import { getCSS as getAlignmentCSS } from '@Controls/alignment/helper';
import { getCSS as getTypographyCSS } from '@Controls/typography/helper';

export const getWrapperCSS = (attributes, device = '') => {
	return {
		...getAlignmentCSS(attributes?.alignment, 'text-align', device),
	};
};
export const getRatingNumberCSS = (attributes, device = '') => {
	return {
		...getTypographyCSS(attributes?.ratingNumberTypography, device),
	};
};

export const getRatingCSS = (attributes, device = '') => {
	const ratingCSS = {};
	if (attributes?.size['value' + device]) {
		ratingCSS['font-size'] = attributes?.size['value' + device] + 'px';
	}
	return ratingCSS;
};

export const getRatingsCSS = (attributes, device = '') => {
	const ratingsCSS = {};
	if (attributes?.spacing['value' + device]) {
		ratingsCSS.gap = attributes?.spacing['value' + device] + 'px';
	}
	return ratingsCSS;
};
