import React, { useRef, useMemo, useEffect } from 'react';

import { useEventCallback } from '../hooks/useEventCallback';
import { clamp } from '../utils/clamp';

// Check if an event was triggered by touch
const isTouch = (event) => 'touches' in event;

// Finds a proper touch point by its identifier
const getTouchPoint = (touches, touchId) => {
	for (let i = 0; i < touches.length; i++) {
		if (touches[i].identifier === touchId) {
			return touches[i];
		}
	}
	return touches[0];
};

// Finds the proper window object to fix iframe embedding issues
const getParentWindow = (node) => {
	return (node && node.ownerDocument.defaultView) || window.self;
};

// Returns a relative position of the pointer inside the node's bounding box
const getRelativePosition = (node, event, touchId) => {
	const rect = node.getBoundingClientRect();

	// Get user's pointer position from `touches` array if it's a `TouchEvent`
	const pointer = isTouch(event)
		? getTouchPoint(event.touches, touchId)
		: event;

	return {
		left: clamp(
			(pointer.pageX - (rect.left + getParentWindow(node).pageXOffset)) /
				rect.width
		),
		top: clamp(
			(pointer.pageY - (rect.top + getParentWindow(node).pageYOffset)) /
				rect.height
		),
	};
};

// Browsers introduced an intervention, making touch events passive by default.
// This workaround removes `preventDefault` call from the touch handlers.
const preventDefaultMove = (event) => {
	!isTouch(event) && event.preventDefault(); // eslint-disable-line no-unused-expressions
};

// Prevent mobile browsers from handling mouse events (conflicting with touch ones).
// If we detected a touch interaction before, we prefer reacting to touch events only.
const isInvalid = (event, hasTouch) => {
	return hasTouch && !isTouch(event);
};

const InteractiveBase = ({ onMove, onKey, ...rest }) => {
	const container = useRef(null);
	const onMoveCallback = useEventCallback(onMove);
	const onKeyCallback = useEventCallback(onKey);
	const touchId = useRef(null);
	const hasTouch = useRef(false);

	const [handleMoveStart, handleKeyDown, toggleDocumentEvents] =
		useMemo(() => {
			const moveStartHandler = ({ nativeEvent }) => {
				const el = container.current;
				if (!el) {
					return;
				}

				// Prevent text selection
				preventDefaultMove(nativeEvent);

				if (isInvalid(nativeEvent, hasTouch.current) || !el) {
					return;
				}

				if (isTouch(nativeEvent)) {
					hasTouch.current = true;
					const changedTouches = nativeEvent.changedTouches || [];
					if (changedTouches.length) {
						touchId.current = changedTouches[0].identifier;
					}
				}

				el.focus();
				onMoveCallback(
					getRelativePosition(el, nativeEvent, touchId.current)
				);
				toggleDocumentEvents(true);
			};

			const handleMove = (event) => {
				// Prevent text selection
				preventDefaultMove(event);

				// If user moves the pointer outside of the window or iframe bounds and release it there,
				// `mouseup`/`touchend` won't be fired. In order to stop the picker from following the cursor
				// after the user has moved the mouse/finger back to the document, we check `event.buttons`
				// and `event.touches`. It allows us to detect that the user is just moving his pointer
				// without pressing it down
				const isDown = isTouch(event)
					? event.touches.length > 0
					: event.buttons > 0;

				if (isDown && container.current) {
					onMoveCallback(
						getRelativePosition(
							container.current,
							event,
							touchId.current
						)
					);
				} else {
					toggleDocumentEvents(false);
				}
			};

			const handleMoveEnd = () => toggleDocumentEvents(false);

			const keyDownHandler = (event) => {
				const keyCode = event.which || event.keyCode;

				// Ignore all keys except arrow ones
				if (keyCode < 37 || keyCode > 40) {
					return;
				}
				// Do not scroll page by arrow keys when document is focused on the element
				event.preventDefault();
				// Send relative offset to the parent component.
				// We use codes (37←, 38↑, 39→, 40↓) instead of keys ('ArrowRight', 'ArrowDown', etc)
				// to reduce the size of the library
				let LeftValue = 0;
				if (keyCode === 39) {
					LeftValue = 0.05;
				} else if (keyCode === 37) {
					LeftValue = -0.05;
				}

				let TopValue = 0;
				if (keyCode === 40) {
					TopValue = 0.05;
				} else if (keyCode === 38) {
					TopValue = -0.05;
				}

				onKeyCallback({
					left: LeftValue,
					top: TopValue,
				});
			};

			function toggleDocumentEventsHandler(state) {
				const touch = hasTouch.current;
				const el = container.current;
				const parentWindow = getParentWindow(el);

				// Add or remove additional pointer event listeners
				const toggleEvent = state
					? parentWindow.addEventListener
					: parentWindow.removeEventListener;
				toggleEvent(touch ? 'touchmove' : 'mousemove', handleMove);
				toggleEvent(touch ? 'touchend' : 'mouseup', handleMoveEnd);
			}

			return [
				moveStartHandler,
				keyDownHandler,
				toggleDocumentEventsHandler,
			];
		}, [onKeyCallback, onMoveCallback]);

	// Remove window event listeners before unmounting
	useEffect(() => toggleDocumentEvents, [toggleDocumentEvents]);

	return (
		<div
			{...rest}
			onTouchStart={handleMoveStart}
			onMouseDown={handleMoveStart}
			className="ablocks-control--color-pickerinteractive"
			ref={container}
			onKeyDown={handleKeyDown}
			tabIndex={0}
			role="slider"
		/>
	);
};

export const Interactive = React.memo(InteractiveBase);
