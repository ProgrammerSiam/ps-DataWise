const ABlocksCheckboxControl = (props) => {
	const {
		label,
		checkboxHandler,
		attributeName,
		deviceType,
		attributeValue,
	} = props;

	const handleControlCheckbox = (controlValue, attributeKey, device) => {
		checkboxHandler(controlValue, attributeKey, device);
	};
	return (
		<div
			style={{
				display: 'flex',
				justifyContent: 'space-between',
				marginBottom: '10px',
			}}
		>
			<label htmlFor="checkbox">{label}</label>
			<input
				type="checkbox"
				id="checkbox"
				checked={attributeValue[attributeName + deviceType]}
				onChange={(e) =>
					handleControlCheckbox(
						e.target.checked,
						attributeName,
						deviceType
					)
				}
			/>
		</div>
	);
};

export default ABlocksCheckboxControl;
