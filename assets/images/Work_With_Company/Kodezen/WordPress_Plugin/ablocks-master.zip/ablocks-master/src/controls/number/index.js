import React from 'react';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import ControlLabel from '@Components/control-label';
import { TextControl } from '@wordpress/components';
import './styles.scss';

const propTypes = {
	label: PropTypes.string,
	attributeName: PropTypes.string,
	attributeValue: PropTypes.any,
	onChangeHandler: PropTypes.func,
	placeholder: PropTypes.string,
	isInline: PropTypes.bool,
};

const defaultProps = {
	label: '',
	placeholder: '',
	attributeValue: '',
	isInline: true,
	attributeName: {},
};

export default function ABlocksNumberControl(props) {
	const {
		label,
		placeholder,
		attributeName,
		attributeValue,
		setAttributes,
		onChangeHandler,
		isInline,
	} = props;

	const changeHandler = (newValue) => {
		if (onChangeHandler) {
			onChangeHandler(newValue);
		} else {
			defaultChangeHandler(newValue);
		}
	};

	const defaultChangeHandler = (newValue) => {
		return setAttributes({
			[attributeName]: newValue,
		});
	};

	return (
		<React.Fragment>
			<div
				className={classnames(
					`ablocks-control ablocks-control--number`,
					{ 'ablocks-control--inline': isInline }
				)}
			>
				{label && <ControlLabel label={label} isResponsive={false} />}
				<TextControl
					className="ablocks-control--number"
					value={attributeValue}
					onChange={(controlValue) => {
						changeHandler(Number(controlValue));
					}}
					placeholder={placeholder}
					type="number"
				/>
			</div>
		</React.Fragment>
	);
}

ABlocksNumberControl.propTypes = propTypes;
ABlocksNumberControl.defaultProps = defaultProps;
