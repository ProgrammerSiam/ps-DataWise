import { __ } from '@wordpress/i18n';
import ABlocksSelectControl from '@Controls/select';
import { typeOptions } from '../helper';
import ABlocksRangeControl from '@Controls/range';
import ABlocksBackgroundColorPicker from './color';
import ABlocksBackgroundImage from './image';
import ABlocksBackgroundVideo from './video';
import './styles.scss';

const BackgroundAllOptions = (props) => {
	const {
		setAttributes,
		attributeName,
		attributeValue,
		hover,
		changeHandler,
	} = props;

	const commonProps = {
		...props,
	};

	return (
		<div
			className={`ablocks-control--backgroundOverlay-all-options-wrapper ablocks-control--backgroundOverlay-all-options-wrapper-${
				hover ? 'hover' : 'normal'
			}`}
		>
			<ABlocksSelectControl
				label={__('Background Type', 'ablocks')}
				options={typeOptions}
				isResponsive={false}
				attributeValue={attributeValue}
				attributeObjectKey={
					hover ? 'backgroundTypeH' : 'backgroundType'
				}
				attributeName={attributeName}
				setAttributes={setAttributes}
			/>
			{!hover && (
				<>
					{attributeValue?.backgroundType === 'color' && (
						<ABlocksBackgroundColorPicker {...commonProps} />
					)}
					{attributeValue?.backgroundType === 'image' && (
						<ABlocksBackgroundImage {...commonProps} />
					)}
					{attributeValue?.backgroundType === 'video' && (
						<ABlocksBackgroundVideo
							{...commonProps}
							changeHandler={changeHandler}
						/>
					)}
				</>
			)}

			{hover && (
				<>
					{/* Hover controls */}
					{attributeValue?.backgroundTypeH === 'color' && (
						<ABlocksBackgroundColorPicker
							{...commonProps}
							hover={hover}
						/>
					)}
					{attributeValue?.backgroundTypeH === 'image' && (
						<ABlocksBackgroundImage
							{...commonProps}
							hover={hover}
						/>
					)}

					<ABlocksRangeControl
						label={__('Transition Duration (ms)', 'ablocks')}
						min={0}
						max={5}
						step={0.01}
						hasUnit={false}
						isInline={false}
						isResponsive={false}
						attributeValue={attributeValue}
						attributeName={attributeName}
						setAttributes={setAttributes}
						onChangeHandler={changeHandler}
						attributeObjectKey="transitionDuration"
					/>
				</>
			)}
		</div>
	);
};

export default BackgroundAllOptions;
