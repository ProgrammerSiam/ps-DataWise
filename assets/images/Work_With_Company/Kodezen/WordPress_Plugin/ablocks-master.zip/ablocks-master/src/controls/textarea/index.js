import React from 'react';
import { TextareaControl } from '@wordpress/components';
import PropTypes from 'prop-types';
import classnames from 'classnames';
import ControlLabel from '@Components/control-label';
import './editor.scss';

const propTypes = {
	label: PropTypes.string,
	attributeName: PropTypes.string,
	attributeValue: PropTypes.any,
	onChangeHandler: PropTypes.func,
	placeholder: PropTypes.string,
	isInline: PropTypes.bool,
};

const defaultProps = {
	label: '',
	placeholder: 'Placeholder Text',
	isInline: false,
};

export default function ABlocksTextareaControl(props) {
	const {
		label,
		placeholder,
		attributeName,
		attributeValue,
		setAttributes,
		onChangeHandler,
		isInline,
	} = props;

	const changeHandler = (newValue) => {
		if (onChangeHandler) {
			onChangeHandler(newValue);
		} else {
			defaultChangeHandler(newValue);
		}
	};

	const defaultChangeHandler = (newValue) => {
		return setAttributes({
			[attributeName]: newValue,
		});
	};

	return (
		<React.Fragment>
			<div
				className={classnames(
					`ablocks-control ablocks-control--textarea`,
					{ 'ablocks-control--inline': isInline }
				)}
			>
				{label && <ControlLabel label={label} isResponsive={false} />}
				<TextareaControl
					className="ablocks-control__textarea"
					value={attributeValue}
					onChange={changeHandler}
					placeholder={placeholder}
				/>
			</div>
		</React.Fragment>
	);
}

ABlocksTextareaControl.propTypes = propTypes;
ABlocksTextareaControl.defaultProps = defaultProps;
