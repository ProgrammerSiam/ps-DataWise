import { getCSS as getAlignmentCSS } from '@Controls/alignment/helper';
import {
	getCSS as getBorderCSS,
	getHoverCSS as getBorderHoverCSS,
	getCSS as getCaptionBorderCSS,
	getHoverCSS as getCaptionBorderHoverCSS,
} from '@Controls/border/helper';
import { getCSS as getDimensionCSS } from '@Controls/dimensions/helper';
import { getCSS as getTypographyCSS } from '@Controls/typography/helper';

export const getWrapperCSS = (attributes, device = '') => {
	return {
		...getDimensionCSS(attributes?.padding, 'padding', device),
	};
};

export const getImageContainerCSS = (attributes, device = '') => {
	const { alignment } = attributes;
	const css = {};

	if (
		alignment['value' + device] !== '' &&
		alignment['value' + device] !== undefined
	) {
		css.display = 'flex';
		css['justify-content'] = alignment['value' + device];
	}

	return css;
};

export const getImageCSS = (attributes, device = '') => {
	const { aspectRatio, opacity, onHoverImg, transitionDuration } = attributes;
	const css = {};

	if (attributes['imgUrl' + device]) {
		css['max-width'] = '100%';
		// css['display'] = 'inline-block';
		css.transition = '0.3s ease';
		if (
			attributes?.widthHeightWidget['width' + device] !== '' &&
			attributes?.widthHeightWidget['width' + device] !== undefined
		) {
			css.width = `${attributes?.widthHeightWidget['width' + device]}px`;
		} else {
			css.width = `${attributes?.widthHeightWidget.imgNaturalWidth}px`;
		}
		if (attributes?.widthHeightWidget['customHeight' + device]) {
			css.height = `${
				attributes?.widthHeightWidget['height' + device]
			}px`;
		} else {
			css.height = '100%';
		}
		if (
			attributes?.objectFit['value' + device] !== '' &&
			attributes?.objectFit['value' + device] !== 'default'
		) {
			css['object-fit'] = attributes?.objectFit['value' + device];
		}
		if (aspectRatio !== 'original' && aspectRatio !== undefined) {
			css['aspect-ratio'] = aspectRatio;
		}
		if (opacity !== '' && opacity !== undefined) {
			css.opacity = opacity;
		}
		if (onHoverImg === 'slide') {
			css.transform = 'translate3d(-40px, 0, 0)';
			css.transition = `transform 0.3s`;
		}
		if (transitionDuration !== '' && transitionDuration !== undefined) {
			css.transition = `${transitionDuration}s`;
		}
	}

	return {
		...css,
		...getBorderCSS(attributes?.border, device),
	};
};

export const getImageHoverCSS = (attributes, device = '') => {
	const { onHoverImg, opacityH } = attributes;
	const css = {};
	if (attributes['imgUrl' + device]) {
		if (onHoverImg === 'zoomin') {
			css.transform = 'scale(1.1)';
			css.transition = `transform 0.3s`;
		} else if (onHoverImg === 'grayscale') {
			css.filter = 'grayscale(100%)';
			css.transition = `transform 0.3s`;
		} else if (onHoverImg === 'blur') {
			css.filter = 'blur(3px)';
			css.transition = `transform 0.3s`;
		} else if (onHoverImg === 'slide') {
			css.transform = 'translate3d(0, 0, 0)';
			css.transition = `transform 0.3s`;
		}
		if (opacityH !== '' && opacityH !== undefined) {
			css.opacity = opacityH;
		}
	}

	return {
		...css,
		...getBorderHoverCSS(attributes?.border, device),
	};
};

export const getImageCaptionCSS = (attributes, device = '') => {
	const {
		captionColor,
		captionBackground,
		captionPosition,
		captionPadding,
		captionAlignment,
		captionTypography,
		captionBorder,
	} = attributes;
	const css = {};

	if (captionColor !== '' && captionColor !== undefined) {
		css.color = captionColor;
	}
	if (captionBackground !== '' && captionBackground !== undefined) {
		css.background = captionBackground;
	}
	if (captionPosition !== '' && captionPosition === 'overlap') {
		css.width = '100%';
		css.position = 'absolute';
		css.bottom = 0;
		css.left = 0;
	}

	return {
		...css,
		...getDimensionCSS(captionPadding, 'padding', device),
		...getAlignmentCSS(captionAlignment, 'text-align', device),
		...getTypographyCSS(captionTypography, device),
		...getCaptionBorderCSS(captionBorder, device),
	};
};

export const getImageCaptionHoverCSS = (attributes, device = '') => {
	const { captionBorder } = attributes;

	return {
		...getCaptionBorderHoverCSS(captionBorder, device),
	};
};
