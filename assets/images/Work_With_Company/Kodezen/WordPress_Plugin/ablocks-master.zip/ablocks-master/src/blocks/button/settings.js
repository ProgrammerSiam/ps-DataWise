import React from 'react';
import { __ } from '@wordpress/i18n';
import ABlocksTextControl from '@Controls/text';
import { PanelBody } from '@wordpress/components';
import ABlocksTextShadow from '@Controls/textShadow';
import ABlocksTypography from '@Controls/typography';
import InspectorTabs from '@Components/inspector-tabs';
import ABlocksAlignmentControl from '@Controls/alignment';
import ABlocksCustomSelect from '@Components/custom-select';
import { InspectorControls } from '@wordpress/block-editor';
import ContentStyleTabs from '@Components/content-style-tabs';
import ABlocksColorControl from '@Controls/color-gradient-control';
import NormalHoverTabs from '@Components/normal-hover-tabs';
import Separator from '@Components/separator';
import ABlocksDimensions from '@Controls/dimensions';
import ABlocksBorderControl from '@Controls/border';
import ABlocksRangeControl from '@Controls/range';
import ABlocksIconUploader from '@Controls/icon-upload';
import ABlockLinkControl from '@Controls/link-control';
import ControlLabel from '@Components/control-label';
import './style.css';

const propTypes = {};
const defaultProps = {};

export default function Settings(props) {
	const { attributes, setAttributes } = props;
	const {
		buttonType,
		text,
		alignment,
		buttonSize,
		textShadow,
		typography,
		textColor,
		textColorH,
		background,
		backgroundH,
		padding,
		iconPosition,
		link,
	} = attributes;

	return (
		<React.Fragment>
			<InspectorControls>
				<InspectorTabs
					attributes={attributes}
					setAttributes={setAttributes}
				>
					<PanelBody
						title={__('Button', 'ablocks')}
						initialOpen={true}
					>
						<ContentStyleTabs
							content={
								<>
									<ABlocksCustomSelect
										label={__('Type', 'ablocks')}
										isResponsive={false}
										options={[
											{
												label: 'Default',
												value: '#ddd',
											},
											{
												label: 'Danger',
												value: '#dc3545',
											},
											{ label: 'Info', value: '#0dcaf0' },
											{
												label: 'Success',
												value: '#198754',
											},
											{
												label: 'Warning',
												value: '#fd7e14',
											},
											{
												label: 'Primary',
												value: '#0d6efd',
											},
										]}
										attributeValue={buttonType || 'Primary'}
										attributeObjectKey="buttonType"
										changeHandler={(
											controlValue,
											attributeObjectKey
										) => {
											return setAttributes({
												[attributeObjectKey]:
													controlValue,
											});
										}}
									/>

									<ABlocksTextControl
										label={__('Text', 'ablocks')}
										attributeName="text"
										attributeValue={text}
										setAttributes={setAttributes}
										isInline={false}
									/>
									<ABlocksAlignmentControl
										label={__('Alignment', 'ablocks')}
										attributeName="alignment"
										attributeValue={alignment}
										setAttributes={setAttributes}
										options={[
											{
												label: 'left',
												value: 'left',
												icon: 'left',
											},
											{
												label: 'center',
												value: 'center',
												icon: 'center',
											},
											{
												label: 'right',
												value: 'right',
												icon: 'right',
											},
										]}
										isInline={false}
									/>

									<ABlocksCustomSelect
										label={__('Sizes', 'ablocks')}
										isResponsive={false}
										options={[
											{
												label: 'Extra small',
												value: 'xs',
											},
											{ label: 'Small', value: 'sm' },
											{
												label: 'Medium',
												value: 'md',
											},
											{ label: 'Large', value: 'lg' },
											{
												label: 'Extra large',
												value: 'xl',
											},
										]}
										attributeValue={buttonSize || 'sm'}
										attributeObjectKey="buttonSize"
										changeHandler={(
											controlValue,
											attributeObjectKey
										) => {
											return setAttributes({
												[attributeObjectKey]:
													controlValue,
											});
										}}
									/>
									<ABlockLinkControl
										label={__('Link', 'ablocks')}
										attributeName="link"
										attributeValue={link}
										setAttributes={setAttributes}
									/>
								</>
							}
							style={
								<>
									<ABlocksTypography
										label={__('Typography', 'ablocks')}
										attributeName="typography"
										attributeValue={typography}
										setAttributes={setAttributes}
										isResponsive={true}
									/>
									<ABlocksTextShadow
										label={__('Text Shadow', 'ablocks')}
										attributeName="textShadow"
										attributeValue={textShadow}
										setAttributes={setAttributes}
										isResponsive={false}
									/>
									<Separator margin="30" />
									<ControlLabel
										label="Color"
										isResponsive={false}
									/>
									<NormalHoverTabs
										normal={
											<>
												<ABlocksColorControl
													label={__(
														'Color',
														'ablocks'
													)}
													attributeName="textColor"
													attributeValue={
														textColor || '#000000'
													}
													setAttributes={
														setAttributes
													}
												/>
												<ABlocksColorControl
													label={__(
														'Background',
														'ablocks'
													)}
													isGradient={true}
													attributeName="background"
													attributeValue={
														background || '#ddd'
													}
													setAttributes={
														setAttributes
													}
												/>
											</>
										}
										hover={
											<>
												<ABlocksColorControl
													label={__(
														'Color',
														'ablocks'
													)}
													attributeName="textColorH"
													attributeValue={textColorH}
													setAttributes={
														setAttributes
													}
												/>
												<ABlocksColorControl
													label={__(
														'Background',
														'ablocks'
													)}
													isGradient={true}
													attributeName="backgroundH"
													attributeValue={backgroundH}
													setAttributes={
														setAttributes
													}
												/>
											</>
										}
									/>

									<Separator margin="30" />
									<ControlLabel
										label="Border"
										isResponsive={false}
									/>
									<ABlocksBorderControl
										attributeName="border"
										attributeValue={attributes?.border}
										setAttributes={setAttributes}
									/>
									<Separator />
									<ABlocksDimensions
										label={__('Padding', 'ablocks')}
										isResponsive={true}
										attributeName="padding"
										attributeValue={padding}
										setAttributes={setAttributes}
									/>
								</>
							}
						/>
					</PanelBody>

					<PanelBody
						title={__('Icon', 'ablocks')}
						initialOpen={false}
					>
						<ABlocksIconUploader
							label={__('Icon', 'ablocks')}
							attributes={attributes}
							setAttributes={setAttributes}
						/>
						<ABlocksCustomSelect
							label={__('Icon position', 'ablocks')}
							isResponsive={false}
							options={[
								{
									label: 'Before',
									value: 'left',
								},
								{
									label: 'After',
									value: 'right',
								},
							]}
							attributeValue={iconPosition || 'left'}
							attributeObjectKey="iconPosition"
							changeHandler={(
								controlValue,
								attributeObjectKey
							) => {
								return setAttributes({
									[attributeObjectKey]: controlValue,
								});
							}}
						/>

						<ABlocksRangeControl
							label={__('Icon spacing', 'ablocks')}
							min={0}
							max={100}
							hasUnit={false}
							isInline={false}
							isResponsive={false}
							attributeName={'iconSpace'}
							attributeValue={attributes}
							setAttributes={setAttributes}
							attributeObjectKey="iconSpace"
						/>
						{/* Icon rotate*/}
						<ABlocksRangeControl
							label={__('Icon Rotate', 'ablocks')}
							min={0}
							max={300}
							hasUnit={false}
							isInline={false}
							isResponsive={false}
							attributeName={'rotation'}
							attributeValue={attributes}
							setAttributes={setAttributes}
							attributeObjectKey="rotation"
						/>
					</PanelBody>
				</InspectorTabs>
			</InspectorControls>
		</React.Fragment>
	);
}

Settings.propTypes = propTypes;
Settings.defaultProps = defaultProps;
