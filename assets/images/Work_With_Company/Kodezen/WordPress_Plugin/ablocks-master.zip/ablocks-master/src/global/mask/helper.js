import { plugin_root_url } from '@Utils/helper';

export const getAttributeDefaultValue = (isResponsive = false) => {
	if (isResponsive) {
		return {
			mask: false,
			maskTablet: false,
			maskMobile: false,
			maskShape: 'circle',
			customMaskShape: '',
			maskSize: '',
			maskSizeTablet: '',
			maskSizeMobile: '',
			maskPosition: '',
			maskPositionTablet: '',
			maskPositionMobile: '',
			maskRepeat: '',
			maskRepeatTablet: '',
			maskRepeatMobile: '',
			scaleUnit: 'px',
			scaleUnitTablet: 'px',
			scaleUnitMobile: 'px',
			scale: '0',
			scaleTablet: '0',
			scaleMobile: '0',
			xPositionUnit: 'px',
			xPositionUnitTablet: 'px',
			xPositionUnitMobile: 'px',
			xPosition: '',
			xPositionTablet: '0',
			xPositionMobile: '0',
			yPositionUnit: '0',
			yPositionUnitTablet: 'px',
			yPositionUnitMobile: 'px',
			yPosition: '0',
			yPositionTablet: '0',
			yPositionMobile: '0',
		};
	}
	return {
		mask: false,
		maskShape: 'circle',
		maskSize: '',
		maskPosition: '',
		maskRepeat: '',
		scaleUnit: 'px',
		scale: '0',
		xPosition: '',
		xPositionUnit: 'px',
		yPosition: '',
		yPositionUnit: 'px',
	};
};

export const getAttribute = (attributeName, isResponsive = false) => {
	if (isResponsive) {
		return {
			[attributeName]: {
				type: 'object',
				default: getAttributeDefaultValue(isResponsive),
			},
		};
	}
	return {
		[attributeName]: {
			type: 'object',
			default: getAttributeDefaultValue(isResponsive),
		},
	};
};

export const getCSS = (attributeValue, device = '') => {
	const value = {
		...getAttributeDefaultValue(device ? true : false),
		...attributeValue,
	};
	const css = {};
	/**
	  css property
	 * mask-image
	 * mask-size
	 * mask-position
	 * mask-repeat
	 */

	if (value.mask) {
		if (value) {
			if (value.maskShape === 'custom') {
				css[`mask-image`] = `url(${value.customMaskShape})`;
			} else {
				css[
					`mask-image`
				] = `url(${plugin_root_url}/assets/images/mask-shapes/${value.maskShape}.svg)`;
			}
		}
		css[`mask-size`] = 'contain';
		css[`mask-position`] = 'center center';
		css[`mask-repeat`] = 'no-repeat';
	}

	if (value['maskSize' + device] && value['maskSize' + device] !== 'custom') {
		css[`mask-size`] = value['maskSize' + device];
	}

	if (
		value['maskSize' + device] &&
		value['maskSize' + device] === 'custom' &&
		value['scaleUnit' + device]
	) {
		css[`mask-size`] = `${value['scale' + device]}${
			value['scaleUnit' + device]
		}`;
	}

	if (value['maskPosition' + device]) {
		css[`mask-position`] = `${value['maskPosition' + device]}`;
	}

	if (
		value['maskPosition' + device] === 'custom' &&
		value['xPosition' + device] &&
		value['xPositionUnit' + device]
	) {
		css[`-webkit-mask-position-x`] = `${value['xPosition' + device]}${
			value['xPositionUnit' + device]
		}`;
		css[`-webkit-mask-position-y`] = `${
			value['yPosition' + device] ? value['yPosition' + device] : 0
		}${value['yPositionUnit' + device]}`;
	}

	if (
		value['maskPosition' + device] === 'custom' &&
		value['yPosition' + device] &&
		value['yPositionUnit' + device]
	) {
		css[`-webkit-mask-position-y`] = `${value['yPosition' + device]}${
			value['yPositionUnit' + device]
		}`;
	}

	if (value['maskRepeat' + device]) {
		css[`mask-repeat`] = `${value['maskRepeat' + device]}`;
	}

	return css;
};
