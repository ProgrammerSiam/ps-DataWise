import React, { useRef, useState } from 'react';
import PropTypes from 'prop-types';
import { __ } from '@wordpress/i18n';
import AblocksPopover from '@Components/popover';
import { objectUniqueCheck } from '@Utils/helper';
import ABlocksRangeControl from '@Controls/range';
import { getAttributeDefaultValue } from './helper';
import ControlLabel from '@Components/control-label';
import ABlocksColorControl from '@Controls/color-gradient-control';
import Button from '@Components/Button';
import './styles.scss';

const propTypes = {
	isResponsive: PropTypes.bool,
	label: PropTypes.string,
	attributeName: PropTypes.string,
	attributeValue: PropTypes.any,
	onChangeHandler: PropTypes.func,
};

const defaultProps = {
	label: '',
};
const ABlocksTextShadow = (props) => {
	const {
		attributeName,
		attributeValue,
		onChangeHandler,
		setAttributes,
		isResponsive,
		label,
	} = props;
	const [isVisible, setIsVisible] = useState(false);
	const anchorRef = useRef(null);
	const changeHandler = (controlValue, deviceMode) => {
		if (onChangeHandler) {
			onChangeHandler(controlValue, deviceMode);
		} else {
			setAttributes({
				[attributeName]: objectUniqueCheck(getAttributeDefaultValue(), {
					...attributeValue,
					[deviceMode]: controlValue,
				}),
			});
		}
	};

	const resetHandler = (resetObj = {}) => {
		setAttributes({
			[attributeName]: objectUniqueCheck(getAttributeDefaultValue, {
				...attributeValue,
				...resetObj,
			}),
		});
	};

	const handleResetTextShadow = () => {
		resetHandler({
			color: '',
			blur: '',
			horizontal: '',
			vertical: '',
		});
	};

	const togglePopoverVisibility = () => {
		setIsVisible(!isVisible);
	};

	return (
		<div className="ablocks-control ablocks-control-color-gradient-root-wrapper">
			{label && (
				<div className="ablocks-control-label">
					<ControlLabel label={label} isResponsive={false} />
				</div>
			)}
			<div className="ablocks-control-color-gradient">
				<div className="ablocks-component-popover">
					<div className="ablocks-component-popover__field">
						<div
							className="ablocks-component-popover-toggler-wrapper"
							ref={anchorRef}
						>
							<Button
								ref={anchorRef}
								onClick={togglePopoverVisibility}
								icon={
									<span className="ablocks-icon ablocks-icon--edit"></span>
								}
								preset="transparent"
								className={
									isVisible
										? 'ablocks-component-popover__field--active'
										: ''
								}
							/>
						</div>
					</div>
					{isVisible && (
						<AblocksPopover
							label={__('Text Shadow', 'ablocks')}
							isShowPrimaryLabel={false}
							isReset={true}
							handleReset={handleResetTextShadow}
							isVisible={isVisible}
							toggleVisible={setIsVisible}
							anchorRef={anchorRef}
						>
							<div className="ablocks-popover-content">
								<ABlocksColorControl
									label={__('Color', 'ablocks')}
									attributeName="color"
									attributeValue={attributeValue.color}
									onChangeHandler={(
										attributeObjectKey,
										controlValue
									) => {
										changeHandler(
											controlValue,
											attributeObjectKey
										);
									}}
								/>
								<div className="ablocks-popover-content--blur">
									<ABlocksRangeControl
										isResponsive={isResponsive}
										attributeName={attributeName}
										attributeValue={attributeValue}
										attributeObjectKey="blur"
										onChangeHandler={changeHandler}
										label={__('Blur Shadow', 'ablocks')}
										min={0}
										max={10}
										isInline={false}
									/>
								</div>
								<div className="ablocks-popover-content--horizontal">
									<ABlocksRangeControl
										isResponsive={isResponsive}
										attributeName={attributeName}
										attributeValue={attributeValue}
										attributeObjectKey="horizontal"
										onChangeHandler={changeHandler}
										label={__(
											'Horizontal Shadow',
											'ablocks'
										)}
										min={-100}
										max={100}
										isInline={false}
									/>
								</div>
								<div className="ablocks-popover-content--vertical">
									<ABlocksRangeControl
										isResponsive={isResponsive}
										attributeName={attributeName}
										attributeValue={attributeValue}
										attributeObjectKey="vertical"
										onChangeHandler={changeHandler}
										label={__('Vertical shadow', 'ablocks')}
										min={-100}
										max={100}
										isInline={false}
									/>
								</div>
							</div>
						</AblocksPopover>
					)}
				</div>
			</div>
		</div>
	);
};

ABlocksTextShadow.propTypes = propTypes;
ABlocksTextShadow.defaultProps = defaultProps;
export default ABlocksTextShadow;
