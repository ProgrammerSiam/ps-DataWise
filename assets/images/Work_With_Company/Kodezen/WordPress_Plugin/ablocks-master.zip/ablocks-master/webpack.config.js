const defaultConfig = require('@wordpress/scripts/config/webpack.config');
const CopyPlugin = require('copy-webpack-plugin');
const path = require('path');
const { readFileSync } = require('fs');
const { dirname, extname, join, sep } = require('path');
const { sync: glob } = require('fast-glob');
const { getWordPressSrcDirectory } = require('@wordpress/scripts/utils');
const { fromProjectRoot } = require('@wordpress/scripts/utils/file');

async function getWebpackConfig() {
	const chalk = (await import('chalk')).default;

	function getWebpackEntryPoints() {
		const blockMetadataFiles = glob('**/block.json', {
			absolute: true,
			cwd: fromProjectRoot(getWordPressSrcDirectory()),
		});

		if (blockMetadataFiles.length > 0) {
			const srcDirectory = fromProjectRoot(
				getWordPressSrcDirectory() + sep
			);
			const entryPoints = blockMetadataFiles.reduce(
				(accumulator, blockMetadataFile) => {
					try {
						const { editorScript, script, viewScript } = JSON.parse(
							readFileSync(blockMetadataFile)
						);
						[editorScript, script, viewScript]
							.flat()
							.filter(
								(value) => value && value.startsWith('file:')
							)
							.forEach((value) => {
								const filepath = join(
									dirname(blockMetadataFile),
									value.replace('file:', '')
								);

								if (!filepath.startsWith(srcDirectory)) {
									// eslint-disable-next-line
									console.log(
										chalk.yellow(
											`Skipping "${value.replace(
												'file:',
												''
											)}" listed in "${blockMetadataFile.replace(
												fromProjectRoot(sep),
												''
											)}". File is located outside of the "${getWordPressSrcDirectory()}" directory.`
										)
									);
									return;
								}
								const entryName = filepath
									.replace(extname(filepath), '')
									.replace(srcDirectory, '')
									.replace(/\\/g, '/');

								const [entryFilepath] = glob(
									`${entryName}.[jt]s?(x)`,
									{
										absolute: true,
										cwd: fromProjectRoot(
											getWordPressSrcDirectory()
										),
									}
								);

								if (!entryFilepath) {
									// eslint-disable-next-line
									console.log(
										chalk.yellow(
											`Skipping "${value.replace(
												'file:',
												''
											)}" listed in "${blockMetadataFile.replace(
												fromProjectRoot(sep),
												''
											)}". File does not exist in the "${getWordPressSrcDirectory()}" directory.`
										)
									);
									return;
								}
								accumulator[entryName] = entryFilepath;
							});
						return accumulator;
					} catch (error) {
						// eslint-disable-next-line
						console.log(
							chalk.yellow(
								`Skipping "${blockMetadataFile.replace(
									fromProjectRoot(sep),
									''
								)}" due to malformed JSON.`
							)
						);
						return accumulator;
					}
				},
				{}
			);

			if (Object.keys(entryPoints).length > 0) {
				return {
					...entryPoints,
					blocks: path.resolve(__dirname, 'src/blocks.js'),
				};
			}
		}
		return {
			blocks: path.resolve(__dirname, 'src/blocks.js'),
		};
	}

	const blockLists = [
		'heading',
		'academy-courses',
		'button',
		'icon',
		'spacer',
		'paragraph',
		'divider',
		'star-ratings',
		'image',
		'video',
		'container',
	];

	const config = {
		...defaultConfig,
		entry: getWebpackEntryPoints(),
		output: {
			...defaultConfig.output,
			path: path.resolve(__dirname, 'assets/build'),
		},
		resolve: {
			alias: {
				...defaultConfig.resolve.alias,
				'@Components': path.resolve(__dirname, 'src/components/'),
				'@Controls': path.resolve(__dirname, 'src/controls/'),
				'@Utils': path.resolve(__dirname, 'src/utils/'),
				'@Global': path.resolve(__dirname, 'src/global/'),
			},
		},
		plugins: [
			...defaultConfig.plugins,
			new CopyPlugin({
				patterns: blockLists.map((blockName) => ({
					from: path.resolve(
						__dirname,
						`src/blocks/${blockName}/style.css`
					),
					to: path.resolve(
						__dirname,
						'assets/build/blocks',
						blockName
					),
				})),
			}),
		],
	};

	return config;
}

module.exports = getWebpackConfig();
