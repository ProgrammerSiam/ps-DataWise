=== aBlocks – WordPress Gutenberg Blocks ===
Contributors: kodezen, academylms, tusharimran
Tags: blocks, block, gutenberg
Requires at least: 5.4
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0-beta2
License: GPLv3
License URI: https://opensource.org/licenses/GPL-3.0

aBlocks is the customizable WordPress plugin for creating stunning and functional websites with the Gutenberg editor. Featuring a variety of customizable blocks, aBlocks allows you to design pages with ease and precision. aBlocks suitable for all types of blogs, portfolios, and business sites.

== Description ==

== aBlocks – Customizable Gutenberg Blocks ==

aBlocks is your ultimate solution for creating stunning and functional websites using the WordPress Gutenberg editor. With a selection of highly customizable blocks, aBlocks allows you to design pages with ease and precision. Whether you’re a beginner or an experienced developer, aBlocks provides the flexibility and features you need to build beautiful and dynamic websites.

== Overview of aBlocks In actions! 👇 ==

https://youtu.be/Yu0HH5S-8RY

== Quick Links: ===
- **Official Website:** [aBlocks](https://ablocks.pro)
- **Support:** Need help? [Visit our support forum.](https://ablocks.pro/support)

=== Customizable Gutenberg Blocks ===
aBlocks includes a set of essential blocks that can be customized to fit your unique design needs. Each block is designed to be flexible and easy to use, making your page-building experience smoother and more efficient.

=== Available Blocks ===
aBlocks provides a versatile set of Gutenberg blocks that are highly customizable, helping you create stunning and functional web pages with ease. Here's a detailed look at each block and its features:

**🔥Container Block:** The Container block is the foundation for creating complex layouts. It allows you to group multiple blocks and apply common styling and layout options.

- **Customization Options:** Background color, gradient, image, padding, margin, border, and shadow.
- **Responsive Controls:** Set different styles for desktop, tablet, and mobile views.
- **Flexibility:** Supports nested containers for advanced layout structures.

**🔥Heading Block:** Make your headings stand out with the customizable Heading block. This block gives you full control over the appearance of your headings, ensuring they fit your site’s design perfectly.

- **Typography:** Choose from a variety of fonts, sizes, and styles.
- **Color Settings:** Customize text color and background color.
- **Text Alignment:** Align your headings to the left, center, or right.

**🔥Button Block:** Create eye-catching call-to-action buttons with the Button block. Perfect for driving user interactions and guiding visitors through your site.

- **Styling Options:** Customize button color, text color, border radius, and shadow.
- **Size and Shape:** Adjust the size and shape to match your design needs.
- **Hover Effects:** Add hover effects to make your buttons more interactive.

**🔥Icon Block:** Enhance your content with visually appealing icons. The Icon block allows you to select from a vast library of icons and customize their appearance.

- **Icon Libraries:** Access to Font Awesome, Material Icons, and more.
- **Customization:** Change icon size, color, and background.
- **Positioning:** Easily position icons within your content or alongside text.

**🔥Image Block:** Insert and style images effortlessly with the Image block. This block provides comprehensive options for showcasing images in the best possible way.

- **Image Styles:** Apply borders, shadows, and custom shapes.
- **Image Effects:** Add hover effects and animations.
- **Captions and Alt Text:** Easily add and style captions and alt text for SEO benefits.

**🔥Star Ratings Block:** Showcase reviews and feedback with the Star Ratings block. This block is perfect for displaying product ratings, testimonials, or any star-based scoring system.

- **Customization:** Set the number of stars and adjust the color for filled and unfilled stars.
- **Interactivity:** Allow users to submit their own ratings.
- **Display Options:** Position star ratings above or below content.

**🔥Divider Block:** Separate content sections with stylish dividers. The Divider block provides a variety of styles to create clear and visually appealing separations.

- **Style Options:** Solid, dashed, dotted lines, and custom SVG dividers.
- **Thickness and Length:** Adjust the thickness and length to suit your design.
- **Color:** Customize the color to match your site’s theme.

**🔥Paragraph Block:** Craft beautifully styled paragraphs with full control over typography and layout. The Paragraph block makes text content look professional and readable.

- **Typography Controls:** Font family, size, weight, line height, and letter spacing.
- **Text Color:** Customize text and background color.
- **Spacing:** Adjust margins and padding for precise layout control.

**🔥Space Block:** Easily add spacing between elements with the Space block. This block helps you fine-tune the layout by adding custom-sized spacers.

- **Height Control:** Set the height of the spacer to create the desired amount of space.
- **Responsive Settings:** Adjust spacing for different screen sizes to ensure a consistent layout.

**🔥Video Block:** Embed responsive videos seamlessly with the Video block. This block supports various video sources and provides customization options to enhance the viewing experience.

- **Source Options:** Embed videos from YouTube, Vimeo, or self-hosted sources.
- **Playback Controls:** Enable autoplay, loop, and mute options.
- **Styling:** Add borders, shadows, and custom aspect ratios.

**🔥Academy Courses Block:** Showcase your course content with the Academy Courses block. Perfect for online educators and institutions, this block highlights your courses effectively.

- **Course Layouts:** Display courses in grid or list layouts.
- **Details Display:** Include course title, description, instructor, and duration.
- **Enrollment Buttons**: Add call-to-action buttons for course enrollment.

Each block in aBlocks is designed to be user-friendly and highly customizable, giving you the tools to create professional and engaging websites with the Gutenberg editor. Start using aBlocks today and unlock the full potential of your WordPress site!

=== Features ===
- **Fully Customizable:** Each block comes with a range of customization options, allowing you to create unique designs that align with your brand.
- **Responsive Design:** Ensure your site looks great on all devices with responsive settings for each block.
- **User-Friendly Interface:** aBlocks is designed to be intuitive and easy to use, making it accessible for users of all skill levels.
- **Optimized Performance:** aBlocks is lightweight and optimized for performance, ensuring fast load times and smooth operation.

=== More Blocks Coming Soon ===
We’re constantly working on adding more blocks to aBlocks to enhance your Gutenberg experience. Stay tuned for updates and new features!

=== Why Choose aBlocks? ===
- **Flexibility:** aBlocks offers a versatile set of blocks that can be tailored to fit any website design.
- **Ease of Use:** With an intuitive interface, you can start building beautiful pages without any coding knowledge.
- **Continuous Improvement:** We are committed to regularly updating aBlocks with new features and improvements based on user feedback.

=== Get Started with aBlocks Today! ===
Ready to take your Gutenberg experience to the next level? Install aBlocks and start building stunning pages with ease. Explore the demo, read the documentation, and join our support forum if you need any assistance.

## 🔥 WHAT’S NEXT
If you like aBlocks, then consider checking out our other WordPress Plugins for FREE:

🔝 [Academy LMS](https://wordpress.org/plugins/academy/) –  eLearning and online course solution for WordPress
🔝 [WP Map Block](https://wordpress.org/plugins/wp-map-block/) –  Gutenberg Map Block for Google Map and OpenStreet Map



== Frequently Asked Questions ==

= Can I Use aBlocks with any WordPress Themes? = 

Yes, aBlocks works with any WordPress theme. It integrates with the Gutenberg editor, so you can use its customizable blocks no matter which theme you have. For the best results, make sure your theme supports the latest version of Gutenberg.

= Is aBlocks suitable for beginners with no coding experience? = 

Absolutely! aBlocks has an easy-to-use interface, making it accessible for all skill levels. Whether you're new to website building or a seasoned developer, you can create beautiful, functional pages without any coding knowledge. The controls are intuitive, and customization options are comprehensive.
 
= Can I Customize the styling of individual blocks in aBlocks? = 

Yes, each block in aBlocks offers extensive customization options. You can adjust background colors, gradients, images, padding, margins, borders, shadows, and more. There are also responsive settings to apply different styles for desktop, tablet, and mobile views, maintaining a consistent look across devices.

== Changelog ==

= 1.0-beta2 - 04/06/2024 =
* Added - SVG icon insert
* Added - Button block link control
* Improved - All Blocks Markup
* Improved - Revamped icon settings
* Improved - Make all blocks left align
* Fixed - Image Block attribute improvements
* Fixed - Icon Rotation issue
* Fixed - Transform CSS generate issue
* Fixed - Mask CSS generate issue
* Fixed - Reorder Wrapper and Container CSS
* Fixed - Removed undefined and true/false class
* Fixed - Lot of Bugs

= 1.0-beta1 - 29/05/2024 =

* Initial beta release

== Upgrade Notice ==
Please do not use this plugin on the production site; it is for beta testing purposes only.