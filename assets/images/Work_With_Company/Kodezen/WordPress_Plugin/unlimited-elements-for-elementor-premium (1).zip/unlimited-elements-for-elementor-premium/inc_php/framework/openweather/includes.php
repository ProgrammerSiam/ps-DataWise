<?php

require_once __DIR__ . "/model.class.php";
require_once __DIR__ . "/client.class.php";

require_once __DIR__ . "/forecast/forecast_has_inline_temperature.class.php";
require_once __DIR__ . "/forecast/forecast_has_sun_time.class.php";
require_once __DIR__ . "/forecast/forecast_abstract.class.php";
require_once __DIR__ . "/forecast/forecast_current.class.php";
require_once __DIR__ . "/forecast/forecast_daily.class.php";
require_once __DIR__ . "/forecast/forecast_hourly.class.php";
