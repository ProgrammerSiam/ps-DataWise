<?php

$pathBase = dirname(__FILE__) . "/";

require_once $pathBase . 'instagram_api_official.class.php';
require_once $pathBase . 'obj_items.class.php';
require_once $pathBase . 'obj_item.class.php';
require_once $pathBase . 'obj_user.class.php';
require_once $pathBase . 'obj_comments.class.php';
require_once $pathBase . 'obj_comment.class.php';
require_once $pathBase . 'helper.class.php';
