=== Happy Addons Pro ===
Plugin Name: Happy Addons Pro
Version: 2.12.2
Author: Leevio
Author URI: https://happyaddons.com/
Contributors: thehappymonster, happyaddons, hasinhayder, mosaddek73, tareq1988, sourav926, wedevs, iqbalrony, mrokon, obiplabon
Tags: Elementor Page Builder, Elementor Addons, Widgets, Editor, Web Page Builder
Requires at least: 4.7
Tested up to: 6.6
Stable tag: 2.12.2
Requires PHP: 5.6
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html
